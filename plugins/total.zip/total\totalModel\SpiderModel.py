# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyleft (c) 2015-2099 宝塔软件(http://bt.cn) All lefts reserved.
# +-------------------------------------------------------------------
# | Author: wzz
# | email : help@bt.cn
# +-------------------------------------------------------------------
# +-------------------------------------------------------------------
# | 堡塔网站统计模型 - 蜘蛛分析模型
# +-------------------------------------------------------------------
import contextlib
import os
import sys
import time
from typing import List, Dict, Any, Union

panelPath = '/www/server/panel'
sys.path.insert(0, panelPath)
os.chdir(panelPath)
if not panelPath + "/class/" in sys.path:
    sys.path.insert(0, panelPath + "/class/")

import public
from totalModel.BaseModel import BaseModel
from itertools import groupby
from BTPanel import cache


class SpiderModel(BaseModel):

    def __init__(self):
        super().__init__()
        self.total_db_name = "spider_total.db"
        self.s_param_obj = None

    def get_spider_overview(self, get):
        """
        获取蜘蛛概览数据
        @param get:
        @return:
        """
        sum_data = {
            "today": {"sum": 0, "overview_data": {}},
            "yesterday": {"sum": 0, "overview_data": {}}
        }
        query_time = ["today", "yesterday"]
        for q_time in query_time:
            get.query_time = q_time
            sum_data[q_time]["overview_data"] = self._get_spider_overview(get)
            sum_data[q_time]["sum"] = sum(sum_data[q_time]["overview_data"].values())

        public.set_module_logs("totalModel", "get_spider_overview")
        return sum_data

    def _get_spider_overview(self, get):
        """
        获取蜘蛛概览数据
        @param get:
        @return:
        """
        self.s_param_obj = self.construction_param(get)

        sum_data_dict = {}
        if self.s_param_obj.spider_type == "all":
            query_fields = self.spider_fields
        else:
            query_fields = self.s_param_obj.spider_type.split(",")

        try:
            ts = self.init_ts(self.s_param_obj.site_name, self.total_db_name)
        except RuntimeError as e:
            print(e)
            return sum_data_dict

        if not ts:
            for field in query_fields:
                sum_data_dict[field] = 0
            return sum_data_dict

        # 构造查询字段
        self.s_param_obj.start_date, self.s_param_obj.end_date = self.get_query_date(
            self.s_param_obj.query_time
        )

        spider_total_fields = ""
        for field in query_fields:
            spider_total_fields += ",sum({}) as {}".format(field, field)
        spider_total_fields = spider_total_fields[1:]

        ts.table("spider_stat").field(spider_total_fields)
        ts.where("time between ? and ?", (self.s_param_obj.start_date, self.s_param_obj.end_date))
        sum_data = ts.find()

        if type(sum_data) != dict:
            for field in query_fields:
                sum_data_dict[field] = 0
            return sum_data_dict

        for key, value in sum_data.items():
            if not value:
                sum_data[key] = 0

        return sum_data

    def get_spider_percentage(self, get) -> dict:
        """
        获取蜘蛛占比数据
        @param get:
        @return:
        """
        get.query_time = "today"
        sum_data_dict_result = self._get_spider_overview(get)

        sum_data_percentage = {}
        sum_data_total = sum(sum_data_dict_result.values())
        if sum_data_total == 0:
            for key, value in sum_data_dict_result.items():
                sum_data_percentage[key] = 0
            return sum_data_percentage

        for key, value in sum_data_dict_result.items():
            sum_data_percentage[key] = round(value / sum_data_total * 100, 2)

        return sum_data_percentage

    def get_spider_overview_old(self, get) -> dict:
        '''
        获取蜘蛛概览数据
        @param get:
        @return:
        @todo: 暂未启用，可对比的概览，只给蜘蛛占比使用
        '''
        self.s_param_obj = self.construction_param(get)

        ts = self.init_ts(self.s_param_obj.site_name, self.total_db_name)
        sum_data_dict_result = {"sum_data": {}, "compare_sum_data": {}}
        sum_data_dict = {}
        compare_sum_data_dict = {}
        if self.s_param_obj.spider_type == "all":
            query_fields = self.spider_fields
        else:
            query_fields = self.s_param_obj.spider_type.split(",")

        if not ts:
            for field in query_fields:
                sum_data_dict[field] = 0
            sum_data_dict_result["sum_data"] = sum_data_dict
            return sum_data_dict_result

        # 构造查询字段
        self.s_param_obj.start_date, self.s_param_obj.end_date = self.get_query_date(
            self.s_param_obj.query_time
        )
        spider_total_fields = ""
        for field in query_fields:
            spider_total_fields += ",sum({}) as {}".format(field, field)
        spider_total_fields = spider_total_fields[1:]

        ts.table("spider_stat").field(spider_total_fields)
        ts.where("time between ? and ?", (self.s_param_obj.start_date, self.s_param_obj.end_date))
        sum_data = ts.find()

        if type(sum_data) != dict:
            for field in query_fields:
                sum_data_dict[field] = 0
            sum_data_dict_result["sum_data"] = sum_data_dict
            return sum_data_dict_result

        for key, value in sum_data.items():
            if not value: sum_data[key] = 0

        sum_data = dict(sorted(sum_data.items(), key=lambda x: x[1], reverse=True))

        # 如果不需要对比数据，或对比时间不是今天，则直接返回
        if self.s_param_obj.compare != "true" or self.s_param_obj.query_time != "today":
            for field in query_fields:
                compare_sum_data_dict[field] = 0
            sum_data_dict_result["sum_data"] = sum_data
            return sum_data_dict_result

        self.s_param_obj.compare_start_date, self.s_param_obj.compare_end_date = self.get_compare_date(
            self.s_param_obj.start_date,
            self.s_param_obj.compare_time
        )
        ts.where("time between ? and ?", (
            self.s_param_obj.compare_start_date,
            self.s_param_obj.compare_end_date
        ))
        compare_sum_data = ts.find()

        if type(compare_sum_data) != dict:
            for field in query_fields:
                compare_sum_data_dict[field] = 0
            sum_data_dict_result["sum_data"] = sum_data
            sum_data_dict_result["compare_sum_data"] = compare_sum_data_dict
            return sum_data_dict_result

        for key, value in compare_sum_data.items():
            if not value: compare_sum_data[key] = 0

        compare_sum_data = dict(sorted(compare_sum_data.items(), key=lambda x: x[1], reverse=True))

        sum_data_dict_result["sum_data"] = sum_data
        sum_data_dict_result["compare_sum_data"] = compare_sum_data
        return sum_data_dict_result

    def get_spider_details(self, get) -> Dict[str, Union[str, Any]]:
        """
        获取蜘蛛详情数据
        @param get:
        @return:
        """
        data = self.get_spider_trend(get)['data']["trend_data_list"]
        query_date = "{}-{}".format(self.s_param_obj.start_date, self.s_param_obj.end_date)
        public.set_module_logs("totalModel", "get_spider_details")
        return {"query_date": query_date, "data": data}

    def get_spider_sum_trend(self, get) -> Dict[str, Union[List[Dict[str, Any]], str]]:
        """
        获取蜘蛛总量趋势数据
        @param get:
        @return:
        """
        spider_trend_dict = self.get_spider_trend(get)
        trend_data_list = []
        for trend_data in spider_trend_dict["data"]["trend_data_list"]:
            trend_data["sum"] = sum([v for k, v in trend_data.items() if k not in ("time", "other", "fake_spider")])
            trend_data_list.append({
                "time": trend_data["time"],
                "sum": trend_data["sum"]
            })
        query_date = spider_trend_dict["query_date"]
        return {"query_date": query_date, "data": trend_data_list}

    def get_spider_trend(self, get) -> dict:
        """
        获取蜘蛛趋势数据
        @param get:
        @return:
        """
        self.s_param_obj = self.construction_param(get)

        spider_trend_dict = {"trend_data_list": [], "trend_compare_data": []}
        if self.s_param_obj.spider_type == "all":
            query_fields = self.spider_fields
        else:
            query_fields = self.s_param_obj.spider_type.split(",")

        # 构造查询字段
        self.s_param_obj.start_date, self.s_param_obj.end_date = self.get_query_date(
            self.s_param_obj.query_time
        )

        query_date = "{}-{}".format(self.s_param_obj.start_date, self.s_param_obj.end_date)

        try:
            ts = self.init_ts(self.s_param_obj.site_name, self.total_db_name)
        except RuntimeError as e:
            print(e)
            return {"query_date": query_date, "data": spider_trend_dict}

        if not ts:
            return {"query_date": query_date, "data": spider_trend_dict}

        if self.s_param_obj.time_scale == "hour":
            spider_total_fields = "time"
            for field in query_fields:
                spider_total_fields += ",{}".format(field)
            ts.table("spider_stat").field(spider_total_fields)
            ts.where("time between ? and ?", (self.s_param_obj.start_date, self.s_param_obj.end_date))
            ts.order("time")

        elif self.s_param_obj.time_scale == "day":
            spider_total_fields = "time / 100 as total_time"
            for field in query_fields:
                spider_total_fields += ",sum({}) as {}".format(field, field)
            ts.table("spider_stat").groupby("total_time").field(spider_total_fields)
            ts.where("time between ? and ?", (self.s_param_obj.start_date, self.s_param_obj.end_date))
            ts.order("total_time")

        trend_data = ts.select()

        if type(trend_data) != list:
            return {"query_date": query_date, "data": spider_trend_dict}

        if self.s_param_obj.time_scale == "day":
            for d in trend_data:
                d["time"] = d["total_time"]
                del d["total_time"]

        spider_trend_dict["trend_data_list"] = trend_data

        # 如果不需要对比数据，则直接返回
        if self.s_param_obj.compare != "true":
            return {"query_date": query_date, "data": spider_trend_dict}

        # 如果需要对比数据，但是时间粒度不是小时，则直接返回
        if self.s_param_obj.compare == "true" and self.s_param_obj.time_scale != "hour":
            return {"query_date": query_date, "data": spider_trend_dict}

        self.s_param_obj.compare_start_date, self.s_param_obj.compare_end_date = self.get_compare_date(
            self.s_param_obj.start_date,
            self.s_param_obj.compare_time
        )

        spider_total_fields = "time"
        for field in query_fields:
            spider_total_fields += ",{}".format(field)
        ts.table("spider_stat").field(spider_total_fields)
        ts.where("time between ? and ?", (
            self.s_param_obj.compare_start_date,
            self.s_param_obj.compare_end_date
        ))
        ts.order("time")

        trend_compare_data = ts.select()

        if type(trend_compare_data) != list:
            return {"query_date": query_date, "data": spider_trend_dict}

        spider_trend_dict["trend_compare_data"] = trend_compare_data
        return {"query_date": query_date, "data": spider_trend_dict}

    def get_spider_default_fetch_uri_data(self, get) -> List[Dict[Any, Dict[Any, int]]]:
        """
        获取蜘蛛抓取目录/uri数据
        @param get:
        @return:
        """
        get.dir_level = "1"
        one_dri = self.get_spider_fetch_uri_data(get)
        get.dir_level = "2"
        two_dri = self.get_spider_fetch_uri_data(get)
        return one_dri + two_dri

    def get_spider_fetch_uri_data(self, get) -> List[Dict[Any, Dict[Any, int]]]:
        """
        获取蜘蛛抓取目录/uri数据
        @param get:
        @return:
        """
        self.s_param_obj = self.construction_param(get)

        import re
        from tsqlite import tsqlite
        fetch_dir_data_list = []
        where_list = []
        if self.s_param_obj.spider_type != "all":
            query_fields = self.s_param_obj.spider_type.split(",")
            for field in query_fields:
                where_list.append(self.spider_table[field])
        else:
            where_list = self.spider_fields_numbers

        fields = "is_spider,uri"
        # 构造where_str, 例如: is_spider in (1,2,3,4,5,6,7,8,9,10,11,12,13,14,15),where_list有多少个元素就有多少个占位符
        where_str = "is_spider in ({})".format(",".join(["?"] * len(where_list)))

        where_str += self.get_uri_dir_level(self.s_param_obj.dir_level)

        self.s_param_obj.start_timestamp, self.s_param_obj.end_timestamp = self.get_query_timestamp(
            self.s_param_obj.query_time
        )
        self.s_param_obj.query_dates = self.split_query_date(
            self.s_param_obj.start_timestamp,
            self.s_param_obj.end_timestamp
        )
        ts = tsqlite()

        for date_list in self.s_param_obj.query_dates:
            self.s_param_obj.start_date = date_list[0]
            self.s_param_obj.end_date = date_list[1]

            db_path = self.get_logs_db_name_by_timestamp(
                self.s_param_obj.site_name,
                self.s_param_obj.start_date,
                self.s_param_obj.end_date
            )

            if not db_path: continue
            if not os.path.isfile(db_path): continue

            ts.dbfile(db_path)
            ts.table("spider_logs").field(fields).where(where_str, tuple(where_list))
            fetch_dir_data = ts.select()

            if type(fetch_dir_data) != list: continue

            # 只取目录出来
            if self.s_param_obj.uri_type == "dir":
                for row in fetch_dir_data:
                    if self.s_param_obj.dir_level == "1":
                        row["uri"] = "/"
                    else:
                        match = re.search("/(.*/)", row["uri"])
                        row["uri"] = "/" + match.group(1)

            grouped_data = {}
            status_count = {}
            # 将is_spider字段转换为对应的蜘蛛名称，然后分组
            fetch_dir_data = [{**x, "is_spider": self.spider_table_reverse[x["is_spider"]]} for x in fetch_dir_data]
            fetch_dir_data = sorted(fetch_dir_data, key=lambda x: x["is_spider"])
            fetch_dir_data = groupby(fetch_dir_data, key=lambda x: x["is_spider"])
            fetch_dir_data = {k: list(v) for k, v in fetch_dir_data}

            # 将uri字段分组
            for is_spider, rows in fetch_dir_data.items():
                for row in rows:
                    row_uri = row["uri"]
                    if row_uri not in status_count:
                        status_count[row_uri] = 0
                    status_count[row_uri] += 1
                grouped_data[is_spider] = status_count
                status_count = {}

            fetch_dir_data_list.append(grouped_data)

        with contextlib.suppress(Exception):
            ts and ts.close()

        return fetch_dir_data_list

    def get_spider_status_code_data(self, get) -> List[Dict[Any, Dict[Any, int]]]:
        """
        获取蜘蛛状态码数据
        @param get:
        @return:
        """
        self.s_param_obj = self.construction_param(get)

        from tsqlite import tsqlite
        where_status_code_list = []
        where_spider_type_list = []
        where_list = []
        status_code_data_list = []
        if self.s_param_obj.status_code != "all":
            status_code_query_fields = self.s_param_obj.status_code.split(",")
            for field in status_code_query_fields:
                where_status_code_list.append(field)

        if self.s_param_obj.spider_type != "all":
            spider_type_query_fields = self.s_param_obj.spider_type.split(",")
            for field in spider_type_query_fields:
                where_spider_type_list.append(self.spider_table[field])

        where_status_code = ""
        where_spider_type = ""
        if len(where_status_code_list) != 0:
            where_status_code = "status_code in ({})".format(",".join(["?"] * len(where_status_code_list)))
        if len(where_spider_type_list) != 0:
            where_spider_type = "is_spider in ({})".format(",".join(["?"] * len(where_spider_type_list)))

        where_str = ""
        if where_status_code and where_spider_type:
            where_str = where_status_code + " AND " + where_spider_type
        elif where_status_code:
            where_str = where_status_code
        elif where_spider_type:
            where_str = where_spider_type

        if where_str != "":
            where_list = where_status_code_list + where_spider_type_list

        self.s_param_obj.start_timestamp, self.s_param_obj.end_timestamp = self.get_query_timestamp(
            self.s_param_obj.query_time
        )
        self.s_param_obj.query_dates = self.split_query_date(
            self.s_param_obj.start_timestamp,
            self.s_param_obj.end_timestamp
        )
        ts = tsqlite()

        for date_list in self.s_param_obj.query_dates:
            self.s_param_obj.start_date = date_list[0]
            self.s_param_obj.end_date = date_list[1]
            db_path = self.get_logs_db_name_by_timestamp(
                self.s_param_obj.site_name,
                self.s_param_obj.start_date,
                self.s_param_obj.end_date
            )

            if not db_path: continue
            if not os.path.isfile(db_path): continue

            fields = "is_spider,status_code"
            # 构造where_str, 例如: is_spider in (1,2,3,4,5,6,7,8,9,10,11,12,13,14,15),where_list有多少个元素就有多少个占位符
            # 将构造where_str分开处理，如果where_status_code_list有数据

            ts.dbfile(db_path)
            if where_str != "":
                ts.table("spider_logs").field(fields).where(where_str, tuple(where_list))
            else:
                ts.table("spider_logs").field(fields)
            status_code_data = ts.select()

            if type(status_code_data) != list: continue

            try:
                grouped_data = {}
                status_count = {}
                # 将每个不同的is_spider值分组，然后再对每个组中不同的status_code分组，然后统计status_code每组的数量
                status_code_data = sorted(status_code_data, key=lambda x: x["is_spider"])
                status_code_data = [{**x, "is_spider": self.spider_table_reverse[x["is_spider"]]} for x in
                                    status_code_data]
                status_code_data = groupby(status_code_data, key=lambda x: x["is_spider"])
                status_code_data = {k: list(v) for k, v in status_code_data}

                for is_spider, rows in status_code_data.items():
                    for row in rows:
                        status_code = row["status_code"]
                        if status_code not in status_count:
                            status_count[status_code] = 0
                        status_count[status_code] += 1
                    grouped_data[is_spider] = status_count
                    status_count = {}

                status_code_data_list.append(grouped_data)
            except KeyError:
                continue

        with contextlib.suppress(Exception):
            ts and ts.close()

        return status_code_data_list

    def get_spider_logs_info(self, get) -> Union[List[Dict[str, Any]], List[Any]]:
        """
        获取蜘蛛日志信息
        @param get:
        @return:
        """
        self.s_param_obj = self.construction_param(get)

        self.s_param_obj.start_timestamp, self.s_param_obj.end_timestamp = self.get_query_timestamp(
            self.s_param_obj.query_time
        )
        self.s_param_obj.query_dates = self.split_query_date(
            self.s_param_obj.start_timestamp,
            self.s_param_obj.end_timestamp
        )

        now_timestamp = time.time()
        not_today = now_timestamp - self.s_param_obj.end_timestamp > 86400

        cache_key = "spider_logs_row_{}_{}_{}_{}_{}_{}".format(
            self.s_param_obj.site_name,
            self.s_param_obj.query_time,
            self.s_param_obj.spider_type,
            self.s_param_obj.status_code,
            self.s_param_obj.page,
            self.s_param_obj.page_size
        )
        if not_today:
            cache_value = cache.get(cache_key)
            if cache_value:
                return cache_value

        from tsqlite import tsqlite
        ts = tsqlite()
        spider_logs_info_list = []

        for date_list in self.s_param_obj.query_dates:
            self.s_param_obj.start_date = date_list[0]
            self.s_param_obj.end_date = date_list[1]

            db_path = self.get_logs_db_name_by_timestamp(
                self.s_param_obj.site_name,
                self.s_param_obj.start_date,
                self.s_param_obj.end_date
            )

            if not db_path: continue
            if not os.path.isfile(db_path): continue

            ts.dbfile(db_path)
            ts.table("spider_logs")
            # 根据self.s_param_obj.page和self.s_param_obj.page_size计算出offset
            ts.limit("{},{}".format(self.s_param_obj.offset, self.s_param_obj.page_size))
            spider_logs_info = ts.select()

            if type(spider_logs_info) != list: continue
            if len(spider_logs_info) == 0: continue
            spider_logs_info = [{**x, "is_spider": self.spider_table_reverse[x["is_spider"]]} for x in spider_logs_info]

            if len(spider_logs_info_list) == 0:
                spider_logs_info_list = spider_logs_info

            if len(spider_logs_info_list) == self.s_param_obj.page_size:
                spider_logs_info_list = spider_logs_info
                if not_today: cache.set(cache_key, spider_logs_info_list, 86400)
                break
            elif 0 < len(spider_logs_info_list) < self.s_param_obj.page_size:
                spider_logs_info_list += spider_logs_info
                if len(spider_logs_info_list) > self.s_param_obj.page_size:
                    spider_logs_info_list = spider_logs_info_list[:self.s_param_obj.page_size]
                    if not_today: cache.set(cache_key, spider_logs_info_list, 86400)
                    break
                continue

        with contextlib.suppress(Exception):
            ts and ts.close()
        public.set_module_logs("totalModel", "get_spider_logs_info")

        return spider_logs_info_list

    def get_spider_logs_row(self, get) -> Union[int, Any]:
        """
        获取蜘蛛日志行数
        @param get:
        @return:
        """
        self.s_param_obj = self.construction_param(get)
        self.s_param_obj.start_timestamp, self.s_param_obj.end_timestamp = self.get_query_timestamp(
            self.s_param_obj.query_time
        )
        self.s_param_obj.query_dates = self.split_query_date(
            self.s_param_obj.start_timestamp,
            self.s_param_obj.end_timestamp
        )

        row_count = 0
        now_timestamp = time.time()
        not_today = now_timestamp - self.s_param_obj.end_timestamp > 86400

        cache_key = "spider_logs_row_{}_{}_{}_{}".format(
            self.s_param_obj.site_name,
            self.s_param_obj.query_time,
            self.s_param_obj.spider_type,
            self.s_param_obj.status_code
        )
        if not_today:
            cache_value = cache.get(cache_key)
            if cache_value:
                return cache_value

        from tsqlite import tsqlite
        ts = tsqlite()

        for date_list in self.s_param_obj.query_dates:
            self.s_param_obj.start_date = date_list[0]
            self.s_param_obj.end_date = date_list[1]

            db_path = self.get_logs_db_name_by_timestamp(
                self.s_param_obj.site_name,
                self.s_param_obj.start_date,
                self.s_param_obj.end_date
            )

            if not db_path: continue
            if not os.path.isfile(db_path): continue

            ts.dbfile(db_path)
            ts.table("spider_logs")
            # 获取总记录数
            row_count += ts.count()

        with contextlib.suppress(Exception):
            ts and ts.close()

        if not_today: cache.set(cache_key, row_count, 86400)

        return row_count
