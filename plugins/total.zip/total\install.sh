#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
install_tmp='/tmp/bt_install.pl'
public_file=/www/server/panel/install/public.sh
#安装脚本概述
#经过不同的用户安装环境测试，整理安装脚本安装逻辑如下：
#Web Server: nginx, apache
#lua版本: 5.1.4 5.1.5 5.3.1
#OS: CentOS7 CentOS8
#
#nginx和apache单独分开安装逻辑:
#
#因为面板的nginx是固定编译了lua5.1.5，所以nginx的安装统一会安装一个独立的lua5.1.5版本到/www/server/total/lu515,
#用来编译安装luarocks和lsqlite3。
#
#apache的编译跟随OS自带的Lua版本，所以apache默认不安装lua515环境。
#
#所有版本共用一个的lua脚本，已经从lua代码层面解决5.1~5.3的语法不同之处。

pluginPath=/www/server/panel/plugin/total
libraryPath=/www/server/panel/plugin/total/library
total_path=/www/server/total
remote_dir="total2"

wrong_actions=()

Command_Exists() {
    command -v "$@" >/dev/null 2>&1
}

Get_Public() {
    public_file=/www/server/panel/install/public.sh
    public_file_md5=$(md5sum ${public_file} 2>/dev/null | awk '{print $1}')
    md5check="8e49712d1fd332801443f8b6fd7f9208"
    if [ "${public_file_md5}" != "${md5check}" ]; then
        wget -O Tpublic.sh https://download.bt.cn/install/public.sh -T 20
        public_file_md5=$(md5sum Tpublic.sh 2>/dev/null | awk '{print $1}')
        if [ "${public_file_md5}" == "${md5check}" ]; then
            \cp -rpa Tpublic.sh ${public_file}
        fi
        rm -f Tpublic.sh
    fi

    . ${public_file}

    download_Url=${NODE_URL}
}

# Retry Download file
Download_File() {
    local_file=${1}
    source=${2}
    timeout=${3}
    retry=${4}
    if [[ -n ${5} ]]; then
        ori_retry=${5}
    else
        ori_retry=${retry}
    fi

    wget --no-check-certificate -O "${local_file}" "${source}" -T "${timeout}" -t "${ori_retry}"
    if [ -s "${local_file}" ]; then
        echo "${local_file} download successful."
    else
        if [[ ${retry} -gt 1 ]]; then
            retry=$((retry - 1))
            Download_File "${local_file}" "${source}" "${timeout}" "${retry}" "${ori_retry}"
        else
            echo "* ${local_file} download failed!"
            wrong_actions[${#wrong_actions[*]}]=${local_file}
        fi
    fi
}

# Returns the platform
Get_platform() {
    case $(uname -s 2>/dev/null) in
    Linux) echo "linux" ;;
    FreeBSD) echo "freebsd" ;;
    *BSD*) echo "bsd" ;;
    Darwin) echo "macosx" ;;
    CYGWIN* | MINGW* | MSYS*) echo "mingw" ;;
    AIX) echo "aix" ;;
    SunOS) echo "solaris" ;;
    *) echo "unknown" ;;
    esac
}
Remove_path() {
    local prefix=$1
    local new_path
    new_path=$(
        echo "${PATH}" | sed \
            -e "s#${prefix}/[^/]*/bin[^:]*:##g" \
            -e "s#:${prefix}/[^/]*/bin[^:]*##g" \
            -e "s#${prefix}/[^/]*/bin[^:]*##g"
    )
    export PATH="${new_path}"
}
Add_path() {
    local prefix=$1
    local new_path
    new_path=$(
        echo "${PATH}" | sed \
            -e "s#${prefix}/[^/]*/bin[^:]*:##g" \
            -e "s#:${prefix}/[^/]*/bin[^:]*##g" \
            -e "s#${prefix}/[^/]*/bin[^:]*##g"
    )
    export PATH="${prefix}:${new_path}"
}

Get_lua_version() {
    lua -e 'print(_VERSION:sub(5))'
}

Install_Lua515() {
    local install_path="/www/server/total/lua515"

    local version
    version=$(Get_lua_version)

    echo "Current lua version: ${version}"
    if [ -d "${install_path}/bin" ]; then
        Add_path "${install_path}/bin"
        echo "Lua 5.1.5 has installed."
        return 1
    fi

    local lua_version="lua-5.1.5"
    local package_name="${lua_version}.tar.gz"
    local url=http://download.bt.cn/install/plugin/${remote_dir}/library/${package_name}
    echo "lua515下载链接:"$url

    mkdir -p ${install_path}
    local tmp_dir=/tmp/${lua_version}
    mkdir -p ${tmp_dir} && cd ${tmp_dir} || {
        echo "创建lua515临时目录失败"
        return 1
    }

    if [ ! -f ${libraryPath}/${package_name} ]; then
        Download_File ${libraryPath}/${package_name} $url 10 3
    fi
    tar xvzf ${libraryPath}/${package_name}
    cd ${lua_version} || {
        echo "创建lua515临时目录失败"
        return 1
    }

    platform=$(Get_platform)
    if [ "${platform}" = "unknown" ]; then
        platform="linux"
    fi
    make "${platform}" install INSTALL_TOP=${install_path}
    Add_path "${install_path}/bin"
    rm -rf "/tmp/${lua_version}"

    version=$(Get_lua_version)
    if [[ "${version}" == "5.1" ]]; then
        echo "Lua 5.1.5 has installed."
        return 1
    fi
    return 0
}
Install_Sqlite3_For_Nginx() {
    if ! Command_Exists luarocks; then
        rm -rf /tmp/luarocks-3.5.0
        if [ ! -f ${libraryPath}/luarocks-3.5.0.tar.gz ]; then
            Download_File ${libraryPath}/luarocks-3.5.0.tar.gz http://download.bt.cn/install/plugin/${remote_dir}/library/luarocks-3.5.0.tar.gz 10 3
        fi

        cd /tmp && tar xf ${libraryPath}/luarocks-3.5.0.tar.gz
        cd /tmp/luarocks-3.5.0 || {
            echo "创建luarocks临时目录失败"
            return 1
        }
        ./configure --with-lua-include=/www/server/total/lua515/include --with-lua-bin=/www/server/total/lua515/bin
        make -I/www/server/total/lua515/bin
        make install
        cd /tmp && rm -rf /tmp/luarocks-3.5.0
    fi

    if [ true ]; then
        rm -rf /tmp/lsqlite3_fsl09y
        if [ ! -f ${libraryPath}/lsqlite3_fsl09y.zip ]; then
            Download_File ${libraryPath}/lsqlite3_fsl09y.zip http://download.bt.cn/install/plugin/${remote_dir}/library/lsqlite3_fsl09y.zip 10 3
        fi
        cd /tmp && unzip ${libraryPath}/lsqlite3_fsl09y.zip && cd lsqlite3_fsl09y && make
        if [ ! -f '/tmp/lsqlite3_fsl09y/lsqlite3.so' ]; then
            echo "${tip9}"
            wrong_actions[${#wrong_actions[*]}]="lsqlite3 install failed."
            if [ ! -f ${libraryPath}/lsqlite3.so ]; then
                Download_File ${libraryPath}/lsqlite3.so http://download.bt.cn/install/plugin/${remote_dir}/library/lsqlite3.so 10 3
            fi
            \cp -a -r ${libraryPath}/lsqlite3.so ${total_path}/lsqlite3.so
        else
            echo "${tip10}"
            \cp -a -r /tmp/lsqlite3_fsl09y/lsqlite3.so ${total_path}/lsqlite3.so
        fi
        rm -rf /tmp/lsqlite3_fsl09y/*
        rm -rf /tmp/lsqlite3_fsl09y.zip
    fi
    if [ -f /usr/local/lib/lua/5.1/cjson.so ]; then
        is_jit_cjson=$(luajit -e "require 'cjson'" 2>&1 | grep 'undefined symbol: luaL_setfuncs')
        if [ "${is_jit_cjson}" != "" ]; then
            cd /tmp && luarocks install lua-cjson --server https://luarocks.cn || {
                echo "安装lua-cjson失败"
                return 1
            }
        fi
    fi
}

Install_sqlite3_for_apache() {
    if [ -f '/usr/include/lua.h' ]; then
        include_path='/usr/include/'
    elif [ -f '/usr/include/lua5.1/lua.h' ]; then
        include_path='/usr/include/lua5.1'
    elif [ -f '/usr/include/lua5.3/lua.h' ]; then
        include_path='/usr/include/lua5.3'
    elif [ -f '/usr/local/include/luajit-2.0/lua.h' ]; then
        include_path='/usr/local/include/luajit-2.0/'
    elif [ -f '/usr/include/lua5.1/' ]; then
        include_path='/usr/include/lua5.1/'
    elif [ -f '/usr/local/include/luajit-2.1/' ]; then
        include_path='/usr/local/include/luajit-2.1/'
    else
        include_path=''
    fi

    is_lua53=""
    if [ "$(Get_lua_version)" == "5.3" ] && [ -d '/usr/lib64/lua' ]; then
        lua_bin='/usr/bin/'
        is_lua53="yes"
    elif [ "$(Get_lua_version)" == "5.3" ] && [ -f '/usr/lib64/lua' ]; then
        lua_bin='/usr/lib64'
        is_lua53="yes"
    elif [ -f '/usr/bin/lua' ]; then
        lua_bin='/usr/bin/'
    elif [ -f '/usr/lib/lua' ]; then
        lua_bin='/usr/lib/'
    else
        lua_bin=$(which lua | xargs dirname)
    fi

    if [ true ]; then
        rm -rf /tmp/luarocks-3.5.0
        if [ ! -f ${libraryPath}/luarocks-3.5.0.tar.gz ]; then
            Download_File ${libraryPath}/luarocks-3.5.0.tar.gz http://download.bt.cn/install/plugin/${remote_dir}/library/luarocks-3.5.0.tar.gz 10 3
        fi

        cd /tmp && tar xvf ${libraryPath}/luarocks-3.5.0.tar.gz >/dev/null
        cd /tmp/luarocks-3.5.0 || {
            echo "创建luarocks临时目录失败"
            return 1
        }

        if [ $is_lua53 == "yes" ]; then
            ./configure --with-lua-include="${include_path}" --with-lua-bin="${lua_bin}"
            make
        else
            ./configure --with-lua-include="${include_path}" --with-lua-bin="${lua_bin}"
            make -I"${include_path}"
        fi
        make install
        cd /tmp && rm -rf /tmp/luarocks-3.5.0
    fi

    if [ true ]; then
        rm -rf /tmp/lsqlite3_fsl09y
        if [ ! -f ${libraryPath}/lsqlite3_fsl09y.zip ]; then
            Download_File ${libraryPath}/lsqlite3_fsl09y.zip http://download.bt.cn/install/plugin/${remote_dir}/library/lsqlite3_fsl09y.zip 10 3
        fi
        cd /tmp && unzip ${libraryPath}/lsqlite3_fsl09y.zip && cd lsqlite3_fsl09y && make
        if [ ! -f /tmp/lsqlite3_fsl09y/lsqlite3.so ]; then
            echo "${tip9}"
            wrong_actions[${#wrong_actions[*]}]="lsqlite3 install failed."
            if [ ! -f ${libraryPath}/lsqlite3.so ]; then
                Download_File ${libraryPath}/lsqlite3.so http://download.bt.cn/install/plugin/${remote_dir}/library/lsqlite3.so 10 3
            fi
            \cp -a -r ${libraryPath}/lsqlite3.so ${total_path}/lsqlite3.so
        else
            echo "${tip10}"
            \cp -a -r /tmp/lsqlite3_fsl09y/lsqlite3.so ${total_path}/lsqlite3.so
        fi
        rm -rf /tmp/lsqlite3_fsl09y
    fi

    if [ -f /usr/local/lib/lua/5.1/cjson.so ]; then
        is_jit_cjson=$(luajit -e "require 'cjson'" 2>&1 | grep 'undefined symbol: luaL_setfuncs')
        if [ "${is_jit_cjson}" != "" ]; then
            cd /tmp && luarocks install lua-cjson --server https://luarocks.cn
        fi
    fi
}

Install_Cjson() {
    if [ -f /usr/local/lib/lua/5.1/cjson.so ]; then
        is_jit_cjson=$(luajit -e "require 'cjson'" 2>&1 | grep 'undefined symbol:luaL_setfuncs')
        if [ "${is_jit_cjson}" != "" ]; then
            rm -f /usr/local/lib/lua/5.1/cjson.so
        fi
    fi

    Centos8Check=$(cat /etc/redhat-release | grep -iE ' 8(\.\d)*' | grep -iE 'centos|Red Hat|Alibaba|Anolis')
    AlibabaCheck=$(cat /etc/redhat-release | grep 'Alibaba')
    AmzCheck=$(. /etc/os-release && echo "${ID}" | grep -iE 'amzn')
    Install_lua53=""
    if [ "${AlibabaCheck}" ]; then
        version=$(Get_lua_version)
        if [ "${version}" == "5.3" ]; then
            Install_lua53="true"
        fi
    fi
    if [ "${Centos8Check}" ] || [ "${Install_lua53}" ] || [ "${AmzCheck}" ]; then
        yum install lua-socket -y
        if [ ! -f /usr/lib/lua/5.3/cjson.so ]; then
            cd /tmp || {
                mkdir -p /tmp
                cd /tmp
            }
            if [ ! -f ${libraryPath}/lua-5.3-cjson.tar.gz ]; then
                Download_File ${libraryPath}/lua-5.3-cjson.tar.gz ${download_Url}/src/lua-5.3-cjson.tar.gz 20 3
            fi
            tar -xvf ${libraryPath}/lua-5.3-cjson.tar.gz
            cd lua-5.3-cjson && make
            make install
            ln -sf /usr/lib/lua/5.3/cjson.so /usr/lib64/lua/5.3/cjson.so
            cd /tmp && rm -rf lua-5.3-cjson
        fi
        return
    fi

    if [ ! -f /usr/local/lib/lua/5.1/cjson.so ]; then
        cd /tmp || {
            mkdir -p /tmp
            cd /tmp
        }
        if [ ! -f ${libraryPath}/lua-cjson-2.1.0.tar.gz ]; then
            Download_File ${libraryPath}/lua-cjson-2.1.0.tar.gz ${download_Url}/install/src/lua-cjson-2.1.0.tar.gz 20 3
        fi
        tar xvf ${libraryPath}/lua-cjson-2.1.0.tar.gz
        cd lua-cjson-2.1.0 && make clean
        make
        make install
        cd /tmp && rm -rf lua-cjson-2.1.0
        ln -sf /usr/local/lib/lua/5.1/cjson.so /usr/lib64/lua/5.1/cjson.so
        ln -sf /usr/local/lib/lua/5.1/cjson.so /usr/lib/lua/5.1/cjson.so
    else
        if [ -d "/usr/lib64/lua/5.1" ]; then
            ln -sf /usr/local/lib/lua/5.1/cjson.so /usr/lib64/lua/5.1/cjson.so
        fi

        if [ -d "/usr/lib/lua/5.1" ]; then
            ln -sf /usr/local/lib/lua/5.1/cjson.so /usr/lib/lua/5.1/cjson.so
        fi
    fi

    luarocks show lua-cjson
    if [ $? -ne 0 ]; then
        luarocks install lua-cjson --server https://luarocks.cn
    fi
}

Install_socket() {
    if [ ! -f /usr/local/lib/lua/5.1/socket/core.so ]; then
        cd /tmp || {
            mkdir -p /tmp
            cd /tmp
        }
        if [ ! -f ${libraryPath}/luasocket-master.zip ]; then
            Download_File ${libraryPath}/luasocket-master.zip ${download_Url}/install/src/luasocket-master.zip 20 3
        fi
        unzip ${libraryPath}/luasocket-master.zip
        cd luasocket-master && make
        make install
        cd /tmp && rm -rf luasocket-master
    fi

    if [ ! -d /usr/share/lua/5.1/socket ]; then
        if [ -d /usr/lib64/lua/5.1 ]; then
            rm -rf /usr/lib64/lua/5.1/socket /usr/lib64/lua/5.1/mime
            ln -sf /usr/local/lib/lua/5.1/socket /usr/lib64/lua/5.1/socket
            ln -sf /usr/local/lib/lua/5.1/mime /usr/lib64/lua/5.1/mime
        else
            rm -rf /usr/lib/lua/5.1/socket /usr/lib/lua/5.1/mime
            ln -sf /usr/local/lib/lua/5.1/socket /usr/lib/lua/5.1/socket
            ln -sf /usr/local/lib/lua/5.1/mime /usr/lib/lua/5.1/mime
        fi
        rm -rf /usr/share/lua/5.1/mime.lua /usr/share/lua/5.1/socket.lua /usr/share/lua/5.1/socket
        ln -sf /usr/local/share/lua/5.1/mime.lua /usr/share/lua/5.1/mime.lua
        ln -sf /usr/local/share/lua/5.1/socket.lua /usr/share/lua/5.1/socket.lua
        ln -sf /usr/local/share/lua/5.1/socket /usr/share/lua/5.1/socket
    fi

    if ! luarocks show luasocket; then
        luarocks install luasocket --server https://luarocks.cn
    fi
}

Install_mod_lua_for_apache() {
    if [ ! -f /www/server/apache/bin/httpd ]; then
        return 0
    fi

    if [ -f /www/server/apache/modules/mod_lua.so ]; then
        return 0
    fi
    cd /www/server/apache || {
        echo "apache程序目录不存在"
        return 1
    }

    if [ ! -d /www/server/apache/src ]; then
        if [ ! -f ${libraryPath}/httpd-2.4.33.tar.gz ]; then
            Download_File ${libraryPath}/httpd-2.4.33.tar.gz ${download_Url}/src/httpd-2.4.33.tar.gz 20 3
        fi
        tar xvf ${libraryPath}/httpd-2.4.33.tar.gz
        mv httpd-2.4.33 src
        cd /www/server/apache/src/srclib || {
            echo "创建apache临时目录失败"
            return 1
        }
        if [ ! -f ${libraryPath}/apr-1.6.3.tar.gz ]; then
            Download_File ${libraryPath}/apr-1.6.3.tar.gz ${download_Url}/src/apr-1.6.3.tar.gz 10 3
        fi
        if [ ! -f ${libraryPath}/apr-util-1.6.1.tar.gz ]; then
            Download_File ${libraryPath}/apr-util-1.6.1.tar.gz ${download_Url}/src/apr-util-1.6.1.tar.gz 10 3
        fi
        tar zxf ${libraryPath}/apr-1.6.3.tar.gz
        tar zxf ${libraryPath}/apr-util-1.6.1.tar.gz
        mv apr-1.6.3 apr
        mv apr-util-1.6.1 apr-util
    fi

    cd /www/server/apache/src && ./configure --prefix=/www/server/apache --enable-lua
    cd modules/lua && make
    make install

    if [ ! -f /www/server/apache/modules/mod_lua.so ]; then
        echo ${tip8}
        exit 0
    fi
}

Install_pdf_library() {

    if [ ! -f /usr/share/fonts/msyh.ttf ]; then
        Download_File ${libraryPath}/msyh.ttf ${download_Url}/install/plugin/${remote_dir}/library/msyh.ttf 10 3
        \cp ${libraryPath}/msyh.ttf /usr/share/fonts/msyh.ttf
        rm -f ${libraryPath}/msyh.ttf
    fi
    rm -f ${libraryPath}/msyh.ttf

    if Command_Exists apt-get; then
        apt-get install -y wkhtmltopdf
    elif Command_Exists yum; then
        yum install -y wkhtmltopdf
    fi

    if Command_Exists btpip; then
        btpip install pdfkit
    else
        pip install pdfkit
    fi

    if Command_Exists wkhtmltopdf; then
        echo "PDF module is installed."
        return 0
    fi

    v=$(cat /etc/redhat-release | sed -r 's/.* ([0-9]+)\..*/\1/')
    if [ $v -eq 6 ]; then
        if [ ! -f ${libraryPath}/wkhtmltox-0.12.6-1.centos6.x86_64.rpm ]; then
            Download_File ${libraryPath}/wkhtmltox-0.12.6-1.centos6.x86_64.rpm ${download_Url}/install/plugin/${remote_dir}/library/wkhtmltox-0.12.6-1.centos6.x86_64.rpm 10 3
        fi
        yum install -y ${libraryPath}/wkhtmltox-0.12.6-1.centos6.x86_64.rpm
    fi
    if [ $v -eq 7 ]; then
        if [ ! -f ${libraryPath}/wkhtmltox-0.12.6-1.centos7.x86_64.rpm ]; then
            Download_File ${libraryPath}/wkhtmltox-0.12.6-1.centos7.x86_64.rpm ${download_Url}/install/plugin/${remote_dir}/library/wkhtmltox-0.12.6-1.centos7.x86_64.rpm 10 3
        fi
        yum install -y ${libraryPath}/wkhtmltox-0.12.6-1.centos7.x86_64.rpm
    fi
    Centos8Check=$(cat /etc/redhat-release | grep ' 8.' | grep -iE 'centos|Red Hat')
    if [ "${Centos8Check}" ]; then
        if [ ! -f ${libraryPath}/wkhtmltox-0.12.6-1.centos8.x86_64.rpm ]; then
            Download_File ${libraryPath}/wkhtmltox-0.12.6-1.centos8.x86_64.rpm ${download_Url}/install/plugin/${remote_dir}/library/wkhtmltox-0.12.6-1.centos8.x86_64.rpm 10 3
        fi
        yum install -y ${libraryPath}/wkhtmltox-0.12.6-1.centos8.x86_64.rpm
    fi

    os_release=$(. /etc/os-release && echo $ID_LIKE)
    sys_version=$(. /etc/os-release && echo ${version})
    # shellcheck disable=SC2076
    if [[ ${os_release} =~ "centos" ]] && [[ ${sys_version} =~ "8." ]]; then
        yum install -y xorg-x11-fonts-75dpi xorg-x11-fonts-Type1 libXext openssl-devel
        if [ ! -f ${libraryPath}/wkhtmltox-0.12.6.1-2.almalinux8.x86_64.rpm ]; then
            Download_File ${libraryPath}/wkhtmltox-0.12.6.1-2.almalinux8.x86_64.rpm ${download_Url}/install/plugin/${remote_dir}/library/wkhtmltox-0.12.6.1-2.almalinux8.x86_64.rpm 10 3
        fi
        yum install -y ${libraryPath}/wkhtmltox-0.12.6.1-2.almalinux8.x86_64.rpm
    fi

    deb_version_file="/etc/issue"
    os_version=$(cat ${deb_version_file} | grep Ubuntu | grep -Eo '([0-9]+\.)+[0-9]+' | grep -Eo '^[0-9]+')
    if [ -z "${os_version}" ]; then
        os_version=$(cat ${deb_version_file} | grep Debian | awk '{print $3}')
        deb_install_file=''
        if [ "${os_version}" -eq 9 ]; then
            deb_install_file='wkhtmltox_0.12.6-1.stretch_amd64.deb'
        elif [ "${os_version}" -eq 10 ]; then
            deb_install_file='wkhtmltox_0.12.6-1.buster_amd64.deb'
        elif [ "${os_version}" -eq 11 ]; then
            deb_install_file='wkhtmltox_0.12.6.1-2.bullseye_amd64.deb'
        fi
        Download_File ${libraryPath}/$deb_install_file ${download_Url}/install/plugin/${remote_dir}/library/$deb_install_file 10 3
        apt install -y ${libraryPath}/$deb_install_file
    else
        if [ "${os_version}" -eq 20 ]; then
            if [ ! -f ${libraryPath}/wkhtmltox_0.12.6-1.focal_amd64.deb ]; then
                Download_File ${libraryPath}/wkhtmltox_0.12.6-1.focal_amd64.deb ${download_Url}/install/plugin/${remote_dir}/library/wkhtmltox_0.12.6-1.focal_amd64.deb 10 3
            fi
            apt install -y ${libraryPath}/wkhtmltox_0.12.6-1.focal_amd64.deb
        elif [ "${os_version}" -eq 18 ]; then
            if [ ! -f ${libraryPath}/wkhtmltox_0.12.6-1.bionic_amd64.deb ]; then
                Download_File ${libraryPath}/wkhtmltox_0.12.6-1.bionic_amd64.deb ${download_Url}/install/plugin/${remote_dir}/library/wkhtmltox_0.12.6-1.bionic_amd64.deb 10 3
            fi
            apt install -y ${libraryPath}/wkhtmltox_0.12.6-1.bionic_amd64.deb
        elif [ "${os_version}" -eq 16 ]; then
            if [ ! -f ${libraryPath}/wkhtmltox_0.12.6-1.xenial_amd64.deb ]; then
                Download_File ${libraryPath}/wkhtmltox_0.12.6-1.xenial_amd64.deb ${download_Url}/install/plugin/${remote_dir}/library/wkhtmltox_0.12.6-1.xenial_amd64.deb 10 3
            fi
            apt install -y ${libraryPath}/wkhtmltox_0.12.6-1.xenial_amd64.deb
        fi
    fi
}

Install_ip_library() {
    if [ ! -f "/www/server/total/GeoLite2-City.mmdb" ]; then
        if [[ ! -f /www/server/panel/config/GeoLite2-City.mmdb ]] || [[ ! -f ${libraryPath}/GeoLite2-City.mmdb ]]; then
            Download_File ${libraryPath}/GeoLite2-City.mmdb ${download_Url}/install/plugin/${remote_dir}/library/GeoLite2-City.mmdb 10 3
            \cp -a -r ${libraryPath}/GeoLite2-City.mmdb /www/server/panel/config/GeoLite2-City.mmdb
        fi
        \cp -r /www/server/panel/config/GeoLite2-City.mmdb /www/server/total/GeoLite2-City.mmdb
        chown www:www /www/server/total/GeoLite2-City.mmdb
        chmod 600 /www/server/total/GeoLite2-City.mmdb
    fi

    if [ ! -f ${libraryPath}/ip.db ]; then
        Download_File ${libraryPath}/ip.db ${download_Url}/install/plugin/${remote_dir}/library/ip.db 10 3
    fi
}

Install_Nginx_Environment() {
    echo "Installing nginx environment..."
    Install_Lua515
    Install_Sqlite3_For_Nginx
    Install_Cjson
    Install_pdf_library
    Install_ip_library
}

Install_Apache_Environment() {
    echo "Installing apache environment..."
    Install_mod_lua_for_apache
    Install_sqlite3_for_apache
    Install_Cjson
    Install_socket
    Install_pdf_library
    Install_ip_library
}

Install_Lib() {
    if [[ ${PM} == yum ]]; then
        if ! Command_Exists gcc; then
            yum install -y gcc
        fi

        if ! Command_Exists g++; then
            yum install -y gcc+ gcc-c++
        fi

        isInstall=$(rpm -qa | grep lua-devel)
        if [ "$isInstall" == "" ]; then
            yum install -y lua lua-devel lua-socket
        fi

        if [ ! -f /usr/include/linux/limits.h ]; then
            yum install -y kernel-headers
        fi

        yum install -y curl wget unzip sqlite-devel
    elif [[ ${PM} == apt ]]; then
        isInstall=$(dpkg -l | grep liblua5.1-0-dev)
        if [ "$isInstall" == "" ]; then
            apt-get install -y curl wget unzip lua5.1 lua5.1-dev lua5.1-cjson lua5.1-socket
        fi

        if [ ! -f /usr/include/linux/limits.h ]; then
            apt-get install -y linux-headers-"$(uname -r)"
        fi

        apt install -y libsqlite3-dev
    fi
}

Install_Environment() {
    if [ -f /www/server/apache/bin/httpd ]; then
        Install_Apache_Environment
    elif [ -f /www/server/nginx/sbin/nginx ]; then
        Install_Nginx_Environment
    else
        echo "Please install nginx or apache first."
    fi
}

#tip1="检测到当前面板安装了云控，请暂时使用旧版本监控报表。"
#tip2="开始安装旧版本监控报表v3.7..."
tip3="正在安装插件脚本文件..."
tip4="正在初始化数据..."
tip5="开始执行插件补丁..."
tip6="数据初始化完成。"
tip7="安装完成。"
tip8='mod_lua安装失败!'
tip9='解压不成功'
tip10='解压成功'
tip11="安装失败！"

Init_Total() {
    mv -f ${pluginPath}/panelMonitor.py /www/server/panel/class/monitor.py

    if [ ! -f ${total_path}/debug.log ]; then
        touch ${total_path}/debug.log
        chown www:www ${total_path}/debug.log
    fi

    if [ -f ${pluginPath}/total_main.cpython-37m-x86_64-linux-gnu.so ]; then
        rm -f ${pluginPath}/total_main.cpython-37m-x86_64-linux-gnu.so
    fi

    # js fix
    if [ ! -f /www/server/panel/BTPanel/static/js/tools.min.js ]; then
        \cp ${pluginPath}/tools.min.js /www/server/panel/BTPanel/static/js/tools.min.js
    fi
    rm -f ${pluginPath}/tools.min.js

    if [ ! -f /www/server/panel/BTPanel/static/js/china.js ]; then
        \cp ${pluginPath}/china.js /www/server/panel/BTPanel/static/js/china.js
    fi
    rm -f ${pluginPath}/china.js

    # total path install
    if [ ! -f ${total_path}/config.json ]; then
        \cp ${pluginPath}/total_config.json ${total_path}/config.json
    fi
    rm -f ${pluginPath}/total_config.json

    if [ -f /www/server/apache/bin/httpd ]; then
        if [ ! -f ${total_path}/closing ]; then
            if [ ! -f /www/server/panel/vhost/apache/total.conf ]; then
                \cp ${pluginPath}/total_httpd.conf /www/server/panel/vhost/apache/total.conf
            fi
        fi
    elif [ -f /www/server/nginx/sbin/nginx ]; then
        if [ ! -f ${total_path}/closing ]; then
            if [ ! -f /www/server/panel/vhost/nginx/total.conf ]; then
                \cp ${pluginPath}/total_nginx.conf /www/server/panel/vhost/nginx/total.conf
            fi
        fi

        mem_size=$(free -m | grep Mem | awk '{print $2}')
        if [[ ${mem_size} -lt 1024 ]]; then
            sed -i 's/lua_shared_dict.*/lua_shared_dict bt_total 30m;/g' /www/server/panel/vhost/nginx/total.conf
        elif [[ ${mem_size} -gt 1024 ]] && [[ ${mem_size} -lt 2048 ]]; then
            sed -i 's/lua_shared_dict.*/lua_shared_dict bt_total 60m;/g' /www/server/panel/vhost/nginx/total.conf
        elif [[ ${mem_size} -gt 2048 ]] && [[ ${mem_size} -lt 4096 ]]; then
            sed -i 's/lua_shared_dict.*/lua_shared_dict bt_total 80m;/g' /www/server/panel/vhost/nginx/total.conf
        elif [[ ${mem_size} -gt 4096 ]] && [[ ${mem_size} -lt 8192 ]]; then
            sed -i 's/lua_shared_dict.*/lua_shared_dict bt_total 100m;/g' /www/server/panel/vhost/nginx/total.conf
        elif [[ ${mem_size} -gt 8192 ]] && [[ ${mem_size} -lt 16384 ]]; then
            sed -i 's/lua_shared_dict.*/lua_shared_dict bt_total 120m;/g' /www/server/panel/vhost/nginx/total.conf
        elif [[ ${mem_size} -gt 16384 ]]; then
            sed -i 's/lua_shared_dict.*/lua_shared_dict bt_total 140m;/g' /www/server/panel/vhost/nginx/total.conf
        fi
    fi

    /bin/cp -rf ${pluginPath}/total2/* ${total_path}
    rm -rf ${pluginPath}/total2

    if [ ! -f ${pluginPath}/server_port.pl ]; then
        echo 9876 >${pluginPath}/server_port.pl
    fi

    if [ ! -f ${pluginPath}/server.log ]; then
        touch ${pluginPath}/server.log
    fi

    # execute patch
    echo ${tip4}
    if Command_Exists btpip; then
        user_agents=$(btpip list | grep user-agents)
        user_agents_v=$(echo "${user_agents}" | grep "2.2.0")
        if [[ -z ${user_agents} ]] || [[ "${user_agents_v}" == "" ]]; then
            btpip install user-agents==2.2.0
        fi
        btpython ${pluginPath}/total_migrate.py
        echo ${tip5}
        btpython ${pluginPath}/total_patch.py
    else
        python ${pluginPath}/total_migrate.py
        echo ${tip5}
        python ${pluginPath}/total_patch.py
    fi

    echo $tip6

    # authority
    chown -R www:www ${total_path}
    chmod -R 755 ${total_path}

    chmod +x ${total_path}/httpd_log.lua && chown -R root:root ${total_path}/httpd_log.lua
    chmod +x ${total_path}/nginx_log.lua && chown -R root:root ${total_path}/nginx_log.lua
    chmod +x ${total_path}/memcached.lua && chown -R root:root ${total_path}/memcached.lua
    if [ -f ${total_path}/lsqlite3.so ]; then
        chmod +x ${total_path}/lsqlite3.so && chown -R root:root ${total_path}/lsqlite3.so
    fi
    chmod +x ${total_path}/CRC32.lua && chown -R root:root ${total_path}/CRC32.lua

    # load module
    waf=/www/server/panel/vhost/apache/btwaf.conf
    if [ ! -f ${waf} ]; then
        echo "LoadModule lua_module modules/mod_lua.so" >${waf}
    fi

    # del .so
    if [ -f ${pluginPath}/total_main.so ]; then
        rm -rf ${pluginPath}/total_main.so
    fi
}

Install_Total() {
	if [ -f /www/server/panel/vhost/nginx/btwaf.conf ];then
		grep "log_by_lua_file" /www/server/panel/vhost/nginx/btwaf.conf >> /dev/null
		if [ "$?" -eq 0 ];then
			echo "旧版本监控报表于新版本的防火墙存在冲突,建议使用新版本的监控报表、此版本已经停止维护"
			echo '5秒后结束安装进程！！！！'
			if [ -f /www/server/panel/vhost/nginx/total.conf ];then
				chattr -i /www/server/panel/vhost/nginx/total.conf
				sleep 0.5
				rm -rf /www/server/panel/vhost/nginx/total.conf
			fi
			sleep 5
			echo '安装失败,旧版本监控报表于新版本的防火墙存在冲突,建议使用新版本的监控报表、此版本已经停止维护' > $install_tmp
			exit 1
		fi
	fi

    mkdir -p ${total_path}
    mkdir -p ${libraryPath}

    Get_Public
    Install_Lib
    Install_Environment

    cd /tmp || {
        mkdir -p /tmp
        cd /tmp
    }

    echo ${tip3} >${install_tmp}
    Init_Total

    # reload
    if [ -f /etc/init.d/httpd ]; then
        /etc/init.d/httpd restart
    else
        /etc/init.d/nginx restart
#        cat /www/server/nginx/logs/nginx.pid | xargs kill -HUP
    fi

    # echo errors
    if [ ${#wrong_actions[*]} -gt 0 ]; then
        echo ${tip11}
        for ((i = 0; i < ${#wrong_actions[@]}; i++)); do
            echo ${wrong_actions[i]}
        done
        echo "Error:安装失败"
    else
        # success
        if [ ! -f ${pluginPath}/info.json ]; then
            Download_File ${pluginPath}/info.json ${download_Url}/install/plugin/${remote_dir}/info.json 5 3
        fi
        echo ${tip7}
        echo ${tip7} >${install_tmp}
        echo >/www/server/panel/data/reload.pl
        echo "Successify"
    fi
}

UnInstall_Total() {
    if [ -f /etc/init.d/httpd ]; then
        if [ -f ${total_path}/uninstall.lua ]; then
            lua ${total_path}/uninstall.lua
        fi
    fi

    if Command_Exists btpython; then
        btpython ${pluginPath}/total_task.py remove
    else
        python ${pluginPath}/total_task.py remove
    fi

    chkconfig --level 2345 bt_total_init off

    cd /tmp || {
        mkdir -p /tmp
        cd /tmp
    }

    rm -rf ${total_path}
    rm -f /www/server/panel/vhost/apache/total.conf
    rm -f /www/server/panel/vhost/nginx/total.conf
    rm -rf ${pluginPath}

    rm -f /etc/init.d/bt_total_init
    rm -f /usr/bin/bt_total_init

    if [ -f /etc/init.d/httpd ]; then
        if [ ! -d /www/server/panel/plugin/btwaf_httpd ]; then
            rm -f /www/server/panel/vhost/apache/btwaf.conf
        fi
        /etc/init.d/httpd restart
    else
        /etc/init.d/nginx restart
    fi
}

if [ "${1}" == 'install' ]; then
    Install_Total
elif [ "${1}" == 'update' ]; then
    Install_Total
elif [ "${1}" == 'uninstall' ]; then
    UnInstall_Total
fi
