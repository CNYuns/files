# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyleft (c) 2015-2099 宝塔软件(http://bt.cn) All lefts reserved.
# +-------------------------------------------------------------------
# | Author: wzz
# | email : help@bt.cn
# +-------------------------------------------------------------------
# +-------------------------------------------------------------------
# | 堡塔网站统计模型 - 模型调用入口
# +-------------------------------------------------------------------
from flask import request, g, session, Response as Resp
from werkzeug.wrappers import Response

import os
import sys

os.chdir("/www/server/panel")
sys.path.insert(0, "class/")

import public


# json_header = {'Content-Type': 'application/json; charset=utf-8'}


class TotalController:

    # 网站统计模型
    def total_module(self, get):
        '''
        网站统计模型
        @param get: get.mod_name & get.def_name
        @return:
        '''
        # print("get: ", get)
        print("get.mod_name: ", get.mod_name)
        print("get.def_name: ", get.def_name)
        from .manageController import Controller
        controller_obj = Controller()

        defs = ('model',)
        get.model_index = 'total'
        get.action = 'model'
        # result = controller_obj.model(args=get)
        return self.public_object(controller_obj, defs, None, get)

    @staticmethod
    def get_input():

        data = public.dict_obj()
        exludes = ['blob']

        for key in request.args.keys():
            data.set(key, str(request.args.get(key, '')))
        try:
            for key in request.form.keys():
                if key in exludes: continue
                data.set(key, str(request.form.get(key, '')))
        except:
            try:
                post = request.form.to_dict()
                for key in post.keys():
                    if key in exludes: continue
                    data.set(key, str(post[key]))
            except:
                pass

        if 'form_data' in g:
            for k in g.form_data.keys():
                data.set(k, str(g.form_data[k]))

        if not hasattr(data, 'data'): data.data = []
        return data

    def public_object(self, toObject, defs, action=None, get=None, is_csrf=True):
        # try:
        # 模块访问前置检查
        if is_csrf and public.get_csrf_sess_html_token_value() and session.get('login', None):
            if not self.check_csrf():
                # return public.ReturnJson(False, 'INIT_CSRF_ERR'), json_header
                return public.ReturnJson(False, 'INIT_CSRF_ERR')

        if not get:
            # print("get is None")
            get = self.get_input()
            # print(get.__dict__)
            # print(toObject.__dict__)
        if action:
            get.action = action

        if hasattr(get, 'path'):
            get.path = get.path.replace('//', '/').replace('\\', '/')
            if get.path.find('./') != -1:
                # return public.ReturnJson(False, 'INIT_PATH_NOT_SAFE'), json_header
                return public.ReturnJson(False, 'INIT_PATH_NOT_SAFE')
            if get.path.find('->') != -1:
                get.path = get.path.split('->')[0].strip()
            get.path = public.xssdecode(get.path)
        if hasattr(get, 'filename'):
            get.filename = public.xssdecode(get.filename)

        if hasattr(get, 'sfile'):
            get.sfile = get.sfile.replace('//', '/').replace('\\', '/')
            get.sfile = public.xssdecode(get.sfile)
        if hasattr(get, 'dfile'):
            get.dfile = get.dfile.replace('//', '/').replace('\\', '/')
            get.dfile = public.xssdecode(get.dfile)

        if hasattr(toObject, 'site_path_check'):
            if not toObject.site_path_check(get):
                # return public.ReturnJson(False, 'INIT_ACCEPT_NOT'), json_header
                return public.ReturnJson(False, 'INIT_ACCEPT_NOT')
        res = RunExec.run(toObject, defs, get)
        return res
        # except Exception as ex:
        #     print(ex)
        #     return self.error_500(None)
        # finally:
        #     del toObject
        #     del get

    @staticmethod
    def error_500(e):
        if request.method not in ['GET', 'POST']: return Response(status=500)
        if not session.get('login', None):
            g.auth_error = True
            return public.error_not_login()
        ss = '''404 Not Found: The requested URL was not found on the server. If you entered the URL manually please check your spelling and try again.

During handling of the above exception, another exception occurred:'''
        error_info = public.get_error_info().strip().split(ss)[-1].strip()
        _form = request.form.to_dict()
        if 'username' in _form: _form['username'] = '******'
        if 'password' in _form: _form['password'] = '******'
        if 'phone' in _form: _form['phone'] = '******'
        request_info = '''REQUEST_DATE: {request_date}
 PAN_VERSION: {panel_version}
  OS_VERSION: {os_version}
 REMOTE_ADDR: {remote_addr}
 REQUEST_URI: {method} {full_path}
REQUEST_FORM: {request_form}
  USER_AGENT: {user_agent}'''.format(
            request_date=public.getDate(),
            remote_addr=public.GetClientIp(),
            method=request.method,
            full_path=public.xsssec(request.full_path),
            request_form=public.xsssec(str(_form)),
            user_agent=public.xsssec(request.headers.get('User-Agent')),
            panel_version=public.version(),
            os_version=public.get_os_version()
        )
        error_title = error_info.split("\n")[-1].replace('public.PanelError: ', '').strip()
        if error_info.find('连接云端服务器失败') != -1: error_title = "连接云端服务器失败!"
        result = public.readFile(public.get_panel_path() + '/BTPanel/templates/default/panel_error.html').format(
            error_title=error_title,
            request_info=request_info,
            error_msg=error_info
        )
        return Resp(result, 500)

    @staticmethod
    def check_csrf():
        # CSRF校验
        # if app.config['DEBUG']: return True
        http_token = request.headers.get('x-http-token')
        if not http_token: return False
        if http_token != public.get_csrf_sess_html_token_value(): return False
        return True


class RunExec:
    # 模块访问对像
    @staticmethod
    def run(toObject, defs, get):
        if get.action not in defs:
            return public.ReturnJson(False, 'ARGS_ERR')
        result = getattr(toObject, get.action)(get)
        if not hasattr(get, 'html') and not hasattr(get, 's_module'):
            r_type = type(result)
            # print("r_type: ",r_type)
            if r_type in [Response, Resp]:
                return result
        #     result = public.GetJson(result), json_header
        #
        # if g.is_aes:
        #     result = public.aes_encrypt(result[0], g.aes_key), json_header
        return result
