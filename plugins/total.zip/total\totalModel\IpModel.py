# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyleft (c) 2015-2099 宝塔软件(http://bt.cn) All lefts reserved.
# +-------------------------------------------------------------------
# | Author: wzz
# | email : help@bt.cn
# +-------------------------------------------------------------------
# +-------------------------------------------------------------------
# | 堡塔网站统计模型 - 蜘蛛分析模型
# +-------------------------------------------------------------------

import os
import sys

panelPath = '/www/server/panel'
sys.path.insert(0, panelPath)
os.chdir(panelPath)
if not panelPath + "/class/" in sys.path:
    sys.path.insert(0, panelPath + "/class/")

from totalModel.BaseModel import BaseModel
from BTPanel import cache


class IpModel(BaseModel):

    def __init__(self):
        super().__init__()
        self.total_db_name = "total.db"
        self.s_param_obj = None

    def get_ip_location(self, get):
        """
        获取ip归属地信息
        @param get:
        @return:
        """
        ip_location_result = {"locations": self._get_ip_location(get)}
        if not ip_location_result["locations"]:
            return {
                'locations': [],
                'result_dict': {},
                'city_request': {},
                'pv_sum': {},
                'uv_sum': {},
                'ip_count': {},
                'operator': {}
            }

        ip_location_result["city_request"] = self._get_ip_count_result(ip_location_result)
        ip_location_result["pv_sum"] = self._get_ip_count_result(ip_location_result, 1)
        ip_location_result["uv_sum"] = self._get_ip_count_result(ip_location_result, 2)
        ip_location_result["ip_count"] = self._get_ip_count_result(ip_location_result, 3)
        ip_location_result["operator"] = self._get_ip_count_result(ip_location_result, 4)

        return ip_location_result

    def _get_ip_count_result(self, ip_location_result, query_key=0) -> dict:
        """
        获取ip的请求/pv/uv总和信息
        @param ip_location_result:
        @return:
        """
        result_dict = {}
        key_tuple = ("request", "pv", "uv", "ip_count", "operator")

        if not ip_location_result["locations"]:
            ip_location_result["result_dict"] = result_dict
            return ip_location_result

        for ip_data in ip_location_result["locations"]:
            if "count" not in result_dict:
                result_dict['count'] = {}

            if query_key == 4:
                if ip_data["operator"] not in result_dict['count']:
                    result_dict['count'][ip_data["operator"]] = 0
                result_dict['count'][ip_data["operator"]] += 1
                continue

            if ip_data["country"] == "中国":
                if ip_data["province"] + ip_data["city"] not in result_dict['count']:
                    result_dict['count'][ip_data["province"] + ip_data["city"]] = 0

                if query_key == 3:
                    result_dict['count'][ip_data["province"] + ip_data["city"]] += 1
                else:
                    result_dict['count'][ip_data["province"] + ip_data["city"]] += ip_data[key_tuple[query_key]]

                if result_dict['count'][ip_data["province"] + ip_data["city"]] == 0:
                    result_dict['count'][ip_data["province"] + ip_data["city"]] = 1
            else:
                if ip_data["country"] not in result_dict['count']:
                    result_dict['count'][ip_data["country"]] = 0

                if query_key == 3:
                    result_dict['count'][ip_data["country"]] += 1
                else:
                    result_dict['count'][ip_data["country"]] += ip_data[key_tuple[query_key]]

                if result_dict['count'][ip_data["country"]] == 0:
                    result_dict['count'][ip_data["country"]] = 1

        return self._sorted_to_dict(result_dict)

    def _get_ip_count_result_old(self, ip_location_result, query_key=0) -> dict:
        """
        获取ip的请求/pv/uv总和信息
        @param ip_location_result:
        @return:
        """
        result_dict = {}
        key_tuple = ("request", "pv", "uv", "ip_count", "operator")

        if not ip_location_result["locations"]:
            ip_location_result["result_dict"] = result_dict
            return ip_location_result

        for ip_data in ip_location_result["locations"]:
            if ip_data["time"] not in result_dict:
                result_dict[ip_data["time"]] = {}

            if query_key == 4:
                if ip_data["operator"] not in result_dict[ip_data["time"]]:
                    result_dict[ip_data["time"]][ip_data["operator"]] = 0
                result_dict[ip_data["time"]][ip_data["operator"]] += 1
                continue

            if ip_data["country"] == "中国":
                if ip_data["province"] + ip_data["city"] not in result_dict[ip_data["time"]]:
                    result_dict[ip_data["time"]][ip_data["province"] + ip_data["city"]] = 0

                if query_key == 3:
                    result_dict[ip_data["time"]][ip_data["province"] + ip_data["city"]] += 1
                else:
                    result_dict[ip_data["time"]][ip_data["province"] + ip_data["city"]] += ip_data[key_tuple[query_key]]

                if result_dict[ip_data["time"]][ip_data["province"] + ip_data["city"]] == 0:
                    result_dict[ip_data["time"]][ip_data["province"] + ip_data["city"]] = 1
            else:
                if ip_data["country"] not in result_dict[ip_data["time"]]:
                    result_dict[ip_data["time"]][ip_data["country"]] = 0

                if query_key == 3:
                    result_dict[ip_data["time"]][ip_data["country"]] += 1
                else:
                    result_dict[ip_data["time"]][ip_data["country"]] += ip_data[key_tuple[query_key]]

                if result_dict[ip_data["time"]][ip_data["country"]] == 0:
                    result_dict[ip_data["time"]][ip_data["country"]] = 1

        return self._sorted_to_dict(result_dict)

    def _sorted_to_dict(self, result_dict):
        """
        将排序后的数据转换成字典
        @param result_dict:
        @return:
        """
        for result in result_dict:
            if type(result_dict[result]) == dict:
                result_dict[result] = self._sorted_to_dict(result_dict[result])

        result_dict = dict(
            sorted(
                result_dict.items(),
                key=lambda x: x[1] if type(x[1]) != dict else x[0],
                reverse=True
            )
        )

        # 只返回top10
        return dict(list(result_dict.items())[0:10])

    def _get_ip_location(self, get):
        """
        根据时间获取ip归属地所有信息
        @param get:
        @return:
        """
        self.s_param_obj = self.construction_param(get)
        # not_today = self.get_not_today(self.s_param_obj)
        #
        # cache_key = "ip_location_cache_{}_{}_{}_{}".format(
        #     self.s_param_obj.site_name,
        #     self.s_param_obj.query_time,
        #     self.s_param_obj.spider_type,
        #     self.s_param_obj.area_type
        # )

        # if not_today:
        #     ip_location_result = cache.get(cache_key)
        #     if ip_location_result:
        #         return ip_location_result

        ts = self.init_ts(self.s_param_obj.site_name, self.total_db_name)
        where_str = "time between ? and ?"

        if self.s_param_obj.area_type == "province":
            where_str += " AND country like '中国'"
        if self.s_param_obj.spider_type != "all":
            where_list = []
            query_fields = self.s_param_obj.spider_type.split(",")
            for field in query_fields:
                where_list.append(str(self.spider_table[field]))
            where_str += " AND is_spider in ({})".format(",".join(where_list))

        if not ts: return []

        self.s_param_obj.start_date, self.s_param_obj.end_date = self.get_query_date(
            self.s_param_obj.query_time
        )
        self.s_param_obj.start_date = str(self.s_param_obj.start_date)[0:8]
        self.s_param_obj.end_date = str(self.s_param_obj.end_date)[0:8]
        ts.table("ip_areas_stat").where(where_str, (self.s_param_obj.start_date, self.s_param_obj.end_date))
        ip_data_result = ts.select()

        if type(ip_data_result) != list: return []

        # if not_today: cache.set(cache_key, ip_data_result, 86400)

        return ip_data_result
