# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyleft (c) 2015-2099 宝塔软件(http://bt.cn) All lefts reserved.
# +-------------------------------------------------------------------
# | Author: wzz
# | email : help@bt.cn
# +-------------------------------------------------------------------
# +-------------------------------------------------------------------
# | 堡塔网站统计模型 - 网站日志分析模型
# +-------------------------------------------------------------------
import os
import sys
from typing import List, Any, Dict, Union

panelPath = '/www/server/panel'
sys.path.insert(0, panelPath)
os.chdir(panelPath)
if not panelPath + "/class/" in sys.path:
    sys.path.insert(0, panelPath + "/class/")
import public

from totalModel.BaseModel import BaseModel


class SiteLogsModel(BaseModel):

    def __init__(self):
        super().__init__()
        self.total_db_name = "total.db"
        self.s_param_obj = None

    def get_total_overview_data(self, get) -> dict:
        '''
        获取蜘蛛概览数据
        @param get:
        @return:
        '''
        total_overview_data = {}

        query_time = ["today", "yesterday"]
        for q_time in query_time:
            get.query_time = q_time
            total_overview_data[q_time] = self._get_total_overview_data(get)

        public.set_module_logs("totalModel", "get_total_overview_data")
        return total_overview_data

    def _get_total_overview_data(self, get):
        """
        获取网站概览数据
        @param get:
        @return:
        """
        self.s_param_obj = self.construction_param(get)

        self.s_param_obj.start_date, self.s_param_obj.end_date = self.get_query_date(
            self.s_param_obj.query_time
        )

        site_overview_info = self.get_site_overview_sum_data(
            self.s_param_obj.site_name, self.s_param_obj.start_date, self.s_param_obj.end_date
        )

        if type(site_overview_info) != dict: return {}

        return {
            "pv": site_overview_info["pv"],
            "uv": site_overview_info["uv"],
            "ip": site_overview_info["ip"],
            "length": site_overview_info["length"],
            "req": site_overview_info["req"],
            "spider_count": {
                "count": site_overview_info["spider"] + site_overview_info["fake_spider"],
                "spider": site_overview_info["spider"],
                "fake_spider": site_overview_info["fake_spider"]
            },
            "error_count": {
                "count": site_overview_info["s50x"] + site_overview_info["s40x"],
                "s50x": site_overview_info["s50x"],
                "s40x": site_overview_info["s40x"]
            },
        }

    def get_total_overview_realtime_data(self, get):
        """
        获取网站实时数据
        @param get:
        @return:
        """
        self.s_param_obj = self.construction_param(get)
        realtime_request = self.get_realtime_request(site=self.s_param_obj.site_name)
        realtime_traffic = self.get_realtime_traffic(site=self.s_param_obj.site_name)

        return {
            "realtime_request": sum([i["req"] for i in realtime_request]),
            "realtime_traffic": sum([i["flow"] for i in realtime_traffic])
        }

    def get_visitor_trend_data(self, get):
        """
        获取网站访客趋势数据
        visitor
        @param get:
        @return:
        """
        self.s_param_obj = self.construction_param(get)

        self.s_param_obj.start_date, self.s_param_obj.end_date = self.get_query_date(
            self.s_param_obj.query_time
        )
        query_date = "{}-{}".format(self.s_param_obj.start_date, self.s_param_obj.end_date)

        ts = self.init_ts(self.s_param_obj.site_name, self.total_db_name)

        allow_target = ["pv", "uv", "ip", "req", "length", "spider", "fake_spider", "s50x", "s40x"]
        if self.s_param_obj.target not in allow_target: return {"query_date": query_date, "data": []}

        if self.s_param_obj.time_scale == "hour":
            ts.table("request_stat").field("time," + self.s_param_obj.target)
            ts.where("time between ? and ?", (self.s_param_obj.start_date, self.s_param_obj.end_date))
            ts.order("time")
        elif self.s_param_obj.time_scale == "day":
            sum_fields = "sum(" + self.s_param_obj.target + ") as " + self.s_param_obj.target
            sum_fields = "time/100 as time1," + sum_fields
            ts.table("request_stat").groupby("time1").field(sum_fields)
            ts.where("time between ? and ?", (self.s_param_obj.start_date, self.s_param_obj.end_date))
            ts.order("time1")

        data = ts.select()

        if type(data) != list: return {"query_date": query_date, "data": []}

        if self.s_param_obj.time_scale == "day":
            for d in data:
                d["time"] = d["time1"]
                del d["time1"]

        return {"query_date": query_date, "data": data}

    def get_status_code_statistics(self, get) -> Dict[str, Union[List[Any], str]]:
        '''
        获取蜘蛛状态码统计数据
        @param get:
        @return:
        '''
        self.s_param_obj = self.construction_param(get)

        ts = self.init_ts(self.s_param_obj.site_name, self.total_db_name)
        query_fields = "time,status_code,sum(request) AS request"

        if self.s_param_obj.spider_type == "all":
            for field in self.spider_fields:
                query_fields += ",sum({}) AS {}".format(field, field)
        else:
            self.s_param_obj.spider_type = self.s_param_obj.spider_type.split(",")
            for field in self.s_param_obj.spider_type:
                query_fields += ",sum({} AS {})".format(field, field)

        self.s_param_obj.start_date, self.s_param_obj.end_date = self.get_query_date(
            self.s_param_obj.query_time
        )

        query_date = "{}-{}".format(self.s_param_obj.start_date, self.s_param_obj.end_date)

        where_str = "time between ? and ?"

        if self.s_param_obj.status_code != "all":
            self.s_param_obj.status_code = self.s_param_obj.status_code.split(",")
            where_str += " AND status_code in ({})".format(",".join(self.s_param_obj.status_code))

        where_list = [self.s_param_obj.start_date, self.s_param_obj.end_date]
        if not ts: return {"query_date": query_date, "data": []}

        ts.table("status_code_stat").field(query_fields).where(where_str, where_list)
        ts.groupby("time,status_code").order("time")
        status_code_statistics = ts.select()

        if type(status_code_statistics) != list: return {"query_date": query_date, "data": []}

        return {"query_date": query_date, "data": status_code_statistics}
