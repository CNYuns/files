# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyleft (c) 2015-2099 宝塔软件(http://bt.cn) All lefts reserved.
# +-------------------------------------------------------------------
# | Author: wzz
# | email : help@bt.cn
# +-------------------------------------------------------------------
# +-------------------------------------------------------------------
# | 堡塔网站统计模型 - 管理控制器
# +-------------------------------------------------------------------
import os, public, json, re


class Controller:

    @staticmethod
    def model(args):
        '''
        调用指定项目模型
        @author wzz<2023-04-01>
        @param args<dict_obj> {
                mod_name: string<模型名称>
                def_name: string<方法名称>
                data: JSON
            }
        @return:
        '''
        # print("model args: ", args.__dict__)
        try:  # 表单验证
            if args['mod_name'] in ['base']:
                return public.return_status_code(1000, '错误的调用!')
            public.exists_args('def_name,mod_name', args)
            if args['def_name'].find('__') != -1:
                return public.return_status_code(1000, '调用的方法名称中不能包含“__”字符')
            if not re.match(r"^\w+$", args['mod_name']):
                return public.return_status_code(1000, '调用的模块名称中不能包含\w以外的字符')
            if not re.match(r"^\w+$", args['def_name']):
                return public.return_status_code(1000, '调用的方法名称中不能包含\w以外的字符')
        except Exception as e:
            print(e)
            return public.get_error_object()

        # 参数处理
        mod_name = "{}Model".format(args['mod_name'].strip())
        def_name = args['def_name'].strip()
        model_index = None
        if 'model_index' in args: model_index = args['model_index']

        # 指定模型是否存在
        mod_file = "{}/total/totalModel/{}.py".format(public.get_plugin_path(), mod_name)
        if not os.path.exists(mod_file):
            return public.return_status_code(1003, mod_name)
        # 实例化
        def_object = public.get_script_object(mod_file)
        if not def_object: return public.return_status_code(1000, '没有找到{}模型'.format(mod_name))
        # 实例化对象名称
        def_object_name = '{}'.format(mod_name)
        class_obj = getattr(def_object, def_object_name, None)
        # 实例化main 对象
        run_object = getattr(class_obj(), def_name, None)
        # print("run_object: ", run_object)
        if not run_object: return public.return_status_code(1000, '没有在{}模型中找到{}方法'.format(mod_name, def_name))

        if not hasattr(args, 'data'): args.data = {}
        if args.data:
            if isinstance(args.data, str):
                try:  # 解析为dict_obj
                    pdata = public.to_dict_obj(json.loads(args.data))
                except:
                    return public.get_error_object()
            else:
                pdata = args.data
        else:
            pdata = args

        if isinstance(pdata, dict):
            pdata = public.to_dict_obj(pdata)

        if not isinstance(pdata, public.dict_obj):
            return public.return_error("传递的参数不是通用的内部对象")

        # 告诉加载器，要加载什么模块
        if model_index: pdata.model_index = model_index

        # 前置HOOK
        hook_index = '{}_{}_LAST'.format(mod_name.upper(), def_name.upper())
        hook_result = public.exec_hook(hook_index, pdata)
        if isinstance(hook_result, public.dict_obj):
            pdata = hook_result  # 桥接
        elif isinstance(hook_result, dict):
            return hook_result  # 响应具体错误信息
        elif isinstance(hook_result, bool):
            if not hook_result:  # 直接中断操作
                return public.return_data(False, {}, error_msg='前置HOOK中断操作')

        # 调用处理方法
        result = run_object(pdata)

        # 后置HOOK
        hook_index = '{}_{}_END'.format(mod_name.upper(), def_name.upper())
        hook_data = public.to_dict_obj({
            'args': pdata,
            'result': result
        })
        hook_result = public.exec_hook(hook_index, hook_data)
        if isinstance(hook_result, dict):
            result = hook_result['result']
        # print("result: ", result)
        return result
