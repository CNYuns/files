# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyleft (c) 2015-2099 宝塔软件(http://bt.cn) All lefts reserved.
# +-------------------------------------------------------------------
# | Author: wzz
# | email : help@bt.cn
# +-------------------------------------------------------------------
# +-------------------------------------------------------------------
# | 堡塔网站统计模型 -
# +-------------------------------------------------------------------
import datetime
import time
import os
import sys
import json

panelPath = '/www/server/panel'
sys.path.insert(0, panelPath)
os.chdir(panelPath)
if not panelPath + "/class/" in sys.path:
    sys.path.insert(0, panelPath + "/class/")

import public


class BaseModel:

    def __init__(self):
        self.total_db_name = "total.db"
        self._total_data_path = "/www/server/total"
        self.spider_fields = ["bytes", "bing", "soso", "yahoo", "sogou", "google", "baidu", "qh360", "youdao",
                              "yandex", "dnspod", "yisou", "mpcrawler", "duckduckgo", "fake_spider", "other"]
        self.spider_fields_numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 77]
        self.spider_table = {
            "baidu": 1,
            "bing": 2,
            "qh360": 3,
            "google": 4,
            "bytes": 5,
            "sogou": 6,
            "youdao": 7,
            "soso": 8,
            "dnspod": 9,
            "yandex": 10,
            "yisou": 11,
            "other": 12,
            "mpcrawler": 13,
            "yahoo": 14,
            "duckduckgo": 15,
            "fake_spider": 77
        }
        self.spider_table_reverse = {
            1: "baidu",
            2: "bing",
            3: "qh360",
            4: "google",
            5: "bytes",
            6: "sogou",
            7: "youdao",
            8: "soso",
            9: "dnspod",
            10: "yandex",
            11: "yisou",
            12: "other",
            13: "mpcrawler",
            14: "yahoo",
            15: "duckduckgo",
            77: "fake_spider"
        }
        self.status_code_20x = [200, 201, 202, 203, 204, 205, 206, 207, 208, 226]
        self.status_code_30x = [300, 301, 302, 303, 304, 305, 306, 307, 308]
        self.status_code_40x = [400, 401, 402, 403, 404, 405, 406, 407, 408, 409]
        self.status_code_50x = [500, 501, 502, 503, 504, 505, 506, 507, 509]
        self.status_code_5xx = [500, 501, 502, 503, 504, 505, 506, 507, 509, 510]
        self.status_code_4xx = [400, 401, 402, 403, 404, 405, 406, 407, 408, 409,
                                410, 411, 412, 413, 414, 415, 416, 417, 418, 421,
                                422, 423, 424, 425, 426, 449, 451, 499]

    @staticmethod
    def get_time_interval(local_time):
        time_key_format = "%Y%m%d00"
        start = int(time.strftime(time_key_format, local_time))
        time_key_format = "%Y%m%d23"
        end = int(time.strftime(time_key_format, local_time))
        return start, end

    @staticmethod
    def get_timestamp_interval(local_time):
        start = time.mktime((local_time.tm_year, local_time.tm_mon, local_time.tm_mday, 0, 0, 0, 0, 0, 0))
        end = time.mktime((local_time.tm_year, local_time.tm_mon, local_time.tm_mday, 23, 59, 59, 0, 0, 0))
        return start, end

    def get_last_days(self, day):
        now = time.localtime()
        if day == 30:
            last_month = now.tm_mon - 1
            if last_month <= 0:
                last_month = 12
            import calendar
            _, last_month_days = calendar.monthrange(now.tm_year, last_month)
            day = last_month_days
        else:
            day += 1

        t1 = time.mktime(
            (now.tm_year, now.tm_mon, now.tm_mday - day, 0, 0, 0, 0, 0, 0))
        t2 = time.localtime(t1)
        start, _ = self.get_time_interval(t2)
        _, end = self.get_time_interval(now)
        return start, end

    def get_last_days_by_timestamp(self, day):
        now = time.localtime()
        if day == 30:
            last_month = now.tm_mon - 1
            if last_month <= 0:
                last_month = 12
            import calendar
            _, last_month_days = calendar.monthrange(now.tm_year, last_month)
            day = last_month_days
        else:
            day += 1

        t1 = time.mktime(
            (now.tm_year, now.tm_mon, now.tm_mday - day, 0, 0, 0, 0, 0, 0))
        t2 = time.localtime(t1)
        start, _ = self.get_timestamp_interval(t2)
        _, end = self.get_timestamp_interval(now)
        return start, end

    @staticmethod
    def get_time_key(date=None):
        if date is None:
            date = time.localtime()
        time_key = 0
        time_key_format = "%Y%m%d%H"
        if type(date) == time.struct_time:
            time_key = int(time.strftime(time_key_format, date))
        if type(date) == str:
            time_key = int(time.strptime(date, time_key_format))
        return time_key

    def get_query_date(self, query_date):
        """
        获取查询日期的时间区间
        查询日期的表示形式是以区间的格式表示，这里也考虑到了数据库里面实际存储的方式。
        在数据库里面是以小时为单位统计日志数据，所以这里的区间也是也小时来表示。
        比如表示今天，假设今天是2021/3/30，查询日期的格式是2021033000-2021033023。
        @param query_date:
        @return: 2021033000-2021033023
        """
        start_date = None
        end_date = None
        if query_date == "today":
            start_date, end_date = self.get_time_interval(time.localtime())
        elif query_date == "yesterday":
            # day - 1
            now = time.localtime()
            yes_i = time.mktime((now.tm_year, now.tm_mon, now.tm_mday - 1, 0, 0, 0, 0, 0, 0))
            yes = time.localtime(yes_i)
            start_date, end_date = self.get_time_interval(yes)
        elif query_date.startswith("l"):
            days = int(query_date[1:])
            start_date, end_date = self.get_last_days(days)
        elif query_date.startswith("this_month"):
            now = time.localtime()
            start_date = time.localtime(time.mktime((now.tm_year, now.tm_mon, 1, 0, 0, 0, 0, 0, 0)))
            start_date = self.get_time_key(start_date)
            end_date = self.get_time_key(now) + 1
        elif query_date.startswith("h1"):
            # 近1小时查询
            # hours = int(query_date[1:])
            # 如果当前小时未超过30分钟，把上一小时数据计算进来，否则只算当前一小时的数据。
            now = time.localtime()
            if now.tm_min >= 30:
                start_date = time.mktime((now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour, 0, 0, 0, 0, 0))
                start_date = self.get_time_key(start_date)
                end_date = start_date
            else:
                s = time.localtime(time.mktime((now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour - 1, 0, 0, 0, 0, 0)))
                start_date = self.get_time_key(s)
                e = time.localtime(time.mktime((now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour, 0, 0, 0, 0, 0)))
                end_date = self.get_time_key(e)
        else:
            if query_date.find("-") >= 0:
                s, e = query_date.split("-")
                start_time = time.strptime(s.strip(), "%Y%m%d")
                start_date, _ = self.get_time_interval(start_time)
                end_time = time.strptime(e.strip(), "%Y%m%d")
                _, end_date = self.get_time_interval(end_time)
            else:
                if query_date.isdigit():
                    s_time = time.strptime(query_date, "%Y%m%d")
                    start_date, end_date = self.get_time_interval(s_time)

        return start_date, end_date

    def get_query_timestamp(self, query_date):
        """
        获取查询日期的时间戳
        @param query_date:
        @return:
        """
        start_date = None
        end_date = None
        if query_date == "today":
            start_date, end_date = self.get_timestamp_interval(time.localtime())
        elif query_date == "yesterday":
            # day - 1
            now = time.localtime()
            yes_i = time.mktime((
                now.tm_year, now.tm_mon, now.tm_mday - 1, 0,
                0, 0, 0, 0, 0))
            yes = time.localtime(yes_i)
            start_date, end_date = self.get_timestamp_interval(yes)
        elif query_date.startswith("l"):
            days = int(query_date[1:])
            start_date, end_date = self.get_last_days_by_timestamp(days)
        elif query_date.startswith("h1"):
            # 近1小时查询
            # hours = int(query_date[1:])
            # 如果当前小时未超过30分钟，把上一小时数据计算进来，否则只算当前一小时的
            # 数据。
            now = time.localtime()
            start_date = time.mktime((now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour, now.tm_min - 60, 0, 0, 0, 0))
            end_date = time.mktime(now)
        else:
            if query_date.find("-") < 0:
                if query_date.isdigit():
                    s_time = time.strptime(query_date, "%Y%m%d")
                    start_date, end_date = self.get_timestamp_interval(s_time)
            else:
                s, e = query_date.split("-")
                if s[-6:] == "000000" and e[-6:] == "000000":
                    s = s[:-6]
                    e = e[:-6]
                    start_time = time.strptime(s.strip(), "%Y%m%d")
                    end_time = time.strptime(e.strip(), "%Y%m%d")
                    start_date, _ = self.get_timestamp_interval(start_time)
                    _, end_date = self.get_timestamp_interval(end_time)
                else:
                    start_time = time.strptime(s.strip(), "%Y%m%d%H%M%S")
                    end_time = time.strptime(e.strip(), "%Y%m%d%H%M%S")
                    start_date = time.mktime(start_time)
                    end_date = time.mktime(end_time)

        return start_date, end_date

    def split_query_date(self, start_timestamp, end_timestamp=None):
        """倒着写"""
        start = time.localtime(end_timestamp)
        query_list = []
        while True:
            s, e = self.get_timestamp_interval(start)
            if e > end_timestamp: e = end_timestamp
            if s < start_timestamp: s = start_timestamp
            query_list.append((s, e))
            start = time.localtime(time.mktime((start.tm_year, start.tm_mon, start.tm_mday - 1, 0, 0, 0, 0, 0, 0)))
            if s <= start_timestamp: break
        return query_list

    def get_compare_date(self, query_start_date, compare_date):
        """获取对比日期"""
        start_date = time.strptime(str(query_start_date), "%Y%m%d%H")
        end_date = None
        if compare_date == "yesterday":
            yes_i = time.mktime((start_date.tm_year, start_date.tm_mon, start_date.tm_mday - 1, 0, 0, 0, 0, 0, 0))
            yes = time.localtime(yes_i)
            start_date, end_date = self.get_time_interval(yes)
        elif compare_date == "lw":
            week_i = time.mktime((start_date.tm_year, start_date.tm_mon, start_date.tm_mday - 7, 0, 0, 0, 0, 0, 0))
            week = time.localtime(week_i)
            start_date, end_date = self.get_time_interval(week)
        elif compare_date == "h1":
            now = time.localtime()
            if now.tm_min >= 30:
                start_date = time.mktime((now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour - 1, 0, 0, 0, 0, 0))
                start_date = self.get_time_key(start_date)
                end_date = start_date
            else:
                s = time.localtime(time.mktime((now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour - 2, 0, 0, 0, 0, 0)))
                start_date = self.get_time_key(s)
                end_date = start_date
        else:
            if compare_date.find("-") < 0:
                if compare_date.isdigit():
                    s_time = time.strptime(compare_date, "%Y%m%d")
                    start_date, end_date = self.get_time_interval(s_time)
            else:
                # print("区间时间：", compare_date)
                s, e = compare_date.split("-")
                start_time = time.strptime(s.strip(), "%Y%m%d")
                start_date, _ = self.get_time_interval(start_time)
                end_time = time.strptime(e.strip(), "%Y%m%d")
                _, end_date = self.get_time_interval(end_time)

        return start_date, end_date

    def init_ts(self, site, db_name):
        '''
        初始化ts对象
        @param site:
        @param db_name:
        @return:
        '''
        from total_base import totalBase
        totalBase = totalBase()
        return totalBase.init_ts(site, db_name)

    @staticmethod
    def get_file_json(filename, defaultv={}):
        try:
            if not os.path.exists(filename):
                return defaultv
            return json.loads(public.readFile(filename))
        except:
            os.remove(filename)
            return defaultv

    @staticmethod
    def get_logs_db_name(date=None):
        if date is None:
            date = time.localtime()
        time_format = "%Y%m%d"
        return time.strftime(time_format, date) + "_spider.db"

    def get_site_settings(self, site):
        """
        获取站点配置
        @param site:
        """
        config_path = "/www/server/total/config.json"
        config = self.get_file_json(config_path)

        if site not in config.keys():
            res_config = config["global"]
            res_config["push_report"] = False
        else:
            res_config = config[site]

        for k, v in config["global"].items():
            if k not in res_config.keys():
                if k == "push_report":
                    res_config[k] = False
                else:
                    res_config[k] = v
        return res_config

    def get_history_data_dir(self):
        default_history_data_dir = os.path.join(self._total_data_path, "logs")
        settings = self.get_site_settings("global")
        if "history_data_dir" in settings.keys():
            config_data_dir = settings["history_data_dir"]
        else:
            config_data_dir = default_history_data_dir
        history_data_dir = default_history_data_dir if not config_data_dir else config_data_dir
        return history_data_dir

    def get_logs_db_name_by_timestamp(self, site, start_timestamp, end_timestamp):
        """
        根据查询时间查找对应的日志db文件
        start_timestamp (timestamp): 起始时间戳
        end_timestamp (timestamp): 截止时间戳
        @param end_timestamp:
        @param start_timestamp:
        @param site:
        """
        base_dir = "/www/server/total/logs/{}/".format(site)
        normal_db_name = self.get_logs_db_name(time.localtime(start_timestamp))
        except_db_path = os.path.join(base_dir, normal_db_name)
        if os.path.exists(except_db_path):
            return except_db_path
        history_base_dir = self.get_history_data_dir()
        except_db_path = os.path.join(history_base_dir, site, normal_db_name)
        if os.path.exists(except_db_path):
            return except_db_path

        info_file = base_dir + "logs.info"
        log_info_str = public.readFile(info_file)
        if log_info_str:
            log_info = json.loads(log_info_str)
            for fkey, info in log_info.items():
                if not type(info) == dict: continue
                start = info["start"]
                end = info["end"]
                match = False
                if start_timestamp >= start and end_timestamp <= end:
                    match = True
                else:
                    bokeh_start, _ = self.get_timestamp_interval(time.localtime(start))
                    _, bokeh_end = self.get_timestamp_interval(time.localtime(end))
                    if start_timestamp >= bokeh_start and end_timestamp <= bokeh_end:
                        match = True

                if match and fkey.endswith(".db"):
                    db_name = os.path.join(history_base_dir, site, info["file_name"])
                    if os.path.exists(db_name):
                        return db_name
        return ""

    @staticmethod
    def construction_param(get: dict) -> dict:
        """
        构造查询参数
        @param get:
        @return:
        """
        s_param_dict = public.dict_obj()
        s_param_dict.site_name = get.site_name if "site_name" in get else ""
        s_param_dict.spider_type = get.spider_type if "spider_type" in get else "all"
        s_param_dict.query_time = get.query_time if "query_time" in get else "today"
        s_param_dict.status_code = get.status_code if "status_code" in get else "all"
        s_param_dict.compare = get.compare if "compare" in get else "false"
        s_param_dict.compare_time = get.compare_time if "compare_time" in get else ""
        s_param_dict.dir_level = get.dir_level if "dir_level" in get else "1"
        s_param_dict.page = get.page if "page" in get else 1
        s_param_dict.page_size = get.page_size if "page_size" in get else 100
        s_param_dict.offset = (s_param_dict.page - 1) * s_param_dict.page_size
        s_param_dict.area_type = get.area_type if "area_type" in get else "all"
        s_param_dict.realtime_traffic = get.realtime_traffic if "realtime_traffic" in get else "false"
        s_param_dict.realtime_request = get.realtime_request if "realtime_request" in get else "false"
        s_param_dict.target = get.target if "target" in get else "false"
        s_param_dict.uri_type = get.uri_type if "uri_type" in get else "dir"
        s_param_dict.time_scale = "hour" if get.query_time == "today" or get.query_time == "yesterday" else "day"
        if s_param_dict.query_time.isdigit(): s_param_dict.time_scale = "hour"

        return s_param_dict

    def get_not_today(self, s_param_obj):
        """
        判断是否是今天
        @param s_param_obj:
        @return:
        """
        s_param_obj.start_timestamp, s_param_obj.end_timestamp = self.get_query_timestamp(
            s_param_obj.query_time
        )
        s_param_obj.query_dates = self.split_query_date(
            s_param_obj.start_timestamp,
            s_param_obj.end_timestamp
        )

        now_timestamp = time.time()
        return now_timestamp - s_param_obj.end_timestamp > 86400

    @staticmethod
    def get_uri_dir_level(dir_level):
        """
        获取目录层级
        @param dir_level:
        @return:
        """
        # 根据dir_level拼接where_str
        # 并且uri以/开头，但是只包含1个/的记录，即只显示1级目录的记录
        # 并且uri以/开头，但是只包含2个/的记录，即只显示2级目录的记录
        # 并且uri以/开头，但是只包含3个/的记录，即只显示3级目录的记录
        # 并且uri以/开头，但是包含4个/以上的记录
        if dir_level == "1":
            where_str = " AND URI LIKE '/%' AND URI NOT LIKE '/%/%'"
        elif dir_level == "2":
            where_str = " AND URI LIKE '/%' AND URI LIKE '/%/%' AND URI NOT LIKE '/%/%/%'"
        elif dir_level == "3":
            where_str = " AND URI LIKE '/%' AND URI LIKE '/%/%' AND URI LIKE '/%/%/%' AND URI NOT LIKE '/%/%/%/%'"
        elif dir_level == "4":
            where_str = " AND URI LIKE '/%' AND URI LIKE '/%/%' AND URI LIKE '/%/%/%' AND URI LIKE '/%/%/%/%'"
        else:
            where_str = " AND URI LIKE '/%'"

        return where_str

    def get_site_overview_sum_data(self, site, start_date, end_date):
        '''
        获取指定站点概览页的统计数据
        @param site:
        @param start_date:
        @param end_date:
        @return:
        '''
        ts = self.init_ts(site, self.total_db_name)
        sum_data = {}
        default_fields = "req,pv,uv,ip,length,spider,s50x,s40x"
        if not ts:
            for field in default_fields.split(","):
                sum_data[field] = 0
            return sum_data
        # 统计数据
        s50x_fields = ",sum(status_500+status_501+status_502+status_503+status_504+status_505+status_506+status_507+status_509+status_510) as s50x"
        s40x_fields = ",sum(status_400+status_401+status_402+status_403+status_404+status_405+status_406+status_407+status_408+status_409+status_410+status_411+status_412+status_413+status_414+status_415+status_416+status_417+status_418+status_421+status_422+status_423+status_424+status_425+status_426+status_449+status_451+status_499) as s40x"
        total_fields = "sum(req) as req, sum(pv) as pv, sum(uv) as uv, sum(ip) as ip, sum(length) as length, sum(spider) as spider, sum(fake_spider) as fake_spider"
        total_fields += s50x_fields + s40x_fields
        ts.table("request_stat").field(total_fields)
        ts.where("time between ? and ?", (start_date, end_date))
        sum_data = ts.find()

        if type(sum_data) != dict:
            sum_data = {}
            for field in default_fields.split(","):
                sum_data[field] = 0
            return sum_data

        for key, value in sum_data.items():
            if not value:
                sum_data[key] = 0
        return sum_data

    def get_realtime_request(self, site=None):
        '''
        获取实时请求数
        @param site:
        @return:
        '''
        res_data = []
        if site is not None:
            log_file = self._total_data_path + "/logs/{}/req_sec.json".format(site)
            if not os.path.isfile(log_file):
                return res_data

            datetime_now = datetime.datetime.now()
            req_data = public.readFile(log_file)
            lines = req_data.split("\n")
            for line in lines:
                if not line: continue
                try:
                    _rt_req, _write_time = line.split(",")
                    datetime_log = datetime.datetime.fromtimestamp(
                        float(_write_time))
                    datetime_interval = datetime_now - datetime_log
                    if datetime_interval.seconds < 3:
                        data = {"timestamp": _write_time, "req": int(_rt_req)}
                        res_data.append(data)

                except Exception as e:
                    print("Real-time data error:", str(e))
            if len(res_data) > 1:
                res_data.sort(key=lambda o: o["timestamp"], reverse=True)
        return res_data

    def get_realtime_traffic(self, site=None):
        '''
        获取实时流量
        @param site:
        @return:
        '''
        res_data = []
        if site is not None:
            flow_file = self._total_data_path + "/logs/{}/flow_sec.json".format(site)
            if not os.path.isfile(flow_file):
                return res_data
            flow_data = public.readFile(flow_file)
            datetime_now = datetime.datetime.now()
            lines = flow_data.split("\n")
            for line in lines:
                if not line: continue
                try:
                    _flow, _write_time = line.split(",")
                    datetime_log = datetime.datetime.fromtimestamp(
                        float(_write_time))
                    datetime_interval = datetime_now - datetime_log
                    if datetime_interval.seconds < 3:
                        data = {"timestamp": _write_time, "flow": int(_flow)}
                        res_data.append(data)

                except Exception as e:
                    print("Real-time traffic error:", str(e))
            if len(res_data) > 1:
                res_data.sort(key=lambda o: o["timestamp"], reverse=True)
        return res_data