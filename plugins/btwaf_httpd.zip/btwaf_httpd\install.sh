#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
install_tmp='/tmp/bt_install.pl'
pluginPath=/www/server/panel/plugin/btwaf_httpd
pyVersion=$(python -c 'import sys;print(sys.version_info[0]);')
py_zi=$(python -c 'import sys;print(sys.version_info[1]);')
aacher=$(uname -a |grep -Po aarch64|awk 'NR==1')
#lua_version=`lua -e "print( _G._VERSION )"`
#lua_ver=${lua_version: -1}


Get_platform()
{
    case $(uname -s 2>/dev/null) in
        Linux )                    echo "linux" ;;
        FreeBSD )                  echo "freebsd" ;;
        *BSD* )                    echo "bsd" ;;
        Darwin )                   echo "macosx" ;;
        CYGWIN* | MINGW* | MSYS* ) echo "mingw" ;;
        AIX )                      echo "aix" ;;
        SunOS )                    echo "solaris" ;;
        * )                        echo "unknown"
    esac
}

Add_path()
{
    local prefix=$1
    local new_path
    new_path=$(echo "${PATH}" | sed \
        -e "s#${prefix}/[^/]*/bin[^:]*:##g" \
        -e "s#:${prefix}/[^/]*/bin[^:]*##g" \
        -e "s#${prefix}/[^/]*/bin[^:]*##g")
    export PATH="${prefix}:${new_path}"
}

Get_lua_version(){
    echo `${install_path}/bin/lua -e 'print(_VERSION:sub(5))'`
}



Install_lua515(){
    local install_path="/usr/local/lua515"
    
    local version
    version=$(Get_lua_version)

	if [[ $version == *GLIBC* ]]; then	
		rm -rf $install_path
	fi 
    echo "Current lua version: "$version
    if  [ -d "${install_path}/bin" ]
    then
        #Add_path "${install_path}/bin"
        echo "Lua 5.1.5 has installed."
		return 1
    fi
    
    local lua_version="lua-5.1.5"
    local package_name="${lua_version}.tar.gz"
    mkdir -p $install_path
	cd $pluginPath
    tar xvzf $pluginPath/$package_name
    cd $lua_version
    platform=$(Get_platform)
    if [ "${platform}" = "unknown" ] 
    then
        platform="linux"
    fi
    make "${platform}" install INSTALL_TOP=$install_path
    #Add_path "${install_path}/bin"
    #rm -rf "${pluginPath}/${lua_version}*"

    version=$(Get_lua_version)
    if [ ${version} == "5.1" ]
    then
        echo "Lua 5.1.5 has installed."
        return 1
    fi
    return 0
}
Install_lua_530()
{
    local install_path="/usr/local/lua530"
    
    local version
    version=$(Get_lua_version)

	if [[ $version == *GLIBC* ]]; then	
		rm -rf $install_path
	fi 
    echo "Current lua version: "$version
    if  [ -d "${install_path}/bin" ]
    then
        #Add_path "${install_path}/bin"
        echo "Lua 5.3.0 has installed."
		return 1
    fi
    
    local lua_version="lua-5.3.0"
    local package_name="${lua_version}.tar.gz"
    mkdir -p $install_path
	cd $pluginPath
    tar xvzf $pluginPath/$package_name
    cd $lua_version
    platform=$(Get_platform)
    if [ "${platform}" = "unknown" ] 
    then
        platform="linux"
    fi
    make "${platform}" install INSTALL_TOP=$install_path
   # Add_path "${install_path}/bin"
    #rm -rf "${pluginPath}/${lua_version}*"

    version=$(Get_lua_version)
    if [ ${version} == "5.3" ]
    then
        echo "Lua 5.3.0 has installed."
        return 1
    fi
    return 0
}

Install_cjson515(){
	#if [ ! -f /usr/local/lib/lua/5.1/cjson.so ];then
	rm -rf $pluginPath/lua-cjson-2.1.0
	tar xvf $pluginPath/lua-cjson-2.1.0.tar.gz
	rm -f $pluginPath/lua-cjson-2.1.0.tar.gz
	cd $pluginPath/lua-cjson-2.1.0
	make clean
	make LUA_INCLUDE_DIR=/usr/local/lua515/include
	make install LUA_VERSION=5.1
	cd ..
	if [ ! -d "/usr/lib64/lua/5.1" ];then
		mkdir -p /usr/lib64/lua/5.1
	fi
	\cp -a -r /usr/local/lib/lua/5.1/cjson.so /usr/lib64/lua/5.1/cjson.so
	
	if [ ! -d "/usr/lib/lua/5.1" ];then
		mkdir -p /usr/lib/lua/5.1
	fi
	\cp -a -r /usr/local/lib/lua/5.1/cjson.so /usr/lib/lua/5.1/cjson.so
	rm -rf $pluginPath/lua-cjson-2.1.0
	#else
	#	if [ ! -d "/usr/lib64/lua/5.1" ];then
	#		mkdir -p /usr/lib64/lua/5.1
	#	fi
	#	\cp -a -r /usr/local/lib/lua/5.1/cjson.so /usr/lib64/lua/5.1/cjson.so
	#	
	#	if [ ! -d "/usr/lib/lua/5.1" ];then
	#		mkdir -p /usr/lib/lua/5.1
	#	fi
	#	\cp -a -r /usr/local/lib/lua/5.1/cjson.so /usr/lib/lua/5.1/cjson.so
	#fi
}


Install_cjson530(){

	#if [ ! -f /usr/lib64/lua/5.3/cjson.so ];then
		tar xvf $pluginPath/lua-5.3-cjson.tar.gz
		rm -f $pluginPath/lua-5.3-cjson.tar.gz
		cd $pluginPath/lua-5.3-cjson
		make clean
		make LUA_INCLUDE_DIR=/usr/local/lua530/include
		#make install LUA_VERSION=5.3
		cd ..
		#
		#如果/usr/share/lua/5.3/目录不存在，则创建
		if [ ! -d "/usr/share/lua/5.3" ];then
			mkdir -p /usr/share/lua/5.3/
		fi
		\cp -a -r $pluginPath/lua-5.3-cjson/cjson.so /usr/share/lua/5.3/cjson.so
		if [ ! -d "/usr/lib64/lua/5.3/" ];then
			mkdir -p /usr/lib64/lua/5.3/
		fi
		\cp -a -r  $pluginPath/lua-5.3-cjson/cjson.so /usr/lib64/lua/5.3/cjson.so
		if [ ! -d "/usr/lib/lua/5.3/" ];then
			mkdir -p /usr/lib/lua/5.3/
		fi
		\cp -a -r  $pluginPath/lua-5.3-cjson/cjson.so /usr/lib/lua/5.3/cjson.so
		
	    #如果/usr/lib/lua/5.3/ 目录不存在，则创建
		if [ ! -d "/usr/lib/lua/5.3" ];then
			mkdir -p /usr/lib/lua/5.3/
		fi
		\cp -a -r $pluginPath/lua-5.3-cjson/cjson.so /usr/lib/lua/5.3/cjson.so
		\cp -a -r  $pluginPath/lua-5.3-cjson/cjson.so /usr/local/lib/lua/5.3/cjson.so
		rm -rf $pluginPath/lua-5.3-cjson
	#fi
	
}

Install_socket515()
{
    rm -rf $pluginPath/luasocket-master
	if [ ! -f /usr/local/lib/lua/5.1/socket/core.so ];then
		unzip $pluginPath/luasocket-master.zip
		cd $pluginPath/luasocket-master
		make LUAINC_linux=/usr/local/lua515/include/ 
		make install
	fi
	if [ ! -d /usr/share/lua/5.1/socket ]; then
		if [ -d /usr/lib64/lua/5.1 ];then
			rm -rf /usr/lib64/lua/5.1/socket /usr/lib64/lua/5.1/mime
			ln -sf /usr/local/lib/lua/5.1/socket /usr/lib64/lua/5.1/socket
			ln -sf /usr/local/lib/lua/5.1/mime /usr/lib64/lua/5.1/mime
		else
			rm -rf /usr/lib/lua/5.1/socket /usr/lib/lua/5.1/mime
			ln -sf /usr/local/lib/lua/5.1/socket /usr/lib/lua/5.1/socket
			ln -sf /usr/local/lib/lua/5.1/mime /usr/lib/lua/5.1/mime
		fi
		rm -rf /usr/share/lua/5.1/mime.lua /usr/share/lua/5.1/socket.lua /usr/share/lua/5.1/socket
		ln -sf /usr/local/share/lua/5.1/mime.lua /usr/share/lua/5.1/mime.lua
		ln -sf /usr/local/share/lua/5.1/socket.lua /usr/share/lua/5.1/socket.lua
		ln -sf /usr/local/share/lua/5.1/socket /usr/share/lua/5.1/socket
	fi
	rm -rf $pluginPath/luasocket-master
}


Install_socket530()
{
	if [ ! -f /usr/local/lib/lua/5.3/socket.lua ];then
		rm -rf $pluginPath/luasocket-master
		cd $pluginPath &&  unzip $pluginPath/luasocket-master.zip && 
		cd $pluginPath/luasocket-master
		make LUAINC_linux=/usr/local/lua530/include/ 
		make install LUAV=5.3
	fi

}

GetModLua()
{
	#\cp -a -r /usr/local/lib/lua/5.1/cjson.so /www/server/btwaf/cjson.so
	rm -rf /www/server/btwaf/cjson.so
	rm -rf /www/server/btwaf/mycomplib.so
	if [ ! -d "/usr/share/lua/5.3" ];then
		mkdir -p /usr/share/lua/5.3/
	fi
	\cp -a -r /tmp/btwaf/mycomplib_5.3.so /usr/share/lua/5.3/mycomplib.so
	if [ ! -d "/usr/lib64/lua/5.3/" ];then
			mkdir -p /usr/lib64/lua/5.3/
	fi
	\cp -a -r  /tmp/btwaf/mycomplib_5.3.so /usr/lib64/lua/5.3/mycomplib.so
	if [ ! -d "/usr/lib/lua/5.3/" ];then
		mkdir -p /usr/lib/lua/5.3/
	fi
	\cp -a -r  /tmp/btwaf/mycomplib_5.3.so /usr/lib/lua/5.3/mycomplib.so
		
	    #如果/usr/lib/lua/5.3/ 目录不存在，则创建
	if [ ! -d "/usr/lib/lua/5.3" ];then
		mkdir -p /usr/lib/lua/5.3/
	fi
	\cp -a -r /tmp/btwaf/mycomplib_5.3.so /usr/lib/lua/5.3/mycomplib.so
	
	
	if [ ! -d "/usr/local/lib/lua/5.1/" ];then
		mkdir -p /usr/local/lib/lua/5.1/
	fi 
		
	if [ ! -d "/usr/lib/lua/5.1/" ];then
		mkdir -p /usr/lib/lua/5.1/
	fi 
		
	if [ ! -d "/usr/lib64/lua/5.1/" ];then
		mkdir -p /usr/lib64/lua/5.1/
	fi 	
	\cp -a -r /tmp/btwaf/mycomplib.so /usr/local/lib/lua/5.1/mycomplib.so
	\cp -a -r /tmp/btwaf/mycomplib.so /usr/lib/lua/5.1/mycomplib.so
	\cp -a -r /tmp/btwaf/mycomplib.so /usr/lib64/lua/5.1/mycomplib.so

	
	
}

Install_mod_lua()
{
	if [ -f /www/server/apache/modules/mod_lua.so ];then
		return 0;
	fi
	if [ ! -d /www/server/apache/src ];then
		echo '未发现/www/server/apache/src目录请重新编译Apache环境! 5秒后结束安装进程退出!';
		echo '安装失败' > $install_tmp
		sleep 5
		exit 0;
	fi
	cd /www/server/apache/src
	./configure --prefix=/www/server/apache --enable-lua
	cd /www/server/apache/src/modules/lua
	make
	make install
	if [ ! -f /www/server/apache/modules/mod_lua.so ];then
		echo '安装mod_lua模块失败! 5秒后结束安装进程退出!';
		echo 'mod_lua安装失败!';
		sleep 5
		exit 0;
	fi
}

Install_btwaf_httpd()
{	
	if [ -f /www/server/btwaf/init.lua ];then
		rm -rf /www/server/btwaf
	fi
	mkdir -p /www/server/btwaf
	Install_mod_lua
	Install_lua515
	Install_lua_530
	Install_cjson515
	Install_cjson530
	Install_socket515
	Install_socket530
	yum install lua-socket -y
	apt-get install lua-cjson -y 
	apt-get install lua-socket -y 
	mkdir -p $pluginPath
	echo '正在安装脚本文件...' > $install_tmp
	chattr -i /www/server/panel/vhost/apache/btwaf.conf
	rm -rf /www/server/panel/vhost/apache/btwaf.conf
	\cp -a -r $pluginPath/btwaf.conf /www/server/panel/vhost/apache/btwaf.conf
	unzip -o $pluginPath/btwaf.zip -d /tmp/ > /dev/null
	rm -f $pluginPath/btwaf.zip
	btwaf_httpd_path=/www/server/btwaf
	mkdir -p $btwaf_httpd_path/html
	rm -rf /www/server/btwaf/cms
	mv /tmp/btwaf/cms/  $btwaf_httpd_path
	if [ ! -f $btwaf_httpd_path/html/get.html ];then
		\cp -a -r /tmp/btwaf/html/get.html $btwaf_httpd_path/html/get.html
		\cp -a -r /tmp/btwaf/html/get.html $btwaf_httpd_path/html/post.html
		\cp -a -r /tmp/btwaf/html/get.html $btwaf_httpd_path/html/cookie.html
		\cp -a -r /tmp/btwaf/html/get.html $btwaf_httpd_path/html/user_agent.html
		\cp -a -r /tmp/btwaf/html/get.html $btwaf_httpd_path/html/other.html
	fi
	
	mkdir -p $btwaf_httpd_path/rule
	if [ ! -f $btwaf_httpd_path/rule/url.json ];then
		\cp -a -r /tmp/btwaf/rule/url.json $btwaf_httpd_path/rule/url.json
		\cp -a -r /tmp/btwaf/rule/args.json $btwaf_httpd_path/rule/args.json
		\cp -a -r /tmp/btwaf/rule/post.json $btwaf_httpd_path/rule/post.json
		\cp -a -r /tmp/btwaf/rule/cn.json $btwaf_httpd_path/rule/cn.json
		\cp -a -r /tmp/btwaf/rule/cookie.json $btwaf_httpd_path/rule/cookie.json
		\cp -a -r /tmp/btwaf/rule/head_white.json $btwaf_httpd_path/rule/head_white.json
		\cp -a -r /tmp/btwaf/rule/ip_black.json $btwaf_httpd_path/rule/ip_black.json
		\cp -a -r /tmp/btwaf/rule/ip_white.json $btwaf_httpd_path/rule/ip_white.json
		\cp -a -r /tmp/btwaf/rule/scan_black.json $btwaf_httpd_path/rule/scan_black.json
		\cp -a -r /tmp/btwaf/rule/url_black.json $btwaf_httpd_path/rule/url_black.json
		\cp -a -r /tmp/btwaf/rule/url_white.json $btwaf_httpd_path/rule/url_white.json
		\cp -a -r /tmp/btwaf/rule/user_agent.json $btwaf_httpd_path/rule/user_agent.json
		\cp -a -r /tmp/btwaf/rule/referer.json $btwaf_httpd_path/rule/referer.json
	fi
	\cp -a -r /tmp/btwaf/rule/args.json $btwaf_httpd_path/rule/args.json
	\cp -a -r /tmp/btwaf/rule/post.json $btwaf_httpd_path/rule/post.json
	\cp -a -r /tmp/btwaf/rule/referer.json /www/server/btwaf/rule/referer.json
	if [ ! -f $btwaf_httpd_path/rule/cc_uri_white.json ];then
		\cp -a -r /tmp/btwaf/rule/cc_uri_white.json $btwaf_httpd_path/rule/cc_uri_white.json
	fi
	
	if [ ! -f /dev/shm/stop_ip.json ];then
		\cp -a -r /tmp/btwaf/stop_ip.json /dev/shm/stop_ip.json
	fi
	
	chmod 777 /dev/shm/stop_ip.json
	chown www:www /dev/shm/stop_ip.json
	
	
	for fileName in 1 2 3 4 5 6 7 zhi site config total
	do
		\cp -a -r /tmp/btwaf/${fileName}.json $btwaf_httpd_path/${fileName}.json
	done
	
	if [ ! -f $btwaf_httpd_path/drop_ip.log ];then
		\cp -a -r /tmp/btwaf/drop_ip.log $btwaf_httpd_path/drop_ip.log
	fi
	\cp -a -r /tmp/btwaf/8.6.lua $btwaf_httpd_path/httpd.lua
	\cp -a -r /tmp/btwaf/zhi.lua $btwaf_httpd_path/zhi.lua
	GetModLua
	Centos6Check=$(cat /etc/redhat-release | grep ' 6.' | grep -iE 'centos|Red Hat')
	if [ "${Centos6Check}" ];then 
		\cp -a -r /tmp/btwaf/mycomplib_centos6.so $btwaf_httpd_path/mycomplib.so
	fi 
	\cp -a -r /tmp/btwaf/memcached.lua $btwaf_httpd_path/memcached.lua
	\cp -a -r /tmp/btwaf/CRC32.lua $btwaf_httpd_path/CRC32.lua
	\cp -a -r /tmp/btwaf/multipart.lua $btwaf_httpd_path/multipart.lua
	chmod +x $btwaf_httpd_path/httpd.lua
	chmod +x $btwaf_httpd_path/memcached.lua
	chmod +x $btwaf_httpd_path/CRC32.lua
	
	mkdir -p /www/wwwlogs/btwaf
	chmod 777 /www/wwwlogs/btwaf
	chmod -R 755 /www/server/btwaf
	cd /www/server/panel
	chown -R root:root /www/server/btwaf/
	chown www:www /www/server/btwaf/*.json
	chown www:www /www/server/btwaf/drop_ip.log
	chattr +i /www/server/panel/vhost/apache/btwaf.conf
	/etc/init.d/httpd restart
	rm -rf /tmp/btwaf
	rm -rf $pluginPath/*.gz
	bash /www/server/panel/init.sh start
	
	echo '安装完成' > $install_tmp
}


Uninstall_btwaf_httpd()
{
	chattr -i /www/server/panel/vhost/apache/btwaf.conf
	rm -f /www/server/panel/vhost/apache/btwaf.conf
	rm -rf $pluginPath
	/etc/init.d/httpd reload
}

if [ "${1}" == 'install' ];then
	Install_btwaf_httpd
elif  [ "${1}" == 'update' ];then
	Install_btwaf_httpd
elif [ "${1}" == 'uninstall' ];then
	Uninstall_btwaf_httpd
fi