import json
import os
import time
from typing import Dict, Union, Optional
from datetime import datetime, timedelta
import importlib
import sys

if "/www/server/panel/class" not in sys.path:
    sys.path.insert(0, "/www/server/panel/class")

if "/www/server/panel" not in sys.path:
    sys.path.insert(0, "/www/server/panel")

import public


class _OldPushManager:
    _conf_file = "/www/server/panel/class/push/push.json"


    @staticmethod
    def del_today_push_counter(task_id:str):
        push_counter_file= '{}/data/push/tips/load_balance_today.json'.format(public.get_panel_path())
        t_day = datetime.now().strftime('%Y-%m-%d')
        if os.path.exists(push_counter_file):
            tip = json.loads(public.readFile(push_counter_file))
            if tip["t_day"] != t_day:
                tip = {"t_day": t_day}
                public.writeFile(push_counter_file, json.dumps(tip))
                return

            tip.pop(task_id, None)
            public.writeFile(push_counter_file, json.dumps(tip))


    def get_task_list(self):
        if not os.path.isfile(self._conf_file):
            return []
        try:
            conf = json.loads(public.readFile(self._conf_file))
        except:
            return []

        load_balance_push = conf.get("load_balance_push", {})
        if not load_balance_push:
            return []

        res = []
        for k, v in load_balance_push.items():
            res.append({
                "project": v["project"],
                "cycle": v["cycle"],
                "count": int(v["count"]),
                "interval": int(v["interval"]),
                "title": v["title"],
                "day_num": int(v["push_count"]),
                "status": v["status"],
                "sender": v["module"].split(",")
            })
        return res

    @staticmethod
    def get_sender_list():
        config_mod = importlib.import_module("config", "class")
        sender_map = config_mod.config().get_msg_configs(None)
        return [{
            "title": v["title"],
            "value": v["name"]
        } for _, v in sender_map.items() if v["name"] != "sms"]

    def set_task_conf_data(self, config_data: dict) -> Optional[str]:
        """
        {
            "template_id": "50",
            "task_data": {
                "status": True,
                "sender": ["aaaaaa"],
                "task_data": {
                    "project": "all",
                    "cycle": "200|301|302|403|404"
                },
                "number_rule": {
                    "day_num": v_data.get("push_count", 3)
                }
            }
        }
        """
        task_data = config_data["task_data"]["task_data"]
        sender = config_data["task_data"].get("sender", [])
        day_num = config_data["task_data"].get("number_rule", {}).get("day_num", 3)
        if not sender:
            return "请选择告警通道"

        sl = [i["value"] for i in self.get_sender_list()]
        for i in sender:
            if i not in sl:
                return "请选择正确的告警通道"

        if task_data["project"] == "all":
            task_data["project"] = "all"
            task_data["title"] = "所有已配置的负载异常告警"
        else:
            all_upstream_name = public.M("upstream").field("name").select()
            if isinstance(all_upstream_name, str) and all_upstream_name.startswith("error"):
                return public.returnMsg(False, '没有负载均衡配置，无法设置告警')
            all_upstream_name = [i["name"] for i in all_upstream_name]
            if task_data["project"] not in all_upstream_name:
                return "负载均衡配置不存在"
            task_data["title"] = "负载{}的异常告警".format(task_data["project"])

        if not day_num or day_num < 0:
            return "请设置推送次数"
        try:
            cycle = []
            for i in task_data["cycle"].split("|"):
                if bool(i) and i.isdecimal():
                    code = int(i)
                    if 100 <= code < 600:
                        cycle.append(str(code))
            if not cycle:
                return '没有指定任何错误码，无法设置告警'
        except:
            return "请设置正确的错误码"

        cycle = "|".join(cycle)
        task_data["cycle"] = cycle

        if not os.path.isfile(self._conf_file):
            conf = {}
        else:
            try:
                conf = json.loads(public.readFile(self._conf_file))
            except:
                conf = {}

        create = True
        for k, tmp_conf in conf.get("load_balance_push", {}).items():
            if tmp_conf["project"] == task_data["project"]:
                tmp_conf["interval"] = 60
                tmp_conf["module"] = ",".join(sender)
                tmp_conf["push_count"] = day_num
                tmp_conf["status"] = config_data["task_data"].get("status", True)
                self.del_today_push_counter(k)
                create = False
        if create:
            conf.setdefault("load_balance_push", {})[str(time.time())] = task_data
            task_data["module"] = ",".join(sender)
            task_data["push_count"] = day_num
            task_data["status"] = config_data["task_data"].get("status", True)
            task_data["interval"] = 60

        public.writeFile(self._conf_file, json.dumps(conf))
        return None

    def change_task_status(self, project: str, status: bool):
        if not os.path.isfile(self._conf_file):
            conf = {}
        else:
            try:
                conf = json.loads(public.readFile(self._conf_file))
            except:
                conf = {}

        load_balance_push = conf.get("load_balance_push", {})
        for _, v in load_balance_push.items():
            if v["project"] == project:
                v["status"] = status
        public.writeFile(self._conf_file, json.dumps(conf))

    def remove_task_conf(self, project: str):
        if not os.path.isfile(self._conf_file):
            conf = {}
        else:
            try:
                conf = json.loads(public.readFile(self._conf_file))
            except:
                conf = {}

        load_balance_push = conf.get("load_balance_push", {})
        t = None
        for task_id, v in load_balance_push.items():
            if v["project"] == project:
                t = task_id
                break
        if t:
            self.del_today_push_counter(t)
            del load_balance_push[t]
        public.writeFile(self._conf_file, json.dumps(conf))


class _ModPushManager:
    TYPE2TITLE = {
        "wx_account": "微信公众号",
        "mail": "邮箱",
        "webhook": "自定义",
        "feishu": "飞书",
        "dingding": "钉钉",
        "weixin": "企业微信",
    }
    TYPE_SORT = ("wx_account", "mail",  "feishu", "dingding", "weixin", "webhook")


    def __init__(self):
        from mod.base.push_mod import PushManager, TaskConfig, SenderConfig

        self.push_manager = PushManager
        self.tc = TaskConfig
        self.sc = SenderConfig

    def get_task_list(self):
        return [{
            "title": v["title"],
            "day_num": int(v["number_rule"]["day_num"]),
            "project": v["task_data"]["project"],
            "cycle": v["task_data"]["cycle"],
            "status": v["status"],
            "sender": v["sender"]
        } for v in self.tc().config if v["template_id"] == "50"]


    def set_task_conf_data(self, config_data: dict):
        return self.push_manager().set_task_conf_data(config_data)

    def change_task_status(self, project:str, status: bool):
        task = self.tc().get_by_keyword("nginx_load_push", project)
        if not task:
            return "该目录的告警任务不存在"

        self.push_manager().change_task_conf(public.to_dict_obj(
            {
                "task_id": task["id"],
                "status": status
            }
        ))

    def remove_task_conf(self, project:str):
        task = self.tc().get_by_keyword("nginx_load_push", project)
        if not task:
            return "该目录的告警任务不存在"

        self.push_manager().remove_task_conf(public.to_dict_obj(
            {
                "task_id": task["id"]
            }
        ))

    def get_sender_list(self):
        sc = self.sc()
        res = [
            {
                "title": v["data"]["title"] + "({})".format(self.TYPE2TITLE[v["sender_type"]]),
                "value": v["id"],
                "sender_type": v["sender_type"]
            }
            for v in sc.config if v["sender_type"] != "sms" and v["used"]
        ]
        res.sort(key=lambda i: self.TYPE_SORT.index(i["sender_type"]))
        return res


def _can_use_mod_push():
    """
    是否可用新版本的告警设置
    """
    return os.path.exists("/www/server/panel/mod/base/push_mod/load_push.py")


# 兼容新旧版本告警，实现设置告警、移除告警、关闭告警、获取告警、获取告警通道等功能
class CompatiblePushManager:
    PANEL_PATH = "/www/server/panel"

    def install(self):
        if _can_use_mod_push():
            self._update_old_conf()

    def uninstall(self):
        if _can_use_mod_push():
            print("移除告警设置..")
            if self.PANEL_PATH not in sys.path:
                sys.path.insert(0, self.PANEL_PATH)

            from mod.base.push_mod import TaskTemplateConfig

            tt = TaskTemplateConfig()
            tmp = tt.get_by_id("50")
            if tmp:
                tt.config.remove(tmp)
                tt.save_config()

    @classmethod
    def _update_old_conf(cls):
        if cls.PANEL_PATH not in sys.path:
            sys.path.insert(0, cls.PANEL_PATH)

        from mod.base.push_mod.load_push import load_load_template
        from mod.base.push_mod import PushManager, get_default_module_dict

        load_load_template()

        # try:
        #     push_data = json.loads(public.readFile("/www/server/panel/class/push/push.json"))
        # except:
        #     return
        #
        # if not isinstance(push_data, dict):
        #     return
        #
        # pmgr = PushManager()
        # df_mdl = get_default_module_dict()
        # for k, v in push_data.get("load_balance_push", {}).items():
        #     sender_list = [df_mdl[i.strip()] for i in v.get("module", "").split(",") if i.strip() in df_mdl]
        #     tmp_data = {
        #         "template_id": "50",
        #         "task_data": {
        #             "status": bool(v.get("status", True)),
        #             "sender": sender_list,
        #             "task_data": {
        #                 "project": v.get("project", ""),
        #                 "cycle": v.get("cycle", "200|301|302|403|404")
        #             },
        #             "number_rule": {
        #                 "day_num": v.get("push_count", 3)
        #             }
        #         }
        #     }
        #
        #     pmgr.set_task_conf_data(tmp_data)


    @staticmethod
    def get_task_list(get=None):
        projects = [{
            "title": "所有已配置的负载",
            "value": "all"
        }]

        all_upstream_name = public.M("upstream").field("name").select()
        if isinstance(all_upstream_name, str) and all_upstream_name.startswith("error"):
            return public.returnMsg(False, '没有负载均衡配置，无法设置告警')
        all_upstream_name = [i["name"] for i in all_upstream_name]
        for i in all_upstream_name:
            projects.append({
                "title": i,
                "value": i
            })
        if not all_upstream_name:
            projects = []

        if _can_use_mod_push():
            the_pm = _ModPushManager()
            task_list = the_pm.get_task_list()
            sender_list = the_pm.get_sender_list()
        else:
            old_pm = _OldPushManager()
            task_list = old_pm.get_task_list()
            sender_list = old_pm.get_sender_list()

        sender_values = [i["value"] for i in sender_list]
        for t in task_list:
            t["sender"] = [i for i in t["sender"] if i in sender_values]
        return {
            "projects": projects,
            "task_list": task_list,
            "sender_list": sender_list,
        }

    @staticmethod
    def set_task_conf(get):
        project = get.get("project/s", "all")
        cycle = get.get("cycle/s", "200")
        day_num = get.get("day_num/d", 3)
        status = get.get("status/d", 1)
        sender = get.get("sender/s", '')

        sender_list = [i.strip() for i in sender.split(",") if i.strip()]
        pdata = {
            "template_id": "50",
            "task_data": {
                "status": bool(status),
                "sender": sender_list,
                "task_data": {
                    "project": project,
                    "cycle": cycle,
                },
                "number_rule": {
                    "day_num": day_num
                }
            }
        }
        if _can_use_mod_push():
            the_pm = _ModPushManager()
            res = the_pm.set_task_conf_data(pdata)
        else:
            the_pm = _OldPushManager()
            res = the_pm.set_task_conf_data(pdata)

        if res is None:
            return public.returnMsg(True, "告警设置成功")
        else:
            return public.returnMsg(False, res)

    @staticmethod
    def remove_task_conf(get):
        pid = get.get("project/s", "all")
        if _can_use_mod_push():
            the_pm = _ModPushManager()
            the_pm.remove_task_conf(pid)
        else:
            the_pm = _OldPushManager()
            the_pm.remove_task_conf(pid)

        return public.returnMsg(True, "移除告警任务成功")

    @staticmethod
    def remove_task_conf_pid(pid):
        if _can_use_mod_push():
            the_pm = _ModPushManager()
            the_pm.remove_task_conf(str(pid))
        else:
            the_pm = _OldPushManager()
            the_pm.remove_task_conf(str(pid))


pm = CompatiblePushManager()
pm.install()  # 这里的install兼容，不仅是在安装插件是执行，在面板重启后执行到该文件时，也会执行一次，应对面板更新
if __name__ == "__main__":
    if len(sys.argv) < 2 or sys.argv[1] not in ("install", "uninstall"):
        print("Usage: python3 {0} install|uninstall".format(sys.argv[0]))
        sys.exit(1)
    if sys.argv[1] == "uninstall":
        pm.uninstall()

del pm
