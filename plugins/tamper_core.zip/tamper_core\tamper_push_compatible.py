import json
import os
from typing import Dict, Union, Optional, Iterable
from datetime import datetime, timedelta
import importlib
import sys

if "/www/server/panel/class" not in sys.path:
    sys.path.insert(0, "/www/server/panel/class")

if "/www/server/panel" not in sys.path:
    sys.path.insert(0, "/www/server/panel")

import public


class _OldPushManager:
    """
    @description 旧版防篡改告警管理器
    """
    _conf_file = "/www/server/panel/class/push/push.json"

    def __init__(self):
        self._tamper_core_config = None

    @property
    def tamper_core_config(self) -> dict:
        """
        @description 获取防篡改核心配置
        @return dict 配置字典
        """
        if self._tamper_core_config is not None:
            return self._tamper_core_config
        file = "/www/server/tamper/tamper.conf"
        try:
            self._tamper_core_config = json.loads(public.readFile(file))
            return self._tamper_core_config
        except:
            self._tamper_core_config = {}
            return self._tamper_core_config

    def get_task_list(self, get=None):
        """
        @description 获取防篡改任务列表
        """
        if not os.path.isfile(self._conf_file):
            return []

        try:
            conf = json.loads(public.readFile(self._conf_file))
        except:
            return []

        res = []
        for k, v in conf.get("tamper_push", {}).items():
            res.append({
                "project": int(k),
                "cycle": int(v["cycle"]),
                "count": int(v["count"]),
                "interval": int(v["interval"]),
                "title": v["title"],
                "day_num": int(v["push_count"]),
                "status": v["status"],
                "sender": v["module"].split(",")
            })
        return res

    @staticmethod
    def get_sender_list():
        """
        @description 获取告警通道列表
        """
        config_mod = importlib.import_module("config", "class")
        sender_map = config_mod.config().get_msg_configs(None)

        return [{
            "title": v["title"],
            "value": v["name"]
        } for _, v in sender_map.items() if v["name"] != "sms"]

    @staticmethod
    def del_today_push_count(project):
        """
        @description 清除告警次数
        @param id<int> 网站id
        """
        t_day = datetime.now().strftime('%Y-%m-%d')
        today_tip = '{}/data/push/tips/tamper_today.json'.format(public.get_panel_path())
        if os.path.exists(today_tip):
            tip = json.loads(public.readFile(today_tip))
            if tip["t_day"] != t_day:
                tip = {"t_day": t_day}
            elif str(project) in tip:
                del tip[str(project)]

            public.writeFile(today_tip, json.dumps(tip))

    def set_task_conf_data(self, config_data: dict) -> Optional[str]:
        """
        {
            "template_id": "140",
            "task_data": {
                "status": bool(v_data.get("status", True)),
                "sender": sender_list,
                "task_data": {
                    "project": str(pid),
                    "cycle": v_data.get("cycle", 30),
                    "count": v_data.get("count", 3),
                    "interval": v_data.get("interval", 600)
                },
                "number_rule": {
                    "day_num": v_data.get("push_count", 3)
                }
            }
        }
        """
        task_data = config_data["task_data"]["task_data"]
        sender = config_data["task_data"].get("sender", [])
        day_num = config_data["task_data"].get("number_rule", {}).get("day_num", 3)
        if not sender:
            return "请选择告警通道"

        sl = [i["value"] for i in self.get_sender_list()]
        for i in sender:
            if i not in sl:
                return "请选择正确的告警通道"

        if not day_num or day_num < 0:
            return "请设置推送次数"
        if not os.path.isfile(self._conf_file):
            conf = {}
        else:
            try:
                conf = json.loads(public.readFile(self._conf_file))
            except:
                conf = {}

        if task_data["interval"] < 60:
            task_data["interval"] = 60

        if task_data["project"] == 0 or task_data["project"] == "0":
            task_data["project"] = 0
            task_data["title"] = "所有受保护目录防篡改告警"
        else:
            try:
                project = int(task_data["project"])
            except:
                return "保护目录指定错误"
            for i in self.tamper_core_config.get("paths", []):
                if i.get("pid", None) == project:
                    p:str = i.get("path", "")
                    task_data["project"] = project
                    task_data["title"] = "目录[{}]防篡改告警".format(os.path.basename(p.rstrip("/")))
                    break
            else:
                return "保护目录指定错误"

        tamper_push = conf.get("tamper_push", {})
        if not (isinstance(task_data.get('count', None), int) and task_data['count'] > 0):
            return "次数参数错误，不能设置小于等于0的数据"

        if not (isinstance(task_data.get('cycle', None), (int, float)) and task_data['cycle'] > 0):
            return "周期参数错误，不能设置小于等于0的数据"

        tamper_push[str(task_data["project"])] = task_data
        task_data["pid"] = int(task_data["project"])
        self.del_today_push_count(task_data["pid"])
        task_data["project"] = "tamper_core"
        task_data["module"] = ",".join(sender)
        task_data["status"] = config_data["task_data"].get("status", True)
        task_data["key"] = ""
        task_data["type"] = "tamper_pash"
        task_data["push_count"] = day_num

        conf["tamper_push"] = tamper_push
        public.writeFile(self._conf_file, json.dumps(conf))

        return None

    def change_task_status(self, project: str, status: bool):
        """
        @description 变更任务状态
        @param project<int|str> 任务id
        @param status<bool> 任务状态
        """
        if isinstance(project, int):
            project = str(project)

        if not os.path.isfile(self._conf_file):
            conf = {}
        else:
            try:
                conf = json.loads(public.readFile(self._conf_file))
            except:
                conf = {}

        if project in conf.get("tamper_push", {}):
            conf["tamper_push"][project]["status"] = status
            public.writeFile(self._conf_file, json.dumps(conf))

    def remove_task_conf(self, project: str):
        """
        @description 删除任务配置
        @param project<int|str> 任务id
        """
        if isinstance(project, int):
            project = str(project)

        if not os.path.isfile(self._conf_file):
            conf = {}
        else:
            try:
                conf = json.loads(public.readFile(self._conf_file))
            except:
                conf = {}

        if project in conf.get("tamper_push", {}):
            del conf["tamper_push"][project]
            public.writeFile(self._conf_file, json.dumps(conf))


class _ModPushManager:
    TYPE2TITLE = {
        "wx_account": "微信公众号",
        "mail": "邮箱",
        "webhook": "自定义",
        "feishu": "飞书",
        "dingding": "钉钉",
        "weixin": "企业微信",
    }

    def __init__(self):
        from mod.base.push_mod import PushManager, TaskConfig, SenderConfig

        self.push_manager = PushManager
        self.tc = TaskConfig
        self.sc = SenderConfig

    def get_task_list(self, get=None):
        tc = self.tc()
        return [{
            "project": v["task_data"]["project"],
            "cycle": int(v["task_data"]["cycle"]),
            "count": int(v["task_data"]["count"]),
            "interval": int(v["task_data"]["interval"]),
            "title": v["title"],
            "day_num": int(v["number_rule"]["day_num"]),
            "status": v["status"],
            "sender": v["sender"]
        } for v in tc.config if v["template_id"] == "140"]

    def set_task_conf_data(self, config_data: dict):
        return self.push_manager().set_task_conf_data(config_data)

    def change_task_status(self, project: str, status: bool):
        task = self.tc().get_by_keyword("tamper_push", str(project))
        if not task:
            return "该目录的告警任务不存在"

        self.push_manager().change_task_conf(public.to_dict_obj(
            {
                "task_id": task["id"],
                "status": status
            }
        ))

    def remove_task_conf(self, project: str):
        task = self.tc().get_by_keyword("tamper_push", str(project))
        if not task:
            return "该目录的告警任务不存在"

        self.push_manager().remove_task_conf(public.to_dict_obj(
            {
                "task_id": task["id"]
            }
        ))

    def get_sender_list(self):
        sc = self.sc()
        return [
            {
                "title": v["data"]["title"] + "({})".format(self.TYPE2TITLE[v["sender_type"]]),
                "value": v["id"]
            }
            for v in sc.config if v["sender_type"] != "sms" and v["used"]
        ]


def _can_use_mod_push() -> bool:
    """
    是否可用新版本的告警设置
    """
    ver = [int(i) for i in public.version().split(".")]
    if len(ver) < 3:
        ver.extend([0] * (3 - len(ver)))
    if ver >= [9, 5, 0]:
        return True
    return False


# 兼容新旧版本告警，实现设置告警、移除告警、关闭告警、获取告警、获取告警通道等功能
class CompatiblePushManager:
    PANEL_PATH = "/www/server/panel"

    def install(self):
        if _can_use_mod_push():
            self._update_old_conf()

    def uninstall(self):
        if _can_use_mod_push():
            print("移除告警设置..")
            if self.PANEL_PATH not in sys.path:
                sys.path.insert(0, self.PANEL_PATH)

            from mod.base.push_mod import TaskTemplateConfig

            tt = TaskTemplateConfig()
            tmp = tt.get_by_id("140")
            if tmp:
                tt.config.remove(tmp)
                tt.save_config()

    @classmethod
    def _update_old_conf(cls):
        """
        @description 更新旧版本的告警配置到新版本
        """
        if cls.PANEL_PATH not in sys.path:
            sys.path.insert(0, cls.PANEL_PATH)

        from mod.base.push_mod import load_task_template_by_file, get_default_module_dict, PushManager

        # 加载模板数据
        load_task_template_by_file("{}/plugin/tamper_core/tamper_push_template.json".format(cls.PANEL_PATH))

        # 将旧版本的配置数据更新到新版本的配置文件中
        old_conf = "{}/class/push/push.json".format(cls.PANEL_PATH)
        try:
            o_conf: Dict[str, dict] = json.loads(public.readFile(old_conf))
        except:
            return

        if "tamper_push" not in o_conf or len(o_conf["tamper_push"]) == 0:
            return

        df_mdl = get_default_module_dict()
        mod_pm = PushManager()
        for pid, v_data in o_conf["tamper_push"].items():
            sender_list = [df_mdl[i.strip()] for i in v_data.get("module", "").split(",") if i.strip() in df_mdl]
            mod_pm.set_task_conf_data({
                "template_id": "140",
                "task_data": {
                    "status": bool(v_data.get("status", True)),
                    "sender": sender_list,
                    "task_data": {
                        "project": int(pid),
                        "cycle": v_data.get("cycle", 30),
                        "count": v_data.get("count", 3),
                        "interval": v_data.get("interval", 600)
                    },
                    "number_rule": {
                        "day_num": v_data.get("push_count", 3)
                    }
                }
            })

        o_conf.pop("tamper_push", None)
        public.writeFile(old_conf, json.dumps(o_conf))

    @staticmethod
    def get_task_list(get=None):
        projects = [{
            "title": "所有受保护目录",
            "value": 0
        }]

        old_pm = _OldPushManager()
        for i in old_pm.tamper_core_config.get("paths", []):
            projects.append({
                "title": i.get("path", ""),
                "value": i.get("pid", 0)
            })

        if _can_use_mod_push():
            """
            @description 获取防篡改任务列表
            """
            the_pm = _ModPushManager()
            task_list = the_pm.get_task_list(get)
            sender_list = the_pm.get_sender_list()
        else:
            task_list = old_pm.get_task_list(get)
            sender_list = old_pm.get_sender_list()

        sender_values = [i["value"] for i in sender_list]
        for t in task_list:
            t["sender"] = [i for i in t["sender"] if i in sender_values]
        return {
            "projects": projects,
            "task_list": task_list,
            "sender_list": sender_list,
        }

    @staticmethod
    def set_task_conf(get):
        project = get.get("project/d", 0)
        cycle = get.get("cycle/d", 30)
        count = get.get("count/d", 3)
        interval = get.get("interval/d", 600)
        day_num = get.get("day_num/d", 3)
        status = get.get("status/d", 1)
        sender = get.get("sender/s", '')

        sender_list = [i.strip() for i in sender.split(",") if i.strip()]
        pdata = {
            "template_id": "140",
            "task_data": {
                "status": bool(status),
                "sender": sender_list,
                "task_data": {
                    "project": project,
                    "cycle": cycle,
                    "count": count,
                    "interval": interval
                },
                "number_rule": {
                    "day_num": day_num
                }
            }
        }
        if _can_use_mod_push():
            the_pm = _ModPushManager()
            res = the_pm.set_task_conf_data(pdata)
        else:
            the_pm = _OldPushManager()
            res = the_pm.set_task_conf_data(pdata)

        if res is None:
            return public.returnMsg(True, "告警设置成功")
        else:
            return public.returnMsg(False, res)

    @staticmethod
    def change_task_status(get):
        """
        @description 变更任务状态
        @param project<int|str> 任务id
        @param status<bool> 任务状态
        """
        pid = get.get("project/d", 0)
        status = bool(get.get("status/d", 1))
        if _can_use_mod_push():
            the_pm = _ModPushManager()
            the_pm.change_task_status(pid, status)
        else:
            the_pm = _OldPushManager()
            the_pm.change_task_status(pid, status)

        return public.returnMsg(True, "修改告警状态成功")

    @staticmethod
    def remove_task_conf(get):
        """
        @description 删除任务配置
        @param project<int|str> 任务id
        """
        pid = get.get("project/d", 0)
        if _can_use_mod_push():
            the_pm = _ModPushManager()
            the_pm.remove_task_conf(pid)
        else:
            the_pm = _OldPushManager()
            the_pm.remove_task_conf(pid)

        return public.returnMsg(True, "移除告警任务成功")

    @staticmethod
    def remove_task_conf_pid(pid: int):
        """
        @description 删除任务配置
        @param project<int|str> 任务id
        """
        if _can_use_mod_push():
            the_pm = _ModPushManager()
            the_pm.remove_task_conf(str(pid))
        else:
            the_pm = _OldPushManager()
            the_pm.remove_task_conf(str(pid))


if _can_use_mod_push():
    from mod.base.push_mod import BaseTask, WxAccountMsg, TaskConfig, BaseTaskViewMsg


    class _LogCheck:
        _logs_path = "/www/server/tamper/logs"

        def __init__(self, task: "TamperPushTask", pid: Union[str, int], cycle: int):
            self.task = task
            now = datetime.now()
            td = now.strftime('%Y-%m-%d')
            yd = (now - timedelta(days=1)).strftime('%Y-%m-%d')
            if int(pid) == 0:
                paths = self.task.tamper_core_config.get("paths", [])
                file_list = ["" for _ in range(len(paths) * 2)]
                for i, path_data in enumerate(paths):
                    file_list[i] = "{}/{}/{}.log".format(self._logs_path, path_data["pid"], td)
                    file_list[len(paths) + i] = "{}/{}/{}.log".format(self._logs_path, path_data["pid"], yd)
            else:
                file_list = [
                    "{}/{}/{}.log".format(self._logs_path, pid, td),
                    "{}/{}/{}.log".format(self._logs_path, pid, yd)
                ]
            self.file_list = file_list
            self.target_time = now - timedelta(minutes=cycle)

        def __iter__(self):
            for file in self.file_list:
                for line in self._iter_file_log(file):
                    if not line:
                        continue
                    d = self.get_time(line)
                    if not d:
                        continue
                    if d >= self.target_time:
                        yield line
                    else:
                        break

        @staticmethod
        def get_time(log: str) -> Optional[datetime]:
            """
            @description 解析日志时间
            @param log<str> 日志行
            @return Optional[datetime] 时间对象
            """
            d = log.split("] [", 1)[0].strip("[").strip()
            try:
                return datetime.strptime(d, "%Y-%m-%d %H:%M:%S")
            except:
                return None

        @staticmethod
        def _iter_file_log(file: str) -> Iterable[str]:
            """
            @description 迭代文件日志行
            @param file<str> 文件路径
            @return Iterable[str] 日志行迭代器
            """
            if not os.path.isfile(file):
                return

            batch_size = 1024 * 100  # 100kb
            file_size = os.path.getsize(file)
            offset = file_size

            buffer = bytearray()
            with open(file, 'rb') as fp:
                while offset > 0:
                    offset = max(offset - batch_size, 0)
                    fp.seek(offset)
                    batch = fp.read(file_size - offset)
                    buffer = batch + buffer
                    file_size = offset

                    lines = buffer.splitlines(keepends=True)
                    if len(lines) > 1:
                        for line in lines[1:][::-1]:
                            yield line.decode('utf-8')
                        buffer = lines[0]
                    elif len(lines) == 1:
                        buffer = lines[0]

                if buffer:
                    for line in buffer.splitlines(keepends=True)[::-1]:
                        yield line.decode('utf-8')


    class TamperPushTask(BaseTask):
        __tamper_path = "{}/tamper".format(public.get_setup_path())
        __total_path = "{}/total/total.json".format(__tamper_path)

        def __init__(self):
            super().__init__()
            self.source_name = "tamper_push"
            self.template_name = "企业防篡改告警"

            self._tamper_core_config = None
            self.task_path_name = "所有受保护目录"
            self.wx_logs = ""

        @property
        def tamper_core_config(self) -> dict:
            """
            @description 获取防篡改核心配置
            @return dict 配置字典
            """
            if self._tamper_core_config is not None:
                return self._tamper_core_config
            file = "/www/server/tamper/tamper.conf"
            try:
                self._tamper_core_config = json.loads(public.readFile(file))
                return self._tamper_core_config
            except:
                self._tamper_core_config = {}
                return self._tamper_core_config

        def project_id2path(self, project_id: int) -> str:
            """
            @description 根据项目id获取目录路径
            @param project_id<int|str> 项目id
            @return str 目录路径
            """
            for i in self.tamper_core_config.get("paths", []):
                if str(i.get("pid", None)) == str(project_id):
                    return i.get("path", "")
            return ""

        def filter_template(self, template: dict) -> Optional[dict]:
            """
            @description 过滤防篡改告警模板
            @param template<dict> 原始模板
            @return Optional[dict] 过滤后的模板
            """
            if not os.path.exists("/www/server/panel/plugin/tamper_core/tamper_core_main.py"):
                return None
            items = [{
                "title": "所有受保护目录",
                "value": 0
            }]
            for i in self.tamper_core_config.get("paths", []):
                items.append({
                    "title": i.get("path", ""),
                    "value": i.get("pid", 0)
                })

            template["field"][0]["items"] = items
            return template

        def get_title(self, task_data: dict) -> str:
            """
            @description 获取防篡改告警标题
            @param task_data<dict> 任务数据
            @return str 标题
            """
            if task_data["project"] == 0:
                return "所有受保护目录防篡改告警"
            p = self.project_id2path(task_data["project"])
            if p:
                return "目录[{}]的防篡改告警".format(os.path.basename(p.rstrip("/")))
            return "所有受保护目录防篡改告警"

        def get_keyword(self, task_data: dict) -> str:
            return str(task_data["project"])

        def check_task_data(self, task_data: dict) -> Union[dict, str]:
            if task_data["interval"] < 60:
                task_data["interval"] = 60

            if task_data["project"] == 0 or task_data["project"] == "0":
                task_data["project"] = 0
            else:
                try:
                    project = int(task_data["project"])
                except:
                    return "保护目录指定错误"
                for i in self.tamper_core_config.get("paths", []):
                    if i.get("pid", None) == project:
                        task_data["project"] = project
                        break
                else:
                    return "保护目录指定错误"

            if not (isinstance(task_data.get('cycle', None), (int, float)) and task_data['cycle'] > 0):
                return "周期参数错误，不能设置小于等于0的数据"

            if not (isinstance(task_data.get('count', None), int) and task_data['count'] > 0):
                return "次数参数错误，不能设置小于等于0的数据"

            return task_data

        def get_push_data(self, task_id: str, task_data: dict) -> Optional[dict]:
            """
               @description 获取防篡改告警推送数据
            """
            lc = _LogCheck(self, task_data['project'], task_data["cycle"])

            logs = list(lc)
            # 检测是否超过推送次数
            try:
                tc = TaskConfig()
                t = tc.get_by_keyword("tamper_push", str(task_data["project"]))
                if t and "number_rule" in t and isinstance(t["number_rule"].get("day_num", None), int):
                    day_num = int(t["number_rule"]["day_num"])
                
                # 获取任务id
                task_id = t["id"]
                # 获取今日推送
                today_push = tc.get_by_id(task_id)
                # 读取今日已推送次数 today_push.number_data.day_num，若没有获取到默认0
                today_push_count = int(today_push.get("number_data", {}).get("day_num", 0))
                # 判断是否超过推送次数
                if today_push_count >= day_num:
                    return None
            except Exception:
                pass

            if len(logs) > task_data["count"]:
                if task_data['project'] != 0:
                    self.task_path_name = self.project_id2path(task_data['project'])

                s_list = [
                    ">通知类型：企业版防篡改告警",
                    ">告警内容：<font color=#ff0000>在最近的{}分钟内{}被篡改攻击超过{}次，"
                    "目前已成功拦截，请关注网站情况，并及时处理。</font> ".format(
                        task_data['cycle'], self.project_id2path(task_data['project']), task_data['count']
                    )
                ]
                self.wx_logs = "{}分钟内出现{}次攻击".format(task_data['cycle'], len(logs))
                self.title = self.get_title(task_data)
                
                # 记录告警次数
                self._set_total()

                return {"msg_list": s_list}

            return None
        def _set_total(self):
            """
               @description 记录告警次数
            """
            try:
                total = json.loads(public.readFile(self.__total_path))
                if "warning_msg" not in total:
                    total["warning_msg"] = 1
                else:
                    total["warning_msg"] += 1
                public.writeFile(self.__total_path, json.dumps(total))
            except Exception as e:
                pass


        def to_wx_account_msg(self, push_data: dict, push_public_data: dict) -> WxAccountMsg:
            """
               @description 转换为企业微信消息
            """
            msg = WxAccountMsg.new_msg()
            if "/" in self.task_path_name:
                name = os.path.basename(self.task_path_name)
            else:
                name = self.task_path_name

            if len(name) > 14:
                real_name = name[:11] + "..."
            else:
                real_name = name
            msg.thing_type = "{}目录篡改提醒".format(real_name)
            if len(self.wx_logs) > 20:
                msg.msg = self.wx_logs[:17] + "..."
            else:
                msg.msg = self.wx_logs

            return msg

        def task_config_create_hook(self, task: dict) -> Optional[str]:
            """
               @description 任务创建前钩子
            """
            project = task["task_data"]["project"]
            if TaskConfig().get_by_keyword("tamper_push", str(project)):
                return "该目录已存在防篡改告警任务，请勿重复创建"


        class ViewMsgFormat(BaseTaskViewMsg):
            """
               @description 任务视图消息格式化
            """
            def get_msg(self, task: dict) -> str:
                task_data = task["task_data"]
                if task["template_id"] == "140":
                    if str(task_data["project"]) == "0":
                        return "所有受保护目录在{}分钟内，受攻击次数达到{}次时，发出告警信息".format(
                            task_data["cycle"], task_data["count"]
                        )
                    tp = TamperPushTask()
                    return "目录【{}】在{}分钟内，受攻击次数达到{}次时，发出告警信息".format(
                        tp.project_id2path(task_data["project"]), task_data["cycle"], task_data["count"]
                    )
                return ""

        VIEW_MSG = ViewMsgFormat

else:
    TamperPushTask = object

pm = CompatiblePushManager()
# 这里的install兼容，不仅是在安装插件是执行，在面板重启后执行到该文件时，也会执行一次，应对面板更新
pm.install()
if __name__ == "__main__":
    if len(sys.argv) < 2 or sys.argv[1] not in ("install", "uninstall"):
        print("Usage: python3 {0} install|uninstall".format(sys.argv[0]))
        sys.exit(1)
    if sys.argv[1] == "uninstall":
        pm.uninstall()

del pm
