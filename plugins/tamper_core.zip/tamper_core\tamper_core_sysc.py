# -*- coding: UTF-8 -*-
"""
@Description：同步配置文件,用于插件更新/初次安装
@Author：Mr wpl
@Time：2024/6/19
"""
import os
import shutil


def sync_config():
    import json
    # 源文件和目标文件路径
    src_file = "/www/server/panel/plugin/tamper_core/tamper/tamper.conf"
    dst_file = "/www/server/tamper/tamper.conf"
    # 读取源文件
    with open(src_file, 'r') as f:
        source_data = json.load(f)

    # 读取目标文件
    with open(dst_file, 'r') as f:
        target_data = json.load(f)

    # 同步default_white_files
    target_data['default_white_dirs'] = source_data['default_white_dirs']

    # 将白名单路径同步过去，并做出配置检测
    for path in target_data['paths']:
        if 'white_files' not in path or not path['white_files']:
            path['white_files'] = []
        else:
            # 删除"."开头且紧接的不是"/"的值等错误配置
            path['white_files'] = [file for file in path['white_files'] if
                                   not file.startswith('.') or file.startswith('./')]
            # 检查是否存在"./.well-known/*.txt"
            if './.well-known/*.txt' in path['white_files']:
                path['white_files'].remove('./.well-known/*.txt')

        # 检查white_dirs中是否存在".well-known/"，如果不存在则添加
        if 'white_dirs' not in path or not path['white_dirs']:
            path['white_dirs'] = ['.well-known/']
        elif '.well-known/' not in path['white_dirs']:
            path['white_dirs'].append('.well-known/')
    # 写回目标文件
    with open(dst_file, 'w') as f:
        json.dump(target_data, f, indent=4)

    # 同步告警配置文件
    spush_file = "/www/server/panel/plugin/tamper_core/tamper_push.py"
    dpush_file = "/www/server/panel/class/push/tamper_push.py"
    shutil.copyfile(spush_file, dpush_file)
    os.chmod(dpush_file, mode=0o777)

if __name__ == "__main__":
    import sys
    if sys.argv[1] == "sync_config":
        sync_config()