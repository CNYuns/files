import base64
import copy
import datetime
import gzip
import json
import os
import random
import re
import shutil
import sys
import time
import traceback
from collections import namedtuple, Counter, OrderedDict
from typing import Optional, List, Dict, TextIO, Any, Iterable, Tuple, Union, Callable, Set

import psutil
from urllib3.util.url import parse_url

# 添加项目根目录到环境变量
os.chdir("/www/server/panel")
if "/www/server/panel/class" not in sys.path:
    sys.path.insert(0, "/www/server/panel/class")

import public
import db

if "/www/server/panel/plugin/monitor" not in sys.path:
    sys.path.insert(0, "/www/server/panel/plugin/monitor")
elif "/www/server/panel/plugin/monitor" in sys.path and sys.path[0] != "/www/server/panel/plugin/monitor":
    sys.path.remove("/www/server/panel/plugin/monitor")
    sys.path.insert(0, "/www/server/panel/plugin/monitor")
from monitor_cmd import udp_cmd
from monitor_proxy import BaiduZZApi, ZZ360Api
from cache_tool import TTLCache
from xml.sax.saxutils import escape
from utils import sitetool, IPRange, get_page_with_smart_pages, file_attr_i, file_attr_add_i, file_attr_del_i

Xurl = namedtuple(
    "Xurl",
    ["loc", "priority", "lastmod", "changefreq", "mobile"],
    defaults=(None, None, None, None, None)
)


def _xml_url(x) -> str:
    tmp_list = [
        '<url>',
        "    <loc>{}</loc>".format(x.loc),
        "    <changefreq>{}</changefreq>".format(x.changefreq or "always"),
        "    <priority>%.2f</priority>" % (x.priority or 1.0),
        "</url>",
    ]
    if x.lastmod is not None:
        tmp_list.insert(2, "    <lastmod>{}</lastmod>".format(x.lastmod))
    if x.mobile is not None:
        tmp_list.insert(-1, '    <mobile:mobile type="{}"/>'.format(x.mobile))

    return "\n".join(tmp_list)


Xurl.__str__ = _xml_url

path_danger_regex = re.compile(r"//|\.\.|[:$;\[\]]")


class SeoUriCollectConfig:
    default_config = {
        "ext_list": [
            ".html",
            ".htm",
            ".php",
            ".jsp",
            ".aspx",
            ".asp",
            ".cgi",
            ".jhtml",
            ".shtml",
            ".shtm",
            ".net"
        ],
        "include": [],
        "exclude": [],
        "site_name": "",
        "save_query": False,
        "status": False

    }

    config_file = "/www/server/monitor/config/site_seo_uri.json"

    @classmethod
    def _load_config(cls) -> dict:
        try:
            data: dict = json.loads(public.readFile(cls.config_file))
        except Exception as e:
            return {}
        if not isinstance(data, dict):
            return {}
        return data

    @classmethod
    def _save_config(cls, data: dict) -> bool:
        return public.writeFile(cls.config_file, json.dumps(data, indent=4))

    def __init__(self):
        self._config: Optional[dict] = None

    def site_config(self, site_name: str) -> dict:
        """
        获取配置
        """
        if self._config is None:
            self._config = self._load_config()
        if site_name not in self._config:
            self._config[site_name] = copy.deepcopy(self.default_config)
            self._config[site_name]["site_name"] = site_name
        return self._config[site_name]

    def __getitem__(self, item: str):
        return self.site_config(item)

    def __setitem__(self, key, value):
        if self._config is None:
            self._config = self._load_config()
        conf = self.site_config(key)
        conf.update(value)

    def save_config(self):
        """
        保存配置
        """
        if self._config is None:
            return
        return self._save_config(self._config)

    def open_all(self):
        """
        开启所有站点
        """
        if self._config is None:
            self._config = self._load_config()

        for site_name, conf in self._config.items():
            conf["status"] = True

        self.save_config()

    def close_all(self):
        """
        关闭所有站点
        """
        if self._config is None:
            self._config = self._load_config()

        for site_name, conf in self._config.items():
            conf["status"] = False

        self.save_config()


class SeoUriData:
    ttl_cache = TTLCache(maxsize=200, ttl=60 * 6)
    ttl_cache_count = TTLCache(maxsize=10, ttl=60)
    EXT_MAP = {
        '.html': 1,
        '.htm': 2,
        '.php': 3,
        '.jsp': 4,
        '.aspx': 5,
        '.asp': 6,
        '.cgi': 7,
        '.jhtml': 8,
        '.shtml': 9,
        '.shtm': 10,
        '.net': 11,
    }
    EXT_MAP_REVERSE = {v: k for k, v in EXT_MAP.items()}
    _all_host = dict()

    def __init__(self, site_name: str, db_path: str):
        if not os.path.exists(db_path):
            raise FileNotFoundError(f"db_path: {db_path} not found")

        self.site_name = site_name
        self.db_path = db_path
        self.db_file = os.path.join(db_path, site_name, "seo_uri.db")
        self._sql_conn: Optional[db.Sql] = None

    def get_conn(self) -> db.Sql:
        if self._sql_conn is not None and self._sql_conn._Sql__DB_CONN:
            return self._sql_conn
        sql = db.Sql()
        sql._Sql__DB_FILE = self.db_file
        return sql

    def _field_id_list(self, table_name: str, filed: str, val: str, id_field: str) -> List[int]:
        if not table_name or not filed or not val:
            return []
        ck = public.Md5("{}{}{}{}{}".format(self.site_name, table_name, filed, val, id_field))
        res = self.ttl_cache.get(ck)
        if isinstance(res, list):
            return res
        val = val.replace("%", "\\%")
        if val.startswith('^') and val.endswith('$'):
            real_value = val[1:-1]
            db_obj = self.get_conn()
            if not db_obj:
                return []
            data = db_obj.table(table_name).where("{} = ?".format(filed), (real_value,)).field(id_field).find()
            if not isinstance(data, dict) or not data:
                return []

            res = [int(data[id_field])]
            self.ttl_cache[ck] = res
            return res

        else:
            real_value = "%{}%".format(val)
            if val.startswith('^'):
                real_value = "{}%".format(val[1:])
            elif val.endswith('$'):
                real_value = "%{}".format(val[:-1])

            db_obj = self.get_conn()
            if not db_obj:
                return []
            data = db_obj.table(table_name).where("{} like ?".format(filed), (real_value,)).field(id_field).select()

            if not isinstance(data, list) or not data:
                return []

            res = [int(i[id_field]) for i in data]
            self.ttl_cache[ck] = res
            return res

    def get_path_ids(self, path: str) -> List[int]:
        return self._field_id_list("path_list", "path", path, "path_id")

    def get_query_ids(self, query: str) -> List[int]:
        return self._field_id_list("query_list", "query", query, "query_id")

    def get_ext_ids(self, ext: List[str]) -> List[int]:
        return [self.EXT_MAP[i] for i in ext if i in self.EXT_MAP]

    def ext2id(self, ext: str) -> Optional[int]:
        if ext in self.EXT_MAP:
            return self.EXT_MAP[ext]
        return None

    def id2ext(self, ext_id: int) -> Optional[str]:
        if ext_id in self.EXT_MAP_REVERSE:
            return self.EXT_MAP_REVERSE[ext_id]
        return None

    def _get_filed_by_id(self, table_name: str, id_name: str, id_val: int, field: str) -> str:
        if id_val == 0:
            return ""
        if not table_name or not id_name or not id_val or not field:
            return ""
        ck = public.Md5("{}{}{}{}{}".format(self.site_name, table_name, id_name, id_val, field))
        res = self.ttl_cache.get(ck)
        if isinstance(res, str):
            return res

        db_obj = self.get_conn()
        if not db_obj:
            return ""
        data = db_obj.table(table_name).where("{} = ?".format(id_name), (id_val,)).field(field).find()
        if not isinstance(data, dict) or not data:
            return ""
        res = data[field]
        self.ttl_cache[ck] = res
        return res

    def get_path_by_id(self, path_id: int) -> str:
        return self._get_filed_by_id("path_list", "path_id", path_id, "path")

    def get_query_by_id(self, query_id: int) -> str:
        return self._get_filed_by_id("query_list", "query_id", query_id, "query")

    def set_send_time_by_path_and_query(self, data: List[Tuple[int, int]], send_time: int):
        conn = self.get_conn()
        if not conn:
            return
        where_list = []
        parm_list = []
        for path_id, query_id in data:
            where_list.append("path_id = ? AND query_id = ?")
            parm_list.append(path_id)
            parm_list.append(query_id)
        where = " OR ".join(where_list)
        res = conn.table("seo_uri").where(where, parm_list).update({"send_time": send_time})

    def get_data(self,
                 page: int = 1,
                 size: int = 20,
                 search_path: str = '',
                 search_query: str = '',
                 start_time: int = None,
                 end_time: int = None,
                 disable: Optional[bool] = False,
                 ext: Optional[List[str]] = None,
                 no_query: Optional[bool] = None,
                 send_time: Optional[bool] = None,
                 sitemap_time: Optional[bool] = None,
                 ) -> Dict[str, Any]:

        no_data = public.get_page(0, page, size)
        no_data["data"] = []
        where_str, parm = self.build_where_params(search_path, search_query, start_time, end_time, disable, ext,
                                                  no_query, send_time, sitemap_time)
        if where_str is None:
            return no_data

        db_obj = self.get_conn()
        if not db_obj:
            return no_data
        count_ck = public.Md5(self.site_name + where_str + ",".join([str(i) for i in parm]))
        if count_ck in self.ttl_cache_count:
            count = self.ttl_cache_count[count_ck]
        else:
            if where_str:
                count = db_obj.table("seo_uri").where(where_str, parm).order("id desc").count()
            else:
                count = db_obj.table("seo_uri").order("id desc").count()
            self.ttl_cache_count[count_ck] = count

        if count == 0:
            return no_data

        page_data = get_page_with_smart_pages(count, page, size)
        lm, of = page_data['row'], page_data['shift']

        if where_str:
            data = db_obj.table('seo_uri').where(where_str, parm).order("id desc").limit(lm, of).select()
        else:
            data = db_obj.table('seo_uri').order("id desc").limit(lm, of).select()
        now_time = int(time.time())
        for i in data:
            if i["lastmod"] == 1 << 26:
                i["lastmod"] = i["time"]
            if i["sitemap_time"] == 1 << 26:
                i["sitemap_time"] = 0
            if i["send_time"] == 1 << 26:
                i["send_time"] = 0

            if i["freq"] < 7:
                freq = "{}({})".format(SiteMap.FREQ_LIST[i["freq"]], SiteMap.FREQ_LIST_NAME[i["freq"]])
            else:
                freq = "{}({})".format(SiteMap.FREQ_LIST[0], SiteMap.FREQ_LIST_NAME[0])
            i["freq"] = freq
            i["time"] = public.format_date("%Y-%m-%d %H:%M:%S", i["time"])
            i["ext"] = self.id2ext(i["ext_id"])
            path = self.get_path_by_id(i["path_id"])
            if 0 < i["priority"] <= 100:
                i["priority"] = "%.1f" % (i["priority"] / 100)
            else:
                n = max(1, min(5, path.count('/')))
                i["priority"] = "%.1f" % SiteMap.DEFAULT_PRIORITY[n]
            query = self.get_query_by_id(i["query_id"])
            if query:
                i["loc"] = "{}?{}".format(path, query)
            else:
                i["loc"] = path

        db_obj.close()
        page_data["data"] = data
        return page_data

    @classmethod
    def parser_search_args(cls, args: public.dict_obj) -> dict:
        """
            解析SEO URI数据查询参数
        """
        search_path = args.get("search_path/s", "")
        search_query = args.get("search_query/s", "")
        start_time = args.get("start_time/d", 0)
        end_time = args.get("end_time/d", 0)
        disable = None
        if "disable" in args:
            disable = args.get("disable/d", None)
        no_query = args.get("no_query/d", None)
        ext = args.get("ext/s", "[]")

        send_time = None
        if "send_time" in args:
            send_time = args.get("send_time/d", None)
            if send_time == -1:
                send_time = None
            else:
                send_time = bool(send_time)

        sitemap_time = None
        if "sitemap_time" in args:
            sitemap_time = args.get("sitemap_time/d", None)
            if sitemap_time == -1:
                sitemap_time = None
            else:
                sitemap_time = bool(sitemap_time)

        if not (search_path or search_query or start_time or end_time or
                disable is not None or ext or send_time is not None or sitemap_time is not None):
            return {}

        ext_list = []
        try:
            ext_list = json.loads(ext)
        except:
            for i in ext.split(","):
                if i:
                    ext_list.append(i)
        real_list = []
        for i in ext_list:
            if i in cls.EXT_MAP:
                real_list.append(i)

        if not real_list:
            real_list = None

        if disable is None or disable in ("-1", -1):
            disable = None
        elif disable in ("1", 1):
            disable = True
        else:
            disable = False

        if no_query is None or no_query in ("-1", -1):
            no_query = None
        elif no_query in ("1", 1):
            no_query = True
        else:
            no_query = False

        try:
            if start_time != 0 and end_time != 0:
                if start_time == end_time:
                    t = datetime.datetime.fromtimestamp(start_time)
                    start_time = int(t.replace(hour=0, minute=0, second=0).timestamp())
                    end_time = int(t.replace(hour=23, minute=59, second=59).timestamp())
                else:
                    start_time = int(
                        datetime.datetime.fromtimestamp(start_time).replace(hour=0, minute=0, second=0).timestamp())
                    end_time = int(
                        datetime.datetime.fromtimestamp(end_time).replace(hour=23, minute=59, second=59).timestamp())
        except:
            start_time = end_time = None

        return {
            "search_path": search_path,
            "search_query": search_query,
            "start_time": start_time,
            "end_time": end_time,
            "disable": disable,
            "ext": real_list,
            "no_query": no_query,
            "send_time": send_time,
            "sitemap_time": sitemap_time,
        }

    @classmethod
    def parser_change_data_args(cls, args: public.dict_obj) -> Optional[Dict]:
        change_data = args.get("change_data/s", "{}")
        try:
            change_data_dict = json.loads(change_data)
            if not isinstance(change_data_dict, dict):
                return None
        except:
            return None

        all_freq = ("always", "hourly", "daily", "weekly", "monthly", "yearly", "never")
        if "freq" in change_data_dict and change_data_dict["freq"] in all_freq:
            change_data_dict["freq"] = all_freq.index(change_data_dict["freq"])

        if "priority" in change_data_dict and isinstance(change_data_dict["priority"], (float, int)) and \
                0 < change_data_dict["priority"] <= 1:
            change_data_dict["priority"] = int(change_data_dict["priority"] * 100)

        res_dict = {}
        key_verify = {
            "priority": lambda x: isinstance(x, int) and x in range(0, 101),
            "freq": lambda x: isinstance(x, int) and 0 <= x <= 6,
            "disable": lambda x: x in (0, 1, True, False),
            "lastmod": lambda x: isinstance(x, int) and 0 <= x,
        }
        for k, v in change_data_dict.items():
            if k in key_verify:
                if not key_verify[k](v):
                    return None
                res_dict[k] = int(v)

        if not res_dict:
            return None
        return res_dict

    def build_where_params(self,
                           search_path: str = '',
                           search_query: str = '',
                           start_time: int = None,
                           end_time: int = None,
                           disable: Optional[bool] = False,
                           ext: Optional[List[str]] = None,
                           no_query: Optional[bool] = None,
                           send_time: Optional[bool] = None,
                           sitemap_time: Optional[bool] = None,
                           ) -> Tuple[Optional[str], List[Any]]:
        where_list, parm = [], []
        if ext and isinstance(ext, list):
            ext_ids = self.get_ext_ids(ext)
            if not ext_ids:
                return None, []
            ext_ids.append(0)
            where_list.append("ext_id in ({})".format(",".join(["?"] * len(ext_ids))))
            parm.extend(ext_ids)

        if start_time and end_time and not start_time <= end_time:
            return None, []

        search_path_use = False
        if no_query is not None:
            if no_query:
                where_list.append("query_id=0")
            else:
                where_list.append("query_id>0")
        else:
            if search_query and isinstance(search_query, str) and search_path and isinstance(search_path, str):
                query_id_list = self.get_query_ids(search_query)
                path_id_list = self.get_path_ids(search_path)
                if query_id_list and path_id_list:
                    where_list.append(
                        "query_id in (%s) OR path_id in (%s)" % (
                            ",".join([str(i) for i in query_id_list]),
                            ",".join([str(i) for i in path_id_list]))
                    )
                    search_path_use = True
                elif query_id_list:
                    where_list.append("query_id in (%s)" % ",".join([str(i) for i in query_id_list]))
                elif path_id_list:
                    search_path_use = True
                    where_list.append("path_id in (%s)" % ",".join([str(i) for i in path_id_list]))
                else:
                    return None, []

            elif search_query and isinstance(search_query, str):
                query_id_list = self.get_query_ids(search_query)
                if not query_id_list:
                    return None, []
                where_list.append("query_id in (%s)" % ",".join([str(i) for i in query_id_list]))

        if not search_path_use and search_path and isinstance(search_path, str):
            path_id_list = self.get_path_ids(search_path)
            if not path_id_list:
                return None, []

            where_list.append("path_id in (%s)" % ",".join([str(i) for i in path_id_list]))

        if start_time:
            where_list.append("time >= ?")
            parm.append(start_time)

        if end_time:
            where_list.append("time <= ?")
            parm.append(end_time)

        if send_time is not None:
            if send_time:
                where_list.append("send_time > 67108864")
            else:
                where_list.append("send_time <= 67108864")

        if sitemap_time is not None:
            if sitemap_time:
                where_list.append("sitemap_time > 67108864")
            else:
                where_list.append("sitemap_time <= 67108864")

        if disable is not None:
            if disable:
                where_list.append("disable=1")
            else:
                where_list.append("disable=0")

        where_str = " and ".join(where_list)
        return where_str, parm

    def set_change_by_ids(self, change_data: dict, id_list: List[int]) -> Optional[str]:
        if not isinstance(id_list, list) or not id_list:
            return "未制定要修改的数据"
        db_obj = self.get_conn()
        where_str = "id IN ({})".format(",".join(["?"] * len(id_list)))
        db_obj.table("seo_uri").where(where_str, id_list).update(change_data)
        db_obj.close()
        self.ttl_cache_count.clear()
        return None

    def set_change_by_search(self, change_data: dict, black_id_list: List[int] = None, **kwargs) -> Optional[str]:
        where_str, parm = self.build_where_params(**kwargs)
        if where_str is None:
            return "未查询到需要修改的数据"
        if black_id_list:
            if where_str:
                where_str = "{} AND ".format(where_str)
            where_str = "{}id not in ({})".format(where_str, ",".join(["?"] * len(black_id_list)))
            parm.extend(black_id_list)
        db_obj = self.get_conn()
        if where_str:
            db_obj.table("seo_uri").where(where_str, parm).update(change_data)
        else:
            db_obj.table("seo_uri").update(change_data)
        db_obj.close()
        self.ttl_cache_count.clear()
        return None

    def iter_uri(self, build_time: int, build_host: str, id_list: List[int] = None, search_data: dict = None,
                 log_func: Callable[[str], None] = print) -> Iterable[Dict]:
        """
            迭代查询SEO URI数据
        """
        if id_list is not None and not isinstance(id_list, list):
            where_str = "id in ({})".format(",".join(["?"] * len(id_list)))
            parm = id_list
        elif search_data is not None and isinstance(search_data, dict):
            search_data.pop("disable", None)
            where_str, parm = self.build_where_params(**search_data)
        else:
            where_str, parm = None, []

        db_obj = self.get_conn()
        last_id = 1 << 48
        # page 的范围应当在 100 - 1000 之间，一次导出并更新的数据量过大 可能导致磁盘长时间占用， 整体速度下降
        page = 1000
        fields = "id,path_id,query_id,priority,freq,lastmod"
        if where_str:
            count_where = where_str + " AND disable = 0"
        else:
            count_where = "disable = 0"
        count = db_obj.table("seo_uri").where(count_where, parm).count()
        log_func("开始进行数据导出....")
        log_func("本次导出数据量：{}".format(count))
        num = 0
        path_cache, query_cache = {}, {0: ""}  

        regexp_err_path = re.compile("&[^=]+=[^&=]+")

        host_db = self.get_host_db()

        if build_host.startswith("*."):
            build_host_data = build_host[2:]
            build_host = "www." + build_host_data

            def _filter_host(host_list: List[str]) -> List[str]:
                return [h for h in host_list if h.endswith(build_host_data)]
        else:
            def _filter_host(host_list: List[str]) -> List[str]:
                return [h for h in host_list if h == build_host]

        while True:
            if not where_str:
                where = "id < ? AND disable = 0"
                tmp_parm = [last_id]
            else:
                where = where_str + " AND id < ? AND disable = 0"
                tmp_parm = parm + [last_id]

            data = db_obj.table("seo_uri").where(where, tmp_parm).field(fields).order("id DESC").limit(page).select()
            if not data or not isinstance(data, list):
                break
            num += len(data)
            log_func("[{}/{}]已获取{}条URL数据，正在写入sitemap文件....".format(num, count, len(data)))

            now_ids = []

            self.__get_path_for_rows(data, path_cache)
            self.__get_query_for_rows(data, query_cache)
            self.__get_host_for_rows(data, host_db)

            for row in data:
                now_ids.append(str(row["id"]))
                # row["path"] = self.get_path_by_id(row["path_id"])
                # row["query"] = self.get_query_by_id(row["query_id"])
                if path_danger_regex.search(row["path"]) is not None:
                    continue
                if regexp_err_path.search(row["path"]) is not None:
                    continue

                if row["query"]:
                    row["loc"] = "{}?{}".format(row["path"], row["query"])
                else:
                    row["loc"] = row["path"]

                row["loc"] = escape(row["loc"])
                row["host_list"] = _filter_host(row["host_list"])
                if len(row["host_list"]) == 0:
                    row["host_list"] = [build_host]
                for i in row["host_list"]:
                    row["host"] = i
                    yield row

            last_id = data[-1]["id"]
            # 遍历成数据后更新sitemap_time
            db_obj.table("seo_uri").where("id in ({})".format(",".join(now_ids)), tuple()).update(
                {"sitemap_time": build_time})
            if len(data) < page:
                break

        host_db.close()
        db_obj.close()

    def __get_path_for_rows(self, rows: List[Dict], path_cache: Dict[int, str]):
        need_id = set()
        for row in rows:
            if row["path_id"] not in path_cache:
                need_id.add(str(row["path_id"]))

        db_obj = self.get_conn()
        path_data = db_obj.table("path_list").where("path_id in ({})".format(",".join(need_id)), tuple()).select()
        for p in path_data:
            path_cache[p["path_id"]] = p["path"]

        for row in rows:
            row["path"] = path_cache[row["path_id"]]

    def __get_query_for_rows(self, rows: List[Dict], query_cache: Dict[int, str]):
        need_id = set()
        for row in rows:
            if row["query_id"] not in query_cache:
                need_id.add(str(row["query_id"]))

        db_obj = self.get_conn()
        path_data = db_obj.table("query_list").where("query_id in ({})".format(",".join(need_id)), tuple()).select()
        for p in path_data:
            query_cache[p["query_id"]] = p["query"]

        for row in rows:
            row["query"] = query_cache[row["query_id"]]

    def __get_host_for_rows(self, rows: List[Dict], host_db: db.Sql):
        min_id = min(rows[0]["id"], rows[-1]["id"])
        max_id = max(rows[0]["id"], rows[-1]["id"])

        all_host = self.__get_all_host()
        data_list = host_db.table("seo_uri_host").where(
            "seo_uri_id >= ? AND seo_uri_id <= ?",
            (min_id, max_id)
        ).field("seo_uri_id,host_id").select()
        data_map = {}
        for i in data_list:
            host_str = all_host.get(i["host_id"], "")
            if not host_str:
                continue
            data_map.setdefault(i["seo_uri_id"], []).append(host_str)

        for row in rows:
            row["host_list"] = data_map.get(row["id"], [])

        return data_map

    def __get_all_host(self) -> Dict[int, str]:
        if self._all_host:
            return self._all_host
        db_obj = db.Sql()
        db_obj._Sql__DB_FILE = self.db_path + "/global/list.db"
        all_host_list = db_obj.table("host").field("host_id,host").select()
        self._all_host = {}
        for i in all_host_list:
            self._all_host[i["host_id"]] = i["host"]

        return self._all_host

    def get_host_db(self):
        db_obj = db.Sql()
        db_obj._Sql__DB_FILE = os.path.join(self.db_path, self.site_name, 'seo_uri_host.db')
        return db_obj

    def get_sitemap_data(self, sitemap_path: str = None):
        """
        获取站点地图文件数据
        
        @param sitemap_path: 站点地图路径，如果为None则从配置中获取默认路径
        @return tuple: (站点地图路径, 文件数据列表)
        
        返回的文件数据包含以下字段：
        - path: 完整文件路径
        - uri: 相对URI路径  
        - url: 完整访问URL
        - name: 文件名
        - size: 文件大小（字节）
        - time: 文件修改时间
        - host: 主机信息
        - baidu: 百度收录状态信息
        """
        # 获取站点地图路径，如果未指定则从配置中获取
        if not sitemap_path:
            sitemap_path = SiteMap.get_site_sitemap_info(self.site_name, "use_path")
            if not isinstance(sitemap_path, str):
                sitemap_path = "/"

        # 获取站点信息和运行路径
        site_info = sitetool.get_site_info(self.site_name)
        run_path = sitetool.site_run_path(self.site_name, site_info['project_type'])
        path = os.path.join(run_path, sitemap_path.lstrip("/"))
        
        # 检查路径是否存在，不存在则返回空列表
        if not os.path.isdir(path):
            return sitemap_path, []
        res = []

        def test_ext(p: str) -> bool:
            """
            检查文件是否为支持的站点地图格式
            
            @param p: 文件路径
            @return bool: 是否为支持的站点地图格式
            """
            for ext in (".txt", ".xml", ".xml.gz"):
                if p.endswith(ext):
                    return True
            return False

        # 获取百度站点列表和缓存
        sites = BaiduZZApi.bt_site2baidu_site(self.site_name)
        baidu_cache = {}
        
        # 遍历目录中的所有文件
        for f in os.listdir(path):
            tmp = os.path.join(path, f)
            # 检查是否为站点地图文件（支持.txt, .xml, .xml.gz格式且文件名包含sitemap）
            if os.path.isfile(tmp) and test_ext(tmp) and f.find("sitemap") != -1:
                # 尝试解析站点地图文件获取主机信息
                try:
                    host, baidu_site = self._get_sitemap_host(tmp)
                except:
                    host = baidu_site = None
                
                # 检查是否在百度站点列表中，获取百度收录状态
                if baidu_site in sites:
                    # 使用缓存避免重复查询百度API
                    if baidu_site in baidu_cache:
                        data_list = baidu_cache[baidu_site]
                    else:
                        data_list = BaiduZZApi(default_site=baidu_site).link_submit_list(baidu_site)
                        baidu_cache[baidu_site] = data_list
                else:
                    data_list = []

                # 构建相对URI路径
                uri = tmp.replace(run_path.rstrip("/"), "")
                is_baidu = None
                
                # 在百度提交列表中查找匹配的URL
                for i in data_list:
                    if i["url"].endswith(uri):
                        is_baidu = i
                        break

                # 构建返回数据
                res.append({
                    "path": tmp,  # 完整文件路径
                    "uri": uri,   # 相对URI路径
                    "url": uri if baidu_site is None else baidu_site + uri.lstrip("/"),  # 完整访问URL
                    "name": f,    # 文件名
                    "size": os.path.getsize(tmp),  # 文件大小
                    "time": os.path.getmtime(tmp), # 修改时间
                    "host": host, # 主机信息
                    "baidu": is_baidu  # 百度收录状态
                })
        return sitemap_path, res

    @staticmethod
    def _get_sitemap_host(file: str):
        regexp_url = re.compile("(http|https)://(?P<host>[^/]+)/")
        if file.endswith(".txt"):
            with open(file, "r") as fd:
                line = fd.readline()
            res_url = parse_url(line)
            return res_url.netloc, res_url.scheme + "://" + res_url.netloc + "/"
        elif file.endswith(".xml"):
            data = []
            with open(file, "r") as fd:
                for i in range(8):
                    tmp = fd.readline()
                    if i < 2:
                        continue
                    data.append(tmp)
            data_str = "\n".join(data)
        elif file.endswith(".xml.gz"):
            data = []
            with gzip.open(file, 'rt', encoding='utf-8') as fd:
                for i in range(8):
                    tmp = fd.readline()
                    if i < 2:
                        continue
                    data.append(tmp)
            data_str = "\n".join(data)
        else:
            return None, None

        res_url = regexp_url.search(data_str)
        if res_url:
            return res_url.group("host"), res_url.group()
        return None, None


class _ChangeConfig:
    _CONFIG_FILE = "{}/sitemap_config.json".format(public.get_plugin_path('monitor'))
    default_build_config = {
        "domain": "",
        "lastmod": None,
        "out_type": ["txt"],
        "other_schema": "pc",
        "page_type": "std",
        "changefreq": "always",
        "page_num": 2000,
        "priority": {
            1: 1,
            2: 0.8,
            3: 0.4,
            4: 0.2,
            5: 0.1,
        },
        "use": False,
        "use_path": "/",
        "max_sitemap_files": 60,
        "auto_cleanup": True
    }

    @classmethod
    def parser_build_config(cls, args: public.dict_obj) -> Optional[dict]:
        """
        domain  域名
        lastmod  最后修改时间
        out_type  输出类型  "txt", "xml", "xml.gz"
        other_schema  协议 "pc", "mobile"
        page_type 分页 "baidu", "std"
        changefreq 默认权限  "always", "hourly", "daily", "weekly", "monthly", "yearly", "never"
        page_num 每页url条数 1- 40000
        priority 默认权重 json对象  key 1-6 value 0.1-1
        max_sitemap_files 最大保存sitemap文件数量 正整数，默认60
        auto_cleanup 是否自动清理旧文件 布尔值，默认true

        """
        change_data = args.get("build_config/s", "{}")

        try:
            change_data_dict = json.loads(change_data)
            if not isinstance(change_data_dict, dict):
                return None
            new_priority = {}
            for k, v in change_data_dict.get("priority", {}).items():
                new_priority[int(k)] = v
            if new_priority:
                change_data_dict["priority"] = new_priority
        except:
            public.print_log("解析 sitemap_config.json 失败")
            return None

        res_dict = {}
        key_verify = {
            "domain": lambda x: isinstance(x, str) and x.strip(),
            "lastmod": lambda x: x is None or isinstance(x, int) and x >= 0,
            "out_type": lambda x: all(i in ("txt", "xml", "xml.gz") for i in x),
            "other_schema": lambda x: x in ("pc", "mobile", "all"),
            "page_type": lambda x: x in ("baidu", "std", "all"),
            "changefreq": lambda x: x in ("always", "hourly", "daily", "weekly", "monthly", "yearly", "never"),
            "page_num": lambda x: isinstance(x, int) and 0 < x <= 40000,
            "priority": lambda x: isinstance(x, dict) and all(n in range(1, 6) and 0 < m <= 1 for n, m in x.items()),
            "max_sitemap_files": lambda x: isinstance(x, int) and x > 0,
            "auto_cleanup": lambda x: isinstance(x, bool),
        }

        for k, v in change_data_dict.items():
            if k in key_verify:
                if not key_verify[k](v):
                    return None
                res_dict[k] = v

        if "use" in change_data_dict:
            use_data = change_data_dict["use"]
            if isinstance(use_data, str):
                if use_data.lower() in ("true", "1"):
                    res_dict["use"] = True
                else:
                    res_dict["use"] = False
            if isinstance(use_data, bool):
                res_dict["use"] = use_data

        if "use_path" in change_data_dict:
            use_path_data = change_data_dict["use_path"]
            if isinstance(use_path_data, str):
                res_dict["use_path"] = use_path_data

        if "submit" in change_data_dict:
            submit_data = change_data_dict["submit"]
            if isinstance(submit_data, (bool, int, float)):
                res_dict["submit"] = bool(submit_data)

            if isinstance(submit_data, str):
                if submit_data.lower() in ("true", "1"):
                    res_dict["submit"] = True
                else:
                    res_dict["submit"] = False

        if "submit_list" in change_data_dict:
            submit_list = change_data_dict["submit_list"]
            if isinstance(submit_list, list):
                res_dict["submit_list"] = submit_list

        #  解析下max_sitemap_files 和auto_cleanup
        if "max_sitemap_files" in change_data_dict:
            max_sitemap_files = change_data_dict["max_sitemap_files"]
            if isinstance(max_sitemap_files, int) and max_sitemap_files > 0:
                res_dict["max_sitemap_files"] = max_sitemap_files
            else:
                res_dict["max_sitemap_files"] = 60

        if "auto_cleanup" in change_data_dict:
            auto_cleanup = change_data_dict["auto_cleanup"]
            if isinstance(auto_cleanup, bool):
                res_dict["auto_cleanup"] = auto_cleanup
            elif isinstance(auto_cleanup, str):
                if auto_cleanup.lower() in ("true", "1"):
                    res_dict["auto_cleanup"] = True
                else:
                    res_dict["auto_cleanup"] = False
            else:
                res_dict["auto_cleanup"] = True

        if not res_dict:
            return None
        return res_dict

    def __init__(self):
        if not os.path.isfile(self._CONFIG_FILE):
            public.writeFile(self._CONFIG_FILE, "{}")

        self._config: Optional[dict] = None

    @property
    def config(self) -> dict:
        if self._config is None:
            try:
                config = json.loads(public.readFile(self._CONFIG_FILE))
            except (json.JSONDecodeError, TypeError, ValueError):
                config = {}

            self._config = config

        return self._config

    def get_config(self, site_name: str):
        if site_name in self.config:
            return self.config[site_name]
        else:
            copy.deepcopy(self.default_build_config)

    def set_config(self, site_name: str, build_config: dict = None):
        self.config[site_name] = build_config
        public.writeFile(self._CONFIG_FILE, json.dumps(self.config))


class SiteMap:
    SITEMAP_PATH = "/www/server/monitor/sitemap"
    XML_VERSION = '<?xml version="1.0" encoding="UTF-8"?>\n'
    URL_SET_HEADER_PC = '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
    URL_SET_HEADER_MOBILE = '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:mobile="http://www.baidu.com/schemas/sitemap-mobile/1/">\n'
    SITEMAP_INDEX_HEADER = '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
    FREQ_LIST = ("always", "hourly", "daily", "weekly", "monthly", "yearly", "never")
    FREQ_LIST_NAME = ("随时", "每小时", "每天", "每周", "每月", "每年", "从不")
    PID_FILE = "{}/pid.txt".format(SITEMAP_PATH)
    DEFAULT_PRIORITY = {
        1: 1.0,
        2: 0.6,
        3: 0.4,
        4: 0.2,
        5: 0.1,
    }
    CRON_TASK_CONF = "{}/crontab_sitemap_config.json".format(public.get_plugin_path("monitor"))
    SITEMAP_USE_INFO = "{}/site_sitemap_info.json".format(public.get_plugin_path("monitor"))

    @classmethod
    def set_site_sitemap_info(cls, site_name: str, k_v_data: dict):
        if not os.path.isfile(cls.SITEMAP_USE_INFO):
            public.writeFile(cls.SITEMAP_USE_INFO, "{}")

        try:
            data = json.loads(public.readFile(cls.SITEMAP_USE_INFO))
        except:
            data = {}

        data.setdefault(site_name, {}).update(k_v_data)
        public.writeFile(cls.SITEMAP_USE_INFO, json.dumps(data))

    @classmethod
    def get_site_sitemap_info(cls, site_name: str, key: str):
        if not os.path.isfile(cls.SITEMAP_USE_INFO):
            public.writeFile(cls.SITEMAP_USE_INFO, "{}")

        try:
            data = json.loads(public.readFile(cls.SITEMAP_USE_INFO))
        except:
            data = {}

        return data.get(site_name, {}).get(key, None)

    @classmethod
    def read_cron_conf(cls) -> Dict[str, Dict[str, Any]]:
        try:
            data = json.loads(public.readFile(cls.CRON_TASK_CONF))
        except:
            data = {}
        if not isinstance(data, dict):
            data = {}
        return data

    @staticmethod
    def check_cron_task():
        if public.M('crontab').where('name=?', '宝塔监控报表-SiteMap定时生成任务').find():
            return public.returnMsg(False, '定时任务已存在!')

        import crontab
        crontabs = crontab.crontab()
        sh = "{}/pyenv/bin/python3.7 -u {}/monitor_seo.py cron_task".format(
            public.get_panel_path(), public.get_plugin_path('monitor')
        )
        args = {
            "name": "宝塔监控报表-SiteMap定时生成任务",
            "type": 'day',
            "where1": '',
            "hour": '3',
            "week": "",
            "minute": '50',
            "sName": 'toShell',
            "sType": 'toShell',
            "notice": '',
            "notice_channel": '',
            "save": '',
            "save_local": '1',
            "backupTo": '',
            "sBody": sh,
            "urladdress": '',
            "status": "1"
        }
        res = crontabs.AddCrontab(args)
        if res["status"] and "id" in res.keys():
            return public.returnMsg(True, '定时任务添加成功!')
        return public.returnMsg(False, '定时任务添加失败')

    @classmethod
    def remove_cron_task(cls, args: public.dict_obj):
        site_name = args.get("SiteName/s", "")  # 站点名称 -> 必填
        if not site_name:
            return False, "站点名称不能为空"
        conf = cls.read_cron_conf()
        if site_name not in conf:
            return True, "删除成功"
        else:
            conf.pop(site_name)

        public.writeFile(cls.CRON_TASK_CONF, json.dumps(conf))
        cls.check_cron_task()
        return True, "删除成功"

    @classmethod
    def get_build_config(cls, site_name: str) -> dict:
        return _ChangeConfig().get_config(site_name)

    parser_build_config = _ChangeConfig.parser_build_config

    @classmethod
    def remove_all_records(cls, site_name: str):
        sitemap_dir = "{}/{}".format(cls.SITEMAP_PATH, site_name)
        if os.path.isdir(sitemap_dir):
            shutil.rmtree(sitemap_dir)

    def _auto_cleanup_old_files(self, log_func: Callable[[str], None], max_files: int):
        """
        自动清理旧的sitemap文件，保持指定数量
        @param log_func: 日志输出函数
        @param max_files: 最大保存文件数量
        """
        if max_files <= 0:
            return

        if not os.path.isdir(self.sitemap_dir):
            return

        # 获取所有时间戳目录
        timestamp_dirs = []
        for item in os.listdir(self.sitemap_dir):
            if item.isdigit():
                timestamp_path = os.path.join(self.sitemap_dir, item)
                if os.path.isdir(timestamp_path):
                    timestamp_dirs.append(int(item))

        # 按时间排序，最新的在前
        timestamp_dirs.sort(reverse=True)

        # 如果超过最大数量，删除最旧的
        if len(timestamp_dirs) > max_files:
            to_delete = timestamp_dirs[max_files:]
            deleted_count = 0

            for timestamp in to_delete:
                try:
                    old_dir = os.path.join(self.sitemap_dir, str(timestamp))
                    if os.path.isdir(old_dir):
                        shutil.rmtree(old_dir)
                        deleted_count += 1
                except Exception as e:
                    log_func(f"删除目录 {timestamp} 时出错: {str(e)}")

            if deleted_count > 0:
                log_func(f"自动清理完成，删除了 {deleted_count} 个旧版本，保留最新 {max_files} 个")

    @classmethod
    def remove_record(cls, site_name: str, task_id: Union[int, str]):
        sitemap_dir = "{}/{}".format(cls.SITEMAP_PATH, site_name)
        if not os.path.isdir(sitemap_dir):
            return

        for i in os.listdir(sitemap_dir):
            if i.isdigit() and i == str(task_id):
                task_path = os.path.join(sitemap_dir, i)
                if os.path.isdir(task_path):
                    shutil.rmtree(task_path)
                    return

    @classmethod
    def sitemap_list(cls, site_name: str):
        sitemap_dir = "{}/{}".format(cls.SITEMAP_PATH, site_name)
        if not os.path.isdir(sitemap_dir):
            os.makedirs(sitemap_dir)

        res = list()
        for i in os.listdir(sitemap_dir):
            if i.isdigit():
                date = datetime.datetime.fromtimestamp(int(i))
                res.append({
                    "date": date.strftime("%Y-%m-%d %H:%M:%S"),
                    "task_id": int(i),
                    "running": False
                })

        res.sort(key=lambda x: x["task_id"], reverse=True)
        if cls.running() and len(res) > 0:
            res[0]["running"] = True

        return res

    def pack(self) -> str:
        pack_data = {
            "site_name": self.site_name,
            "db_path": self.db_path,
            "build_config": self.build_config,
            "search_data": self.search_data,
            "id_list": self.id_list,
            "build_time": self.build_time,
        }
        return base64.b64encode(json.dumps(pack_data).encode("utf-8")).decode("utf-8")

    def pack_data(self) -> dict:
        return {
            "site_name": self.site_name,
            "build_config": self.build_config,
            "search_data": self.search_data,
            "id_list": self.id_list,
        }

    @staticmethod
    def get_global_db_path() -> str:
        config_file = "/www/server/monitor/config/config.json"
        try:
            conf_data = json.loads(public.readFile(config_file))
        except:
            return ""

        return conf_data.get("data_save_path", "")

    @classmethod
    def unpack(cls, pack_data: str) -> Optional["SiteMap"]:
        pack_data = base64.b64decode(pack_data).decode("utf-8")
        try:
            pack_data = json.loads(pack_data)
            if "build_config" in pack_data and isinstance(pack_data["build_config"], dict):
                res = cls(
                    pack_data["site_name"],
                    pack_data["db_path"],
                    pack_data["build_config"],
                    pack_data["id_list"],
                    pack_data["search_data"]
                )
                res.build_time = pack_data["build_time"]
                return res
        except:
            pass
        return None

    @classmethod
    def unpack_data(cls, pack_data: dict) -> Optional["SiteMap"]:
        try:
            if "build_config" in pack_data and isinstance(pack_data["build_config"], dict):
                res = cls(
                    pack_data["site_name"],
                    pack_data["db_path"],
                    pack_data["build_config"],
                    pack_data["id_list"],
                    pack_data["search_data"]
                )
                res.build_time = pack_data["build_time"]
                return res
        except:
            pass
        return None

    @classmethod
    def stop(cls):
        pid = public.readFile(cls.PID_FILE)
        if isinstance(pid, str):
            try:
                p = psutil.Process(int(pid))
                if p.is_running():
                    p.terminate()
            except:
                pass

    @classmethod
    def running(cls) -> bool:
        pid = public.readFile(cls.PID_FILE)
        if isinstance(pid, str):
            try:
                p = psutil.Process(int(pid))
                return p.is_running()
            except:
                return False
        return False

    def start(self) -> Union[str, int]:
        if self.running():
            return "当前有其他任务正在运行中，请勿同时开启多个任务"

        run_path = "{}/{}".format(self.sitemap_dir, self.build_time)
        if not os.path.exists(run_path):
            os.makedirs(run_path)
        log_file = "{}/{}/task.log".format(self.sitemap_dir, self.build_time)
        public.writeFile(log_file, "")
        python = "{}/pyenv/bin/python3.7".format(public.get_panel_path())
        script_file = "{}/monitor_seo.py".format(public.get_plugin_path("monitor"))

        _sh = "nohup {} -u {} build_sitemap {} &> {} &".format(
            python, script_file, self.pack(), log_file
        )

        res = public.ExecShell(_sh)
        return self.build_time

    @classmethod
    def run_cron_task_for_site_data(cls, data):
        log_file = "{}/{}/{}/task.log".format(cls.SITEMAP_PATH, data["site_name"], data["build_time"])
        run_path = os.path.dirname(log_file)
        if not os.path.exists(run_path):
            os.makedirs(run_path)
        public.writeFile(log_file, "【定时生成SiteMap任务】")

        def log_func(log_str: str):
            print(log_str)
            with open(log_file, "a") as fp:
                print(log_str, file=fp)

        task = cls.unpack_data(data)
        if task is None:
            print("读取配置失败！！！")
            print("跳过网站：{}的任务".format(data["site_name"]))
            return
        task.build(log_func)

    def set_cron_task(self):
        conf = self.read_cron_conf()
        conf[self.site_name] = self.pack_data()
        public.writeFile(self.CRON_TASK_CONF, json.dumps(conf))
        self.check_cron_task()

    def __init__(self,
                 site_name: str,
                 db_path: str,
                 build_config: dict,
                 id_list: List[int] = None,
                 search_data: Dict[str, Any] = None,
                 ):
        self.site_name = site_name
        self.db_path = db_path
        self.build_config = build_config
        self._uri_data: Optional[SeoUriData] = None
        self.search_data = search_data
        self.id_list = id_list
        self.sitemap_dir = "{}/{}".format(self.SITEMAP_PATH, self.site_name)
        if not os.path.isdir(self.sitemap_dir):
            os.makedirs(self.sitemap_dir)

        # 创建用参数
        self.out_type: List[str] = ["txt", "xml", "xml.gz"]
        self.other_schema = "all"
        self.out_txt = True
        self.out_xml = True
        self.out_mobile = True
        self.out_pc = True
        self.page_type = "all"
        self.page_num = 2000
        self.lastmod = None
        self.priority = copy.deepcopy(self.DEFAULT_PRIORITY)

        # 文件句柄 与 变量
        self._txt_fs: Optional[TextIO] = None
        self._xml_fs: Optional[TextIO] = None
        self._xml_fs_mobile: Optional[TextIO] = None
        self.idx: int = 1
        self._url_set: Optional[Dict[str, dict]] = None
        self.build_time = int(time.time())
        self.build_host = ""
        self.url_schema = "https://"
        self.now_str = None

        self.use = False
        self.use_path = "/"

        self.submit = False
        self.submit_list = ["baidu"]

        # 清理配置默认值
        self.max_sitemap_files = 60
        self.auto_cleanup = True

    def _init_args(self):
        out_type = self.build_config.get("out_type", None)
        other_schema = self.build_config.get("other_schema", None)
        page_type = self.build_config.get("page_type", None)
        page_num = self.build_config.get("page_num", None)
        lastmod = self.build_config.get("lastmod", None)
        priority = self.build_config.get("priority", None)
        domain = self.build_config.get("domain", "")
        use = self.build_config.get("use", None)
        use_path = self.build_config.get("use_path", "")
        max_sitemap_files = self.build_config.get("max_sitemap_files", None)
        auto_cleanup = self.build_config.get("auto_cleanup", None)

        submit = self.build_config.get("submit", None)
        submit_list = self.build_config.get("submit_list", "")

        if not sitetool.site_use_https(self.site_name):
            self.url_schema = "http://"

        if domain:
            self.build_host = domain

        if page_type is not None:
            if page_type in ["baidu", "std", "all"]:
                self.page_type = page_type

        if out_type is not None:
            self.out_type = []
            for t in out_type:
                if t in ["txt", "xml", "xml.gz"] and t not in self.out_type:
                    self.out_type.append(t)
            if not self.out_type:
                self.out_type = ["txt", "xml", "xml.gz"]

        if page_num is not None:
            self.page_num = max(1, min(page_num, 50000))

        if priority is not None and isinstance(priority, dict):
            for i in range(1, 6):
                if i in priority and 0 <= priority[i] <= 1:
                    self.priority[i] = priority[i]

        if lastmod is not None and isinstance(lastmod, int) and lastmod > 0:
            self.lastmod = lastmod
            self.now_str = time.strftime("%Y-%m-%d", time.localtime(lastmod))

        if other_schema is not None:
            if other_schema in ["mobile", "pc", "all"]:
                self.other_schema = other_schema

        if not os.path.isdir("{}/{}".format(self.sitemap_dir, self.build_time)):
            os.makedirs("{}/{}".format(self.sitemap_dir, self.build_time))

        if self.other_schema == "pc" or self.other_schema == "all":
            self.out_pc = True
        else:
            self.out_pc = False

        # if self.other_schema == "mobile" or self.other_schema == "all":
        #     self.out_mobile = True
        # else:
        self.out_mobile = False

        if "txt" in self.out_type:
            self.out_txt = True
        else:
            self.out_txt = False

        if "xml" in self.out_type or "xml.gz" in self.out_type:
            self.out_xml = True
        else:
            self.out_xml = False

        if use is not None:
            self.use = bool(use)

        if use_path:
            self.use_path = use_path

        if submit is not None:
            self.submit = bool(submit)

        if submit_list and isinstance(submit_list, list):
            self.submit_list = submit_list

        # 初始化新的清理配置项
        if max_sitemap_files is not None:
            self.max_sitemap_files = max(1, min(max_sitemap_files, 100))
        else:
            self.max_sitemap_files = 60

        if auto_cleanup is not None:
            self.auto_cleanup = bool(auto_cleanup)
        else:
            self.auto_cleanup = True

    @property
    def uri_data(self) -> SeoUriData:
        if self._uri_data is None:
            self._uri_data = SeoUriData(self.site_name, self.db_path)
        return self._uri_data

    @property
    def txt_fs(self):
        if self._txt_fs is None:
            self._txt_fs = open("{}/{}/sitemap{}.txt".format(self.sitemap_dir, self.build_time, self.idx), "w")
        return self._txt_fs

    @property
    def xml_fs(self):
        if self._xml_fs is None:
            self._xml_fs = open("{}/{}/sitemap{}.xml".format(self.sitemap_dir, self.build_time, self.idx), "w")
            self.xml_fs.write(self.XML_VERSION)
            self.xml_fs.write(self.URL_SET_HEADER_PC)

        return self._xml_fs

    @property
    def xml_fs_mobile(self):
        if self._xml_fs_mobile is None:
            self._xml_fs_mobile = open(
                "{}/{}/sitemap-mobile{}.xml".format(self.sitemap_dir, self.build_time, self.idx), "w")
            self._xml_fs_mobile.write(self.XML_VERSION)
            self._xml_fs_mobile.write(self.URL_SET_HEADER_MOBILE)

        return self._xml_fs_mobile

    def next(self):
        self.idx += 1
        if self._xml_fs is not None:
            self._xml_fs.write("</urlset>")
            self._xml_fs.close()
            self._xml_fs = None

        if self._txt_fs is not None:
            self._txt_fs.close()
            self._txt_fs = None

        if self._xml_fs_mobile is not None:
            self._xml_fs_mobile.write("</urlset>")
            self._xml_fs_mobile.close()
            self._xml_fs_mobile = None

    def close(self):
        if self._xml_fs is not None:
            self._xml_fs.write("</urlset>")
            self._xml_fs.close()
        if self._txt_fs is not None:
            self._txt_fs.close()
        if self._xml_fs_mobile is not None:
            self._xml_fs_mobile.write("</urlset>")
            self._xml_fs_mobile.close()

    @classmethod
    def use_sitemap(cls, site_name: str, task_id: Union[str, int], use_path: str = "/") -> Optional[str]:
        cls.set_site_sitemap_info(site_name, {"use_path": use_path, "task_id": task_id})
        site_info = sitetool.get_site_info(site_name)
        if not site_info:
            return "没有查询到当前网站"
        run_path = sitetool.site_run_path(site_name, site_info["project_type"])
        if not run_path or not os.path.isdir(run_path):
            return "当前网站没有查询到运行目录"

        run_path = os.path.abspath(run_path)
        src_dir = "{}/{}/{}".format(cls.SITEMAP_PATH, site_name, task_id)
        if not os.path.isdir(src_dir):
            return "当前任务没有查询到sitemap文件"
        target_path = run_path + use_path
        target_path = os.path.abspath(target_path)
        use_path = target_path.replace(run_path, "")
        if not os.path.isdir(target_path):
            os.makedirs(target_path, 0o755)
            public.set_mode(target_path, "755")
            public.set_own(target_path, "www")

        need_attr_i = False
        file_list = []
        without_list = []
        for f in os.listdir(src_dir):
            if "sitemap" in f and os.path.isfile(src_dir + "/" + f):
                has_attr_i = file_attr_i(target_path + "/" + f)
                if has_attr_i:
                    file_attr_del_i(target_path + "/" + f)
                need_attr_i = has_attr_i or need_attr_i
                shutil.copy(src_dir + "/" + f, target_path)
                without_list.append(f)
                public.set_mode(target_path + "/" + f, "755")
                public.set_own(target_path + "/" + f, "www")
                file_list.append(target_path + "/" + f)

        if need_attr_i:
            for fn in file_list:
                file_attr_add_i(fn)

        index_file = "{}/sitemap.xml".format(target_path)
        cls.change_index_file(index_file, use_path)
        cls.clear_old_sitemap(target_path, without_list)

    @classmethod
    def change_index_file(cls, index_file: str, use_path: str = "/"):
        # 本来就是生成为根目录，不需要修改
        if use_path == "/" or use_path == "":
            return

        data = public.readFile(index_file)
        if not isinstance(data, str):
            return

        # 不是索引行文件
        if data.find("<sitemapindex") == -1:
            return

        loc_regexp = re.compile(r'<loc>(?P<host>[^/]*//[^/]*)(?P<uri>.*)</loc>')
        idx = 0
        new_data = []
        for machine in loc_regexp.finditer(data):
            start = machine.start()
            end = machine.end()
            host = machine.group("host")
            uri = machine.group("uri")
            new_data.append(data[idx:start])
            new_data.append("<loc>{}</loc>".format(host + use_path + uri))
            idx = end

        new_data.append(data[idx:])

        has_attr_i = file_attr_i(index_file)
        if has_attr_i:
            file_attr_del_i(index_file)

        public.writeFile(index_file, "".join(new_data))
        if has_attr_i:
            file_attr_add_i(index_file)

        index_file_gz = "{}.gz".format(index_file)
        if os.path.isfile(index_file_gz):
            has_attr_i = file_attr_i(index_file_gz)
            if has_attr_i:
                file_attr_del_i(index_file_gz)
            os.remove(index_file_gz)
            with open(index_file, 'rb') as src_fp:
                with gzip.open(index_file_gz, 'wb') as dst:
                    shutil.copyfileobj(src_fp, dst)

            public.set_own(index_file_gz, "www")
            public.set_mode(index_file_gz, "644")
            if has_attr_i:
                file_attr_add_i(index_file_gz)

    @staticmethod
    def clear_old_sitemap(path: str, without: List[str] = None):
        if without is None:
            without = []
        exp = re.compile(r"^sitemap(-mobile)?\d+\.(xml|txt)$")
        try:
            for f in os.listdir(path):
                if f in without:
                    continue
                if f in ("sitemap.xml", "sitemap-mobile.xml", "sitemap.txt"):
                    os.remove(path + "/" + f)
                elif exp.match(f):
                    os.remove(path + "/" + f)
        except:
            pass

    def build(self, log_func: Callable[[str], None] = print):
        self._init_args()
        public.writeFile(str(os.getpid()), self.PID_FILE)
        self.now_str = public.format_date("%Y-%m-%d", self.lastmod or self.build_time)
        log_func("开始生成网站【{}】的sitemap文件...".format(self.build_host))
        num = 0
        host_set = set()
        for data in self.uri_data.iter_uri(self.build_time, self.build_host, id_list=self.id_list,
                                           search_data=self.search_data, log_func=log_func):
            if not data["host"]:
                continue
            host_set.add(data["host"])
            if self.out_xml:
                self.add_to_xml(data)
            if self.out_pc:
                self.add_to_txt(data)
            num += 1
            if num >= self.page_num:
                self.next()
                num = 0

        self.close()
        if self.idx == 1:
            for i in ("txt", "xml"):
                src = "{}/{}/sitemap1.{}".format(self.sitemap_dir, self.build_time, i)
                target = "{}/{}/sitemap.{}".format(self.sitemap_dir, self.build_time, i)
                if os.path.isfile(src):
                    os.rename(src, target)

            src = "{}/{}/sitemap-mobile1.{}".format(self.sitemap_dir, self.build_time, i)
            target = "{}/{}/sitemap-mobile.{}".format(self.sitemap_dir, self.build_time, i)
            if os.path.isfile(src):
                os.rename(src, target)
        else:
            self.build_sitemap_idx(self.idx, host_set)

        if "xml.gz" in self.out_type:
            for i in ("sitemap.xml", "sitemap-mobile.xml"):
                # 通过sitemap.xml生成sitemap.xml.gz的gzip的压缩文件
                src = "{}/{}/{}".format(self.sitemap_dir, self.build_time, i)
                if not os.path.isfile(src):
                    continue
                target = src + ".gz"
                with open(src, 'rb') as src_fp:
                    with gzip.open(target, 'wb') as dst:
                        shutil.copyfileobj(src_fp, dst)

        if self.use and self.use_path:
            log_func("开始应用到网站...")
            res = self.use_sitemap(self.site_name, self.build_time, self.use_path)
            if isinstance(res, str):
                log_func("应用失败:" + res)

        if self.submit and self.submit_list:
            log_func("开始提交到搜索引擎...")
            if "baidu" in self.submit_list:
                site = self.url_schema + self.build_host.lstrip("*.") + "/"
                zz = BaiduZZApi(default_site=site)
                _, m = zz.link_submit_update_all(site)
                log_func("百度站长平台:" + m)
            if "360" in self.submit_list:
                site = self.build_host.lstrip("*.")
                zz = ZZ360Api(default_site=site)
                _, m = zz.update_sitemap_all(site)
                log_func("360站长平台:" + m)

        # 自动清理旧的sitemap文件
        # 读取self.max_sitemap_files，没有默认
        # auto_cleanup = self.build_config.get("auto_cleanup", True)
        # max_sitemap_files = self.build_config.get("max_sitemap_files", 60)
        if self.auto_cleanup:
            try:
                log_func("开始清理旧的sitemap文件...")
                self._auto_cleanup_old_files(log_func, self.max_sitemap_files)
            except Exception as e:
                log_func(f"清理旧文件时出错: {str(e)}")

    # 多页时创建sitemap索引
    def build_sitemap_idx(self, idx: int, host_set: Set[str]):
        if self.page_type == "std" or self.page_type == "all":
            self.__build_sitemap_idx(idx, self.SITEMAP_INDEX_HEADER, "</sitemapindex>", "", host_set)

    def __build_sitemap_idx(self, idx: int, header: str, footer: str, suffix: str, host_set: Set[str]):
        with open("{}/{}/sitemap{}.xml".format(self.sitemap_dir, self.build_time, suffix), "w") as xml_fs:
            xml_fs.write(self.XML_VERSION)
            xml_fs.write(header)
            item_format = '<loc>{}/sitemap{}.xml</loc>\n<lastmod>{}</lastmod>\n'
            for i in range(1, idx + 1):
                for host in host_set:
                    xml_fs.write("<sitemap>\n")
                    xml_fs.write(item_format.format(self.url_schema + host, i, self.now_str))
                    xml_fs.write("</sitemap>\n")
            xml_fs.write(footer)

    def add_to_txt(self, data: dict):
        if "txt" not in self.out_type:
            return
        url = self.url_schema + data["host"] + data["loc"]
        self.txt_fs.write(url)
        self.txt_fs.write("\n")

    def add_to_xml(self, data: dict):
        lastmod = data.get("lastmod", 0)
        if lastmod > (1 << 26):
            lm = time.strftime("%Y-%m-%d", time.localtime(lastmod))
        else:
            lm = self.now_str

        if data["priority"] > 0:
            priority = data["priority"] / 100
        else:
            p = max(1, min(5, data["path"].count("/")))
            priority = self.priority[p]

        if data["freq"] < 7:
            freq = self.FREQ_LIST[data["freq"]]
        else:
            freq = self.FREQ_LIST[0]

        url = self.url_schema + data["host"] + data["loc"]
        if self.out_pc:
            u = Xurl(loc=url, priority=priority, lastmod=lm, changefreq=freq, mobile=None)
            self.xml_fs.write(str(u) + "\n")
        if self.out_mobile:
            u = Xurl(loc=url, priority=priority, lastmod=lm, changefreq=freq, mobile="mobile")
            self.xml_fs_mobile.write(str(u) + "\n")

    @classmethod
    def run_cron_task(cls):
        db_path = cls.get_global_db_path()
        if not db_path or not os.path.exists(db_path):
            print("无法获取任务数据")
            return
        config_map = cls.read_cron_conf()
        all_site = sitetool.get_site_list()
        if not config_map:
            print("暂无定时任务")
            return
        if not all_site:
            print("暂无站点")
            return

        t = int(time.time())
        target_site = []
        has_all = None
        for site_name, item in config_map.items():
            if item.get("status", 1) not in (1, True, "true"):
                continue
            if site_name == "all":
                has_all = item
                continue

            if site_name not in all_site:
                print("站点不存在：{}".format(item["site_name"]))
                continue
            item["site_name"] = site_name
            item["db_path"] = db_path
            item["build_time"] = t
            target_site.append(item)
            all_site.remove(item["site_name"])

        if has_all:
            for i in all_site:
                tmp = has_all.copy()
                tmp["site_name"] = i
                tmp["db_path"] = db_path
                tmp["build_time"] = t
                target_site.append(tmp)

        for item in target_site:
            print("开始处理网站：{} ".format(item["site_name"]))
            cls.run_cron_task_for_site_data(item)


class _SpiderAnalysisConfig:
    CONFIG_FILE = "/www/server/monitor/config/spider_analysis_config.json"

    # _config_ = {
    #     {
    #         "192.168.69.172": {
    #             "ip_rule": [
    #                 {
    #                     "rule": "3702877184-3702877439",
    #                     "ruleSource": "220.181.108.*",
    #                     "id": "srrfka",
    #                     "name": "沙盒",
    #                     "show": True,
    #                     "spider_id": 11
    #                 }
    #             ],
    #             "uri_rule": [
    #                 {
    #                     "rule": "/diigsm",
    #                     "ruleSource": "/diigsm",
    #                     "id": "sddkka",
    #                     "name": "作者A",
    #                     "show": True
    #                 }
    #             ]
    #         }
    #     }
    # }

    def __init__(self):
        self._config: Optional[dict] = None

    @property
    def config(self) -> dict:
        if self._config is not None:
            return self._config
        try:
            _config = json.loads(public.readFile(self.CONFIG_FILE))
            if isinstance(_config, dict):
                self._config = _config
            else:
                self._config = {}
        except:
            self._config = {}
        return self._config

    @staticmethod
    def new_id(src: str) -> str:
        import hashlib
        res = hashlib.md5(src.encode()).hexdigest()
        return res[:10]

    def save(self):
        public.writeFile(self.CONFIG_FILE, json.dumps(self._config))
        public.set_own(self.CONFIG_FILE, "bt-monitor")

    def get_site_uri_rule(self, site_name: str) -> List[dict]:
        return self.config.get(site_name, {}).get("uri_rule", [])

    def get_site_ip_rule(self, site_name: str) -> List[dict]:
        return self.config.get(site_name, {}).get("ip_rule", [])

    def get_site_spider_ip_rule(self, site_name: str, spider_id: int) -> List[dict]:
        ip_rule_list = self.config.get(site_name, {}).get("ip_rule", [])
        res = []
        for ip_rule in ip_rule_list:
            if ip_rule.get("spider_id", 0) == spider_id:
                res.append(ip_rule)

        return res


class _SpiderAnalysisData:

    def __init__(self, site_name: str):
        self.site_name = site_name
        self._is_individual: Optional[bool] = None
        self._monitor_db_path: Optional[str] = None
        self._log_conns: Dict[int, db.Sql] = {}

    @property
    def db_path(self) -> str:
        if self._monitor_db_path is None:
            global_config_file = "/www/server/monitor/config/config.json"
            db_path = None
            try:
                tmp_data = json.loads(public.ReadFile(global_config_file))
                if isinstance(tmp_data, dict):
                    db_path = tmp_data["data_save_path"]
            except:
                pass
            if not isinstance(db_path, str) or not os.path.isdir(db_path):
                db_path = ""
            self._monitor_db_path = db_path
        return self._monitor_db_path

    @property
    def is_individual(self) -> bool:
        if self._is_individual is not None:
            return self._is_individual
        spider_config_file = "/www/server/monitor/config/spider_config.json"
        try:
            tmp_data = json.loads(public.ReadFile(spider_config_file))
            if isinstance(tmp_data, dict) and isinstance(tmp_data.get("individual", None), bool):
                self._is_individual = tmp_data["individual"]
        except:
            self._is_individual = False

        return self._is_individual

    def get_conn(self, date: int) -> Optional[db.Sql]:
        if date in self._log_conns and getattr(self._log_conns[date], "_Sql__DB_CONN", None):
            return self._log_conns[date]

        if not self.db_path:
            return None
        if self.is_individual:
            db_file = "{}/{}/spider_log-{}.db".format(self.db_path, self.site_name, date)
        else:
            db_file = "{}/{}/access-{}.db".format(self.db_path, self.site_name, date)

        if not os.path.isfile(db_file):
            return None

        sql = db.Sql()
        sql._Sql__DB_FILE = db_file
        self._log_conns[date] = sql

        return sql

    def _spider_name(self) -> Tuple[str, str, str]:
        if self.is_individual:
            return "spider_log", "spider", "id"
        return "access_log", "is_gzip", "access_id"

    def get_date_range(self, start_date: int, end_date: int) -> List[int]:
        _list = []
        start = self.date_int2datetime(start_date)
        end = self.date_int2datetime(end_date)
        while start <= end:
            _list.append(self.datetime2date_int(start))
            start += datetime.timedelta(days=1)
        return _list

    @staticmethod
    def date_int2datetime(date: int) -> datetime.datetime:
        y, md = divmod(date, 10000)
        m, d = divmod(md, 100)
        return datetime.datetime(y, m, d)

    @staticmethod
    def datetime2date_int(date: datetime.datetime) -> int:
        return 10000 * date.year + 100 * date.month + date.day

    def today_date(self) -> int:
        return self.datetime2date_int(datetime.datetime.today())


class SpiderIPAnalysis(_SpiderAnalysisData):

    def __init__(self, site_name: str, spider_id: int):
        super().__init__(site_name)
        self.spider_id = spider_id

    def add_rule(self, rule_source: str, name: str) -> Optional[str]:
        ip_range = IPRange.parse(rule_source)
        if ip_range is None:
            return "错误的ip格式"
        rule = str(ip_range)
        conf = _SpiderAnalysisConfig()
        ip_rule_list = conf.get_site_ip_rule(self.site_name)
        for ip_rule in ip_rule_list:
            if ip_rule["rule"] == rule:
                return "已存在该规则"

        the_rule = {
            "id": conf.new_id(rule_source),
            "name": name,
            "rule": rule,
            "rule_source": rule_source,
            "show": True,
            "spider_id": self.spider_id,
        }

        ip_rule_list.append(the_rule)

        conf.config[self.site_name]["ip_rule"] = ip_rule_list
        conf.save()
        self._query_rule_date(the_rule, self.today_date())
        from monitor_cmd import udp_cmd
        udp_cmd("reload_config")
        return None

    def del_rule(self, rule_id: str) -> None:
        conf = _SpiderAnalysisConfig()
        ip_rule_list = conf.get_site_ip_rule(self.site_name)
        target = None
        for ip_rule in ip_rule_list:
            if ip_rule["id"] == rule_id:
                target = ip_rule
                break

        if target is None:
            return
        ip_rule_list.remove(target)
        conf.config[self.site_name]["ip_rule"] = ip_rule_list
        conf.save()
        from monitor_cmd import udp_cmd
        udp_cmd("reload_config")
        return None

    def modify_rule(self, rule_id: str, name: str, status: bool) -> Optional[str]:
        conf = _SpiderAnalysisConfig()
        ip_rule_list = conf.get_site_ip_rule(self.site_name)
        target = None
        for ip_rule in ip_rule_list:
            if ip_rule["id"] == rule_id:
                target = ip_rule
                break

        if target is None:
            return "未查找到对应的配置信息"

        target["name"] = name
        target["show"] = status

        conf.config[self.site_name]["ip_rule"] = ip_rule_list
        conf.save()
        return None

    def get_data_db(self) -> Optional[db.Sql]:
        db_file = "{}/{}/spider_analysis_ip.db".format(self.db_path, self.site_name)
        if not os.path.isfile(db_file):
            return None

        sql = db.Sql()
        sql._Sql__DB_FILE = db_file
        return sql

    def get_rules(self) -> List[dict]:
        return _SpiderAnalysisConfig().get_site_spider_ip_rule(self.site_name, self.spider_id)

    def get_data(self, start_date: int, end_date: int) -> List[dict]:
        rules = _SpiderAnalysisConfig().get_site_spider_ip_rule(self.site_name, self.spider_id)
        conn = self.get_data_db()
        if conn is None:
            return []

        rules_ids = [rule["id"] for rule in rules]
        data = conn.table("ip_total").where(
            "rule_id in ({}) AND date <= ? AND date >= ?".format(",".join(["?"] * len(rules_ids))),
            (*rules_ids, end_date, start_date)
        ).field("rule_id,date,request").select()

        conn.close()
        date_map = {}

        for row in data:
            date_map.setdefault(row["date"], {})[row["rule_id"]] = row["request"]

        date_range = self.get_date_range(start_date, end_date)
        return [
            {
                "date": self.date_int2datetime(date).strftime("%Y-%m-%d"),
                "data": [
                    {
                        "rule": rule,
                        "count": date_map.get(date, {}).get(rule["id"], 0)
                    } for rule in rules
                ]
            } for date in date_range
        ]

    def get_data_on_date(self, date: int) -> List[dict]:
        rules = _SpiderAnalysisConfig().get_site_spider_ip_rule(self.site_name, self.spider_id)
        res = []
        for rule in rules:
            count = self._query_rule_date(rule, date)
            res.append({"rule": rule, "count": count})
        self.get_conn(date).close()
        return res

    def rule_to_where(self, rule: str) -> Tuple[str, list]:
        ip_range = IPRange.parse(rule)
        if ip_range is None:
            return "", []
        if ip_range.start_ip == ip_range.end_ip:
            if self.is_individual:
                return "ip_id = ?", [int(ip_range.start_ip)]
            else:
                return "ip_id = ? AND ipv6 = 0", [int(ip_range.start_ip)]

        if self.is_individual:
            return "ip_id >= ? AND ip_id <= ?", [int(ip_range.start_ip), int(ip_range.end_ip)]
        else:
            return "ip_id >= ? AND ip_id <= ? AND ipv6 = 0", [int(ip_range.start_ip), int(ip_range.end_ip)]

    def _query_rule_date(self, rule: dict, date: int) -> int:
        data = self._query_rule_date_cache(rule, date)
        if data is not None:
            return data

        i_where, i_params = self.rule_to_where(rule["rule"])
        if not i_where and not i_params:
            return 0

        conn = self.get_conn(date)
        if not conn:
            return 0

        table, spider, _ = self._spider_name()
        data = conn.table(table).where("{} AND {} = {}".format(i_where, spider, self.spider_id), i_params).count()
        if not data:
            return 0
        self.set_date_count(rule["id"], date, data)
        return data

    def _query_rule_date_cache(self, rule: dict, date: int) -> Optional[int]:
        conn = self.get_data_db()
        if not conn:
            return None
        data = conn.table("ip_total").where("rule_id = ? AND date = ?", (rule["id"], date)).field("request").find()
        conn.close()
        if data:
            return data["request"]
        return None

    def set_date_count(self, rule_id: str, date: int, count: int):
        conn = self.get_data_db()
        if not conn:
            return
        sql = "INSERT INTO ip_total (rule_id,date,request) VALUES (?,?,?)"
        conn.execute(sql, (rule_id, date, count))
        conn.close()


class SpiderURIAnalysis(_SpiderAnalysisData):
    # 单种蜘蛛每日有16,0000的数据量, 预估会有15w左右的url数据, 如果uri规则宽泛， 可能会在uri_list中有千万级符合规则的数据
    # 数据查询方式：
    # 1. 查询路由中符合条件的uri数量是否大于1000, 如果不是，则利用该数据，通过group分蜘蛛信息，一次查询就能获取到所有蜘蛛的所需数据
    # 2. 如果是（符合条件的uri数量很多），则查询需要根据蜘蛛的uri数据过滤
    # 2.1 查所有符合条件的蜘蛛的uri数据，并在python进行分割，再到uri_list中查询符合条件的数据
    SEP = 10000

    def __init__(self, site_name: str, spider_id: int):
        super().__init__(site_name)
        self.spider_id = spider_id
        self._uri_db: Optional[db.Sql] = None

    def add_rule(self, rule_source: str, name: str) -> Optional[str]:
        rule = str(rule_source)
        conf = _SpiderAnalysisConfig()
        uri_rule_list = conf.get_site_uri_rule(self.site_name)
        for ip_rule in uri_rule_list:
            if ip_rule["rule"] == rule:
                return "已存在该规则"

        the_rule = {
            "id": conf.new_id(rule_source),
            "name": name,
            "rule": rule,
            "rule_source": rule_source,
            "show": True,
        }

        uri_rule_list.append(the_rule)

        conf.config[self.site_name]["uri_rule"] = uri_rule_list
        conf.save()
        self._query_rule_date(the_rule, self.today_date())
        from monitor_cmd import udp_cmd
        udp_cmd("reload_config")
        return None

    def del_rule(self, rule_id: str) -> None:
        conf = _SpiderAnalysisConfig()
        uri_rule_list = conf.get_site_uri_rule(self.site_name)
        target = None
        for ip_rule in uri_rule_list:
            if ip_rule["id"] == rule_id:
                target = ip_rule
                break

        if target is None:
            return
        uri_rule_list.remove(target)
        conf.config[self.site_name]["uri_rule"] = uri_rule_list
        conf.save()
        from monitor_cmd import udp_cmd
        udp_cmd("reload_config")
        return None

    def modify_rule(self, rule_id: str, name: str, status: bool) -> Optional[str]:
        conf = _SpiderAnalysisConfig()
        uri_rule_list = conf.get_site_uri_rule(self.site_name)
        target = None
        for ip_rule in uri_rule_list:
            if ip_rule["id"] == rule_id:
                target = ip_rule
                break

        if target is None:
            return "未查找到对应的配置信息"

        target["name"] = name
        target["show"] = status

        conf.config[self.site_name]["uri_rule"] = uri_rule_list
        conf.save()
        return None

    def get_data_db(self) -> Optional[db.Sql]:
        db_file = "{}/{}/spider_analysis_uri.db".format(self.db_path, self.site_name)
        if not os.path.isfile(db_file):
            return None

        sql = db.Sql()
        sql._Sql__DB_FILE = db_file
        return sql

    def get_rules(self) -> List[dict]:
        return _SpiderAnalysisConfig().get_site_uri_rule(self.site_name)

    def get_data(self, start_date: int, end_date: int) -> List[dict]:
        rules = _SpiderAnalysisConfig().get_site_uri_rule(self.site_name)
        conn = self.get_data_db()
        if conn is None:
            return []

        rules_ids = [rule["id"] for rule in rules]
        data = conn.table("uri_total").where(
            "rule_id in ({}) AND date <= ? AND date >= ? AND spider_id = ?".format(",".join(["?"] * len(rules_ids))),
            (*rules_ids, end_date, start_date, self.spider_id)
        ).field("rule_id,date,request").select()

        date_map = {}
        for row in data:
            date_map.setdefault(row["date"], {})[row["rule_id"]] = row["request"]

        date_range = self.get_date_range(start_date, end_date)
        return [
            {
                "date": self.date_int2datetime(date).strftime("%Y-%m-%d"),
                "data": [
                    {
                        "rule": rule,
                        "spider_id": self.spider_id,
                        "count": date_map.get(date, {}).get(rule["id"], 0)
                    } for rule in rules
                ]
            } for date in date_range
        ]

    def get_data_on_date(self, date: int) -> List[dict]:
        rules = _SpiderAnalysisConfig().get_site_uri_rule(self.site_name)
        res = []
        for rule in rules:
            count = self._query_rule_date(rule, date)
            res.append({"rule": rule, "count": count})
        if not self.get_conn(date):
            self.get_conn(date).close()
        return res

    def uri_db(self) -> Optional[db.Sql]:
        if self._uri_db is not None and getattr(self._uri_db, "_Sql__DB_CONN", None):
            return self._uri_db

        if not self.db_path:
            return None

        db_file = "{}/{}/uri_list.db".format(self.db_path, self.site_name)
        if not os.path.isfile(db_file):
            return None

        sql = db.Sql()
        sql._Sql__DB_FILE = db_file
        return sql

    @staticmethod
    def rule_to_where(rule: str) -> Tuple[str, list]:
        rule = rule.replace("%", "\\%")
        if rule.startswith('^') and rule.endswith('$'):
            real_value = rule[1:-1]
            return "uri = ?", [real_value]
        else:
            real_value = "%{}%".format(rule)
            if rule.startswith('^'):
                real_value = "{}%".format(rule[1:])
            elif rule.endswith('$'):
                real_value = "%{}".format(rule[:-1])

            return "uri like ?", [real_value]

    def _query_rule_date_cache(self, rule: dict, date: int) -> Optional[int]:
        conn = self.get_data_db()
        if not conn:
            return None
        data = conn.table("uri_total").where("rule_id = ? AND spider_id=? AND date = ?",
                                             (rule["id"], self.spider_id, date)).field("request").find()
        conn.close()
        if data:
            return data["request"]
        return None

    def _query_rule_date(self, rule: dict, date: int) -> int:
        data = self._query_rule_date_cache(rule, date)
        if data is not None:
            return data

        uri_db = self.uri_db()
        if not uri_db:
            return 0

        u_where, u_parm = self.rule_to_where(rule["rule"])
        uri_ids = uri_db.table("uri_list").where(u_where, u_parm).limit(self.SEP).field("uri_id").select()
        if not isinstance(uri_ids, list):
            return 0
        if len(uri_ids) == 0:
            return 0

        if len(uri_ids) <= 1000:
            return self._query_rule_date_by_uri_ids([str(i["uri_id"]) for i in uri_ids], date, rule)
        else:
            return self._query_rule_date_by_large_uri(date, rule, u_where, u_parm)

    def _query_rule_date_by_uri_ids(self, uri_ids: List[str], date: int, rule: dict) -> int:
        conn = self.get_conn(date)
        if not conn:
            return 0

        where = "uri_id in ({}) group by %s".format(",".join(uri_ids))
        table, spider, _ = self._spider_name()
        data = conn.query(
            sql="SELECT COUNT(*) AS count,{} FROM {} WHERE {}".format(spider, table, where % spider),
            param=tuple())

        if not isinstance(data, list):
            return 0

        spider_res = {i: 0 for i in range(11, 20)}
        for i in data:
            try:
                spider_res[i[1]] = i[0]
            except:
                continue

        res = 0
        count_data = []
        for k, v in spider_res.items():
            count_data.append((k, v))
            if k == self.spider_id:
                res = v
        self.set_date_count(rule["id"], date, count_data)
        return res

    def _query_rule_date_by_large_uri(self, date: int, rule: dict, u_where: str, u_parm: List[Any]) -> int:
        conn = self.get_conn(date)
        if not conn:
            return 0

        uri_counter = Counter()
        table, spider, idx_name = self._spider_name()
        idx = 0
        field = "{},uri_id".format(idx_name, spider)
        while True:
            where = "{} > ? AND {} = ? ".format(idx_name, spider)
            param = (idx, self.spider_id)

            data = conn.table(table).where(where, param).order(idx_name).limit(self.SEP).field(field).select()
            if not isinstance(data, list):
                return 0

            uri_counter.update((i["uri_id"] for i in data))
            if len(data) < 10000:
                break
            idx = data[-1][idx_name]

        idx = 0
        uri_id_list = uri_counter.keys()
        tmp_list = uri_id_list[idx: idx + self.SEP]
        filter_uri_set = set()
        while tmp_list:
            where = "uri_id in ({}) AND {}".format(",".join((str(i) for i in tmp_list)), u_where)
            data = conn.table("uri_list").where(where, u_parm).field("uri_id").select()
            if not isinstance(data, list):
                return 0

            filter_uri_set.update((i["uri_id"] for i in data))
            idx += self.SEP
            tmp_list = uri_id_list[idx: idx + self.SEP]

        res = sum((v for k, v in uri_counter.items() if k in filter_uri_set))
        self.set_date_count(rule["id"], date, [(self.spider_id, res)])
        return res

    def set_date_count(self, rule_id: str, date: int, count_data: List[Tuple[int, int]]):
        conn = self.get_data_db()
        if not conn:
            return
        v = ",".join(["(?,?,?,?)"] * len(count_data))
        p = []
        for spider_id, count in count_data:
            p.extend((rule_id, date, spider_id, count))
        sql = "INSERT INTO uri_total (rule_id,date,spider_id,request) VALUES {}".format(v)
        conn.execute(sql, p)
        conn.close()


class _InitSpiderAnalysis(_SpiderAnalysisData):
    _yesterday_date: Optional[int] = None

    @classmethod
    def yesterday_date(cls):
        if cls._yesterday_date is None:
            yesterday = datetime.date.today() - datetime.timedelta(days=1)
            date = yesterday.year * 10000 + yesterday.month * 100 + yesterday.day
            cls._yesterday_date = date
        return cls._yesterday_date

    def get_uri_prefix(self) -> Optional[Iterable[str]]:
        if not self.is_individual:
            return None
        yesterday = datetime.date.today() - datetime.timedelta(days=1)
        date = yesterday.year * 10000 + yesterday.month * 100 + yesterday.day
        conn = self.get_conn(date)
        if not conn:
            return None
        max_id = conn.table("spider_log").order("id DESC").limit(1).find()
        if not max_id or not isinstance(max_id, dict):
            return None
        max_id = max_id["id"]
        if max_id < 1000:
            return self._get_uri_prefix_by_all(conn)

        enable_bit = 1 << 62
        reserved_bits = (0 & 0xF) << 58  # 保留位，最多4位

        date_part = (date - 20000000) << 38

        min_id = enable_bit | reserved_bits | date_part

        offset = max_id - min_id

        if offset < 1000:
            return self._get_uri_prefix_by_all(conn)

        id_list = []
        sep = offset // 1000
        for i in range(0, (offset // 1000) * 1000, sep):
            id_list.append(str(min_id + random.randint(i, i + sep - 1)))

        return self._get_uri_prefix_by_ids(conn, id_list)

    def _get_uri_prefix_by_all(self, conn) -> Iterable[str]:
        return self._get_uri_prefix_by_ids(conn, id_list=None)

    def _get_uri_prefix_by_ids(self, conn, id_list: List[str] = None) -> Iterable[str]:
        if id_list:
            where = "id in ({})".format(",".join(id_list))
            data = conn.table("spider_log").where(where, tuple()).field("uri_id").select()
        else:
            data = conn.table("spider_log").field("uri_id").select()
        conn.close()
        if not isinstance(data, list):
            return []
        uri_id_set = set((str(i["uri_id"]) for i in data))

        db_file = "{}/{}/uri_list.db".format(self.db_path, self.site_name)
        if not os.path.isfile(db_file):
            return []

        sql = db.Sql()
        sql._Sql__DB_FILE = db_file
        uri_list = sql.table("uri_list").where("uri_id in ({})".format(",".join(uri_id_set)), tuple()).field(
            "uri").select()
        if not isinstance(uri_list, list):
            return []

        res = set()
        for i in uri_list:
            uri: str = i["uri"].split("?", 1)[0]
            uri = uri.lstrip("/")
            print(uri)
            if uri.find("robots.txt") != -1 or uri.find("sitemap") != -1:
                continue
            prefix = uri.split("/", 1)[0]
            if len(prefix) > 10 or len(prefix) <= 1:
                continue
            res.add("/" + prefix)

        print(res)
        return res

    def get_ip_c_class(self) -> Optional[Dict[int, List[str]]]:
        spider_net_data: str = public.readFile("{}/spider_net.json".format(public.get_plugin_path("monitor")))
        if not spider_net_data:
            return None
        try:
            spider_net: Dict[str, List[str]] = json.loads(spider_net_data)
        except:
            return None

        res = {}
        conn = self.get_conn(self.yesterday_date())
        if conn is None:
            return None
        for k, v in spider_net.items():
            spider_id = int(k) + 10
            data = self._get_spider_ip_c_class(conn, spider_id, v)
            if data:
                res[spider_id] = data

        conn.close()
        return res

    @staticmethod
    def _get_spider_ip_c_class(conn: db.Sql, spider_id: int, net_list: List[str]) -> List[str]:
        case = []
        for net in net_list:
            ip_range = IPRange.parse(net)
            case.append(
                "WHEN ip_id BETWEEN {} AND {} THEN '{}'".format(int(ip_range.start_ip), int(ip_range.end_ip), net))

        sql = "SELECT ( CASE {} END) as ip_net, COUNT(*) as count FROM spider_log " \
              "WHERE spider = {} GROUP BY ip_net".format(" ".join(case), spider_id)

        res_data = conn.query(sql, tuple())
        if not isinstance(res_data, list) or not res_data:
            return []
        res_list = []
        for net, count in res_data:
            if net is not None and count > 0:
                res_list.append(net)

        return res_list


def init_spider_analysis():
    site_list = public.M('sites').field('id,name,project_type').select()
    if not isinstance(site_list, list) or not site_list:
        return

    spider_ana_conf = _SpiderAnalysisConfig()
    change = False
    for site in site_list:
        site_name = site['name']
        if site_name in spider_ana_conf.config:
            continue
        spider_ana_conf.config[site_name] = {}
        iana = _InitSpiderAnalysis(site_name=site['name'])
        uris = iana.get_uri_prefix()
        if uris:
            tmp_num = 0
            uri_rule = []
            for u in uris:
                tmp_num += 1
                uri_rule.append({
                    "rule": u,
                    "rule_source": u,
                    "id": spider_ana_conf.new_id(u),
                    "name": u.strip("/"),
                    "show": tmp_num <= 5,
                })

            spider_ana_conf.config[site_name]["uri_rule"] = uri_rule
            change = True

        ip_class = iana.get_ip_c_class()
        if ip_class:
            ip_rule = []
            for k, v in ip_class.items():
                tmp_num = 0
                for net in v:
                    ip_range = IPRange.parse(net)
                    tmp_num += 1
                    ip_rule.append({
                        "rule": str(ip_range),
                        "rule_source": net.replace(".0/24", ".*"),
                        "id": spider_ana_conf.new_id(net),
                        "name": net.replace(".0/24", ".*"),
                        "show": tmp_num <= 5,
                        "spider_id": k
                    })
            spider_ana_conf.config[site_name]["ip_rule"] = ip_rule
            change = True

    if change:
        spider_ana_conf.save()
        from monitor_cmd import udp_cmd
        udp_cmd("reload_config")


class BadSeoUri:
    ttl_cache = TTLCache(maxsize=100, ttl=60 * 5)
    _sql_cache: Dict[str, db.Sql] = dict()
    BAD_URI_CONF_FILE = "{}/bad_uri.json".format(public.get_plugin_path("monitor"))
    BAD_URI_STATUS_FILE = "/www/server/monitor/config/bad_uri_status"

    @classmethod
    def set_bad_uri_status(cls, status: Union[List[Union[str, int]], str]) -> Optional[str]:
        if isinstance(status, str):
            status = status.split(",")
        if not isinstance(status, list):
            return "参数错误"

        real_data = []
        allow = (404, 410, 500, 501, 502, 503, 504)
        for i in status:
            try:
                tmp = int(i)
                if tmp in allow:
                    real_data.append(str(i))
            except:
                return "参数错误"

        if len(real_data) == 0:
            return "参数错误"

        udp_cmd("bad_uri_status|" + ",".join(real_data))
        public.writeFile(cls.BAD_URI_STATUS_FILE, ",".join(real_data))
        return None

    @classmethod
    def bad_uri_status(cls) -> List[str]:
        data = public.readFile(cls.BAD_URI_STATUS_FILE)
        if not data:
            return ["404", "410", "500", "501", "502", "503", "504"]
        return data.strip().split(",")

    def __init__(self, site_name: str, db_path: str):
        self.site_name = site_name
        self.db_path = db_path
        self._config: Optional[Dict] = None

    def _get_filed_by_id(self, table_name: str, id_name: str, id_val: int, field: str) -> str:
        if id_val == 0:
            return ""
        if not table_name or not id_name or not id_val or not field:
            return ""
        ck = public.Md5("{}{}{}{}{}".format(self.site_name, table_name, id_name, id_val, field))
        res = self.ttl_cache.get(ck)
        if isinstance(res, str):
            return res

        db_obj = self.db_conn()
        if not db_obj:
            return ""
        data = db_obj.table(table_name).where("{} = ?".format(id_name), (id_val,)).field(field).find()
        if not isinstance(data, dict) or not data:
            return ""
        res = data[field]
        self.ttl_cache[ck] = res
        return res

    def get_path_by_id(self, path_id: int) -> str:
        return self._get_filed_by_id("path_list", "path_id", path_id, "path")

    def get_query_by_id(self, query_id: int) -> str:
        return self._get_filed_by_id("query_list", "query_id", query_id, "query")

    def db_conn(self, db_path: str = None, site_name: str = None) -> Optional[db.Sql]:
        """
        连接数据库
        :param db_path: 数据库路径
        :param site_name: 网站名称
        :return: 数据库连接对象
        """
        if db_path is None:
            db_path = self.db_path

        if site_name is None:
            site_name = self.site_name

        db_file = os.path.join(db_path, site_name, "seo_bad_uri.db")
        if not os.path.isfile(db_file):
            return None

        if self._sql_cache.get(db_file, None) is not None and self._sql_cache[db_file]._Sql__DB_CONN:
            return self._sql_cache[db_file]
        sql = db.Sql()
        sql._Sql__DB_FILE = db_file
        self._sql_cache[db_file] = sql
        return sql

    @classmethod
    def bad_uri_tips(cls, db_path: str) -> List[Dict[str, int]]:
        """
        获取所有网站的死链提示
        :param db_path: 数据库路径
        :return: 死链提示列表
        """
        data = cls.ttl_cache.get("bad_uri_tips", None)
        if data is not None:
            return data
        res = []
        t = int(cls.today_zero_time().timestamp())
        for site_name in os.listdir(db_path):
            if not os.path.isfile(os.path.join(db_path, site_name, "seo_bad_uri.db")):
                continue
            db_obj = cls.db_conn(cls("", ""), db_path, site_name)
            if db_obj is None:
                continue

            count = db_obj.table("seo_bad_uri").where("time >= ? AND status = 0 AND disable = 0", (t,)).count()
            if count > 0:
                res.append({"site_name": site_name, "count": count})

            db_obj.close()
        cls.ttl_cache["bad_uri_tips"] = res
        return res

    @staticmethod
    def today_zero_time() -> datetime.datetime:
        return datetime.datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)

    def bad_uri_list(self,
                     page: int,
                     rows: int,
                     start_time: int = None,
                     end_time: int = None,
                     disable: int = 0) -> Dict[str, Any]:
        page = max(1, page)
        rows = min(max(1, rows), 200)
        no_data = public.get_page(0, page, rows)
        no_data["data"] = []
        db_obj = self.db_conn()
        if db_obj is None:
            return no_data

        where, parm = [], []
        if start_time is not None and start_time != 0:
            where.append("time >= ?")
            parm.append(start_time)
        if end_time is not None and end_time != 0:
            where.append("time <= ?")
            parm.append(end_time)

        if disable == 1:
            where.append("disable = 1")
        elif disable == -1:
            pass
        else:
            where.append("disable = 0")

        where_str = " AND ".join(where)
        count = db_obj.table("seo_bad_uri").where(where_str, parm).count()
        if count == 0:
            db_obj.close()
            return no_data

        data_list = db_obj.table("seo_bad_uri").where(where_str, parm).order("status ASC, time DESC").limit(rows, (
                    page - 1) * rows).select()

        data = public.get_page(count, page, rows)
        for row in data_list:
            path = self.get_path_by_id(row["path_id"])
            if row["query_id"] == 0:
                query = ""
            else:
                query = self.get_query_by_id(row["query_id"])
            if query != "":
                row["uri"] = "{}?{}".format(path, query)
            else:
                row["uri"] = path

        data["data"] = data_list

        db_obj.close()

        return data

    def bad_uri_conf(self) -> Dict[str, Any]:
        """
        获取网站死链配置
        :return: 网站死链配置
        """
        site_info = sitetool.get_site_info(self.site_name)
        domain_list = sitetool.site_domain_list(self.site_name)
        default_conf = {
            "files": [
                {
                    "uri": "/{}-silian.txt".format(d.replace(".", "_").replace(":", "_")),
                    "domain": d
                } for d in domain_list
            ],
            "use_https": sitetool.site_use_https_by_conf(self.site_name, site_info["project_type"]),
            "run_path": sitetool.site_run_path(self.site_name, site_info["project_type"])
        }
        try:
            conf = json.loads(public.readFile(self.BAD_URI_CONF_FILE))
            if self.site_name not in conf:
                return default_conf
            return conf[self.site_name]
        except:
            return default_conf

    def bad_uri_conf_status(self) -> Dict[str, Any]:
        """
        获取网站死链配置状态
        :return: 网站死链配置状态
        """
        conf = self.bad_uri_conf()
        site_info = sitetool.get_site_info(self.site_name)
        conf["use_https"] = sitetool.site_use_https_by_conf(self.site_name, site_info["project_type"])
        conf["run_path"] = sitetool.site_run_path(self.site_name, site_info["project_type"])
        for item in conf["files"]:
            item["exists"] = os.path.exists(conf["run_path"] + item["uri"])

        return conf

    def save_bad_uri_conf(self, data: dict) -> Optional[str]:
        """
        保存网站死链配置
        :param data: 网站死链配置
        :return: 保存结果
        """
        try:
            conf = json.loads(public.readFile(self.BAD_URI_CONF_FILE))
        except:
            conf = {}

        if self.site_name not in conf:
            conf[self.site_name] = data
        else:
            conf[self.site_name].update(data)
        public.writeFile(self.BAD_URI_CONF_FILE, json.dumps(conf))

    def option_bad_uri(self, id_list: List[int], si_lian: bool = False) -> Optional[str]:
        """
        操作死链
        :param id_list: 要操作的死链ID列表
        :param si_lian: 是否添加到死链文件中
        :return: 操作结果
        """
        db_obj = self.db_conn()
        if db_obj is None:
            return "获取数据错误"
        if len(id_list) == 0:
            return "请选择要操作的记录"
        where = "id IN ({})".format(",".join(["?"] * len(id_list)))
        pdata = {
            "status": 1,
            "option_time": int(time.time())
        }
        if si_lian:
            pdata["s_time"] = pdata["option_time"]

        db_obj.table("seo_bad_uri").where(where, id_list).update(pdata)
        db_obj.close()
        if hasattr(db_obj, "ERR_INFO"):
            return None if db_obj.ERR_INFO is None else "数据修改错误: {}".format(db_obj.ERR_INFO)

        return None

    def disable_bad_uri(self, id_list: List[int]) -> Optional[str]:
        """
        删除死链记录
        :param id_list: 要禁用的死链ID列表
        :return: 删除结果
        """
        db_obj = self.db_conn()
        if db_obj is None:
            return "获取数据错误"
        if len(id_list) == 0:
            return "请选择要操作的记录"
        where = "id IN ({})".format(",".join(["?"] * len(id_list)))
        pdata = {
            "disable": 1
        }
        db_obj.table("seo_bad_uri").where(where, id_list).update(pdata)
        db_obj.close()
        if hasattr(db_obj, "ERR_INFO"):
            return None if db_obj.ERR_INFO is None else "数据修改错误: {}".format(db_obj.ERR_INFO)

        return None

    def clear_all_bad_uri(self) -> Optional[str]:
        """
        一键清空所有死链记录
        :return: 清空结果
        """
        db_obj = self.db_conn()
        if db_obj is None:
            return "暂无数据，无需清理！"
        
        # 获取所有未禁用的死链记录数量
        count_result = db_obj.table("seo_bad_uri").where("disable=?", 0).count()
        if count_result == 0:
            return "暂无数据，无需清理！"
        
        # 批量禁用所有未禁用的死链记录
        pdata = {"disable": 1}
        db_obj.table("seo_bad_uri").where("disable=?", 0).update(pdata)
        db_obj.close()
        
        if hasattr(db_obj, "ERR_INFO"):
            return None if db_obj.ERR_INFO is None else "数据修改错误: {}".format(db_obj.ERR_INFO)
        
        return None

    def add_to_file(self, id_list: List[int], domains: List[str]) -> Optional[str]:
        """
        将死链添加到指定域名的文件中
        :param id_list: 要添加的死链ID列表
        :param domains: 要添加到的域名列表
        :return: 添加结果
        """
        res = self.option_bad_uri(id_list, si_lian=True)
        if res is not None:
            return res
        conf = self.bad_uri_conf()
        update_files = []
        for item in conf["files"]:
            if item["domain"] in domains:
                update_files.append(item)

        self.update_bad_uri_file(update_files)

    def update_bad_uri_file(self, files: List[Dict[str, Any]]) -> Optional[str]:
        """
        更新网站死链文件
        :param files: 要更新的文件列表
        :return: 更新结果
        """
        site_info = sitetool.get_site_info(self.site_name)
        run_path = sitetool.site_run_path(self.site_name, site_info["project_type"])

        db_obj = self.db_conn()
        if db_obj is None:
            return "获取数据错误"

        use_https = "https://" if sitetool.site_use_https_by_conf(self.site_name,
                                                                  site_info["project_type"]) else "http://"
        file_list = []
        for item in files:
            file_path = os.path.join(run_path, item["uri"].lstrip("/"))
            item["file_path"] = file_path
            if not os.path.exists(file_path):
                dir_name = os.path.dirname(file_path)
                if not os.path.exists(dir_name):
                    os.makedirs(dir_name)
                item["old_data"] = dict()
            else:
                old_data = OrderedDict()
                old_data_str = public.readFile(file_path)
                if old_data_str:
                    old_data_list = old_data_str.split("\n")
                    for i in old_data_list:
                        old_data[i] = 1

                item["old_data"] = old_data

            file_list.append(item)

        for uri in self.iter_bad_uri():
            for item in file_list:
                tmp_uri = use_https + item["domain"] + uri
                if tmp_uri not in item["old_data"]:
                    item["old_data"][tmp_uri] = 1

        for item in file_list:
            public.writeFile(item["file_path"], "\n".join(item["old_data"].keys()))
        return None

    def __get_path_for_rows(self, rows: List[Dict], path_cache: Dict[int, str]) -> Optional[str]:
        """
        获取死链记录中的路径
        :param rows: 死链记录列表
        :param path_cache: 路径缓存字典
        :return: 获取结果
        """
        need_id = set()
        for row in rows:
            if row["path_id"] not in path_cache:
                need_id.add(str(row["path_id"]))

        db_obj = self.db_conn()
        path_data = db_obj.table("path_list").where("path_id in ({})".format(",".join(need_id)), tuple()).select()
        for p in path_data:
            path_cache[p["path_id"]] = p["path"]

        for row in rows:
            row["path"] = path_cache[row["path_id"]]

    def __get_query_for_rows(self, rows: List[Dict], query_cache: Dict[int, str]) -> Optional[str]:
        """
        获取死链记录中的查询参数
        :param rows: 死链记录列表
        :param query_cache: 查询参数缓存字典
        :return: 获取结果
        """
        need_id = set()
        for row in rows:
            if row["query_id"] not in query_cache:
                need_id.add(str(row["query_id"]))

        db_obj = self.db_conn()
        path_data = db_obj.table("query_list").where("query_id in ({})".format(",".join(need_id)), tuple()).select()
        # public.print_log(path_data)
        # public.print_log(rows)
        # public.print_log(need_id)
        for p in path_data:
            query_cache[p["query_id"]] = p["query"]

        for row in rows:
            row["query"] = query_cache[row["query_id"]]

    def iter_bad_uri(self, sep: int = 1000) -> Iterable[str]:
        db_obj = self.db_conn()
        if db_obj is None:
            raise StopIteration

        where = "id > ? AND status = 1 AND disable = 0 AND s_time > 0"
        last_id = 0
        fields = "id,path_id,query_id"
        path_cache = dict()
        query_cache = {0: ""}
        while True:
            data = db_obj.table("seo_bad_uri").where(where, [last_id, ]).field(fields).order("id DESC").limit(
                sep).select()
            if not data or not isinstance(data, list):
                break

            self.__get_path_for_rows(data, path_cache)
            self.__get_query_for_rows(data, query_cache)

            last_id = data[-1]["id"]
            for row in data:
                if path_danger_regex.search(row["path"]) is not None:
                    continue
                if row["query"]:
                    row["uri"] = "{}?{}".format(row["path"], row["query"])
                else:
                    row["uri"] = row["path"]
                yield row["uri"]

    def set_silian_file(self, domain: str, uri: str, status: bool) -> Optional[str]:
        """
        设置死链文件
        :param domain: 域名
        :param uri: 死链URI
        :param status: 是否启用
        :return: 设置结果
        """
        conf = self.bad_uri_conf()
        old_data = None
        if domain not in sitetool.site_domain_list(self.site_name):
            return "域名不存在"

        site_info = sitetool.get_site_info(self.site_name)
        run_path = sitetool.site_run_path(self.site_name, site_info["project_type"])

        for item in conf["files"]:
            if item["domain"] == domain:
                old_data = item
                break
        if old_data is None and not status:
            return None

        if not status:
            file_path = os.path.join(run_path, old_data["uri"].lstrip("/"))
            if os.path.exists(file_path):
                os.remove(file_path)

            old_data["uri"] = uri
            self.save_bad_uri_conf(conf)
            return None
        # 更新、生成或rename
        if old_data is not None:
            old_uri = old_data["uri"]
            old_data['uri'] = uri
            file_path = os.path.join(run_path, old_uri.lstrip("/"))
            if os.path.exists(file_path):
                os.rename(file_path, os.path.join(run_path, uri.lstrip("/")))

        if old_data is None:
            old_data = {"domain": domain, "uri": uri}

        res = self.update_bad_uri_file([old_data])
        if res is not None:
            return res
        return None


def main():
    if len(sys.argv) == 2 and sys.argv[1] == "init_spider_analysis":
        init_spider_analysis()
        return
    if len(sys.argv) < 2:
        print("Usage: python3 monitor_seo.py <action> <args>")
        exit(1)
    action = sys.argv[1]
    args = sys.argv[2:]
    if action == "build_sitemap":
        if not len(args) == 1:
            print("Usage: python3 monitor_seo.py sitemap_by_log <config_info>")
            exit(1)
        args = args[0]
        s_log_task = SiteMap.unpack(args)
        if s_log_task is None:
            print("Invalid config info: {}".format(args))
            exit(1)
        try:
            s_log_task.build()
        except:
            print(traceback.format_exc())
            print("生成失败")
        else:
            print("生成成功")
        return
    elif action == "cron_task":
        SiteMap.run_cron_task()
        return
    else:
        print("Unknown action: {}".format(action))


if __name__ == '__main__':
    main()