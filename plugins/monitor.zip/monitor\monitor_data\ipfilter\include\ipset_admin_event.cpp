// -------------------------------------------------------------------
// 宝塔Linux面板
// -------------------------------------------------------------------
// Copyright (c) 2015-2024 宝塔软件(http://bt.cn) All rights reserved.
// -------------------------------------------------------------------
// Author: hwliang <hwl@bt.cn>
// -------------------------------------------------------------------
#define IPSET_ADMIN_EVENT_CPP

#ifndef UNIXSERVER_H
#include "unixserver.h"
#endif

#ifndef PUBLIC_H
#include "public.h"
#endif

#ifndef IPSET_MANAGER_H
#include "ipset_manager.h"
#endif

#define SPLIT_DIM "|"
#define RES_ERROR "0"

ipset_admin::ipset_admin(){
    this->ipset_manager_obj = new ipset_manager();
}

ipset_admin::~ipset_admin(){
    delete this->ipset_manager_obj;
}

string ipset_admin::create_ipset(string data){
    vector<string> ptr = split(data,SPLIT_DIM);
    if(ptr.size() != 7){
        return RES_ERROR;
    }
    int ret = this->ipset_manager_obj->create_ipset(ptr[0],ptr[1],atoi(ptr[2].c_str()),atoi(ptr[3].c_str()),atoi(ptr[4].c_str()),ptr[5],ptr[6]);
    return to_string(ret);
}


string ipset_admin::delete_ipset(string data){
    vector<string> ptr = split(data,SPLIT_DIM);
    if(ptr.size() != 3){
        return RES_ERROR;
    }
    int ret = this->ipset_manager_obj->delete_ipset(ptr[0],ptr[1],ptr[2]);
    return to_string(ret);
}


string ipset_admin::add_to_collection(string data){
    vector<string> ptr = split(data,SPLIT_DIM);
    if(ptr.size() != 4){
        return RES_ERROR;
    }
    int ret = this->ipset_manager_obj->add_to_collection(ptr[0],ptr[1],atoi(ptr[2].c_str()),atoi(ptr[3].c_str()));
    return to_string(ret);
}

string ipset_admin::del_from_collection(string data){
    vector<string> ptr = split(data,SPLIT_DIM);
    if(ptr.size() != 3){
        return RES_ERROR;
    }
    int ret = this->ipset_manager_obj->del_from_collection(ptr[0],ptr[1],atoi(ptr[2].c_str()));
    return to_string(ret);
}

string ipset_admin::get_collection_count(string data){
    vector<string> ptr = split(data,SPLIT_DIM);
    if(ptr.size() != 1){
        return RES_ERROR;
    }
    int ret = this->ipset_manager_obj->get_collection_count(ptr[0]);
    return to_string(ret);
}

string ipset_admin::get_collection_list(string data){
    vector<string> ret = this->ipset_manager_obj->get_collection_list();
    return vector_to_string(ret,"\n");
}

string ipset_admin::get_collection_element_list(string data){
    vector<string> ptr = split(data,SPLIT_DIM);
    if(ptr.size() != 1){
        return RES_ERROR;
    }
    vector<string> ret = this->ipset_manager_obj->get_collection_element_list(ptr[0]);
    return vector_to_string(ret,"\n");
}

string ipset_admin::get_collection_element_timeout(string data){
    vector<string> ptr = split(data,SPLIT_DIM);
    if(ptr.size() != 3){
        return RES_ERROR;
    }
    int ret = this->ipset_manager_obj->get_collection_element_timeout(ptr[0],ptr[1],atoi(ptr[2].c_str()));
    return to_string(ret);
}

string ipset_admin::flush_collection(string data){
    vector<string> ptr = split(data,SPLIT_DIM);
    if(ptr.size() != 1){
        return RES_ERROR;
    }
    int ret = this->ipset_manager_obj->flush_collection(ptr[0]);
    return to_string(ret);
}

string ipset_admin::get_iptables_collection_list(string data){
    vector<string> ret = this->ipset_manager_obj->get_iptables_collection_list();
    return vector_to_string(ret,"\n");
}

string ipset_admin::check_protocol(string data){
    vector<string> ptr = split(data,SPLIT_DIM);
    if(ptr.size() != 1){
        return RES_ERROR;
    }
    int ret = this->ipset_manager_obj->check_protocol(ptr[0]);
    return to_string(ret);
}


string ipset_admin::add_waf_ip(string data){
    vector<string> ptr = split(data,SPLIT_DIM);
    if(ptr.size() != 2){
        return RES_ERROR;
    }
    int ret = this->ipset_manager_obj->add_waf_ip(ptr[0], atoi(ptr[1].c_str()));
    return to_string(ret);
}

string ipset_admin::del_waf_ip(string data){
    vector<string> ptr = split(data,SPLIT_DIM);
    if(ptr.size() != 1){
        return RES_ERROR;
    }
    int ret = this->ipset_manager_obj->del_waf_ip(ptr[0]);
    return to_string(ret);
}


string ipset_admin::update_waf_ip(string data){
    vector<string> ptr = split(data,SPLIT_DIM);
    if(ptr.size() != 2){
        return RES_ERROR;
    }
    int ret = this->ipset_manager_obj->update_waf_ip(ptr[0], atoi(ptr[1].c_str()));
    return to_string(ret);
}



