-- 蜘蛛访问统计
-- ip或ip范围统计
CREATE TABLE IF NOT EXISTS `ip_total`
(
    `total_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `rule_id`  TEXT    DEFAULT "",
    `date`     INTEGER DEFAULT 0,
    `request`  INTEGER DEFAULT 0
);

-- 增加索引
CREATE UNIQUE INDEX IF NOT EXISTS `idx_date_rule_id_ip` ON `ip_total` (`date`, `rule_id`);
