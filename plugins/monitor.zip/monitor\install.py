import json
import os
import shutil
import subprocess
import sys
import platform
import time
from typing import Optional, List
from datetime import datetime

import psutil

# 添加项目根目录到环境变量
os.chdir("/www/server/panel")
if "/www/server/panel/class" not in sys.path:
    sys.path.insert(0, "/www/server/panel/class")

import public

if "/www/server/panel/plugin/monitor" not in sys.path:
    sys.path.insert(0, "/www/server/panel/plugin/monitor")
else:
    sys.path.remove("/www/server/panel/plugin/monitor")
    sys.path.insert(0, "/www/server/panel/plugin/monitor")


from utils import file_attr_i, file_attr_add_i, file_attr_del_i
from service import Service

# 1. 添加标记文件
# 2. 检查文件并下载大文件
# 3. 复制文件
# 4. 初始化配置文件
# 5. 配置并启动服务

VERSION = "4.4.0"
MONITOR_USER = "bt-monitor"


class MonitorInstaller:
    panel_path = public.get_panel_path()
    PLUGIN_PATH = public.get_plugin_path('monitor')
    RUN_PATH = '{}/monitor'.format(public.get_setup_path())
    SYSTEMD_PATH = '/usr/lib/systemd/system' if os.path.islink('/lib') and os.readlink('/lib') == '/usr/lib' else '/lib/systemd/system'

    DEFAULT_CONFIG = {
        "open": True,
        "debug": False,
        "listen": "0.0.0.0",
        "port": 9030,
        "save_err_log": True,
        "slow_time": 1000,
        "data_save_path": "/www/server/monitor/data/dbs",
        "max_access_save_day": 30,
        "max_err_save_day": 30,
        "max_slow_save_day": 30,
        "max_total_save_day": 30,
        "max_access_save_size": 1073741824,
        "max_err_save_size": 104857600,
        "max_slow_save_size": 209715200,
        "max_memory_size": 536870912,
        "ip_total_mode": 0,
        "is_cdn": 1,
        "is_baidu_cdn": 0,
        "filter_uri": [
            "/favicon.ico"
        ],
        "filter_method": [
        ],
        "filter_status": [],
        "filter_exts": [
            ".png",
            ".jpeg",
            ".jpg",
            ".gif",
            ".bmp",
            ".swf",
            ".icon",
            ".js",
            ".css",
            ".woff",
            ".woff2",
            ".ttf",
            ".eot",
            ".svg"
        ],
        "filter_user_agent": [],
        "filter_host": [],
        "filter_ip": []
    }

    def __init__(self):
        self.config_path = self.RUN_PATH + "/config"
        self.global_config_file =  self.config_path + "/config.json"
        self.sites_config_file = self.config_path + "/sites.json"

        self._install_time = None
        self._arch: Optional[str] = None

        # 判断为更新 还是安装
        if os.path.isdir(self.RUN_PATH) and os.path.isfile(self.global_config_file) and os.path.isfile(
                self.sites_config_file):
            self._is_update = True
        else:
            self._is_update = False

        self._webserver = public.get_webserver()

        self._global_config: Optional[dict] = None

    @property
    def global_config(self):
        if self._global_config is None:
            if os.path.isfile(self.global_config_file):
                with open(self.global_config_file, 'r') as f:
                    self._global_config = json.loads(f.read())
            else:
                self._global_config = self.DEFAULT_CONFIG

        return self._global_config

    @staticmethod
    def create_directory(path):
        if not os.path.exists(path):
            os.makedirs(path)

    @classmethod
    def copy_file(cls, src, dst, retries=3, delay=1):
        try:
            shutil.copy2(src, dst)
        except OSError as e:
            if "Text file busy" in str(e) or "Device or resource busy" in str(e):
                print("Attempt {}: File is busy".format(3-retries))
                if retries > 0:
                    print("Retrying in {} seconds...".format(delay))
                    time.sleep(delay)
                    cls.copy_file(src, dst,retries=retries-1, delay=delay+1)
            else:
                print("Error copying file: {}".format(str(e)))
        except Exception as e:
            print("Unknown Error copying file: {}".format(str(e)))


    @staticmethod
    def copy_directory(src, dst):
        if os.path.exists(dst):
            shutil.rmtree(dst)
        shutil.copytree(src, dst)

    @property
    def arch(self) -> str:
        if self._arch is None:
            is64bit = platform.machine()
            if "aarch64" in is64bit:
                self._arch = "arm64"
            else:
                self._arch = "amd64"
        return self._arch

    @staticmethod
    def run_command(command):
        """运行命令并实时打印输出"""
        process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        while True:
            output = process.stdout.readline()
            if output == '' and process.poll() is not None:
                break
            if output:
                print(output.strip())
        rc = process.poll()
        return rc

    # 记录安装时间 和 记录更新时间以及版本
    def install_and_update_time(self):
        # 记录安装时间
        now_time = int(datetime.now().timestamp())
        install_time_file = os.path.join(self.PLUGIN_PATH, 'install_time.pl')
        if not os.path.exists(install_time_file):
            print("Install time (seconds): {}".format(now_time))
            with open(install_time_file, 'w') as f:
                f.write(str(now_time))
                self._install_time = now_time
                self._is_update = False
        else:
            print("Install time file already exists.")

        # 记录更新时间以及版本
        update_time_file = os.path.join(self.PLUGIN_PATH, 'update_time.pl')
        if not os.path.exists(update_time_file):
            print("Update to {} time (seconds): {}".format(VERSION, now_time))
            with open(update_time_file, 'w') as f:
                f.write("{} {}".format(VERSION, now_time))
        else:
            try:
                with open(update_time_file, 'r') as f:
                    file_version, last_update_time = f.read().strip().split(" ")
            except:
                file_version, last_update_time = "0", "0"

            if file_version != VERSION:
                print("Update to {} time (seconds): {}".format(VERSION, now_time))
                with open(update_time_file, 'w') as f:
                    f.write("{} {}".format(VERSION, now_time))
            else:
                print("Version is already up to date: {}".format(file_version))

    def try_download_bin_gz(self) -> bool:
        bin_path = os.path.join(self.PLUGIN_PATH, "monitor", "monitor-{}-{}.gz".format(self.arch, VERSION))
        if not os.path.isfile(bin_path):
            url = public.get_url() + "/src/monitor-{}-{}.gz".format(self.arch, VERSION)
            self.run_command("wget -O {} {}".format(bin_path, url))
            if not os.path.isfile(bin_path):
                # print("!" * 50, "\nFailed to download binary gzip file.\n 下载服务文件失败\n", "!" * 50)
                return False
            elif os.path.getsize(bin_path) < 1024 * 1024 * 10:
                os.remove(bin_path)
                # print("!" * 50, "\nFailed to download binary gzip file.\n 下载服务文件失败\n", "!" * 50)
                return False
        try:
            import gzip
            with gzip.open(bin_path, 'rb') as f_in:
                with open(bin_path[:-3], 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)
        except:
            # print("!" * 50, "\nFailed to decompress binary gzip file.\n 解压服务文件失败\n", "!" * 50)
            return False
        return True

    def try_download_bin(self) -> bool:
        bin_path = os.path.join(self.PLUGIN_PATH, "monitor", "monitor-{}-{}".format(self.arch, VERSION))
        if not os.path.isfile(bin_path):
            if not self.try_download_bin_gz(): # 尝试下载gzip文件
                url = public.get_url() + "/src/monitor-{}-{}".format(self.arch, VERSION)
                self.run_command("wget -O {} {}".format(bin_path, url))
                if not os.path.isfile(bin_path):
                    print("!" * 50, "\nFailed to download binary file.\n 下载服务文件失败\n", "!" * 50)
                    return False

        if self._is_update:
            self.stop_monitor()

        self.copy_file(bin_path, os.path.join(self.RUN_PATH, "monitor"))
        public.set_mode( os.path.join(self.RUN_PATH, "monitor"), "700")

        mmdb_file = os.path.join(self.PLUGIN_PATH, "monitor", "data", "bt_monitor.mmdb")
        if not os.path.isfile(mmdb_file):
            url = public.get_url() + "/src/bt_monitor.mmdb"
            self.run_command("wget -O {} {}".format(mmdb_file, url))
            if not os.path.isfile(mmdb_file):
                pass
        if os.path.exists(mmdb_file):
            self.copy_file(mmdb_file, os.path.join(self.RUN_PATH, "data/bt_monitor.mmdb"))

        return True

    def first_copy(self):
        if os.path.exists(os.path.join(self.PLUGIN_PATH, 'monitor')):
            shutil.rmtree(os.path.join(self.PLUGIN_PATH, 'monitor'))
        self.copy_directory(
            os.path.join(self.PLUGIN_PATH, 'monitor_data'),
            os.path.join(self.PLUGIN_PATH, 'monitor')
        )

    def check_user(self):
        print("Checking user: {} ..".format(MONITOR_USER))
        def check_user_exists():
            try:
                import pwd
                pwd.getpwnam(MONITOR_USER)
                return True
            except KeyError:
                return False

        if check_user_exists():
            return True

        # 需要检查的文件
        files_to_check = ["/etc/passwd", "/etc/shadow", "/etc/group", "/etc/gshadow"]
        files_to_restore = []
        # 检查文件是否有特殊权限
        for filename in files_to_check:
            if file_attr_i(filename):
                print("Found special permissions on {} . Removing...".format(filename))
                file_attr_del_i(filename)
                files_to_restore.append(filename)

        self.run_command("useradd -r -s /sbin/nologin " + MONITOR_USER)
        print("Created user: {} ..".format(MONITOR_USER))

        # 恢复特殊权限
        for filename in files_to_restore:
            print("Restoring special permissions on {} ...".format(filename))
            file_attr_add_i(filename)

        return check_user_exists()

    def copy_static_file(self):
        print("Copying static files...")
        """复制静态文件"""
        # data/sql 文件夹
        self.create_directory(os.path.join(self.RUN_PATH, 'data/sql'))
        self.copy_directory(os.path.join(self.PLUGIN_PATH, 'monitor/data/sql'), os.path.join(self.RUN_PATH, 'data/sql'))

        # data/sql 文件夹
        self.create_directory(os.path.join(self.RUN_PATH, 'data/daily_sql'))
        self.copy_directory(
            os.path.join(self.PLUGIN_PATH, 'monitor/data/daily_sql'),
            os.path.join(self.RUN_PATH, 'data/daily_sql')
        )

        # data/dbs/global/spider_ip_list.db  --------------------------------------------
        self.create_directory(os.path.join(self.RUN_PATH, 'data/dbs/global'))
        spider_ip_list_file = os.path.join(self.RUN_PATH, 'data/dbs/global/spider_ip_list.db')
        if self._is_update:
            data_save_path = self.global_config["data_save_path"]
            spider_ip_list_file = data_save_path + '/global/spider_ip_list.db'

        if not os.path.isfile(spider_ip_list_file) or os.path.getsize(spider_ip_list_file) < 100:
            self.copy_file(os.path.join(self.PLUGIN_PATH, 'monitor/data/dbs/global/spider_ip_list.db'),
                           spider_ip_list_file)

        # data/dbs/global/spider_ip_net_list.db  --------------------------------------------
        spider_ip_net_list_file = os.path.join(self.RUN_PATH, 'data/dbs/global/spider_ip_net_list.db')
        if self._is_update:
            data_save_path = self.global_config["data_save_path"]
            spider_ip_net_list_file = data_save_path + '/global/spider_ip_net_list.db'

        if not os.path.isfile(spider_ip_net_list_file) or os.path.getsize(spider_ip_net_list_file) < 100:
            self.copy_file(
                os.path.join(self.PLUGIN_PATH, 'monitor/data/dbs/global/spider_ip_net_list.db'),
                spider_ip_net_list_file
            )

        # data/dbs/global/other_spiders.db  --------------------------------------------
        other_spiders_file = os.path.join(self.RUN_PATH, 'data/dbs/global/other_spiders.db')
        if self._is_update:
            data_save_path = self.global_config["data_save_path"]
            other_spiders_file = data_save_path + '/global/other_spiders.db'

        if not os.path.isfile(other_spiders_file) or os.path.getsize(other_spiders_file) < 100:
            self.copy_file(
                os.path.join(self.PLUGIN_PATH, 'monitor/data/dbs/global/other_spiders.db'),
                other_spiders_file
            )

        self.copy_file(
            os.path.join(self.PLUGIN_PATH, 'monitor/data/tencent.json'),
            os.path.join(self.RUN_PATH, 'data/tencent.json')
        )

        self.create_directory(os.path.join(self.RUN_PATH, 'config'))
        config_file_list = (
            "config.json",
            "malicious_ip.json",
            "sites.json",
            "spider_config.json",
            "site_seo_uri.json",
            "spider_analysis_config.json",
        )
        for file in config_file_list:
            target = os.path.join(self.RUN_PATH, 'config/{}'.format(file))
            if not os.path.isfile(target):
                self.copy_file(
                    os.path.join(self.PLUGIN_PATH, 'monitor/config/{}'.format(file)),
                    target
                )

        self.copy_file(
            os.path.join(self.PLUGIN_PATH, 'monitor/config/spider.json'),
            os.path.join(self.RUN_PATH, 'config/spider.json')
        )
        self.copy_file(
            os.path.join(self.PLUGIN_PATH, 'monitor/config/spider_settings.json'),
            os.path.join(self.RUN_PATH, 'config/spider_settings.json')
        )

        self.copy_file(
            os.path.join(self.PLUGIN_PATH, 'icon.png'),
            os.path.join(self.panel_path, 'BTPanel/static/vite/images/soft_ico/ico-monitor.png')
        )

        self.create_directory(os.path.join(self.RUN_PATH, 'web'))
        self.create_directory(os.path.join(self.RUN_PATH, 'web/data'))

        self.copy_file(
            os.path.join(self.PLUGIN_PATH, 'web/data/web_user.sql'),
            os.path.join(self.RUN_PATH, 'web/data/web_user.sql'))

        self.copy_directory(os.path.join(self.PLUGIN_PATH, 'web/static'), os.path.join(self.RUN_PATH, 'web/static'))
        self.copy_file(
            os.path.join(self.PLUGIN_PATH, 'web/apache_proxy.conf'),
            os.path.join(self.RUN_PATH, 'web/apache_proxy.conf')
        )
        self.copy_file(
            os.path.join(self.PLUGIN_PATH, 'web/nginx_proxy.conf'),
            os.path.join(self.RUN_PATH, 'web/nginx_proxy.conf')
        )

    def set_log_format(self):
        print("Setting log format...")
        # Nginx log format
        self.copy_file(
            os.path.join(self.PLUGIN_PATH, 'monitor/config/nginx_log_format.conf'),
            os.path.join(self.RUN_PATH, 'config/nginx_log_format.conf')
        )

        self.copy_file(
            os.path.join(self.PLUGIN_PATH, 'monitor/config/waf2monitor_data.conf'),
            os.path.join(self.RUN_PATH, 'config/waf2monitor_data.conf')
        )

        # Sub panel Nginx log format
        nginx_log_format_file = os.path.join(self.panel_path, 'vhost/nginx/0.monitor_log_format.conf')
        self.copy_file(
            os.path.join(self.RUN_PATH, 'config/nginx_log_format.conf'),
            nginx_log_format_file)
        public.set_mode(nginx_log_format_file, "600")

        nginx_waf2monitor_file = os.path.join(self.panel_path, 'vhost/nginx/waf2monitor_data.conf')
        self.copy_file(
            os.path.join(self.RUN_PATH, 'config/waf2monitor_data.conf'),
            nginx_waf2monitor_file
        )
        public.set_mode(nginx_waf2monitor_file, "600")

        # Apache log format
        self.copy_file(
            os.path.join(self.PLUGIN_PATH, 'monitor/config/apache_log_format.conf'),
            os.path.join(self.RUN_PATH, 'config/apache_log_format.conf')
        )

        # Sub panel Apache log format
        apache_log_format_file = os.path.join(self.panel_path, 'vhost/apache/0.monitor_log_format.conf')
        self.copy_file(
            os.path.join(self.RUN_PATH, 'config/apache_log_format.conf'),
            apache_log_format_file

        )
        public.set_mode(apache_log_format_file, "600")

    def build_ipfilter(self) -> bool:
        ipfilter_bin = os.path.relpath(os.path.join(self.RUN_PATH, 'ipfilter'))
        for p in psutil.pids():
            try:
                p_exe = os.readlink("/proc/{}/exe".format(p))
                if p_exe.endswith('(deleted)'):
                    p_exe = p_exe[:-9].strip()
                if p_exe == ipfilter_bin:
                    public.ExecShell("kill -9 {}".format(p))
            except:
                pass

        # Build ipfilter
        if os.path.isfile(ipfilter_bin):
            os.remove(ipfilter_bin)
        print("Compiling ipfilter")
        self.run_command("bash {}".format(os.path.join(self.PLUGIN_PATH, 'monitor/ipfilter/build_ipfilter.sh')))
        if not os.path.isfile(os.path.join(self.RUN_PATH, 'ipfilter')):
            print("Failed to compile ipfilter")
            return False
        ipfilter_log = "{}/ipfilter.log".format(self.RUN_PATH)
        cmd = "nohup {} &> {} &".format(ipfilter_bin, ipfilter_log)
        res = public.ExecShell(cmd)
        print("ipfilter started")
        return True

    @staticmethod
    def check_site_config():
        res = Service().check_site_config()
        if not res["status"]:
            print(res['msg'])
        else:
            print("Site config check passed")


    def set_systemd_service(self):
        """设置系统服务"""
        print("Adding system services")
        if not os.path.exists(self.SYSTEMD_PATH):
            src_file = os.path.join(self.PLUGIN_PATH, 'service', 'monitor.init')
            dst_file = '/etc/init.d/monitor'

            # 检查目标文件是否存在
            if os.path.exists(dst_file):
                # 停止服务
                self.run_command('service monitor stop')
                # 从 chkconfig 中删除服务
                self.run_command('chkconfig --del monitor')

            # 复制文件
            self.copy_file(src_file, dst_file)
            # 设置文件权限
            self.run_command('chmod +x {dst_file}'.format(dst_file=dst_file))
            # 添加服务到 chkconfig
            self.run_command('chkconfig --add monitor')
            # 设置启动级别
            self.run_command('chkconfig --level 2345 monitor on')
            # 启动服务
            self.run_command('service monitor start')

            print("Script execution completed successfully.")
        else:
            src_file = os.path.join(self.PLUGIN_PATH, 'service/monitor.service')
            dst_file = os.path.join(self.SYSTEMD_PATH, 'monitor.service')
            if os.path.exists(dst_file):
                self.run_command("systemctl stop monitor.service")
            self.copy_file(src_file, dst_file)
            time.sleep(1)
            self.run_command("systemctl daemon-reload && systemctl enable monitor.service && systemctl restart monitor.service")

        time.sleep(2)
        self.run_command("systemctl status monitor.service")
        if not self.monitor_running() and self.not_systemd():
            print("未发现systemd服务，使用nohup启动")
            public.ExecShell("cd {path} && nohup {path}/monitor &> /dev/null &".format(path=self.RUN_PATH))
            time.sleep(2)

        return self.monitor_running()

    def monitor_running(self):
        monitor_pid_file = self.RUN_PATH + "/monitor.pid"
        if not os.path.exists(monitor_pid_file):
            print("未发现monitor.pid文件")
            pid = self._check_monitor_running_by_exe()
            if pid == 0:
                return False
        else:
            try:
                pid = int(public.readFile(monitor_pid_file))
            except:
                print("错误的monitor.pid文件")
                pid = self._check_monitor_running_by_exe()
                if pid == 0:
                    return False

        print("monitor正在运行, pid: {}".format(pid))
        if not psutil.pid_exists(pid):
            return False
        return True

    def _check_monitor_running_by_exe(self) -> int:
        pids: List[int] = []
        try:
            real_path = os.path.relpath(self.RUN_PATH + "/monitor")
            for i in os.listdir("/proc"):
                if not i.isdigit():
                    continue

                exe = "/proc/{}/exe".format(i)
                if os.path.isfile(exe) and os.path.samefile(exe, real_path):
                    pids.append(int(i))

            # 找出父进程
            for i in pids:
                try:
                    p = psutil.Process(i)
                    if p.ppid() not in pids:
                        return i
                except Exception as e:
                    print("Failed to find parent process:", str(e))
                    pass

            return 0

        except Exception as e:
            print("Failed to find process:", str(e))
        return 0

    def stop_monitor(self):
        public.ExecShell("systemctl stop monitor.service")
        time.sleep(4)
        if self.monitor_running():
            monitor_pid_file = self.RUN_PATH + "/monitor.pid"
            if not os.path.exists(monitor_pid_file):
                return
            try:
                pid = int(public.readFile(monitor_pid_file))
                psutil.Process(pid).terminate()
            except:
                    return
    def add_monitor_cron(self):
        """添加监控定时任务"""
        try:
            if public.M('crontab').where('name=?', '[勿删]宝塔监控报表-重构版定时检查任务').find():
                return

            import crontab
            crontabs = crontab.crontab()
            sh = "{panel_path}/pyenv/bin/python3.7 -u {panel_path}/plugin/monitor/monitor_check.py".format(
                panel_path=public.get_panel_path()
            )
            args = {
                "name": "[勿删]宝塔监控报表-重构版定时检查任务",
                "type": 'hour',
                "where1": '',
                "hour": '',
                "week": "",
                "minute": '0',
                "sName": 'toShell',
                "sType": 'toShell',
                "notice": '',
                "notice_channel": '',
                "save": '',
                "save_local": '1',
                "backupTo": '',
                "sBody": sh,
                "urladdress": '',
                "status": "1"
            }
            res = crontabs.AddCrontab(args)
            if res["status"] and "id" in res.keys():
                return
            return
        except Exception:
            return

    def fix_docker_module_bug(self):
        """
        检测并修复 Docker 模块
        """
        docker_base_file = "/www/server/panel/mod/project/docker/sites/base.py"

        # 1. 检查文件是否存在
        if not os.path.exists(docker_base_file):
            return

        try:
            import re

            # 2. 读取文件内容
            with open(docker_base_file, 'r', encoding='utf-8') as f:
                content = f.read()

            # 3. 使用正则表达式精确查找目标代码
            pattern = r"public\.M\('docker_domain'\)\.where.*?\.getField\('id'\)"

            # 查找所有匹配
            matches = list(re.finditer(pattern, content))
            if not matches:
                return  # 没有找到需要修复的代码

            # 4. 检查第一个匹配是否在监控配置的上下文中
            match = matches[0]
            match_pos = match.start()

            # 获取上下文（前后 200 字符）
            context_start = max(0, match_pos - 200)
            context_end = min(len(content), match_pos + 200)
            context = content[context_start:context_end]

            # 确认这是在监控配置的上下文中
            if "monitor_conf" not in context or "sites_data" not in context:
                return  # 不是目标代码，不修复

            # # 5. 备份原文件
            # backup_file = docker_base_file + ".bak.monitor"
            # shutil.copy2(docker_base_file, backup_file)

            # 6. 修复
            # 只替换第一个匹配（只应有一处需要修复）
            fixed_content = re.sub(pattern, lambda m: m.group(0).replace(".getField('id')", ".getField('pid')"), content, count=1)

            # 7. 写回文件
            with open(docker_base_file, 'w', encoding='utf-8') as f:
                f.write(fixed_content)


        except Exception as e:
            pass

    def install_monitor(self):
        if not os.path.exists(self.RUN_PATH):
            os.makedirs(self.RUN_PATH)
        self.install_and_update_time()
        self.first_copy()
        self._reset_web_ssl()
        self.check_user()
        if not self.try_download_bin():
            print("Failed to download binary files")

        self.copy_static_file()
        self.set_log_format()
        self.build_ipfilter()
        if not self.set_systemd_service():
            print("Failed to start service")

        self.install_report_env()
        # 添加定时任务
        self.add_monitor_cron()

        # 修复 Docker 模块
        self.fix_docker_module_bug()

        self.check_site_config()
        public.serviceReload()
        print('Successfully!')
        if self._is_update:
            public.writeFile('{}/data/restart.pl'.format(self.panel_path), 'True')

    def uninstall_monitor(self):
        """卸载监控"""
        try:
            if os.path.exists(self.SYSTEMD_PATH):
                self.run_command("systemctl stop monitor.service")
                self.run_command("systemctl disable monitor.service")
                os.remove(os.path.join(self.SYSTEMD_PATH, 'monitor.service'))
                self.run_command("systemctl daemon-reload")
            else:
                self.run_command("service monitor stop")
                self.run_command("chkconfig --del monitor")
                os.remove("/etc/init.d/monitor")
        except Exception as e:
            print(e)

        # 清理 ipset 资源和 iptables 规则
        self._clear_ipset_resources()

        Service().clear_site_config()
        shutil.rmtree(self.RUN_PATH)  # 删除程序目录

        # 删除日志格式
        nginx_log_format_file = os.path.join(self.panel_path, 'vhost/nginx/0.monitor_log_format.conf')
        if os.path.exists(nginx_log_format_file):
            os.remove(nginx_log_format_file)

        for i in os.listdir(os.path.join(self.panel_path, 'vhost/nginx')):
            if i.startswith('0.monitor') and i.endswith('_log_format.conf'):
                os.remove(os.path.join(self.panel_path, 'vhost/nginx', i))

        apache_log_format_file = os.path.join(self.panel_path, 'vhost/apache/0.monitor_log_format.conf')
        if os.path.exists(apache_log_format_file):
            os.remove(apache_log_format_file)

        for i in ("apache", "nginx"):
            web_proxy_file = os.path.join(self.panel_path, 'vhost/{}/monitor_web_proxy.conf'.format(i))
            if os.path.exists(web_proxy_file):
                os.remove(web_proxy_file)

        print('Successfully!')

    def _clear_ipset_resources(self):
        """清理 ipset 集合和 iptables 规则"""
        try:
            # 清空 ipset 内容
            # print('Flushing ipset collections...')
            self.run_command("ipset flush monitor_filter 2>/dev/null || true")
            self.run_command("ipset flush monitor_filter_v6 2>/dev/null || true")

            # 销毁 ipset 集合
            # print('Destroying ipset collections...')
            self.run_command("ipset destroy monitor_filter 2>/dev/null || true")
            self.run_command("ipset destroy monitor_filter_v6 2>/dev/null || true")

        except Exception as e:
            pass

    @staticmethod
    def not_systemd() -> bool:
        res = public.readFile("/proc/1/comm")
        if isinstance(res, str) and res.strip() == "systemd":
            return False
        return True

    @staticmethod
    def _reset_web_ssl():
        ssl_path = "/www/server/monitor/web/ssl"
        if not os.path.exists(ssl_path):
            return
        try:
            for i in ("certificate.pem", "privateKey.pem"):
                if os.path.exists(os.path.join(ssl_path, i)):
                    os.remove(os.path.join(ssl_path, i))
        except:
            pass

    def install_report_env(self) -> bool:
        """准备报告所需环境， 1.下载 NotoSans字体 2.下载所需软件包 （ matplotlib reportlab） 不指定版本尽可能兼容"""
        font_files = [
            "{}/report/NotoSansSC-Bold.ttf".format(self.PLUGIN_PATH),
            "{}/report/NotoSansSC-Regular.ttf".format(self.PLUGIN_PATH)
        ]
        has_font = True
        for font_file in font_files:
            if not os.path.exists(font_file) or os.path.getsize(font_file) < 1024:
                has_font = False
        if not has_font:
            self._download_font()
            if not os.path.exists(font_files[0]) or not os.path.exists(font_files[0]):
                self._download_font()

        if not self._test_report_lib():
            self._install_report_lib()
        return  True

    def _download_font(self):
        url = public.get_url() + "/src/monitor_font.tar"
        target_path = "{}/report/monitor_font.tar".format(self.PLUGIN_PATH)
        self.run_command("wget -O {} {}".format(target_path, url))
        self.run_command("tar -xvf {} -C {}".format(target_path, os.path.join(self.PLUGIN_PATH, "report")))
        self.run_command("rm -rf {}".format(target_path))
        self.run_command(
            "mv {p}/report/monitor_font/* {p}/report/ && rm -rf {p}/report/monitor_font/".format(p=self.PLUGIN_PATH)
        )

    @staticmethod
    def _test_report_lib() -> bool:
        python_bin = "{}/pyenv/bin/python3".format(public.get_panel_path())
        return public.ExecShell(
            "{} -c 'import reportlab, matplotlib;from reportlab.platypus import SimpleDocTemplate; print(\"successful\")'".format(python_bin)
        )[0].strip().endswith("successful")

    def _install_report_lib(self):
        python_bin = "{}/pyenv/bin/python3.7".format(public.get_panel_path())
        if os.path.islink(python_bin) and os.path.basename(os.path.realpath(python_bin)) == "python3.13":
            self.run_command("{} -m pip install reportlab matplotlib --only-binary=contourpy,numpy".format(python_bin))
        else:
            self.run_command("{} -m pip install reportlab==4.3.1 matplotlib==3.5.3 --only-binary=contourpy,numpy".format(python_bin))


if __name__ == '__main__':
    if len(sys.argv) < 2:
        exit('参数错误')
    if sys.argv[1] == 'install':
        MonitorInstaller().install_monitor()
    elif sys.argv[1] == 'uninstall':
        MonitorInstaller().uninstall_monitor()
    elif sys.argv[1] == 'test':
        MonitorInstaller().install_report_env()
        pass
    else:
        exit('参数错误')
