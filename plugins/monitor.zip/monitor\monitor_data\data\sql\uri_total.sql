-- URI请求统计表
CREATE TABLE IF NOT EXISTS `uri_total` (
    `ut_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `date` INTEGER DEFAULT 0,               -- 日期
    `uri_id` INTEGER DEFAULT 0,             -- URI ID
    `sent_bytes` INTEGER DEFAULT 0,         -- 总计发送字节数
    `recv_bytes` INTEGER DEFAULT 0,     -- 总计接收字节数
    `pv` INTEGER DEFAULT 0,                 -- PV
    `uv` INTEGER DEFAULT 0,                 -- UV
    `request` INTEGER DEFAULT 0             -- 请求次数
);

-- 增加索引
CREATE INDEX IF NOT EXISTS `idx_date_request` ON `uri_total` (`date`, `request`);
CREATE INDEX IF NOT EXISTS `idx_date_uri_id` ON `uri_total` (`date`,`uri_id`);