-- host 记录
CREATE TABLE IF NOT EXISTS `seo_uri_host`
(
    `id`             INTEGER PRIMARY KEY AUTOINCREMENT,
    `seo_uri_id`     INTEGER DEFAULT 0, -- seo_uri 表中记录的id
    `host_id`        INTEGER DEFAULT 0 -- host_id
);

-- 增加索引
CREATE INDEX IF NOT EXISTS `idx_seo_uri_id_host` ON `seo_uri_host` (`seo_uri_id`, `host_id`);