
-- Web 服务用户信息记录
CREATE TABLE IF NOT EXISTS `web_user` (
    `uid` INTEGER PRIMARY KEY AUTOINCREMENT,  -- 用户id
    `name` TEXT DEFAULT "" NOT NULL,          -- 用户名
    `sites` TEXT DEFAULT "" NOT NULL,         -- 可访问的站点名称
    `salt` TEXT DEFAULT "" NOT NULL,          -- 密码盐
    `md5_passwd` TEXT DEFAULT "" NOT NULL,    -- 密码
    `level` INTEGER DEFAULT 0,                -- 权限 0.超级管理员，1.管理员，2.普通用户
    `update_time` INTEGER DEFAULT 0,          -- 是否ipv6
    `create_time` INTEGER NOT NULL DEFAULT (strftime('%s')) -- 创建时间
);

-- 超级管理员 可以操作其他用户的所有权限  超级管理员 的身份通过面板的登录用户验证，本表不会记录器密码， 且不能修改
-- 管理员 可以查看其他用户的权限
-- 普通用户 根据 sites 确认权限

