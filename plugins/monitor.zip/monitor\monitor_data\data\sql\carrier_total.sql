-- IP运营商统计表
CREATE TABLE IF NOT EXISTS `carrier_total` (
    `carrier_total_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `date` INTEGER DEFAULT 0,                       -- 日期 20190101
    `carrier_id` INTEGER DEFAULT 0,                 -- 运营商ID
    `request` INTEGER DEFAULT 0                     -- 请求次数
);

-- 增加索引
CREATE INDEX IF NOT EXISTS `idx_date_carrier_id` ON `carrier_total` (`date`,`carrier_id`);