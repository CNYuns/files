// -------------------------------------------------------------------
// 宝塔Linux面板
// -------------------------------------------------------------------
// Copyright (c) 2015-2024 宝塔软件(http://bt.cn) All rights reserved.
// -------------------------------------------------------------------
// Author: hwliang <hwl@bt.cn>
// -------------------------------------------------------------------
#define IPSET_MANAGER_CPP
#ifndef IPSET_MANAGER_H
#include "ipset_manager.h"
#endif
using namespace std;

regex_t ipset_name_regex_x = match_compile("^[a-zA-Z0-9_\\-]{1,64}$");
ipset_manager::ipset_manager()
{
    this->ipset_name_regex = ipset_name_regex_x;
}


vector<string> ipset_manager::get_ipset_info(string name){
    vector<string> result;
    if(this->install_ipset() == 0){
        write_log("错误: ipset未安装",LOG_ERROR);
        return result;
    }

    string cmd = "ipset list " + name + " -t";
    string output = exec_shell(cmd);
    if(output.find("not exist") != string::npos){
        write_log("警告: ipset集合不存在",LOG_WARNING);
        return result;
    }

    vector<string> lines = split(output,"\n");

    for(int i=0;i<lines.size();i++){
        if(lines[i].find("Name:") != string::npos){
            result.push_back(lines[i].substr(6));
        }
        if(lines[i].find("Type:") != string::npos){
            result.push_back(lines[i].substr(6));
        }
        if(lines[i].find("Header:") != string::npos){
            vector<string> ptr = split(lines[i].substr(8)," ");
            for (int j=0;j<ptr.size();j++){
                if (ptr[j].find("hashsize") != string::npos){
                    result.push_back(ptr[j + 1]);
                }
                if (ptr[j].find("maxelem") != string::npos){
                    result.push_back(ptr[j + 1]);
                }
            }
        }
    }

    return result;
}


int ipset_manager::create_ipset(string name,string hash,int hashsize,int maxelem,int timeout,string ports,string protocol)
{
    if(this->is_iptables_installed() == 0){
        write_log("错误: iptables未安装",LOG_ERROR);
        return 0;
    }

    if(this->install_ipset() == 0){
        write_log("错误: ipset未安装",LOG_ERROR);
        return 0;
    }

    if(this->create_collection(name,hash,hashsize,maxelem,timeout) == 0)
    {
        write_log("警告: 创建ipset集合失败",LOG_WARNING);
        return 0;
    }

    vector<string> port_list =  split(ports,",");
    for(int i=0;i<port_list.size();i++)
    {
        int port = atoi(port_list[i].c_str());
        if(port < 0 || port > 65535){
            write_log("警告: 端口号范围不合法，跳过: " + port_list[i],LOG_WARNING);
            continue;
        }
        if(this->set_collection_to_iptables(name,port,protocol) == 0)
        {
            write_log("警告: 将ipset集合添加到iptables失败",LOG_WARNING);
            return 0;
        }
    }

    //write_log("成功创建ipset集合 - " + name,LOG_INFO);

    return 1;
}


int ipset_manager::delete_ipset(string name,string ports,string protocol)
{
    vector<string> port_list =  split(ports,",");
    for(int i=0;i<port_list.size();i++)
    {
        int port = atoi(port_list[i].c_str());
        if(port < 0 || port > 65535){
            write_log("警告: 端口号范围不合法，跳过: " + port_list[i],LOG_WARNING);
            continue;
        }
        if(this->del_collection_from_iptables(name,port,protocol) == 0)
        {
            write_log("警告: 从iptables删除ipset集合失败",LOG_WARNING);
            return 0;
        }
    }

    if(this->delete_collection(name) == 0)
    {
        write_log("警告: 删除ipset集合失败",LOG_WARNING);
        return 0;
    }

    write_log("成功删除ipset集合 - " + name,LOG_INFO);

    return 1;
}


int ipset_manager::check_ipset_name(string name){
    if(!match_exec(this->ipset_name_regex,name.c_str())){
        return 0;
    }
    return 1;
}

int ipset_manager::is_hash_supported(string hash)
{
    vector<string> supporte_list = {"ip","ip,port","net"};
    for (int i = 0; i < supporte_list.size(); i++)
    {
        if (supporte_list[i] == hash)
        {
            return 1;
        }
    }
    return 0;
}

int ipset_manager::create_collection(string name,string hash,int hashsize,int maxelem,int timeout)
{
    // 检查集合名称
    if (name.empty() || this->check_ipset_name(name) == 0)
    {
        write_log("未能成功创建ipset - " + name + ", 因为集合名称格式错误", LOG_WARNING);
        return 0;
    }

    //检查hash是否支持
    if(!is_hash_supported(hash))
    {
        return 0;
    }

    //检查参数值范围
    int max_hashsize = 65536;
    int max_maxelem = 1024 * 512;
    int max_timeout = 86400 * 30;
    if (hashsize > max_hashsize || hashsize < 1) hashsize = max_hashsize;
    if (maxelem > max_maxelem || maxelem < 32) maxelem = max_maxelem;
    if (timeout > max_timeout) timeout = max_timeout;
    if (timeout < 0) timeout = 0;

    string cmd = "";
    string result = "";
    string v4_name = name;
    string v6_name = name + "_ipv6";
    int is_ipv4 = 1,is_ipv6 = 1;
    //创建ipset
    
    if(this->is_collection_exists(v4_name) == 0){
        cmd = "ipset create " + v4_name + " hash:" + hash + " hashsize " + to_string(hashsize) + " maxelem " + to_string(maxelem);
        if(timeout > 0) cmd += " timeout " + to_string(timeout);
        cmd += " 2>&1";
        result = exec_shell(cmd);
        if(result.size() > 10){
            write_log(result, LOG_WARNING);
            write_log("未能成功创建ipset - " + v4_name, LOG_WARNING);
            is_ipv4 = 0;
        }
    }


    if (this->is_collection_exists(v6_name) == 0)
    {
        // ipv6
        cmd = "ipset create " + v6_name + " hash:" + hash + " hashsize " + to_string(hashsize) + " maxelem " + to_string(maxelem);
        if(timeout > 0) cmd += " timeout " + to_string(timeout);
        cmd += " family inet6";
        cmd += " 2>&1";
        result = exec_shell(cmd);
        if (result.size() > 10)
        {
            write_log(result, LOG_WARNING);
            write_log("未能成功创建ipset - IPv6 " + v6_name, LOG_WARNING);
            is_ipv6 = 0;
        }
    }

    if(is_ipv4 == 0 && is_ipv6 == 0){
        return is_ipv4;
    }
    
    return is_ipv4;
}

int ipset_manager::delete_collection(string name)
{
    // 检查集合名称
    if (name.empty() || this->check_ipset_name(name) == 0)
    {
        write_log("未能成功删除ipset - " + name + ", 因为集合名称格式错误", LOG_WARNING);
        return 0;
    }

    string cmd = "";
    string result = "";
    string v4_name = name;
    string v6_name = name + "_ipv6";
    int is_ipv4 = 1,is_ipv6 = 1;

    if(this->is_collection_exists(v4_name) == 1){
        cmd = "ipset destroy " + name + " 2>&1";
        result = exec_shell(cmd);
        if(result.size() > 10){
            write_log(result, LOG_WARNING);
            write_log("未能成功删除ipset - " + v4_name, LOG_WARNING);
            is_ipv4 = 0;
        }
    }


    if (this->is_collection_exists(v6_name) == 1)
    {
        // ipv6
        cmd = "ipset destroy " + v6_name + " 2>&1";
        result = exec_shell(cmd);
        if (result.size() > 10)
        {
            write_log(result, LOG_WARNING);
            write_log("未能成功删除ipset - IPv6 " + v6_name, LOG_WARNING);
            is_ipv6 = 0;
        }
    }

    if(is_ipv4 == 0 && is_ipv6 == 0){
        return is_ipv4;
    }
    
    return is_ipv4;
}

int ipset_manager::add_to_collection(string name,string ip,int port,int timeout)
{
    // 检查集合名称
    if (name.empty() || this->check_ipset_name(name) == 0)
    {
        write_log("未能成功添加["+ip+"]到ipset - " + name + ", 因为集合名称格式错误", LOG_WARNING);
        return 0;
    }

    //检查ip
    if(!is_ipaddr(ip.c_str())){
        write_log("未能成功添加["+ip+"]到ipset - " + name + ", 因为IP地址格式错误", LOG_WARNING);
        return 0;
    }

    //检查端口
    if(port < 0 || port > 65535){
        write_log("未能成功添加["+ip+":"+to_string(port)+"]到ipset - " + name + ", 因为端口号范围错误", LOG_WARNING);
        return 0;
    }

    if(is_ipv6(ip.c_str())){
        name += "_ipv6";
    }

    string cmd = "ipset add " + name + " " + ip;
    if (port > 0) cmd += "," + to_string(port);
    if (timeout > 0) cmd += " timeout " + to_string(timeout);
    cmd += " 2>&1";
    string result = exec_shell(cmd);
    if (result.size() < 10)
    {
        write_log("成功添加["+ip+"]到ipset - " + name, LOG_INFO);
        return 1;
    }

    write_log(result, LOG_WARNING);
    if(result.find("already added") != string::npos){
        write_log("未能成功添加["+ip+"]到ipset - " + name + ", 因为指定IP已存在", LOG_WARNING);
        return 2;
    }else{
        write_log("未能成功添加["+ip+"]到ipset - " + name, LOG_WARNING);
        return 0;
    }
}

int ipset_manager::update_to_collection(string name,string ip,int port,int timeout)
{
    int res = this -> add_to_collection(name, ip, port, timeout);
    if (res != 2) {
        return res;
    }else {
        this -> del_from_collection(name, ip, port);
        return this -> add_to_collection(name, ip, port, timeout);
    }
}

int ipset_manager::del_from_collection(string name,string ip,int port)
{
    // 检查集合名称
    if (name.empty() || this->check_ipset_name(name) == 0)
    {
        write_log("未能从ipset - " + name + "删除["+ip+"], 因为集合名称格式错误", LOG_WARNING);
        return 0;
    }

    //检查ip
    if(!is_ipaddr(ip.c_str())){
        write_log("未能从ipset - " + name + "删除["+ip+"], 因为IP地址格式错误", LOG_WARNING);
        return 0;
    }

    //检查端口
    if(port < 0 || port > 65535){
        write_log("未能从ipset - " + name + "删除["+ip+":"+to_string(port)+"] 因为端口号范围错误", LOG_WARNING);
        return 0;
    }

    if(is_ipv6(ip.c_str())){
        name += "_ipv6";
    }


    string cmd = "ipset del " + name + " " + ip;
    if (port > 0) cmd += "," + to_string(port);
    cmd += " 2>&1";
    string result = exec_shell(cmd);
    if (result.size() < 10)
    {
        write_log("成功从ipset - " + name + "删除["+ip+"]", LOG_INFO);
        return 1;
    }


    write_log(result, LOG_WARNING);
    if(result.find("not added") != string::npos){
        write_log("未能从ipset - " + name + "删除["+ip+"] 因为指定IP不存在", LOG_WARNING);
    }else{
        write_log("未能从ipset - " + name + "删除["+ip+"]", LOG_WARNING);
    }
    return 0;
}


int ipset_manager::get_collection_count(string name)
{
    string cmd = "ipset list " + name + " -t";
    string result = exec_shell(cmd);
    if (result.find("Name:") != string::npos)
    {
        vector<string> lines = split(result, "\n");
        for (int i = 0; i < lines.size(); i++)
        {
            if (lines[i].find("Number of entries:") != string::npos)
            {
                vector<string> items = split(lines[i], " ");
                return atoi(items[3].c_str());
            }
        }
    }
    return 0;
}

vector<string> ipset_manager::get_collection_list(){
    string cmd = "ipset list -t|grep 'Name:'";
    string result = exec_shell(cmd);
    vector<string> lines = split(result, "\n");
    vector<string> list;
    for (int i = 0; i < lines.size(); i++)
    {
        if (lines[i].find("Name:") != string::npos)
        {
            vector<string> items = split(lines[i], " ");
            list.push_back(items[1]);
        }
    }
    return list;
}


vector<string> ipset_manager::get_collection_element_list(string name){
    string cmd = "ipset list " + name;
    string result = exec_shell(cmd);
    if(result.find("Members:") == string::npos){
        write_log("未能获取ipset - " + name + "的元素列表，指定集合不存在", LOG_WARNING);
        return vector<string>();
    }
    vector<string> lines = split(result, "\n");
    vector<string> list;
    for (int i = 0; i < lines.size(); i++)
    {
        if (lines[i].find("Members:") != string::npos)
        {
            for (int j = i + 1; j < lines.size(); j++)
            {
                list.push_back(lines[j]);
            }
        }
    }
    return list;
}

int ipset_manager::get_collection_element_timeout(string name,string ip,int port){
    string cmd = "ipset list " + name + "|grep " + ip;
    string result = exec_shell(cmd);
    vector<string> lines = split(result, "\n");
    for (int i = 0; i < lines.size(); i++)
    {
        if(lines[i].find(ip) != string::npos) {
            vector<string> items = split(lines[i], " ");
            if(items.size() == 3){
                return atoi(items[2].c_str());
            }
        }
    }
    return 0;
}

int ipset_manager::flush_collection(string name)
{
    string cmd = "ipset flush " + name;
    string result = exec_shell(cmd);
    if (result.find("not exist") != string::npos)
    {
        write_log(result, LOG_WARNING);
        write_log("未能清空ipset - " + name + " 因为指定集合不存在", LOG_WARNING);
        return 0;
    }
    return 1;
}


int ipset_manager::check_protocol(string protocol){
    if(protocol == "tcp" || protocol == "udp" || protocol == "icmp" || protocol == "all"){
        return 1;
    }
    return 0;
}

int ipset_manager::set_collection_to_iptables(string name,int port,string protocol){
    if(protocol == "all") port = 0;
    if(this->is_collection_exists(name) == 0){
        write_log("未能将ipset - " + name + "添加到iptables, 因为指定集合不存在", LOG_WARNING);
        return 0;
    }

    if(this->check_protocol(protocol) == 0){
        write_log("未能将ipset - " + name + "添加到iptables, 因为指定协议错误", LOG_WARNING);
        return 0;
    }
    string result = "";
    string cmd = "";
    string v4_name = name;
    string v6_name = name + "_ipv6";
    int is_ipv4 = 1,is_ipv6 = 1;
    if(this->iptables_is_exists(v4_name,port) == 0){
        cmd = "iptables -I INPUT -m set --match-set " + v4_name + " src";
        cmd += " -p " + protocol;
        if (port > 0  && protocol != "all") cmd += " --destination-port " + to_string(port);
        cmd += " -j DROP 2>&1";
        result = exec_shell(cmd);
        if(result.size() > 10){
            write_log(result, LOG_WARNING);
            write_log("未能将ipset - " + v4_name + "添加到iptables", LOG_WARNING);
            is_ipv4 = 0;
        }
    }
    
    if(this->ip6tables_is_exists(v6_name,port) == 0){
        cmd = "ip6tables -I INPUT -m set --match-set " + v6_name + " src";
        cmd += " -p " + protocol;
        if (port > 0 && protocol != "all") cmd += " --destination-port " + to_string(port);
        cmd += " -j DROP 2>&1";
        result = exec_shell(cmd);
        if (result.size() > 10)
        {
            write_log(result, LOG_WARNING);
            write_log("未能将ipset - " + v6_name + "添加到ip6tables", LOG_WARNING);
            is_ipv6 = 0;
        }
        
    }

    if(is_ipv4 == 0 && is_ipv6 == 0){
        write_log("未能将ipset - " + v4_name + "添加到iptables, 因为指定规则已存在", LOG_WARNING);
        return is_ipv4;
    }

    return is_ipv4;
}

int ipset_manager::del_collection_from_iptables(string name,int port,string protocol){
    if(protocol == "all") port = 0;

    if(this->check_protocol(protocol) == 0){
        write_log("未能将ipset - " + name + "从iptables删除, 因为指定协议错误", LOG_WARNING);
        return 0;
    }
    string cmd = "";
    string result = "";
    string v4_name = name;
    string v6_name = name + "_ipv6";
    int is_ipv4 = 1,is_ipv6 = 1;
    if(this->iptables_is_exists(v4_name,port) == 1){
        cmd = "iptables -D INPUT -m set --match-set " + v4_name + " src";
        cmd += " -p " + protocol;
        if (port > 0 && protocol != "all") cmd += " --destination-port " + to_string(port);
        cmd += " -j DROP 2>&1";
        result = exec_shell(cmd);
        if(result.size() > 10){
            write_log(result, LOG_WARNING);
            write_log("未能将ipset - " + v4_name + "从iptables删除", LOG_WARNING);
            is_ipv4 = 0;
        }
    }


    if(this->ip6tables_is_exists(v6_name,port) == 1){
        cmd = "ip6tables -D INPUT -m set --match-set " + v6_name + " src";
        cmd += " -p " + protocol;
        if (port > 0 && protocol != "all") cmd += " --destination-port " + to_string(port);
        cmd += " -j DROP 2>&1";
        result = exec_shell(cmd);
        if (result.size() > 10){
            write_log(result, LOG_WARNING);
            write_log("未能将ipset - " + v6_name + "从ip6tables删除", LOG_WARNING);
            is_ipv6 = 0;
        }
    }

    if(is_ipv4 == 0 && is_ipv6 == 0){
        write_log("未能将ipset - " + v4_name + "从iptables删除, 因为指定规则不存在", LOG_WARNING);
        return is_ipv4;
    }

    return is_ipv4;
}

vector<string> ipset_manager::get_iptables_collection_list(){
    string cmd = "iptables -L INPUT -n --line-numbers|grep match-set 2>&1";
    string result = exec_shell(cmd);
    vector<string> list;
    vector<string> lines = split(result,"\n");
    for (int i = 0; i < lines.size(); i++)
    {
        string line = lines[i];
        if (line.find("match-set") != string::npos)
        {
            vector<string> tmp = split(line," ");
            for (int j = 0; j < tmp.size(); j++)
            {
                if (tmp[j] == "match-set")
                {
                    list.push_back(tmp[j+1]);
                }
            }
        }
    }
    return list;
}

int ipset_manager::iptables_is_exists(string name,int port){
    string cmd = "iptables -L INPUT -n --line-numbers|grep match-set 2>&1";
    if(port > 0){
        cmd += "|grep dpt:" + to_string(port);
    }
    string result = exec_shell(cmd);
    if (result.find(name) != string::npos)
    {
        return 1;
    }
    return 0;
}


int ipset_manager::ip6tables_is_exists(string name,int port){
    string cmd = "ip6tables -L INPUT -n --line-numbers|grep match-set 2>&1";
    if(port > 0){
        cmd += "|grep dpt:" + to_string(port);
    }
    string result = exec_shell(cmd);
    if (result.find(name) != string::npos)
    {
        return 1;
    }
    return 0;
}

int ipset_manager::install_ipset(){

    // 检查是否已安装
    if(is_ipset_installed()){
        return 1;
    }

    // 检查是否有安装命令
    string cmd = "";
    if(file_exists("/usr/bin/yum")){
        cmd = "yum install ipset -y 2>&1";
    }else if(file_exists("/usr/bin/apt-get")){
        cmd = "apt-get install ipset -y 2>&1";
    }else if(file_exists("/usr/bin/dnf")){
        cmd = "dnf install ipset -y 2>&1";
    }else{
        write_log("错误: 不兼容的操作系统，请手动安装ipset后再尝试启动",LOG_ERROR);
        return 0;
    }

    // 执行安装命令
    string result = exec_shell(cmd);

    // 检查是否安装成功
    return is_ipset_installed();
}


int ipset_manager::is_ipset_installed(){
    string cmd = "ipset -v 2>&1";
    string result = exec_shell(cmd);
    if (result.find("ipset v") != string::npos)
    {
        return 1;
    }
    return 0;
}

int ipset_manager::is_iptables_installed(){
    string cmd = "iptables -V 2>&1";
    string result = exec_shell(cmd);
    if (result.find("iptables v") != string::npos)
    {
        return 1;
    }
    return 0;
}


int ipset_manager::is_collection_exists(string name)
{
    string cmd = "ipset list " + name + " -t 2>&1";
    string result = exec_shell(cmd);
    if (result.find("Name:") != string::npos)
    {
        return 1;
    }
    return 0;
}

int ipset_manager::add_waf_ip(string ip,int timeout){
    return this->add_to_collection(RULE_NAME,ip,0,timeout);
}

int ipset_manager::del_waf_ip(string ip){
    return this->del_from_collection(RULE_NAME,ip,0);
}

int ipset_manager::update_waf_ip(string ip,int timeout){
    return this->update_to_collection(RULE_NAME,ip,0,timeout);
}



