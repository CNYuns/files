-- 会话列表
CREATE TABLE IF NOT EXISTS `session_list` (
    `session_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `session` TEXT DEFAULT "" NOT NULL, -- 会话索引 md5(ua + ip + date)
    `user_agent_id` INTEGER DEFAULT 0,  -- user_agent
    `ip_id` INTEGER DEFAULT 0,          -- 访问IP
    `ipv6` INTEGER DEFAULT 0,           -- 是否ipv6
    `date` INTEGER DEFAULT 0,           -- 访问日期
    `start_time` INTEGER DEFAULT 0,     -- 开始时间
    `end_time` INTEGER DEFAULT 0,       -- 结束时间
    `request` INTEGER DEFAULT 0,        -- 请求次数
    `in_uri_id` INTEGER DEFAULT 0,      -- 进入uri_id
    `last_uri_id` INTEGER DEFAULT 0,    -- 最近一次请求的uri_id
    `referer_id` INTEGER DEFAULT 0,     -- 来路
    `area_id` INTEGER DEFAULT 0         -- 地区 id
);

-- 增加唯一索引
CREATE UNIQUE INDEX IF NOT EXISTS `idx_session` ON `session_list` (`session`);
CREATE INDEX IF NOT EXISTS `idx_ip_id` ON `session_list` (`ip_id`);