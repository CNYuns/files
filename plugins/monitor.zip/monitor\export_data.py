# conding:utf-8
import json
import os
import sys
import socket
import csv
import traceback
from collections import OrderedDict
from datetime import datetime

from typing import Dict, List, Tuple, Optional, Any, TypeVar, TextIO, Type

# 添加项目根目录到环境变量
os.chdir("/www/server/panel")
if "/www/server/panel/class" not in sys.path:
    sys.path.insert(0, "/www/server/panel/class")

if "/www/server/panel/plugin/monitor" not in sys.path:
    sys.path.insert(0, "/www/server/panel/plugin/monitor")

from split_db import SSqlite
from monitor_cmd import udp_cmd
import public
import db

RUN_PATH = "/www/server/monitor"
Sql = TypeVar("Sql")
CsvWriter = TypeVar("CsvWriter")


class OrderedSet:
    def __init__(self):
        self.set = OrderedDict()

    def add(self, element):
        self.set[element] = None

    def pop(self, element):
        self.set.pop(element, None)

    def __iter__(self):
        return iter(self.set)

    def __contains__(self, element):
        return element in self.set

    def __len__(self):
        return len(self.set)


# 字段获取
# 带有缓存的基础字段获取
class FieldTool:
    _global_dbs = ["ip_list", "ua_list", "list", "area_list", "carrier_list", "spider_ip_list", "shield_ip"]
    _countries = {}
    _provinces = {}
    _cities = {}
    _unknown_areas = {}
    _ip_areas = {}
    _db_objs = {}
    _udp_cmd = b"PLUGIN_CMD|"
    other_spider = {
        "AhrefsBot": "Ahrefs",
        "PanguBot": "华为盘古",
        "BitSightBot": "BitSight",
        "Amazonbot": "亚马逊",
        "AspiegelBot": "华为",
        "DingTalkBot": "钉钉",
        "YisouSpider": "神马",
        "UptimeRobot": "Uptime机器人",
        "GPTBot": "ChatGPT",
        "SemrushBot": "Semrush",
        "Applebot": "苹果",
        "BLEXBot": "Blex",
        "DotBot": "Dot",
        "PetalBot": "Petal",
        "DataForSeoBot": "DataForSeo",
        "DnyzBot": "Dnyz",
        "MJ12bot": "Majestic",
        "DNSPod": "DNPod",
        "msnbot": "MSN",
        "EtaoSpider": "一淘",
        "JikeSpider": "即刻",
        "EasouSpider": "宜搜",
        "ia_archiver": "Alexa",
        "YoudaoBot": "有道",
        "Sosospider": "搜搜",
        "Uptimebot": "Uptime",
        # 新增AI爬虫
        "AI2Bot": "AI2",
        "Ai2Bot-Dolma": "AI2 Dolma",
        "anthropic-ai": "Anthropic",
        "Claude-Web": "Claude",
        "ClaudeBot": "Claude",
        "cohere-ai": "Cohere",
        "Diffbot": "Diffbot",
        "DuckAssistBot": "DuckAssist",
        "Applebot-Extended": "苹果",
        "CCBot": "CommonCrawl",
        "OAI-SearchBot": "OpenAI",
        "omgili": "Omgili",
        "omgilibot": "Omgili",
        "PerplexityBot": "Perplexity",
        "ImagesiftBot": "Imagesift",
        "img2dataset": "img2dataset",
        "Meta-ExternalAgent": "Meta",
        "Meta-ExternalFetcher": "Meta",
        "Tongyi-Crawler": "通义千问",
        "ERNIE-Bot-Crawler": "文心一言"
    }

    def __init__(self, site_name: str):
        self.__err_list_cache = {}
        self.__key_cache = {}
        self._site_name = site_name
        self._global_config: Optional[dict] = None
        self._udp_error = False
        self.__spider_config = None

    @property
    def spider_config(self) -> List[Dict[str, Any]]:
        if self.__spider_config is not None:
            return self.__spider_config
        try:
            spider_config_file = RUN_PATH + '/config/spider.json'
            if not os.path.exists(spider_config_file):
                return []
            self.__spider_config = json.loads(public.readFile(spider_config_file))
            return self.__spider_config
        except:
            return []

    def get_ip(self, ip_id: int, ipv6: int):
        if not ip_id:
            return '-'
        if not ipv6:
            return public.long2ip(ip_id)
        ip = self._get_field('ip_list', 'ip_list', 'ip', 'ip_id', ip_id, '')
        if not ip:
            return '-'
        return ip

    def get_area(self, ip: str):
        ip = ip.strip()
        if ip in self._ip_areas:
            return self._ip_areas[ip]
        data = udp_cmd("ip_area|" + ip)
        if data:
            ip_area_arr = data.split('|')
            if len(ip_area_arr) > 6:
                tmp = []
                for i in ip_area_arr[1:5]:
                    tmp_i = i.strip()
                    if tmp_i:
                        tmp.append(tmp_i)
                data = ' '.join(tmp)
                data = data.replace("保留", "局域网")
                self._ip_areas[ip] = data
                return self._ip_areas[ip]
        else:
            return "-"

    # 获取伪装爬虫
    def _get_false_spider(self, ua: str):
        if not ua:
            return '-'
        ua_lower = ua.lower()
        if ua_lower.find('spider') == -1 and ua_lower.find('bot') == -1:
            return '-'

        # 遍历蜘蛛配置列表
        for i in self.spider_config:
            if ua_lower.find(i['ua_key'].lower()) != -1:
                return "伪装{}".format(i['name'])

        for k, v in self.other_spider.items():
            if ua.find(k) != -1:
                return v

        return '-'

    def get_spider_title(self, ip_id: int, spider_title_id: int, ua: str):
        if spider_title_id in [0, 1, 10, 1000]:
            if not ip_id:
                return self._get_false_spider(ua)
            # 从数据库获取蜘蛛ID
            spider_title_id = self._get_field('spider_ip_list', 'spider_ip_list', 'spider_title_id', 'ip_id', ip_id, 0)
            if not spider_title_id:
                return self._get_false_spider(ua)
        # 遍历蜘蛛配置列表，匹配蜘蛛ID，取得蜘蛛名称
        for i in self.spider_config:
            if i['id'] + 10 == spider_title_id or i['id'] == spider_title_id:
                return i['name']

        return self._get_false_spider(ua)

    def get_uri(self, uri_id: int):
        val = self._get_field('uri_list', 'uri_list', 'uri', 'uri_id', uri_id, '/')
        if val:
            return val
        return '/'

    def get_method(self, method_id: int):
        val = self._get_field('list', 'method_list', 'method', 'method_id', method_id, '-')
        if val:
            return val
        return '-'

    def get_referer(self, referer_id: int):
        val = self._get_field('referer_list', 'referer_list', 'referer', 'referer_id', referer_id, '-')
        if val:
            return val
        return '-'

    def get_user_agent(self, user_agent_id: int):
        val = self._get_field('ua_list', 'user_agent', 'user_agent', "user_agent_id", user_agent_id, "-")
        if val:
            return val
        return '-'

    def get_host(self, host_id: int):
        val = self._get_field('list', 'host', 'host', "host_id", host_id, "-")
        if val:
            return val
        return '-'

    def get_content_type(self, content_type_id: int):
        val = self._get_field('list', 'content_type', 'content_type', "content_type_id", content_type_id, "-")
        if val:
            return val
        return '-'

    def _get_field(self,
                   db_name: str,
                   table_name: str,
                   field_name: str,
                   field_id: str,
                   field_id_value: Any,
                   default_value: Any = None) -> Optional[Any]:
        key = public.md5("{}_{}_{}_{}_{}".format(db_name, table_name, field_name, field_id, field_id_value))
        if key in self.__key_cache:
            return self.__key_cache[key]
        if not db_name or not table_name or not field_name or not field_id or not field_id_value:
            return default_value
        db_obj = self._get_sql(db_name)
        if not db_obj:
            return default_value
        find_value = db_obj.table(table_name).where('{}=?'.format(field_id), (field_id_value,)).field(field_name).find()
        if not find_value:
            find_value = dict()
        val = find_value.get(field_name, default_value)
        self.__key_cache[key] = val
        return val

    def _get_sql(self, db_name: str) -> Sql:
        """获取数据库对象"""
        if db_name in self._global_dbs:
            site_name = 'global'
        else:
            site_name = self._site_name

        db_path = self.db_path()
        if not db_path:
            return None

        db_file = "{}/{}/{}.db".format(db_path, site_name, db_name)
        if db_file in self._db_objs:
            if getattr(self._db_objs[db_file], "_Sql__DB_CONN", None):
                return self._db_objs[db_file]
        if not os.path.exists(db_file) or os.path.getsize(db_file) == 0:
            return None
        db_obj = db.Sql()
        db_obj._Sql__DB_FILE = db_file
        self._db_objs[db_file] = db_obj
        return db_obj

    def db_path(self) -> Optional[str]:
        if self._global_config is not None:
            return self._global_config["data_save_path"]
        global_config_file = os.path.join(RUN_PATH, "config", "config.json")
        try:
            tmp_data = json.loads(public.ReadFile(global_config_file))
        except:
            tmp_data = None

        if isinstance(tmp_data, dict):
            self._global_config = tmp_data
            return tmp_data["data_save_path"]
        return None

    def get_field_ids(self,
                      db_name: str,
                      table_name: str,
                      field_name: str,
                      field_id: str,
                      field_id_value: Any,
                      default_value: Any = None) -> Optional[Any]:
        if not db_name or not table_name or not field_name or not field_id or not field_id_value:
            return default_value
        key = public.md5("{}_{}_{}_{}_{}".format(db_name, table_name, field_name, field_id, field_id_value))
        if key in self.__key_cache:
            return self.__key_cache[key]
        if key in self.__key_cache:
            return self.__key_cache[key]

        db_obj = self._get_sql(db_name)
        if field_id_value.startswith('^') and field_id_value.endswith('$'):
            field_value = db_obj.table(table_name).where(
                '{} = ?'.format(field_id),
                (field_id_value[1:-1],)
            ).field(field_name).select()

        else:
            real_value = "%{}%".format(field_id_value)
            if field_id_value.startswith('^'):
                real_value = "{}%".format(field_id_value[1:])
            elif field_id_value.endswith('$'):
                real_value = "%{}".format(field_id_value[:-1])
            field_value = db_obj.table(table_name).where(
                '{} like ?'.format(field_id), (real_value,)
            ).field(field_name).select()
        print("{}_{}_{}_{}_{}".format(db_name, table_name, field_name, field_id, field_id_value), field_value)
        if not field_value:
            return default_value
        ids = [i[field_name] for i in field_value]
        return ids

    def get_url_id(self, url):
        return self.get_field_ids('uri_list', 'uri_list', 'uri_id', 'uri', url)

    def get_ua_id(self, ua):
        return self.get_field_ids('ua_list', 'user_agent', 'user_agent_id', 'user_agent', ua)

    def get_referer_id(self, referer):
        return self.get_field_ids('referer_list', 'referer_list', 'referer_id', 'referer', referer)

    def get_method_id(self, method):
        return self._get_field('list', 'method_list', 'method_id', 'method', method)

    def get_content_type_id(self, content_type):
        return self._get_field('list', 'content_type', 'content_type_id', 'content_type', content_type)

    def get_host_id(self, host):
        return self._get_field('list', 'host', 'host_id', 'host', host)

    def get_ip_id(self, ip):
        ip = ip.strip()
        if not ip:
            return None
        if public.is_ipv4(ip):
            return public.ip2long(ip)
        ip_id = self._get_field('ip_list', 'ip_list', 'ip', 'ip_id', ip)
        return ip_id

    def ip_range_from_partial(self, partial_ip: str, ip_ranges: List[int] = None):
        parts = partial_ip.split('.')
        if ip_ranges is None:
            ip_ranges = []
        # 遍历部分IP地址的每一部分
        for i in range(len(parts)):
            if parts[i] == '*':
                # 如果当前部分是 *，则尝试在该位置上进行替换
                for j in range(256):
                    # 生成替换后的IP地址
                    replaced_part = [str(j) if k == i else parts[k] for k in range(len(parts))]
                    result_ip = ".".join(replaced_part)
                    if result_ip.find('*') >= 0:
                        ip_ranges = self.ip_range_from_partial(result_ip, ip_ranges)  # 若仍有*则继续往下循环
                    else:
                        ip_ranges.append(self.get_ip_id(result_ip))  # 将ip长整型存入列表

        return ip_ranges


class ExportData:
    FILED_LIST: Tuple[str, Tuple[str, str]] = ("", ("", ""))
    EXPORT_PATH = ""

    def __init__(self, task_id: str, site_name: str, date: int, fields: List[str], params: Dict[str, str]):
        self.task_id = task_id
        self.site_name = site_name
        self.date = date
        self._fields: OrderedSet = OrderedSet()
        self._field_names = []
        self._init_export_file: bool = False
        self._csv_obj: Optional[CsvWriter] = None
        self._csv_fp: Optional[TextIO] = None
        self._db_filed = ''
        self.set_fields(fields)
        self.field_tool = FieldTool(site_name)
        self.param = params
        if self.EXPORT_PATH and not os.path.exists(self.EXPORT_PATH):
            os.makedirs(self.EXPORT_PATH)

    def set_fields(self, fields: List[str]):
        self._field_names = []
        db_filed = set()
        for k, (v, t) in self.FILED_LIST:
            if k in fields:
                self._fields.add(k)
                self._field_names.append(t)
                for i in v.split(','):
                    db_filed.add(i)
        self._db_filed = ','.join(db_filed)

    def save_progress_bar(self, now: int, count: int):
        file = "{}/{}_{}.bar".format(self.EXPORT_PATH, self.site_name, self.task_id)
        print("导出进行中， 已完成：%.2f%% （%d/%d）" % ((now / count) * 100 if count > 0 else 0, now, count))
        public.writeFile(file, "{} {}".format(now, count))

    def export(self):
        raise NotImplementedError()

    def range_timestamp(self):
        y, md = divmod(self.date, 10000)
        m, d = divmod(md, 100)
        return int(datetime(y, m, d, 0, 0, 0).timestamp()), int(datetime(y, m, d, 23, 59, 59).timestamp())

    def _init_csv(self):
        if not os.path.exists(self.EXPORT_PATH):
            os.makedirs(self.EXPORT_PATH)
        csv_file = "{}/{}_{}.csv".format(self.EXPORT_PATH, self.site_name, self.task_id)
        fp = open(csv_file, 'w+', encoding='utf-8')
        self._csv_obj = csv.writer(fp)
        self._csv_obj.writerow(self._field_names)

    def write_line(self, line: List[str]):
        if not self._init_export_file:
            self._init_export_file = True
            self._init_csv()
        self._csv_obj.writerow(line)

    def close(self):
        if self._csv_fp is not None:
            if not self._csv_fp.closed:
                self._csv_fp.close()

    def flush(self):
        if self._csv_fp is not None and not self._csv_fp.closed:
            self._csv_fp.flush()

    @staticmethod
    def get_in_param(in_param):
        if not in_param:
            return '(0)'
        if not isinstance(in_param, list):
            return '(0)'
        return '(' + ','.join([str(i) for i in in_param]) + ')'


class AccessLog(ExportData):
    PAGE_SIZE = 10000
    MAX_SIZE = 1000 * PAGE_SIZE
    EXPORT_PATH = "/www/server/panel/plugin/monitor/export"
    FILED_LIST = (
        ("request_time", ("request_time", "时间")),
        ("host", ("host_id", "域名")),
        ("ip", ("ip_id,ipv6", "IP")),
        ("area", ("ip_id,ipv6", "地区")),
        ("method", ("method_id", "类型")),
        ("status", ("status_code", "状态码")),
        ("request_take", ("request_take", "耗时")),
        ("content_type", ("content_type_id", "响应类型")),
        ("send_bytes", ("send_bytes", "发送大小")),
        ("receive_bytes", ("receive_bytes", "接收大小")),
        ("uri", ("uri_id", "URI")),
        ("referer", ("referer_id", "来路")),
        ("user_agent", ("user_agent_id", "User-Agent")),
        ("spider", ("ip_id,ipv6,is_gzip,user_agent_id", "蜘蛛")),
    )

    def build_filter_data(self) -> Tuple[str, List[Any]]:
        wheres = []
        args = []
        spider = self.param.get('spider', None)
        reverse_list = self.param.get('reverse_list', [])
        url = self.param.get('url', None)
        user_agent = self.param.get('user_agent', None)
        referer = self.param.get("referer", None)
        ip = self.param.get("ip", None)
        ip_search = self.param.get("ip_search", None)  # 新增：支持 CIDR、IPv6 等
        status = self.param.get("status", None)
        method = self.param.get("method", None)
        host = self.param.get("host", None)
        content_type = self.param.get("content_type", None)
        start_time = self.param.get("start_time", None)
        end_time = self.param.get("end_time", None)

        # 搜索指定蜘蛛 用is_gzip字段代替
        if spider:
            spider_num = int(spider)
            # -1 仅显示蜘蛛 -2 不显示蜘蛛
            # 避免使用 is_gzip=0 这个会使用access_log_is_gzip索引，但是蜘蛛为0的数据太多，此时使用索引会导致查询速度变慢
            if spider_num < 0:
                reverse_spider = "spider" in reverse_list
                show_spider = (spider_num == -1 and not reverse_spider) or (spider_num == -2 and reverse_spider)
                if show_spider:
                    wheres.append('is_gzip !=?')
                    args.append(0)
                else:
                    spider_ids = [1000] + list(range(10, 20))
                    wheres.append('is_gzip NOT IN ({})'.format(','.join(map(str, spider_ids))))

            # 0 不过滤（默认全部显示）
            elif spider_num == 0:
                pass
            # 显示单独蜘蛛
            else:
                args.append(spider_num)
                if "spider" in reverse_list:
                    wheres.append('is_gzip!=?')
                else:
                    wheres.append('is_gzip=?')
        if url:
            url_ids = self.field_tool.get_url_id(url)
            param = self.get_in_param(url_ids)
            if "url" in reverse_list:
                wheres.append('uri_id NOT IN {}'.format(param))
            else:
                wheres.append('uri_id IN {}'.format(param))

        if user_agent:
            user_agent_ids = self.field_tool.get_ua_id(user_agent)
            param = self.get_in_param(user_agent_ids)
            if "user_agent" in reverse_list:
                wheres.append('user_agent_id NOT IN {}'.format(param))
            else:
                wheres.append('user_agent_id IN {}'.format(param))
        if referer:
            referer_ids = self.field_tool.get_referer_id(referer)
            param = self.get_in_param(referer_ids)
            if "referer" in reverse_list:
                wheres.append('referer_id NOT IN {}'.format(param))
            else:
                wheres.append('referer_id IN {}'.format(param))

        # 使用 ip_search 参数（支持 CIDR、IPv6 等）
        if ip_search:
            # 处理精确 IPv4 列表
            if ip_search.get('ipv4_list', []):
                tmp_list = ip_search['ipv4_list']
                if "ip" in reverse_list:
                    wheres.append('ip_id NOT IN {}'.format(self.get_in_param(tmp_list)))
                else:
                    wheres.append('ip_id IN {}'.format(self.get_in_param(tmp_list)))

            # 处理 IPv4 范围列表（CIDR、通配符、部分 IP）
            for ip_range in ip_search.get('ipv4_range_list', []):
                start_ip = ip_range['start']
                end_ip = ip_range['end']
                range_size = end_ip - start_ip + 1

                if range_size > 10000:
                    # 使用范围查询（避免展开大量 IP）
                    if "ip" in reverse_list:
                        wheres.append('(ip_id < ? OR ip_id > ?)')
                        args.extend([start_ip, end_ip])
                    else:
                        wheres.append('(ip_id >= ? AND ip_id <= ?)')
                        args.extend([start_ip, end_ip])
                else:
                    # 展开为列表
                    tmp_list = list(range(start_ip, end_ip + 1))
                    if "ip" in reverse_list:
                        wheres.append('ip_id NOT IN {}'.format(self.get_in_param(tmp_list)))
                    else:
                        wheres.append('ip_id IN {}'.format(self.get_in_param(tmp_list)))

            # 处理 IPv6 列表
            if ip_search.get('ipv6_list', []):
                for ipv6 in ip_search['ipv6_list']:
                    ip_id = self.field_tool.get_ip_id(ipv6)
                    if "ip" in reverse_list:
                        wheres.append('ip_id!=?')
                    else:
                        wheres.append('ip_id=?')
                    args.append(ip_id)

        # 保留原有逻辑作为兼容（当没有 ip_search 时使用）
        elif ip:
            ip = ip.replace("，", ",")  # 替换中文逗号
            # 逗号分隔的情况
            if ip.find(',') >= 0:
                tmp_ip_list = ip.split(",")  # 用逗号分隔开
                tmp_ipid_list = [self.field_tool.get_ip_id(ip1) for ip1 in tmp_ip_list]
                if "ip" in reverse_list:
                    wheres.append('ip_id NOT IN {}'.format(self.get_in_param(tmp_ipid_list)))
                else:
                    wheres.append('ip_id IN {}'.format(self.get_in_param(tmp_ipid_list)))

            # *通配符的情况（目前仅支持ipv4）
            elif ip.find('*') >= 0:
                tmp_ipid_list = self.field_tool.ip_range_from_partial(ip)
                param = self.get_in_param(tmp_ipid_list)
                if "ip" in reverse_list:
                    wheres.append('ip_id NOT IN {}'.format(param))
                else:
                    wheres.append('ip_id IN {}'.format(param))
            # 通常情况
            else:
                ip_id = self.field_tool.get_ip_id(ip)
                args.append(ip_id)
                if "ip" in reverse_list:
                    wheres.append('ip_id!=?')
                else:
                    wheres.append('ip_id=?')
        if status:
            args.append(status)
            if "status" in reverse_list:
                wheres.append('status_code!=?')
            else:
                wheres.append('status_code=?')
        if method:
            args.append(self.field_tool.get_method_id(method.upper()))
            if "method" in reverse_list:
                wheres.append('method_id!=?')
            else:
                wheres.append('method_id=?')
        if host:
            args.append(self.field_tool.get_host_id(host))
            if "host" in reverse_list:
                wheres.append('host_id!=?')
            else:
                wheres.append('host_id=?')
        if content_type:
            args.append(self.field_tool.get_content_type_id(content_type))
            if "content_type" in reverse_list:
                wheres.append('content_type_id!=?')
            else:
                wheres.append('content_type_id=?')
        if start_time:
            wheres.append('request_time>=?')
            args.append(start_time)
        if end_time:
            wheres.append('request_time<=?')
            args.append(end_time)

        if not (start_time and end_time):
            wheres.append('request_time > ? AND request_time < ?')
            args.extend(self.range_timestamp())

        return " AND ".join(wheres), args

    def get_target_target_date(self):
        start_time = self.param.get("start_time", None)
        end_time = self.param.get("end_time", None)
        if start_time and end_time:
            return start_time, end_time
        return [self.date, self.date]

    def _export_num(self, db_obj: SSqlite, start: int, num: int):
        data = db_obj.limit(start, num).select()
        for i in data:
            if 'ip' in self._fields or 'area' in self._fields or "spider" in self._fields:
                i['ip'] = self.field_tool.get_ip(i['ip_id'], i["ipv6"])
            if 'area' in self._fields:
                i['area'] = self.field_tool.get_area(i['ip'])
            if 'user_agent' in self._fields or "spider" in self._fields:
                i['user_agent'] = self.field_tool.get_user_agent(i['user_agent_id'])
            if 'spider' in self._fields:
                i['spider'] = self.field_tool.get_spider_title(i['ip_id'], i['is_gzip'], i["user_agent"])
            if 'uri' in self._fields:
                i['uri'] = self.field_tool.get_uri(i['uri_id'])
            if 'referer' in self._fields:
                i['referer'] = self.field_tool.get_referer(i['referer_id'])
            if 'content_type' in self._fields:
                i['content_type'] = self.field_tool.get_content_type(i['content_type_id'])
            if 'status' in self._fields:
                i['status'] = i['status_code']
            if 'method' in self._fields:
                i['method'] = self.field_tool.get_method(i['method_id'])
            if 'host' in self._fields:
                i['host'] = self.field_tool.get_host(i['host_id'])
            i['request_time'] = public.format_date('%Y-%m-%d %H:%M:%S', i['request_time'])
            self.write_line([i[j] for j in self._fields])

    def export(self):
        base_db_path = self.field_tool.db_path()
        if not os.path.exists(base_db_path):
            print("无日志数据")
            self.write_line(["无日志数据"])
            self.close()
            return
        db_path = "{}/{}".format(base_db_path, self.site_name)
        db_obj = SSqlite(db_path, "access", self.get_target_target_date(), smart_default=True)
        where, args = self.build_filter_data()
        db_obj = db_obj.table('access_log').where(where, args).order("request_time", "DESC")
        count = sum(db_obj.count().values())
        if count == 0:
            print("无日志数据")
            self.save_progress_bar(0, 0)
            self.write_line(["无日志数据"])
            self.close()
            return
        ep_count = min(count, self.MAX_SIZE)
        for i in range(0, ep_count, self.PAGE_SIZE):
            self._export_num(db_obj, i, min(self.PAGE_SIZE, ep_count - i))
            self.save_progress_bar(i, ep_count)
            self.flush()
        self.close()
        self.save_progress_bar(ep_count, ep_count)


class SlowLog(ExportData):
    PAGE_SIZE = 10000
    MAX_SIZE = 1000 * PAGE_SIZE
    EXPORT_PATH = "/www/server/panel/plugin/monitor/export_slow"
    FILED_LIST = (
        ("request_time", ("request_time", "请求时间")),
        ("date", ("date", "日期")),
        ("ip", ("ip_id,ipv6", "IP")),
        ("area", ("ip_id,ipv6", "地区")),
        ("method", ("method_id", "类型")),
        ("status", ("status_code", "状态码")),
        ("request_take", ("request_take", "耗时")),
        ("uri", ("uri_id", "URI")),
    )

    def build_filter_data(self) -> Tuple[str, List[Any]]:
        wheres = []
        args = []
        url = self.param.get('url', None)
        ip = self.param.get("ip", None)
        date = self.param.get("date", None)
        status = self.param.get("status", None)
        method = self.param.get("method", None)
        start_time = self.param.get("start_time", None)
        end_time = self.param.get("end_time", None)
        request_take_less = self.param.get("request_take_less", None)
        request_take_greater = self.param.get("request_take_greater", None)

        if date:
            wheres.append('date=?')
            args.append(date)

        if request_take_less:
            wheres.append('request_time<=?')
            args.append(request_take_less)

        if request_take_greater:
            wheres.append('request_time>=?')
            args.append(request_take_greater)

        if url:
            url_ids = self.field_tool.get_url_id(url)
            param = self.get_in_param(url_ids)
            wheres.append('uri_id IN {}'.format(param))

        if ip:
            ip = ip.replace("，", ",")  # 替换中文逗号
            # 逗号分隔的情况
            if ip.find(',') >= 0:
                tmp_ip_list = ip.split(",")  # 用逗号分隔开
                tmp_ipid_list = [self.field_tool.get_ip_id(ip1) for ip1 in tmp_ip_list]
                wheres.append('ip_id IN {}'.format(self.get_in_param(tmp_ipid_list)))

            # *通配符的情况（目前仅支持ipv4）
            elif ip.find('*') >= 0:
                tmp_ipid_list = self.field_tool.ip_range_from_partial(ip)
                param = self.get_in_param(tmp_ipid_list)
                wheres.append('ip_id IN {}'.format(param))
            # 通常情况
            else:
                ip_id = self.field_tool.get_ip_id(ip)
                args.append(ip_id)
                wheres.append('ip_id=?')

        if status:
            args.append(status)
            wheres.append('status_code=?')

        if method:
            args.append(self.field_tool.get_method_id(method.upper()))
            wheres.append('method_id=?')

        if end_time:
            wheres.append('request_time<=?')
            args.append(end_time)

        if start_time:
            wheres.append('request_time>=?')
            args.append(start_time)

        if not (start_time and end_time):
            wheres.append('request_time > ? AND request_time < ?')
            args.extend(self.range_timestamp())

        return " AND ".join(wheres), args

    def get_target_target_date(self):
        start_time = self.param.get("start_time", None)
        end_time = self.param.get("end_time", None)
        if start_time and end_time:
            return start_time, end_time
        return [self.date, self.date]

    def export(self):
        base_db_path = self.field_tool.db_path()
        if not os.path.exists(base_db_path):
            print("无日志数据")
            self.write_line(["无日志数据"])
            self.close()
            return
        db_path = "{}/{}".format(base_db_path, self.site_name)
        db_obj = SSqlite(db_path, "slow", [0,0], smart_default=True)
        where, args = self.build_filter_data()
        db_obj = db_obj.table('slow_request').where(where, args).order("request_time", "DESC")
        count = sum(db_obj.count().values())
        if count == 0:
            print("无日志数据")
            self.save_progress_bar(0, 0)
            self.write_line(["无日志数据"])
            self.close()
            return
        ep_count = min(self.MAX_SIZE, count)
        for i in range(0, ep_count, self.PAGE_SIZE):
            self._sub_export_num(db_obj, i, min(self.PAGE_SIZE, ep_count - i))
            self.save_progress_bar(i, ep_count)
            self.flush()
        self.close()
        self.save_progress_bar(ep_count, ep_count)

    def _sub_export_num(self, db_obj, start, num):
        data = db_obj.limit(start, num).select()
        for i in data:
            if 'ip' in self._fields or 'area' in self._fields:
                i['ip'] = self.field_tool.get_ip(i['ip_id'], i["ipv6"])
            if 'area' in self._fields:
                i['area'] = self.field_tool.get_area(i['ip'])
            if 'uri' in self._fields:
                i['uri'] = self.field_tool.get_uri(i['uri_id'])
            if 'status' in self._fields:
                i['status'] = i['status_code']
            if 'method' in self._fields:
                i['method'] = self.field_tool.get_method(i['method_id'])
            i['request_time'] = public.format_date('%Y-%m-%d %H:%M:%S', i['request_time'])
            self.write_line([i[j] for j in self._fields])


class Main(object):
    EP_TYPE2CLASS: Dict[str, Type[ExportData]] = {
        "access": AccessLog,
        "slow": SlowLog,
    }
    RUNNING_LOCK_FILE = "/www/server/panel/plugin/monitor/export_running.lock"

    def __init__(self, input_args: List[str]):
        self.input_args = input_args
        if len(self.input_args) not in (1, 6):
            raise ValueError("参数错误")
        if len(self.input_args) == 1:
            self.args_dict = self.decode_args()
        if len(self.input_args) == 5:
            self.args_dict = {
                "ep_type": self.input_args[0],
                "task_id": self.input_args[1],
                "site_name": self.input_args[2],
                "date": int(self.input_args[3]),
                "fields": self.input_args[4].split(','),
                "params": json.loads(self.input_args[5])
            }
        if not os.path.exists(self.RUNNING_LOCK_FILE):
            public.writeFile(self.RUNNING_LOCK_FILE, "")
        else:
            raise ValueError("有其他导出任务正在进行，请勿同时导出多个数据")

    # 解码参数
    def decode_args(self) -> Optional[dict]:
        import base64
        data = base64.b64decode(self.input_args[0]).decode("utf-8")
        try:
            res = json.loads(data)
        except:
            return None
        if isinstance(res, dict):
            for i in ("ep_type", "task_id", "site_name", "date", "fields", "params"):
                if i not in res:
                    print("参数缺失{}".format(i))
                    return None
            return res
        return None

    def __call__(self):
        if self.args_dict is None:
            print("参数错误")
            return
        if self.args_dict["ep_type"] not in self.EP_TYPE2CLASS:
            print("未知导出类型")
            return
        try:
            self.EP_TYPE2CLASS[self.args_dict["ep_type"]](
                task_id=self.args_dict["task_id"],
                site_name=self.args_dict["site_name"],
                date=self.args_dict["date"],
                fields=self.args_dict["fields"],
                params=self.args_dict["params"]
            ).export()
            print("导出成功")
        except:
            print("导出失败")
            error = traceback.format_exc()
            print(error)


if __name__ == '__main__':
    try:
        Main(sys.argv[1:])()
    except:
        traceback.print_exc()
        print("导出失败")
    finally:
        if os.path.exists(Main.RUNNING_LOCK_FILE):
            os.remove(Main.RUNNING_LOCK_FILE)
