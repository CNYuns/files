-- 蜘蛛IP地址列表
CREATE TABLE IF NOT EXISTS `spider_ip_list` (
    `spider_ip_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `ip_id` INTEGER DEFAULT 0, -- ip地址（int）
    `spider_title_id` INTEGER DEFAULT 0  -- 爬虫标题ID 1=百度,2=Google,3=360,4=搜狗,5=雅虎,6=必应,7=头条,8=Yandex,9=神马
);

-- 增加唯一索引
CREATE UNIQUE INDEX IF NOT EXISTS `idx_ip_id` ON `spider_ip_list` (`ip_id`);