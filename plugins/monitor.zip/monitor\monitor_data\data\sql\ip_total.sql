-- IP访问统计表
CREATE TABLE IF NOT EXISTS `ip_total` (
    `ipt_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `date` INTEGER DEFAULT 0,
    `ip_id` INTEGER DEFAULT 0,
    `ipv6`  INTEGER DEFAULT 0,
    `send_bytes` INTEGER DEFAULT 0,
    `receive_bytes` INTEGER DEFAULT 0,
    `request` INTEGER DEFAULT 0
);


-- 创建索引
CREATE INDEX IF NOT EXISTS `idx_date_ipid` ON `ip_total` (`date`,`ip_id`);
CREATE INDEX IF NOT EXISTS `idx_date_request` ON `ip_total` (`date`, `request`);