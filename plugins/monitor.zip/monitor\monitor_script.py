# conding:utf-8
# 监控报表用与执行某些任务的脚本
# 1.数据迁移脚本
# 2.周报月报生成
import json
import os
import pwd
import shutil
import stat
import sys
import time
import traceback
from datetime import datetime, timedelta
from typing import Optional, TextIO, Union

import psutil

# 添加项目根目录到环境变量
os.chdir("/www/server/panel")
if "/www/server/panel/class" not in sys.path:
    sys.path.insert(0, "/www/server/panel/class")

if "/www/server/panel" not in sys.path:
    sys.path.insert(0, "/www/server/panel")

if "/www/server/panel/plugin/monitor" not in sys.path:
    sys.path.insert(0, "/www/server/panel/plugin/monitor")
elif not sys.path.index("/www/server/panel/plugin/monitor") == 0:
    sys.path.remove("/www/server/panel/plugin/monitor")
    sys.path.insert(0, "/www/server/panel/plugin/monitor")

import monitor_report

monitor_report.GENERATE_BY = "Auto"

import public

DEBUG = True


def get_mail_class():
    try:
        if "/www/server/panel" not in sys.path:
            sys.path.insert(0, "/www/server/panel")

        import smtplib
        from email.mime.text import MIMEText
        from email.mime.base import MIMEBase
        from email.mime.multipart import MIMEMultipart
        from email.utils import formataddr
        from email.encoders import encode_base64
        from mod.base.msg import MailMsg, SenderConfig
        from mod.base.msg.util import write_push_log, write_mail_push_log
        from mod.base.push_mod.system import get_push_public_data

        class NewMailMsg(MailMsg):

            @staticmethod
            def get_push_public_data() -> dict:
                return get_push_public_data()

            def send_msg_with_attachment(self, msg: str, title: str, attachment_paths: list):
                """
                邮箱发送带附件
                @msg 消息正文
                @title 消息标题
                @attachment_paths 附件路径列表
                """
                if not self.config:
                    return '未正确配置邮箱信息。'

                if 'port' not in self.config['send']:
                    self.config['send']['port'] = 465

                receive_list = self.config['receive']

                error_list, success_list = [], []
                error_msg_dict = {}
                for email in receive_list:
                    if not email.strip():
                        continue
                    try:
                        # 创建 MIMEMultipart 对象
                        message = MIMEMultipart()
                        message['From'] = formataddr((self.config['send']['qq_mail'], self.config['send']['qq_mail']))
                        message['To'] = formataddr((self.config['send']['qq_mail'], email.strip()))
                        message['Subject'] = title

                        # 添加消息正文
                        message.attach(MIMEText(msg, 'html', 'utf-8'))

                        # 添加附件
                        for attachment_path in attachment_paths:
                            with open(attachment_path, 'rb') as attachment:
                                part = MIMEBase('application', 'octet-stream')
                                part.set_payload(attachment.read())
                                encode_base64(part)
                                part.add_header(
                                    'Content-Disposition',
                                    'attachment; filename={}'.format(os.path.basename(attachment_path))
                                )
                                message.attach(part)

                        # 发送邮件
                        if int(self.config['send']['port']) == 465:
                            server = smtplib.SMTP_SSL(str(self.config['send']['hosts']),
                                                      int(self.config['send']['port']))
                        else:
                            server = smtplib.SMTP(str(self.config['send']['hosts']), int(self.config['send']['port']))

                        server.login(self.config['send']['qq_mail'], self.config['send']['qq_stmp_pwd'])
                        server.sendmail(self.config['send']['qq_mail'], [email.strip(), ], message.as_string())
                        server.quit()
                        success_list.append(email)
                    except:
                        print(traceback.format_exc())
                        error_list.append(email)
                        error_msg_dict[email] = traceback.format_exc()

                if not error_list and not success_list:  # 没有接收者
                    return "未配置接收邮箱"
                if not error_list:
                    write_push_log("邮箱", True, title, success_list)  # 没有失败
                    return True
                if not success_list:
                    write_push_log("邮箱", False, title, error_list)  # 全都失败
                    return "发送信息失败, 发送失败的接收人：{}".format(error_list)
                write_mail_push_log(title, error_list, success_list)

                return "发送邮件到部分接收者时失败，包含：{}".format(error_list)

        return NewMailMsg, SenderConfig
    except Exception as e:
        print(traceback.format_exc())
        return None, None


class DataMover(object):
    run_path = "/www/server/monitor"
    plugin_path = "/www/server/panel/plugin/monitor"

    def __init__(self, old_path: str, new_path: str):
        self.old_path = old_path
        self.new_path = new_path
        self._log_fp: Optional[TextIO] = None
        self._run_user: Optional[pwd.struct_passwd] = None

    def change_global_config(self) -> bool:
        conf_file = os.path.join(self.run_path, "config", "config.json")
        try:
            conf = json.loads(public.readFile(conf_file))
        except Exception as e:
            self.write_log("修改配置文件失败: {}".format(e))
            return False

        if not isinstance(conf, dict):
            return False

        conf["data_save_path"] = self.new_path.rstrip("/")
        public.writeFile(conf_file, json.dumps(conf))
        return True

    @property
    def run_user(self) -> Optional[pwd.struct_passwd]:
        if self._run_user:
            return self._run_user
        try:
            self._run_user = pwd.getpwnam("bt-monitor")
            return self._run_user
        except KeyError:
            return None

    @property
    def log_fp(self) -> TextIO:
        if not self._log_fp:
            log_file = "{}/data_move.log".format(self.plugin_path)
            self._log_fp = open(log_file, "w+", encoding="utf-8")
        return self._log_fp

    @classmethod
    def stop_monitor(cls):
        public.ExecShell("systemctl stop monitor")
        time.sleep(0.5)
        if os.path.exists("{}/monitor.pid".format(cls.run_path)):
            pid = public.readFile("{}/monitor.pid".format(cls.run_path))
            try:
                p = psutil.Process(int(pid))
            except:
                return
            if p.is_running():
                p.terminate()

    @classmethod
    def start_monitor(cls):
        public.ExecShell("systemctl start monitor")
        time.sleep(0.5)
        if not os.path.exists("{}/monitor.pid".format(cls.run_path)):
            running = False
        else:
            pid = public.readFile("{}/monitor.pid".format(cls.run_path))
            try:
                p = psutil.Process(int(pid))
                running = p.is_running()
            except:
                running = False

        if not running and cls.not_systemd():
            public.ExecShell("cd {path} && nohup {path}/monitor &> /dev/null &".format(path=cls.run_path))
            time.sleep(0.2)

    @staticmethod
    def not_systemd() -> bool:
        res = public.readFile("/proc/1/comm")
        if isinstance(res, str) and res.strip() == "systemd":
            return False
        return True

    def write_log(self, msg: str):
        if not msg.endswith("\n"):
            msg += "\n"
        if DEBUG:
            print(msg, end="")

        self.log_fp.write(msg)
        self.log_fp.flush()

    def collect_data(self) -> Union[dict, str]:
        if not os.path.isdir(self.old_path):
            return "数据目录不存在"
        res = {
            "files": [],
            "total_size": 0,
        }
        for root, dirs, files in os.walk(self.old_path):
            for file in files:
                file_path = os.path.join(root, file)
                file_size = os.path.getsize(file_path)
                res["total_size"] += file_size
                res["files"].append({
                    "path": file_path.replace(self.old_path, "").lstrip("/"),
                    "full_path": file_path,
                    "size": file_size
                })
        return res

    def check_free_space(self, total_size: int) -> Optional[str]:
        disk_info = psutil.disk_usage(self.new_path)
        if disk_info.free < total_size + 1024 * 1024 * 100:
            return "目标目录剩余磁盘空间不足, 迁移任务失败."
        return None

    def set_permissions(self, path: str):
        if os.path.isdir(path):
            os.chown(path, self.run_user.pw_uid, self.run_user.pw_gid)
            os.chmod(path, 0o700)
        if os.path.isfile(path):
            os.chown(path, self.run_user.pw_uid, self.run_user.pw_gid)
            os.chmod(path, 0o600)

    def write_progress_bar(self,
                           total: int,
                           current: int,
                           file_total: int,
                           file_current: int,
                           file_name: str = None,
                           file_size: int = None):
        percent = "{:.2f}".format(100 * (current / float(total)))
        filled_length = int(current * 50 // total)
        bar = "[{}{}{}] {}% (文件: {}/{}) {}".format(
            "=" * filled_length,
            ">" if filled_length < 50 else "",
            "-" * (50 - filled_length - 1),
            percent,
            file_current,
            file_total,
            "当前文件：{}({:.2f}MB)".format(file_name, file_size / 1024 / 1024) if file_name else "",
        )
        if DEBUG:
            print(bar)
        self.log_fp.write(bar + "\n")
        self.log_fp.flush()

    # 保障新的路径可以被bt-monitor用户访问
    def set_new_path_accessed(self):
        path_node = os.path.dirname(self.new_path)
        while path_node != "/":
            path_dir_stat = os.stat(path_node)
            if path_dir_stat.st_uid == 0:
                old_mod = stat.S_IMODE(path_dir_stat.st_mode)
                if not old_mod & (1 << 3):
                    os.chmod(path_node, old_mod + (1 << 3))  # chmod g+x
            if path_dir_stat.st_uid == self.run_user.pw_uid:
                old_mod = stat.S_IMODE(path_dir_stat.st_mode)
                if not old_mod & (1 << 6):
                    os.chmod(path_node, old_mod + (1 << 6))  # chmod u+x
            elif path_dir_stat.st_gid == self.run_user.pw_gid:
                old_mod = stat.S_IMODE(path_dir_stat.st_mode)
                if not old_mod & (1 << 3):
                    os.chmod(path_node, old_mod + (1 << 6))  # chmod g+x
            elif path_dir_stat.st_uid != self.run_user.pw_uid or path_dir_stat.st_gid != self.run_user.pw_gid:
                old_mod = stat.S_IMODE(path_dir_stat.st_mode)
                if not old_mod & 1:
                    os.chmod(path_node, old_mod + 1)  # chmod o+x
            path_node = os.path.dirname(path_node)

    def move_data(self):
        self.write_log("开始执行数据迁移任务...")
        if not os.path.isdir(self.new_path):
            self.write_log("目标目录不存在, 迁移任务失败.")
            return
        else:
            # 保障新的路径可以被bt-monitor用户访问
            self.set_new_path_accessed()
            self.set_permissions(self.new_path)
        if not os.path.isdir(self.old_path):
            self.write_log("数据目录不存在, 迁移任务失败.")
            return
        if not self.run_user:
            self.write_log("无法获取监控服务运行用户, 迁移任务失败.")
            return

        self.stop_monitor()
        self.write_log("日志收集服务已停止.")
        self.write_log("开始收集数据")
        data = self.collect_data()
        if isinstance(data, str):
            self.write_log("数据收集失败: {}".format(data))
            return
        total_size = data["total_size"]
        total_file = len(data["files"])
        self.write_log(
            "数据收集完成, 共收集到 {} 个文件, 总大小 {:.2f} MB".format(total_file, total_size / 1024 / 1024))

        self.write_log("开始迁移数据...")
        current_size = 0
        for i, file in enumerate(data["files"]):
            self.write_progress_bar(total_size, current_size, total_file, i + 1, file['path'], file["size"])
            target_path = "{}/{}".format(self.new_path, file["path"])
            if not os.path.isdir(os.path.dirname(target_path)):
                os.makedirs(os.path.dirname(target_path))
                self.set_permissions(os.path.dirname(target_path))
            try:
                shutil.copyfile(file["full_path"], target_path)
            except Exception as e:
                self.write_log("文件 {} 迁移失败: {}".format(file["path"], str(e)))
                self.clear_err_data()
                self.start_monitor()
                return
            current_size += file["size"]
            self.set_permissions(target_path)

        self.write_progress_bar(total_size, current_size, total_file, len(data["files"]))

        self.write_log("数据迁移完成")
        if not self.change_global_config():
            self.write_log("修改配置文件失败.")
            return
        self.clear_old_data()
        self.start_monitor()
        self.write_log("日志收集服务已启动.")
        self.write_log("数据迁移任务完成.")

    @staticmethod
    def _clear_data(dir_name: str):
        """删除目录下的所有文件和子目录，保留顶层目录"""
        if not os.path.isdir(dir_name):
            return
        for root, dirs, files in os.walk(dir_name, topdown=False):
            for file in files:
                os.remove(os.path.join(root, file))
            for d in dirs:
                os.rmdir(os.path.join(root, d))

    def clear_err_data(self):
        return self._clear_data(self.new_path)

    def clear_old_data(self):
        return self._clear_data(self.old_path)

    def run(self):
        return self.move_data()


class ReportCrontab(object):
    _TYPE2NAME = {
        "day": "日",
        "week": "周",
        "month": "月",
    }

    def __init__(self):
        self.rm = monitor_report.ReportManager()
        mail_cls, msg_conf = get_mail_class()
        self.mail_cls = mail_cls
        self.msg_conf = msg_conf

    def run(self):
        tasks = self.rm.get_need_generate_tasks()
        if not tasks:
            print("未查询到待生成的任务")
            return
        for task in tasks:
            tmp_date = (datetime.fromtimestamp(task["next_generate_time"]) - timedelta(days=1)).date()
            task_name = "网站[{}]{}报生成任务({})".format(
                task["site_name"], self._TYPE2NAME[task["part_type"]], tmp_date.strftime("%Y-%m-%d")
            )
            if self.rm.results_exist(task["site_name"], task["part_type"], task["next_generate_time"], generate_by=0):
                print("{}已存在生成记录，跳过".format(task_name))
                self.rm.update_next_next_generate_time(task["id"], task["part_type"])
                continue
            print("开始执行{}".format(task_name))
            if task["part_type"] == "day":
                report = monitor_report.day_report(task["site_name"], tmp_date)
            elif task["part_type"] == "week":
                report = monitor_report.week_report(task["site_name"], tmp_date)
            else:
                report = monitor_report.month_report(task["site_name"], tmp_date)

            report.set_call_log(print)
            res = report.export_pdf()
            if res:
                send_status = 0
                if task["email"]:
                    send_status = self.send_mail(task["email"], report)
                self.rm.add_results(report, send_status)
                self.rm.update_next_next_generate_time(task["id"], task["part_type"])
            else:
                print("{}生成失败".format(report.title))

        del self.rm

    def send_mail(self, email_id: str, report: monitor_report.Report) -> int:
        if not self.mail_cls or not self.msg_conf:
            print("加载邮件发送通道失败，请保障为最新面板")
            return 2
        try:
            tmp_conf = self.msg_conf().get_by_id(email_id)
            if not tmp_conf:
                print("邮件配置加载失败")
                return 2
            email_obj = self.mail_cls(tmp_conf)
            push_public_data = email_obj.get_push_public_data()
            msg_list = [
                "监控报表-网站报告: {}".format(report.title),
                "服务器：" + push_public_data['server_name'],
                "IP地址：{}(外) {}(内)".format(push_public_data['ip'], push_public_data['local_ip']),
                "发送时间：" + push_public_data['time'],
                "数据源时间范围：" + report.time_range,
                "报告详情请查看附件！"
            ]
            msg = "<br>".join(msg_list)
            res = email_obj.send_msg_with_attachment(
                msg, report.title, [os.path.join(report.REPORT_PATH, report.export_filename)]
            )
            if res is True:
                print("邮件发送成功")
                return 1
            print("邮件发送失败: {}".format(str(res)))
            return 2
        except Exception as e:
            print(traceback.format_exc())
            print("邮件发送失败: {}".format(str(e)))
            return 2


def main(action: str, *args):
    if action == "move_data":
        return DataMover(*args).run()
    elif action == "report":
        return ReportCrontab().run()
    else:
        print("Unknown action: {}".format(action))


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python3 monitor_script.py <action> <args>")
        exit(1)

    main(sys.argv[1], *sys.argv[2:])




