// -------------------------------------------------------------------
// 宝塔Linux面板
// -------------------------------------------------------------------
// Copyright (c) 2015-2024 宝塔软件(http://bt.cn) All rights reserved.
// -------------------------------------------------------------------
// Author: hwliang <hwl@bt.cn>
// -------------------------------------------------------------------
#define UNIXSERVER_H
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/epoll.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <string>
#include <vector>
#include <fcntl.h>

using namespace std;
#define SOCK_FILE "/www/server/monitor/ip_filter.sock"
#define MAX_EVENTS 1000

struct pack_header{
    char h1;
    char h2;
    unsigned short type;
    unsigned short length;
};

class epoll_server{
    private:
        int sock;
        int epoll_fd;
        struct sockaddr_un addr;
        struct epoll_event ev;
        struct epoll_event events[MAX_EVENTS];
        int get_header(int fd,unsigned short *action_type,unsigned short *data_length);
        void hand_event(int fd);
        void new_event();
        void goto_event(int fd,int action_type,string data);
        void ipset_admin_event(int fd,int action_type,string data);
        void log_supervisor_event(int fd,int action_type,string data);
        void other_event(int fd,int action_type,string data);
    public:
        int create_socket();
        int create_epoll();
        int run();
        int start();
        int close_fd(int fd);
};


class ipset_admin{
    public:
        ipset_admin();
        ~ipset_admin();
        /**
         * @brief 创建ipset
         * @param fd <int> socket句柄
         * @param data <string> 数据 格式要求: name|hash|hashsize|maxelem|timeout|ports|protocol
         *      name  <string> ipset集合名称
         *      hash  <string> hash类型 支持：ip 或 ip,port 或 net
         *      hashsize  <int> 初始化大小
         *      maxelem  <int> 最大元素数量
         *      timeout  <int> 元素最大超时时间
         *      ports  <string> 目标端口号（在protocol=tcp或udp时有效）,多个端口号用逗号分隔
         *      protocol  <string> 协议类型 支持：tcp/udp/icmp/all
         * @return string 0.失败 1.成功
         */
        string create_ipset(string data);

        /**
         * @brief 删除ipset
         * @param data <string> 数据 格式要求: name|ports|protocol
         *      name  <string> ipset集合名称
         *      ports  <string> 目标端口号（在protocol=tcp或udp时有效）,多个端口号用逗号分隔
         *      protocol  <string> 协议类型 支持：tcp/udp/icmp/all
         * @return string 0.失败 1.成功
         */
        string delete_ipset(string data);

        /**
         * @brief 添加ip到ipset集合
         * @param data <string> 数据 格式要求: name|ip|port|timeout
         *      name  <string> ipset集合名称
         *      ip  <string> ip地址
         *      port  <int> 目标端口号 （在hash=ip,port时有意义）
         *      timeout  <int> 元素超时时间 （0=长期有效，最大不超过2073600）
         * @return string  0.失败 1.成功
         */
        string add_to_collection(string data);
        /**
         * @brief 从ipset集合中删除ip
         * @param data <string> 数据 格式要求: name|ip|port
         *      name  <string> ipset集合名称
         *      ip  <string> ip地址
         *      port  <int> 目标端口号 （在hash=ip,port时有意义）
         * @return string 0.失败 1.成功
         */
        string del_from_collection(string data);

        /**
         * @brief 获取ipset集合中的ip数量
         * @param data <string> 数据 格式要求: name
         *       name  <string> ipset集合名称
         * @return string 
         */
        string get_collection_count(string data);

        /**
         * @brief 获取ipset集合列表
         * @param data <string> 数据 空字符串
         * @return string
         */
        string get_collection_list(string data);

        /**
         * @brief 获取ipset集合中的ip列表
         * @param data <string> 数据 格式要求: name
         *      name  <string> ipset集合名称
         * @return string
         */
        string get_collection_element_list(string data);

        /**
         * @brief 获取ipset集合中的ip超时时间
         * @param data <string> 数据 格式要求: name|ip|port
         *      name  <string> ipset集合名称
         *      ip  <string> ip地址
         *      port  <int> 目标端口号 （在hash=ip,port时有意义）
         * @return string 
         */
        string get_collection_element_timeout(string data);

        /**
         * @brief 清空ipset集合
         * @param data <string> 数据 格式要求: name
         *      name  <string> ipset集合名称
         * @return string 0.失败 1.成功
         */
        string flush_collection(string data);

        /**
         * @brief 获取已配置iptables的集合列表
         * @param data <string> 数据 空字符串
         * @return string 
         */
        string get_iptables_collection_list(string data);

        /**
         * @brief 检查协议是否支持
         * @param data <string> 数据 格式要求: protocol
         * @return string 0.不支持 1.支持
         */
        string check_protocol(string data);

        /**
         * @brief 添加waf ip
         * @param data <string> 数据 格式要求: ip|timeout
         * @return string 0.失败 1.成功
         */
        string add_waf_ip(string data);

        /**
         * @brief 删除waf ip
         * @param data <string> 数据 格式要求: ip
         * @return string 0.失败 1.成功
         */
        string del_waf_ip(string data);

        /**
         * @brief 更新waf ip
         * @param data <string> 数据 格式要求: ip|timeout
         * @return string 0.失败 1.成功
         */
        string update_waf_ip(string data);
    private:
        ipset_manager *ipset_manager_obj;
};



