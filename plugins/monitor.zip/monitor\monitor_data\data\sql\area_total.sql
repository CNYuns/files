-- 地区统计表
CREATE TABLE IF NOT EXISTS `area_total` (
    `area_total_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `date` INTEGER DEFAULT 0,                       -- 日期 20190101
    `country_area_id` INTEGER DEFAULT 0,            -- 国家ID
    `province_area_id` INTEGER DEFAULT 0,           -- 省份ID
    `city_area_id` INTEGER DEFAULT 0,               -- 城市ID
    `sent_bytes` INTEGER DEFAULT 0,                 -- 发送字节数
    `recv_bytes` INTEGER DEFAULT 0,                 -- 接收字节数
    `request` INTEGER DEFAULT 0                     -- 请求次数
);


-- 增加索引
CREATE INDEX IF NOT EXISTS `idx_date_area_id` ON `area_total` (`date`,`country_area_id`,`province_area_id`,`city_area_id`);
CREATE INDEX IF NOT EXISTS `idx_date_request` ON `area_total` (`date`, `request`);
