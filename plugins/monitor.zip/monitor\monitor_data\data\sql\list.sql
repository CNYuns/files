
-- host表
CREATE TABLE IF NOT EXISTS `host` (
    `host_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `host` TEXT DEFAULT "" NOT NULL
);

-- 增加索引
CREATE INDEX IF NOT EXISTS `idx_host` ON `host` (`host`);

-- 响应类型表
CREATE TABLE IF NOT EXISTS `content_type` (
    `content_type_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `content_type` TEXT DEFAULT "" NOT NULL,
    `title` TEXT DEFAULT "" NOT NULL
);

-- 增加索引
CREATE INDEX IF NOT EXISTS `idx_content_type` ON `content_type` (`content_type`);

-- 批量插入响应类型
INSERT INTO `content_type` (`content_type`, `title`) VALUES 
('text/html', 'HTML'), 
('text/plain', '纯文本'), 
('text/css', 'CSS'), 
('text/javascript', 'JavaScript'), 
('application/javascript', 'JavaScript'), 
('application/x-javascript', 'JavaScript'), 
('application/json', 'JSON'), 
('application/xml', 'XML'), 
('application/rss+xml', 'RSS'), 
('application/atom+xml', 'Atom'), 
('application/x-shockwave-flash', 'Flash'), 
('image/jpeg', 'JPEG'), 
('image/png', 'PNG'), 
('image/gif', 'GIF'), 
('image/x-icon', 'ICO'), 
('image/svg+xml', 'SVG'), 
('application/x-font-ttf', 'TTF'), 
('application/x-font-opentype', 'OTF'), 
('application/x-font-woff', 'WOFF'), 
('application/vnd.ms-fontobject', 'EOT'), 
('application/octet-stream', '二进制流'), 
('application/pdf', 'PDF'), 
('application/zip', 'ZIP'), 
('application/x-tar', 'TAR'), 
('application/x-rar-compressed', 'RAR'), 
('application/x-msdownload', 'EXE'), 
('application/x-sh', 'SHELL'), 
('application/x-bzip2', 'BZIP2'), 
('application/x-gzip', 'GZIP'), 
('application/x-7z-compressed', '7Z'), 
('application/x-iso9660-image', 'ISO'), 
('application/vnd.android.package-archive', 'APK'), 
('application/vnd.ms-cab-compressed', 'CAB'), 
('audio/mpeg', 'MP3'), 
('audio/x-wav', 'WAV'), 
('audio/x-ms-wma', 'WMA'), 
('video/mpeg', 'MPEG'), 
('video/mp4', 'MP4'), 
('video/x-msvideo', 'AVI'), 
('video/x-ms-wmv', 'WMV'), 
('video/quicktime', 'MOV'), 
('video/x-flv', 'FLV'), 
('video/x-matroska', 'MKV'), 
('video/3gpp', '3GP'), 
('video/3gpp2', '3G2');


-- spider列表
CREATE TABLE IF NOT EXISTS `spider_list` (
    `spider_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `name` TEXT DEFAULT "" NOT NULL,
    `type` TEXT DEFAULT "" NOT NULL,
    `title` TEXT DEFAULT "" NOT NULL
);

-- 创建索引
CREATE INDEX IF NOT EXISTS `idx_spider` ON `spider_list` (`name`);

-- 批量插入spider
INSERT INTO `spider_list` (`name`, `type`, `title`) VALUES 
('Googlebot', 'Google', '谷歌'), 
('Baiduspider', 'Baidu', '百度'), 
('360Spider', '360', '360'),
('Sogou web spider', 'Sogou', '搜狗'), 
('YisouSpider', 'Yisou', '神马'), 
('bingbot', 'Bing', '必应'), 
('Yahoo! Slurp', 'Yahoo', '雅虎'), 
('Sosospider', 'Soso', '搜搜'), 
('YoudaoBot', 'Youdao', '有道'), 
('ia_archiver', 'Alexa', 'Alexa'), 
('EasouSpider', 'Easou', '宜搜'), 
('JikeSpider', 'Jike', '即刻'), 
('EtaoSpider', 'Etao', '一淘'), 
('YandexBot', 'Yandex', 'Yandex'), 
('msnbot', 'MSN', 'MSN'),
('Bytespider','Byte','头条'),
('DNSPod','DNSPod','DNPod'),
('AspiegelBot','Aspiegel','华为Aspiegel'),
('MJ12bot','MJ12bot','MJ12bot');


-- 请求类型列表
CREATE TABLE IF NOT EXISTS `method_list` (
    `method_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `method` TEXT DEFAULT "" NOT NULL
);

-- 创建索引
CREATE INDEX IF NOT EXISTS `idx_method` ON `method_list` (`method`);

-- 批量插入请求类型
INSERT INTO `method_list` (`method`) VALUES ('GET'), ('POST'), ('PUT'), ('DELETE'), ('HEAD'), 
                                            ('OPTIONS'), ('CONNECT'), ('TRACE'), ('PATCH'), ('PROPFIND'), ('PROPPATCH'), ('MKCOL'), 
                                            ('COPY'), ('MOVE'), ('LOCK'), ('UNLOCK'), ('VERSION-CONTROL'), ('REPORT'), ('CHECKOUT'), 
                                            ('CHECKIN'), ('UNCHECKOUT'), ('MKWORKSPACE'), ('UPDATE'), ('LABEL'), ('MERGE'), ('BASELINE-CONTROL'), 
                                            ('MKACTIVITY'), ('ORDERPATCH'), ('ACL'), ('SEARCH'), ('MKCALENDAR'), ('PATCH'), ('LINK'), ('UNLINK'), 
                                            ('REBIND'), ('UNBIND'), ('BIND'), ('UNBIND');


-- 浏览器类型列表
CREATE TABLE IF NOT EXISTS `browser_list` (
    `browser_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `browser` TEXT DEFAULT "" NOT NULL,
    `title` TEXT DEFAULT "" NOT NULL
);

-- 创建索引
CREATE INDEX IF NOT EXISTS `idx_browser` ON `browser_list` (`browser`);


-- 批量插入浏览器类型
INSERT INTO `browser_list` (`browser`, `title`) VALUES 
('Linux', 'Linux'),
('Android', 'Android'), 
('Macintosh', 'Mac'), 
('iOS', 'iOS'), 
('windows','Windows'),
('Safari', 'Safari'), 
('Chrome', 'Chrome'),
('Firefox', 'Firefox'), 
('Opera,OPR,Presto,OPiOS', 'Opera'), 
('MSIE', 'IE浏览器'), 
('Edge', 'Edge'), 
('spider,bot,crawler','蜘蛛'),
('wget,curl,requests,python,java,axios,apache,Http_Client,HTTPClient,http-client,node.js,okhttp,spring,resttemplate,jersey,retrofit,go-resty,github,gorilla,aiohttp,twisted,httplib,scrapy,tornado,php,guzzle,wordpress,http_request,webclient','机器'),
('nmap,acunetix,nessus,openvas,nikto,zap,metasploit,burp suite,wapiti,skipfish,w3af,sqlmap,arachni,owasp,grabber,webscarab,paros,netsparker,beef','扫描器'),
('QQBrowser,TencentTraveler,MQQ', 'QQ浏览器'), 
('WeChat,MicroMessenger', '微信'), 
('BaiduBrowser', '百度'), 
('Maxthon', '遨游'), 
('Sogou,MetaSr', '搜狗'), 
('360SE,360EE,360Chrome', '360浏览器'), 
('LBBROWSER', '猎豹'), 
('UCBrowser,UBrowser,UCWEB', 'UC浏览器');
