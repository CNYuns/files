-- 屏蔽IP列表
CREATE TABLE `shield_ip` (
  `shield_id` INTEGER PRIMARY KEY AUTOINCREMENT,
  `ip` TEXT DEFAULT '' NOT NULL,
  `end_time` INTEGER DEFAULT 0,
  `msg` TEXT DEFAULT '',
  `create_time` INTEGER DEFAULT 0
);

-- 创建索引
CREATE INDEX `idx_shield_ip_ip` ON `shield_ip` (`ip`);
