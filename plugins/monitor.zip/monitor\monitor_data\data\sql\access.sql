
-- 网站访问日志表
CREATE TABLE IF NOT EXISTS `access_log` (
    `access_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `host_id` INTEGER DEFAULT 0,        -- 访问域名
    `ip_id` INTEGER DEFAULT 0,          -- 访问IP  (真实ip: 用户的ip)
    `ipv6` INTEGER DEFAULT 0,           -- 是否ipv6
    `remote_port` INTEGER DEFAULT 0,    -- 访问端口
    `uri_id` INTEGER DEFAULT 0,         -- 访问URI
    `method_id` INTEGER DEFAULT 0,      -- 请求类型
    `referer_id` INTEGER DEFAULT 0,     -- 来路
    `status_code` INTEGER DEFAULT 0,        -- 状态码
    `request_take` INTEGER DEFAULT 0,       -- 请求耗时
    `request_time` INTEGER DEFAULT 0,       -- 请求时间
    `send_bytes` INTEGER DEFAULT 0,         -- 发送字节数
    `receive_bytes` INTEGER DEFAULT 0,      -- 接收字节数
    `user_agent_id` INTEGER DEFAULT 0,      -- user_agent
    `is_https` INTEGER DEFAULT 0,           -- 是否https
    `is_gzip` INTEGER DEFAULT 0,            -- 是否gzip
    `content_type_id` INTEGER DEFAULT 0,    -- 响应类型
    `session_id` INTEGER DEFAULT 0,         -- 会话ID
    `req_ip_id` INTEGER DEFAULT 0,          -- 请求的原始ip  (实际发起请求的机器ip)
    `pre_req_ip_id` INTEGER DEFAULT 0,      -- 实际发起请求的机器所携带的源ip与用户的ip一直时不记录
    `waf_shield` INTEGER DEFAULT 0          -- 是否被waf拦截
);

-- 增加索引
CREATE INDEX IF NOT EXISTS `access_log_uri_id` ON `access_log` (`uri_id`);
-- is_gzip 蜘蛛的索引有效性较低
CREATE INDEX IF NOT EXISTS `access_log_is_gzip` ON `access_log` (`is_gzip`);
CREATE INDEX IF NOT EXISTS `access_log_session_id` ON `access_log` (`session_id`);
CREATE INDEX IF NOT EXISTS `access_log_request_time` ON `access_log` (`request_time`);
CREATE INDEX IF NOT EXISTS `access_log_ip_id` ON `access_log` (`ip_id`);
CREATE INDEX IF NOT EXISTS `access_log_req_ip_id` ON `access_log` (`req_ip_id`);
CREATE INDEX IF NOT EXISTS `access_log_status_code` ON `access_log` (`status_code`);
CREATE INDEX IF NOT EXISTS `access_log_method_id` ON `access_log` (`method_id`);
CREATE INDEX IF NOT EXISTS `access_log_user_agent_id` ON `access_log` (`user_agent_id`);
CREATE INDEX IF NOT EXISTS `access_log_referer_id` ON `access_log` (`referer_id`);
CREATE INDEX IF NOT EXISTS `access_log_host_id` ON `access_log` (`host_id`);
CREATE INDEX IF NOT EXISTS `access_log_content_type_id` ON `access_log` (`content_type_id`);

-- 🚀 新增复合索引，优化组合查询和搜索性能
-- 时间相关的复合索引（最常用的组合查询）
CREATE INDEX IF NOT EXISTS `idx_access_time_uri` ON `access_log` (`request_time`, `uri_id`);
CREATE INDEX IF NOT EXISTS `idx_access_time_ip` ON `access_log` (`request_time`, `ip_id`);
CREATE INDEX IF NOT EXISTS `idx_access_time_status` ON `access_log` (`request_time`, `status_code`);
CREATE INDEX IF NOT EXISTS `idx_access_time_ua` ON `access_log` (`request_time`, `user_agent_id`);

-- 搜索相关的复合索引（提升搜索性能）
CREATE INDEX IF NOT EXISTS `idx_access_uri_status` ON `access_log` (`uri_id`, `status_code`);
CREATE INDEX IF NOT EXISTS `idx_access_ip_uri` ON `access_log` (`ip_id`, `uri_id`);
CREATE INDEX IF NOT EXISTS `idx_access_ua_uri` ON `access_log` (`user_agent_id`, `uri_id`);

-- 状态码相关的复合索引（错误分析）
CREATE INDEX IF NOT EXISTS `idx_access_status_time` ON `access_log` (`status_code`, `request_time`);

-- 会话相关的复合索引（会话分析）
CREATE INDEX IF NOT EXISTS `idx_access_session_time` ON `access_log` (`session_id`, `request_time`);