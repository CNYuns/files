-- user_agent表
CREATE TABLE IF NOT EXISTS `user_agent` (
    `user_agent_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `user_agent` TEXT DEFAULT "" NOT NULL
);

-- 增加唯一索引
CREATE UNIQUE INDEX IF NOT EXISTS `idx_user_agent` ON `user_agent` (`user_agent`);