import datetime
import json
import re
import ipaddress
import os.path
import sys
from typing import List, Union, Optional, Dict, Tuple, Any, Iterable, Set
import requests
from collections import OrderedDict

# 添加项目根目录到环境变量
os.chdir("/www/server/panel")
if "/www/server/panel/class" not in sys.path:
    sys.path.insert(0, "/www/server/panel/class")

import public
import db

if "/www/server/panel/plugin/monitor" in sys.path:
    sys.path.remove("/www/server/panel/plugin/monitor")
sys.path.insert(0, "/www/server/panel/plugin/monitor")

from cache_tool import TTLCache


class SiteTool:

    @staticmethod
    def docker_projects() -> Dict[str, Dict]:
        db_path = "/www/server/panel/data/db/docker.db"
        sql = db.Sql()
        sql._Sql__DB_FILE = db_path

        if not os.path.exists(db_path):
            return {}

        try:
            data = sql.table("docker_sites").field("id,name").select()
            res = {}
            for i in data:
                i["project_type"] = "docker"
                res[i["name"]] = i
        except:
            return {}

        return res
    @staticmethod
    def docker_domain(site_id: int) -> List[str]:
        db_path = "/www/server/panel/data/db/docker.db"
        sql = db.Sql()
        sql._Sql__DB_FILE = db_path

        if not os.path.exists(db_path):
            return []

        try:
            domains = sql.table("docker_domain").where("pid =?", (site_id,)).field('name,port').order("id ASC").select()
            res = []
            for d in domains:
                if d['port'] and int(d['port']) != 80:
                    res.append("{}:{}".format(d['name'], d['port']))
                else:
                    res.append(d['name'])
        except:
            return []
        return res

    @classmethod
    def get_site_info(cls, site_key: Union[int, str]) -> Optional[Dict]:
        if isinstance(site_key, int):
            site_info = public.M('sites').where('id=?', (site_key,)).find()
        elif isinstance(site_key, str):
            docker_projects = cls.docker_projects()
            if site_key in docker_projects:
                return docker_projects[site_key]
            site_info = public.M('sites').where('name=?', (site_key,)).find()
        else:
            site_info = None
        if not site_info:
            return None
        return site_info

    @classmethod
    def site_domain_list(cls, site_key: Union[int, str]) -> List[str]:
        site_info = cls.get_site_info(site_key)
        if not site_info:
            return []
        if site_info['project_type'] == 'docker':
            return cls.docker_domain(site_info['id'])

        domains = public.M('domain').where('pid=?', (site_info['id'],)).field('name,port').order("id ASC").select()
        res = []
        for d in domains:
            if d['port'] and int(d['port']) != 80:
                res.append("{}:{}".format(d['name'], d['port']))
            else:
                res.append(d['name'])
        return res

    # 传入site_name str, 或者 site_id, 通过站点配置文件获取站点是否使用了https
    @classmethod
    def site_use_https(cls, site_key: Union[int, str]) -> bool:
        site_info = cls.get_site_info(site_key)
        if not site_info:
            return True
        return cls.site_use_https_by_conf(site_info['name'], site_info['project_type'])

    @classmethod
    def site_use_https_by_conf(cls, site_name: str, project_type: str) -> bool:
        path = os.path.join('/www/server/panel/vhost/cert/', site_name)
        if not os.path.exists(path + "/fullchain.pem") or not os.path.exists(path + "/privkey.pem"):
            return False
        web_server = public.get_webserver()
        conf = cls.site_server_config(site_name, project_type)
        if not conf:
            return False
        if web_server == 'nginx':
            key_text = 'ssl_certificate'
        else:
            key_text = 'SSLCertificateFile'

        if conf.find(key_text) == -1:
            return False
        return True

    @staticmethod
    def site_server_config(site_name: str, project_type: str) -> Optional[str]:
        project_type = project_type.lower()
        web_server = public.get_webserver()
        if project_type in ("php", 'proxy', "docker", "wp2"):
            config_file = '{}/vhost/{}/{}.conf'.format(public.get_panel_path(), web_server, site_name)
        else:
            config_file = '{}/vhost/{}/{}_{}.conf'.format(public.get_panel_path(), web_server, project_type, site_name)
        conf = public.readFile(config_file)
        if not conf:
            return None
        return conf

    @classmethod
    def site_run_path(cls, site_name: str, project_type: str) -> Optional[str]:
        conf = cls.site_server_config(site_name, project_type)
        if not conf:
            return None
        web_server = public.get_webserver()
        run_path = None
        if web_server == 'nginx':
            tmp1 = re.search(r'\s*root\s+(?P<path>.+);', conf)
            if tmp1:
                run_path = tmp1.group("path").strip()
        elif web_server == 'apache':
            tmp1 = re.search(r'''\s*DocumentRoot\s*['"](?P<path>.+)['"]\s*\n''', conf)
            if tmp1:
                run_path = tmp1.group("path")

        return run_path

    @classmethod
    def get_site_list(cls) -> List[str]:
        sites = public.M("sites").field("id,name").select()
        docker_sites = [i for i in cls.docker_projects()]
        return [i['name'] for i in sites] + docker_sites


sitetool = SiteTool()


class _IPRangeBase:

    def __str__(self):
        raise NotImplementedError

    def contains(self, ip) -> bool:
        raise NotImplementedError

    def show_string(self) -> str:
        return str(self)

    def set_ps(self, ps: str):
        setattr(self, '_ps', ps)

    def get_ps(self) -> str:
        return getattr(self, '_ps', '')


class IPRange(_IPRangeBase):
    # 完整 IP
    SINGLE_IP_REGEXP = re.compile(r'^\d{1,3}(\.\d{1,3}){3}$')
    # IP 段通配符
    IP_SEGMENT_REGEXP = re.compile(r'^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\*)$')
    IP_SEGMENT_REGEXP2 = re.compile(r'^(\d{1,3}\.\d{1,3}(\.\*){2})$')
    # CIDR 网段
    IP_NETWORK_REGEXP = re.compile(r'^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/\d{1,2})$')
    # IP 范围
    IP_RANGE_REGEXP = re.compile(r'^\d{1,3}(\.\d{1,3}){3}(?P<sep>[_—·~-])\d{1,3}(\.\d{1,3}){3}$')
    IP_RANGE_REGEXP2 = re.compile(r'^\d{1,3}(\.\d{1,3}){3}(?P<sep>[_—·~-])\d{1,3}$')
    IP_RANGE_REGEXP3 = re.compile(r'^\d{1,3}(\.\d{1,3}){3}(?P<sep>[_—·~-])\d{1,3}\.\d{1,3}$')
    # 部分 IP 匹配（新增：支持用户输入部分 IP 段进行模糊搜索）
    # 单个数字段：88 -> 88.0.0.0/8
    IP_PARTIAL_1_REGEXP = re.compile(r'^(\d{1,3})$')
    # 两个数字段：192.168 -> 192.168.0.0/16
    IP_PARTIAL_2_REGEXP = re.compile(r'^(\d{1,3})\.(\d{1,3})$')
    # 三个数字段：192.168.1 -> 192.168.1.0/24
    IP_PARTIAL_3_REGEXP = re.compile(r'^(\d{1,3})\.(\d{1,3})\.(\d{1,3})$')

    def __init__(self, start_ip: ipaddress.IPv4Address, end_ip: ipaddress.IPv4Address):
        self.start_ip = min(start_ip, end_ip)
        self.end_ip = max(start_ip, end_ip)

    def to_long_range(self) -> Tuple[int, int]:
        return int(self.start_ip), int(self.end_ip)

    def to_long_list(self) -> List[int]:
        return list(range(int(self.start_ip), int(self.end_ip) + 1))

    def __str__(self):
        return "{}-{}".format(int(self.start_ip), int(self.end_ip))

    def show_string(self) -> str:
        start_ip_int = int(self.start_ip)
        if start_ip_int & (1 < 8 - 1) == 0 and start_ip_int + 255 == int(self.end_ip):
            return "{}/24".format(str(self.start_ip))

        return "{}-{}".format(str(self.start_ip), str(self.end_ip))

    def contains(self, ip: Union[str, int, ipaddress.IPv4Address]) -> bool:
        try:
            if isinstance(ip, str):
                ip_addr = ipaddress.IPv4Address(ip)
                return self.start_ip <= ip_addr <= self.end_ip
            elif isinstance(ip, ipaddress.IPv4Address):
                return self.start_ip <= ip <= self.end_ip
            elif isinstance(ip, int):
                return self.start_ip <= ipaddress.IPv4Address(ip) <= self.end_ip
        except:
            return False

    @classmethod
    def _deserialization(cls, data: str) -> Optional["IPRange"]:
        try:
            start_ip, end_ip = data.split("-", 1)
            start_ip_addr = ipaddress.IPv4Address(int(start_ip))
            end_ip_addr = ipaddress.IPv4Address(int(end_ip))
            return IPRange(start_ip_addr, end_ip_addr)
        except:
            return None

    @classmethod
    def parse(cls, ip_range_str: str) -> Optional["IPRange"]:
        res = cls._deserialization(ip_range_str)
        if res:
            return res
            
        # 部分 IP 匹配（支持用户输入部分 IP 段进行模糊搜索）
        # 三个数字段：192.168.1 -> 192.168.1.0/24
        match = cls.IP_PARTIAL_3_REGEXP.match(ip_range_str)
        if match:
            try:
                part1, part2, part3 = match.groups()
                # 验证每个段是否有效（0-255）
                if all(0 <= int(p) <= 255 for p in [part1, part2, part3]):
                    net_work_str = f"{part1}.{part2}.{part3}.0/24"
                    net_work = ipaddress.IPv4Network(net_work_str, strict=False)
                    return IPRange(net_work.network_address, net_work.broadcast_address)
            except:
                return None

        # 两个数字段：192.168 -> 192.168.0.0/16
        match = cls.IP_PARTIAL_2_REGEXP.match(ip_range_str)
        if match:
            try:
                part1, part2 = match.groups()
                # 验证每个段是否有效（0-255）
                if all(0 <= int(p) <= 255 for p in [part1, part2]):
                    net_work_str = f"{part1}.{part2}.0.0/16"
                    net_work = ipaddress.IPv4Network(net_work_str, strict=False)
                    return IPRange(net_work.network_address, net_work.broadcast_address)
            except:
                return None

        # 单个数字段：88 -> 88.0.0.0/8
        match = cls.IP_PARTIAL_1_REGEXP.match(ip_range_str)
        if match:
            try:
                part1 = match.group(1)
                # 验证段是否有效（0-255）
                if 0 <= int(part1) <= 255:
                    net_work_str = f"{part1}.0.0.0/8"
                    net_work = ipaddress.IPv4Network(net_work_str, strict=False)
                    return IPRange(net_work.network_address, net_work.broadcast_address)
            except:
                return None

        # 单个IP
        match = cls.SINGLE_IP_REGEXP.match(ip_range_str)
        if match:
            try:
                ip_addr = ipaddress.IPv4Address(ip_range_str)
                return IPRange(ip_addr, ip_addr)
            except:
                return None

        # IP段
        net_work_str = ""
        match = cls.IP_SEGMENT_REGEXP.match(ip_range_str)
        if match:
            net_work_str = ip_range_str.replace('.*', '.0/24')
        else:
            match = cls.IP_NETWORK_REGEXP.match(ip_range_str)
            if match:
                net_work_str = ip_range_str
        if net_work_str:
            try:
                net_work = ipaddress.IPv4Network(net_work_str, strict=False)
                return IPRange(net_work.network_address, net_work.broadcast_address)
            except:
                return None

        # IP段 B段
        net_work_str = ""
        match = cls.IP_SEGMENT_REGEXP2.match(ip_range_str)
        if match:
            net_work_str = ip_range_str.replace('.*.*', '.0.0/16')
        else:
            match = cls.IP_NETWORK_REGEXP.match(ip_range_str)
            if match:
                net_work_str = ip_range_str
        if net_work_str:
            try:
                net_work = ipaddress.IPv4Network(net_work_str, strict=False)
                return IPRange(net_work.network_address, net_work.broadcast_address)
            except:
                return None

        # IP范围
        match = cls.IP_RANGE_REGEXP.match(ip_range_str)
        if match:
            sep = match.group("sep")
            try:
                start_ip, end_ip = ip_range_str.split(sep, 1)
                start_ip_addr = ipaddress.IPv4Address(start_ip)
                end_ip_addr = ipaddress.IPv4Address(end_ip)
                return IPRange(start_ip_addr, end_ip_addr)
            except:
                return None

        match = cls.IP_RANGE_REGEXP2.match(ip_range_str)
        if match:
            sep = match.group("sep")
            try:
                start_ip, end_ip_last = ip_range_str.split(sep, 1)
                start_ip_addr = ipaddress.IPv4Address(start_ip)
                end_ip = start_ip.rsplit(".", 1)[0] + "." + end_ip_last
                end_ip_addr = ipaddress.IPv4Address(end_ip)
                return IPRange(start_ip_addr, end_ip_addr)
            except:
                return None

        match = cls.IP_RANGE_REGEXP3.match(ip_range_str)
        if match:
            sep = match.group("sep")
            try:
                start_ip, end_ip_last = ip_range_str.split(sep, 1)
                start_ip_addr = ipaddress.IPv4Address(start_ip)
                end_ip = start_ip.rsplit(".", 2)[0] + "." + end_ip_last
                end_ip_addr = ipaddress.IPv4Address(end_ip)
                return IPRange(start_ip_addr, end_ip_addr)
            except:
                return None
        return None


class IPSearch:

    def __init__(self):
        self.ipv6_list: List[str] = []
        self.ipv4_list: List[int] = []
        self.ipv4_range_list: List[IPRange] = []

    def is_empty(self) -> bool:
        return len(self.ipv4_range_list) == 0 and len(self.ipv6_list) == 0 and len(self.ipv4_list) == 0

    def to_dict(self) -> dict:
        """序列化为字典，用于跨进程传递"""
        return {
            'ipv4_list': self.ipv4_list,
            'ipv4_range_list': [
                {'start': int(r.start_ip), 'end': int(r.end_ip)}
                for r in self.ipv4_range_list
            ],
            'ipv6_list': self.ipv6_list,
        }

    @staticmethod
    def is_ipv6(ip_str: str) -> Optional[str]:
        try:
            ipaddr = ipaddress.IPv6Address(ip_str)
            return str(ipaddr)
        except:
            return None

    @classmethod
    def parse(cls, ip_search_str: str) -> "IPSearch":
        ip_search = cls()
        is_ipv6 = False  # 同时只处理ipv4或ipv6
        ip_search_str = ip_search_str.replace("，", ",")  # 替换中文逗号
        for ip_range in ip_search_str.split(","):
            ip_range = ip_range.strip()
            if not ip_range:
                continue

            # 处理普通ipv6的情况
            if ":" in ip_range:
                ip_addr = cls.is_ipv6(ip_range)
                if ip_addr:
                    is_ipv6 = True
                    ip_search.ipv6_list.append(ip_addr)
                    continue

            if is_ipv6:
                continue

            # 处理ipv4的情况
            ip_range_obj = IPRange.parse(ip_range)
            if not ip_range_obj:
                continue
            if ip_range_obj.start_ip == ip_range_obj.end_ip:
                ip_search.ipv4_list.append(int(ip_range_obj.start_ip))
            ip_search.ipv4_range_list.append(ip_range_obj)

        return ip_search


def get_page_with_smart_pages(count, p=1, rows=12, callback=''):
    if 0 < p < 100:
        return get_page_with_limit_pages(count, p, rows, callback, result='1,3,5,8', limit_pages=4 * 2)
    elif 100 <= p < 1000:
        return get_page_with_limit_pages(count, p, rows, callback, result='1,3,5,8', limit_pages=3 * 2)
    elif 1000 <= p < 10000:
        return get_page_with_limit_pages(count, p, rows, callback, result='1,3,5,8', limit_pages=2 * 2)
    return get_page_with_limit_pages(count, p, rows, callback, result='1,3,5,8', limit_pages=2 * 2)


def get_page_with_limit_pages(count, p=1, rows=12, callback='', result='1,2,3,4,5,8', limit_pages=4 * 2):
    import page
    try:
        from BTPanel import request
        uri = public.url_encode(request.full_path)
    except:
        uri = ''
    page = page.Page()
    setattr(page, '_Page__LIST_NUM', max(limit_pages // 2, 1))
    info = {'count': count, 'row': rows, 'p': p, 'return_js': callback, 'uri': uri}
    data = {'page': page.GetPage(info, result), 'shift': str(page.SHIFT), 'row': str(page.ROW)}
    return data


def file_attr_i(file_name: str) -> bool:
    if not os.path.isfile(file_name):
        return False
    out, _ = public.ExecShell("lsattr {}".format(file_name))
    stat = out.split(" ", 1)[0]
    if "i" in stat:
        return True
    return False


def file_attr_add_i(file_name: str) -> bool:
    if not os.path.isfile(file_name):
        return False
    if file_attr_i(file_name):
        return True
    public.ExecShell("chattr +i {}".format(file_name))
    return file_attr_i(file_name)


def file_attr_del_i(file_name: str) -> bool:
    if not os.path.isfile(file_name):
        return False
    if not file_attr_i(file_name):
        return True
    public.ExecShell("chattr -i {}".format(file_name))
    return not file_attr_i(file_name)


class IPSet:
    _ttl_cache = TTLCache(maxsize=10, ttl=60)

    def __init__(self, name: str):
        self.name: str = name
        self._bin_path = self._bin()

    def list(self) -> List[str]:
        data = self.__class__._ttl_cache.get(self.name)
        if data:
            return data

        out, _ = public.ExecShell("{} list {}".format(self._bin_path, self.name))
        if not out:
            return []
        # 解析输出，返回 IPSetData 列表
        lines = out.strip().split('\n')
        ip_list = []
        in_list = False
        for line in lines:
            if line.startswith('Members:'):
                in_list = True
                continue
            if not in_list:
                continue

            line_list = line.split()
            if len(line_list) == 3 and line_list[1] == "timeout":
                try:
                    ip = ipaddress.ip_address(line_list[0])  # 验证ip
                    int(line_list[2])  # 验证timeout
                    ip_list.append(str(ip))
                except:
                    continue
            elif len(line_list) == 1:
                try:
                    ip = ipaddress.ip_address(line_list[0])  # 验证ip
                    ip_list.append(str(ip))
                except:
                    continue

        self.__class__._ttl_cache[self.name] = ip_list
        return ip_list

    @staticmethod
    def _bin() -> Optional[str]:
        for i in ("/usr/sbin", "/bin", "/usr/bin", "/usr/local/bin"):
            if os.path.exists("{}/ipset".format(i)):
                return "{}/ipset".format(i)
        return None

    def add(self, ip: str, timeout: int = None) -> bool:
        command = "{} add {} {}".format(self._bin_path, self.name, ip)
        if timeout is not None:
            command += " timeout {}".format(timeout)
        out, err = public.ExecShell(command)
        if err:
            return False
        return True

    def delete(self, ip: str) -> bool:
        out, err = public.ExecShell("{} del {} {}".format(self._bin_path, self.name, ip))
        if err:
            return False
        return True

    def update(self, ip: str, timeout: int = None) -> bool:
        self.delete(ip)
        return self.add(ip, timeout)


class IPv6Range(_IPRangeBase):

    def __init__(self, ip_data: Union[ipaddress.IPv6Address, ipaddress.IPv6Network]):
        self._ip_data = ip_data

    @staticmethod
    def parse(ip_data: str) -> Optional["IPv6Range"]:
        if "/" in ip_data:
            try:
                ip = ipaddress.IPv6Network(ip_data)
                return IPv6Range(ip)
            except:
                return None
        else:
            try:
                ip = ipaddress.IPv6Address(ip_data)
                return IPv6Range(ip)
            except:
                return None

    def contains(self, ip: str) -> bool:
        try:
            ip_obj = ipaddress.IPv6Address(ip)
        except:
            return False
        if isinstance(self._ip_data, ipaddress.IPv6Address):
            return ip_obj == self._ip_data
        else:
            return ip_obj in self._ip_data

    def show_string(self) -> str:
        return str(self._ip_data)

    def __str__(self):
        return str(self._ip_data)


class WafIPFilter:
    """
    WafIPFilter class
    获取 waf 中 ip封禁信息
    """

    _ttl_cache = TTLCache(maxsize=4, ttl=30)
    _WAF_CONFIG_FILE = "/www/server/btwaf/config.json"
    _WAF_IP_BLACK_FILE = "/www/server/btwaf/rule/ip_black.json"
    _WAF_IPV6_BLACK_FILE = "/www/server/btwaf/rule/ip_black_v6.json"
    _WAF_DB_FILE = "/www/server/btwaf/totla_db/totla_db.db"

    def __init__(self, disable_cache: bool = False):
        self._waf_status: Optional[bool] = None
        self._waf_config: Optional[dict] = None
        self._disable_cache = disable_cache

    @classmethod
    def clear_cache(cls, name: str) -> None:
        cls._ttl_cache.pop(name, None)

    def status(self) -> bool:
        if self._waf_status is None:
            self._waf_status = os.path.exists(self._WAF_IP_BLACK_FILE) and os.path.exists(self._WAF_IPV6_BLACK_FILE)
        return self._waf_status

    @property
    def config(self) -> dict:
        if self._waf_config is None:
            try:
                self._waf_config = json.loads(public.readFile(self._WAF_CONFIG_FILE))
            except:
                return {}
        return self._waf_config

    @classmethod
    def black_mod_time(cls) -> int:
        if not os.path.exists(cls._WAF_IPV6_BLACK_FILE) or not os.path.exists(cls._WAF_IP_BLACK_FILE):
            return 0
        return int(min(os.path.getmtime(cls._WAF_IPV6_BLACK_FILE), os.path.getmtime(cls._WAF_IP_BLACK_FILE)))

    def temporary_list(self) -> List[str]:
        if not self.config.get("open", None):
            return []
        if not self._disable_cache:
            data = self.__class__._ttl_cache.get("temporary_list", None)
            if data:
                return data

        url = 'http://127.0.0.1/get_btwaf_drop_ip'
        headers = {
            "User-Agent": "Mozilla/5.0 (windows. NT 10.0; Win64; x64) AppLeWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36",
            'btwaf-access-token': self.config.get("access_token", "")
        }
        try:
            response = requests.get(url, headers=headers,timeout=(3, 1))
            if response.status_code != 200:
                return []
            ip_list = []
            data = response.json()
            for ip in data:
                try:
                    ip_list.append(str(ipaddress.ip_address(ip)))
                except:
                    continue

            self.__class__._ttl_cache["temporary_list"] = ip_list
            return ip_list
        except:
            return []

    def black_ip_list(self) -> List[IPRange]:
        if not self._disable_cache:
            data = self.__class__._ttl_cache.get("black_ip_list", None)
            if data:
                return data

        if not os.path.exists(self._WAF_IP_BLACK_FILE):
            return []
        ip_list = public.readFile(self._WAF_IP_BLACK_FILE)
        if not ip_list:
            return []
        res_list = []
        ip_list = json.loads(ip_list)
        try:
            for item in ip_list:
                res_list.append(IPRange(ipaddress.IPv4Address(item[0]), ipaddress.IPv4Address(item[1])))
        except:
            return []

        self.__class__._ttl_cache["black_ip_list"] = res_list
        return res_list

    def black_rule_data(self) -> Tuple[OrderedDict, OrderedDict]:
        if not self._disable_cache:
            data = self.__class__._ttl_cache.get("black_ip_rule_list", None)
            if data and len(data) == 2:
                return data

        try:
            ipv4_list = json.loads(public.readFile(self._WAF_IP_BLACK_FILE))
            ipv6_list = json.loads(public.readFile(self._WAF_IPV6_BLACK_FILE))

            ip_rule, ip_range_rule = OrderedDict(), OrderedDict()
            for item in ipv4_list:
                if item[0] == item[1]:
                    ip_rule[str(ipaddress.IPv4Address(item[0]))] = "" if len(item) == 2 else item[2]
                else:
                    ip_r = IPRange(ipaddress.IPv4Address(item[0]), ipaddress.IPv4Address(item[1]))
                    ip_r.set_ps("" if len(item) == 2 else item[2])
                    ip_range_rule[ip_r.show_string()] = ip_r

            for item in ipv6_list:
                if item[0].find("/") != -1:
                    tmp = IPv6Range.parse(item)
                    if tmp:
                        tmp.set_ps("" if len(item) == 1 else item[1])
                        ip_range_rule[tmp.show_string()] = tmp
                else:
                    ip_rule[item[0]] = "" if len(item) == 2 else item[1]

            self.__class__._ttl_cache["black_ip_rule_list"] = (ip_rule, ip_range_rule)

            return ip_rule, ip_range_rule
        except:
            return OrderedDict(), OrderedDict()

    def black_ipv6_list(self) -> List[IPv6Range]:
        if not self._disable_cache:
            data = self.__class__._ttl_cache.get("black_ipv6_list", None)
            if data:
                return data

        if not os.path.exists(self._WAF_IPV6_BLACK_FILE):
            return []
        ip_list = public.readFile(self._WAF_IPV6_BLACK_FILE)
        if not ip_list:
            return []
        res_list = []
        ip_list = json.loads(ip_list)
        for item in ip_list:
            tmp = IPv6Range.parse(item)
            if tmp:
                res_list.append(tmp)

        self.__class__._ttl_cache["black_ipv6_list"] = res_list

        return res_list

    def try_temporary_ip_ps(self, ip: str) -> Tuple[int, str]:
        # select filter_rule,incoming_value from totla_log where ip='178.45.125.47' order by id DESC limit 1;
        if not os.path.isfile(self._WAF_DB_FILE):
            return 0, ""

        sql = db.Sql()
        sql._Sql__DB_FILE = self._WAF_DB_FILE
        data = sql.table("totla_log").where("ip=?", (ip,)).field("time,filter_rule,incoming_value").order("id DESC").find()
        if data:
            return data["time"], "{}({})".format(data["filter_rule"], data["incoming_value"])
        return 0, ""

    @classmethod
    def temporary_add(cls, ip: Union[ipaddress.IPv6Address, ipaddress.IPv4Address], timeout: int) -> bool:
        import PluginLoader
        args = public.dict_obj()
        args.fun = "add_temporary_ip"
        args.s = "add_temporary_ip"
        args.ip = str(ip)
        args.timeout = timeout
        data = PluginLoader.plugin_run("btwaf", "add_temporary_ip", args)
        if isinstance(data, dict):
            status = data.get("status", False)
            if status:
                cls.clear_cache("temporary_list")
            return status
        return False

    @classmethod
    def temporary_remove(cls, ip: Union[ipaddress.IPv6Address, ipaddress.IPv4Address]) -> bool:
        import PluginLoader
        args = public.dict_obj()
        args.fun = "remove_waf_drop_ip"
        args.s = "remove_waf_drop_ip"
        args.ip = str(ip)
        data = PluginLoader.plugin_run("btwaf", "remove_waf_drop_ip", args)
        if isinstance(data, dict):
            status = data.get("status", False)
            if status:
                cls.clear_cache("temporary_list")
            return status
        return False

    @classmethod
    def black_add(
            cls,
            ip: Union[ipaddress.IPv6Address, ipaddress.IPv4Address, ipaddress.IPv6Network, ipaddress.IPv4Network],
            ps: str = "") -> bool:
        import PluginLoader
        now = datetime.datetime.now()
        if isinstance(ip, (ipaddress.IPv4Network, ipaddress.IPv4Address)):
            args = public.dict_obj()
            args.fun = "add_ip_black"
            args.s = "add_ip_black"
            args.start_ip = str(ip) if isinstance(ip, ipaddress.IPv4Address) else str(ip.network_address)
            args.end_ip = str(ip) if isinstance(ip, ipaddress.IPv4Address) else str(ip.broadcast_address)
            args.ps = ps or "添加自监控报表,时间为:{}".format(now.strftime("%Y-%m-%d %H:%M:%S"))
            res = PluginLoader.plugin_run("btwaf", "add_ip_black", args)
        else:
            args = public.dict_obj()
            args.fun = "add_ipv6_black"
            args.s = "add_ipv6_black"
            args.ip = str(ip)
            args.ps = ps or "添加自监控报表,时间为:{}".format(now.strftime("%Y-%m-%d %H:%M:%S"))
            res = PluginLoader.plugin_run("btwaf", "add_ipv6_black", args)

        if isinstance(res, dict):
            status = res.get("status", False)
            if status:
                cls.clear_cache("black_ip_list")
                cls.clear_cache("black_ip_rule_list")
                cls.clear_cache("black_ipv6_list")
            return status

        return False

    @classmethod
    def black_remove(
            cls,
            ip: Union[str, ipaddress.IPv6Address, ipaddress.IPv4Address, ipaddress.IPv6Network, ipaddress.IPv4Network],
            end_ip: Optional[Union[ipaddress.IPv4Address, str]] = None
    ) -> bool:
        import PluginLoader

        if isinstance(ip, str):
            ip = ip_parser(ip)
            if not ip:
                return False

        if end_ip is None:
            if isinstance(ip, (ipaddress.IPv4Network, ipaddress.IPv4Address)):
                args = public.dict_obj()
                args.fun = "remove_rule_check"
                args.s = "remove_rule_check"
                args.rule = "ip_black"
                args.type = "ipv4"
                args.start_ip = str(ip) if isinstance(ip, ipaddress.IPv4Address) else str(ip.network_address)
                args.end_ip = str(ip) if isinstance(ip, ipaddress.IPv4Address) else str(ip.broadcast_address)
            else:
                args = public.dict_obj()
                args.fun = "remove_rule_check"
                args.s = "remove_rule_check"
                args.rule = "ip_black"
                args.type = "ipv6"
                args.start_ip = str(ip)

            res = PluginLoader.plugin_run("btwaf", "remove_rule_check", args)
        else:
            end_ip = ip_parser(end_ip)
            if not isinstance(end_ip, ipaddress.IPv4Address) or not isinstance(ip, ipaddress.IPv4Address):
                return False
            args = public.dict_obj()
            args.fun = "remove_rule_check"
            args.s = "remove_rule_check"
            args.rule = "ip_black"
            args.type = "ipv4"
            args.start_ip = str(ip)
            args.end_ip = str(end_ip)

            res = PluginLoader.plugin_run("btwaf", "remove_rule_check", args)

        if isinstance(res, dict):
            status = res.get("status", False)
            if status:
                cls.clear_cache("black_ip_list")
                cls.clear_cache("black_ip_rule_list")
                cls.clear_cache("black_ipv6_list")
            return status

        return False


def ip_parser(ip_data: str) -> Union[
    ipaddress.IPv6Address, ipaddress.IPv4Address, None, ipaddress.IPv6Network, ipaddress.IPv4Network
]:
    try:
        return ipaddress.ip_address(ip_data)
    except:
        try:
            return ipaddress.ip_network(ip_data)
        except:
            return None
