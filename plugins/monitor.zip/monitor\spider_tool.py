import copy
import datetime
import json
import os.path
import re
import sys
import time
import traceback
import uuid
import hashlib
import base64
import warnings
from dataclasses import dataclass
from typing import List, Union, Optional, Dict, Tuple, Any, Iterable, Set
from collections import OrderedDict
from urllib.parse import quote, unquote, urlparse, urlunparse


warnings.filterwarnings("ignore", message=r".*doesn't\s+match\s+a\s+supported\s+version", module="requests")
warnings.filterwarnings("ignore", message=r".*Python 3.7 is no longer supported by the Python core team")

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding
from requests import session

# 添加项目根目录到环境变量
os.chdir("/www/server/panel")
if "/www/server/panel/class" not in sys.path:
    sys.path.insert(0, "/www/server/panel/class")

import public

if "/www/server/panel/plugin/monitor" not in sys.path:
    sys.path.insert(0, "/www/server/panel/plugin/monitor")
elif not sys.path.index("/www/server/panel/plugin/monitor") == 0:
    sys.path.remove("/www/server/panel/plugin/monitor")
    sys.path.insert(0, "/www/server/panel/plugin/monitor")


from utils import sitetool, file_attr_del_i, file_attr_add_i, file_attr_i


# 要支持*不转义
def normalize_uri(uri: str) -> str:
    parsed_url = urlparse(unquote(uri))
    url = urlunparse((
        '', '',
        quote(parsed_url.path, safe="/:*"),
        quote(parsed_url.params, safe=";/:*"),
        quote(parsed_url.query, safe="=&?:/*"),
        quote(parsed_url.fragment, safe="/:*"),
    ))
    return url


def _list_args(args_data: str) -> List[Any]:
    tmp = []
    if not args_data:
        return []
    if args_data.startswith("["):
        try:
            tmp = json.loads(args_data)
        except:
            return []
    else:
        for d in args_data.split(","):
            tmp.append(d.strip())
    return tmp


class _RulePath:

    def __init__(self, path: str, allowance: bool):
        self.original = path
        self.path = path
        self.allowance = allowance
        self.rep: Optional[re.Pattern] = None

        if not self.path.startswith("*") and not self.path.startswith("/"):
            self.path = "/" + self.path
        if self.path.endswith("*"):
            self.path = self.path[:-1]
        if "*" in self.path or "$" in self.path:
            self.path = re.escape(self.path)
            self.path.replace('\\*', '.*')
            self.path.replace('\\$', '$')
            try:
                self.rep = re.compile(self.path)
            except:
                pass

    def weight(self, filename: str) -> int:
        if self.rep:
            if self.rep.match(filename):
                return len(self.original)
        if self.path == "/":
            return 1
        if filename.startswith(self.path):
            return len(self.path)
        return 0


@dataclass
class _Rule:
    ua: str
    allow: List[str]
    disallow: List[str]
    crawl_delay: int
    request_rate: Tuple[int, int]
    ps: str
    title: str

    def weight(self, test_ua: str) -> int:
        if self.ua == '*':
            return 1
        elif self.ua == test_ua:
            return 1000
        elif test_ua.startswith(self.ua):
            return len(self.ua)
        else:
            return 0

    def allowance(self, url: str) -> bool:
        _tans = []
        for i in self.allow:
            _tans.append(_RulePath(i, True))
        for i in self.disallow:
            _tans.append(_RulePath(i, False))

        node: Optional[_RulePath] = None
        weight: int = 0
        for i in _tans:
            tw = i.weight(url)
            if tw > weight:
                node = i
                weight = tw
        if node:
            return node.allowance
        return True

    def __repr__(self):
        return "<Rule(ua={}, allow={}, disallow={}, crawl_delay={}, request_rate={}, ps={}, title={})>".format(
            self.ua, self.allow, self.disallow, self.crawl_delay, self.request_rate, self.ps, self.title
        )

    def __str__(self):
        res = []
        if self.ps:
            res.append('#{}{}'.format(self.title, self.ps.strip("#")))
        res.append('User-agent: {}'.format(self.ua))
        if self.allow:
            for i in self.allow:
                res.append('Allow: {}'.format(normalize_uri(i)))
        if self.disallow:
            for i in self.disallow:
                res.append('Disallow: {}'.format(normalize_uri(i)))
        if self.crawl_delay:
            res.append('Crawl-delay: {}'.format(self.crawl_delay))
        if self.request_rate[0] > 0 and self.request_rate[1] > 0:
            res.append('Request-rate: {}/{}'.format(self.request_rate[0], self.request_rate[1]))

        return '\n'.join(res) + "\n"

    def info(self) -> dict:
        return {
            'ua': self.ua,
            'allow': self.allow,
            'disallow': self.disallow,
            'crawl_delay': self.crawl_delay,
            'request_rate': self.request_rate,
            'ps': self.ps,
            'title': self.title
        }

    @classmethod
    def new(cls, data: dict) -> Optional["_Rule"]:
        ua = data.get('ua', '')
        if not ua:
            return None
        title = RoBots.ua2title(ua)
        allow = data.get('allow', [])
        disallow = data.get('disallow', [])
        crawl_delay = data.get('crawl_delay', 0)
        request_rate = data.get('request_rate', (-1, -1))
        ps = data.get('ps', '')
        return cls(ua, allow, disallow, crawl_delay, request_rate, ps, title)


class RoBots:
    _UA_TITLE = [
        ('Googlebot', 'Google', '谷歌'),
        ('Baiduspider', 'Baidu', '百度'),
        ('360Spider', '360', '360'),
        ('Sogou web spider', 'Sogou', '搜狗'),
        ('YisouSpider', 'Yisou', '神马'),
        ('bingbot', 'Bing', '必应'),
        ('Yahoo! Slurp', 'Yahoo', '雅虎'),
        ('Sosospider', 'Soso', '搜搜'),
        ('YoudaoBot', 'Youdao', '有道'),
        ('ia_archiver', 'Alexa', 'Alexa'),
        ('EasouSpider', 'Easou', '宜搜'),
        ('JikeSpider', 'Jike', '即刻'),
        ('EtaoSpider', 'Etao', '一淘'),
        ('YandexBot', 'Yandex', 'Yandex'),
        ('msnbot', 'MSN', 'MSN'),
        ('Bytespider', 'Byte', '头条'),
        ('DNSPod', 'DNSPod', 'DNPod'),
        ('AspiegelBot', 'Aspiegel', '华为Aspiegel'),
        ('MJ12bot', 'MJ12bot', 'MJ12bot')
    ]
    _REQUEST_RATE_RE = re.compile(r'^(?P<num>\d*)(?P<unit>[mM](inutes)?|[hH](ours)?)?')

    @classmethod
    def ua2title(cls, arg: Union[str, _Rule]) -> Optional[str]:
        if isinstance(arg, str):
            tmp = arg
        elif isinstance(arg, _Rule):
            tmp = arg.ua
        else:
            return None
        if tmp == "*":
            return "所有蜘蛛"
        for ua, _, title in cls._UA_TITLE:
            if ua in tmp:
                return title
        return tmp

    def __init__(self):
        self._rules: List[_Rule] = []
        self._default_rule: Optional[_Rule] = None
        self._sitemap: List[str] = []

    @classmethod
    def load_from_file(cls, filename: str) -> Optional["RoBots"]:
        if not os.path.isfile(filename):
            return None
        data = public.readFile(filename)
        if isinstance(data, str):
            return cls.load(data)
        return None

    @classmethod
    def load(cls, data: str) -> Optional["RoBots"]:
        lines = data.split('\n')
        # states:
        #   0: saw user-agent line
        #   1: saw an allow or disallow line
        state = 0
        current_rule: List[_Rule] = []  # 当前行
        rule_map: Dict[str, _Rule] = OrderedDict()
        default_rule: Optional[_Rule] = None
        sitemap: List[str] = []

        for line in lines:
            line = line.strip()
            if not line:
                if current_rule:
                    current_rule = []
                continue
            # remove optional comment and strip line
            i = line.find('#')
            ps = ''
            if i >= 0:
                ps = line[i + 1:]
                line = line[:i]
            if state == 0:
                last_ps = ps
            else:
                last_ps = ''

            line = line.strip()
            if not line:
                continue
            line_list = line.split(':', 1)
            if not len(line_list) == 2:
                continue

            key = line_list[0].strip().lower()
            val = unquote(line_list[1].strip())
            if key == 'user-agent':
                if val == '*':
                    if not default_rule:
                        default_rule = _Rule(ua='*', allow=[], disallow=[], ps=last_ps, title='所有蜘蛛', crawl_delay=0,
                                             request_rate=(-1, -1))
                    r = default_rule
                else:
                    if val in rule_map:
                        r = rule_map[val]
                    else:
                        r = _Rule(ua=val, allow=[], disallow=[], ps=last_ps, title=cls.ua2title(val), crawl_delay=0,
                                  request_rate=(-1, -1))
                        rule_map[val] = r

                if state == 0:
                    current_rule.append(r)
                if state == 1:  # 解析到了下一个user-agent
                    current_rule = [r]
                    state = 0

            elif key == 'allow':
                state = 1
                if current_rule:
                    for r in current_rule:
                        r.allow.append(val)
            elif key == 'disallow':
                state = 1
                if current_rule:
                    for r in current_rule:
                        r.disallow.append(val)
            elif key == 'crawl-delay':
                state = 1
                if not val.strip().isdigit():
                    continue
                if current_rule:
                    for r in current_rule:
                        r.crawl_delay = int(val)
            elif key == 'request-rate':
                state = 1
                numbers = val.split('/')
                if not len(numbers) == 2:
                    continue
                n, cycle = cls._paser_request_rate(numbers[0], numbers[1])
                if not n or not cycle:
                    continue
                if current_rule:
                    for r in current_rule:
                        r.request_rate = (n, cycle)
            elif key == 'sitemap':
                sitemap.append(val)
        res = cls()
        res._rules = list(rule_map.values())
        res._default_rule = default_rule
        res._sitemap = sitemap
        return res

    @classmethod
    def _paser_request_rate(cls, n, cycle) -> Tuple[Optional[int], Optional[int]]:
        cycle = cycle.strip()
        if not n.isdigit() or not cycle:
            return None, None

        match = cls._REQUEST_RATE_RE.match(cycle)
        if not match:
            return None, None
        num = int(match.group('num') if match.group('num') else "0")
        unit = match.group('unit')
        if not unit:
            return int(n), num
        if unit.lower() in ['minute', 'minutes', 'm']:
            return int(n), num * 60
        elif unit.lower() in ['hour', 'hours', 'h']:
            return int(n), num * 3600
        return None, None

    def can_fetch(self, useragent: str, url: str) -> bool:
        if not self._rules and not self._default_rule:
            return True
        # search for given user agent matches
        # the first match counts
        parsed_url = urlparse(unquote(url))
        url = urlunparse(('', '', parsed_url.path, parsed_url.params, parsed_url.query, parsed_url.fragment))
        url = quote(url)
        if not url:
            url = "/"
        r, weight = None, 0
        for rule in self._rules:
            tmp = rule.weight(useragent)
            if tmp > weight:
                r = rule
                weight = tmp
        if self._default_rule and not r:
            r = self._default_rule
        if r:
            return r.allowance(url)
        return True

    def __repr__(self):
        return "<Robots(Rules=[{}],DefaultRule={},Sitemap={})>".format(
            ",".join([repr(r) for r in self._rules]),
            repr(self._default_rule),
            ",".join(self._sitemap)
        )

    def dump(self) -> str:
        res = []
        for r in self._rules:
            res.append(str(r))

        if self._default_rule:
            res.append(str(self._default_rule))
        if self._sitemap:
            for s in self._sitemap:
                res.append("Sitemap: {}".format(s))

        return "\n".join(res)

    def info(self):
        return {
            "rules": [r.info() for r in (*self._rules, self._default_rule)],
            "sitemap": self._sitemap
        }

    @property
    def sitemap(self):
        return self._sitemap

    @classmethod
    def new(cls, rules: List[dict], sitemap: List[str]) -> 'RoBots':
        res = cls()
        for r in rules:
            r = _Rule.new(r)
            if not r:
                continue
            if r.ua == "*":
                res._default_rule = r
            else:
                res._rules.append(r)
        res._sitemap = sitemap
        return res

    @classmethod
    def build(cls,
              allow_spiders: List[str],
              disallow_spiders: List[str],
              site_map: List[str],
              disallow_path: List[str],
              default_status: bool = True,
              disallow_for_all: bool = False,
              ):
        res = cls()
        res._sitemap = site_map
        for spider in allow_spiders:
            tmp_r = _Rule(
                ua=spider,
                allow=["/"],
                disallow=[],
                title=cls.ua2title(spider),
                crawl_delay=0,
                request_rate=(-1, -1),
                ps=""
            )
            if disallow_for_all:
                tmp_r.disallow = disallow_path
            res._rules.append(tmp_r)
        for spider in disallow_spiders:
            res._rules.append(_Rule(
                ua=spider,
                allow=[],
                disallow=["/"],
                title=cls.ua2title(spider),
                crawl_delay=0,
                request_rate=(-1, -1),
                ps=""
            ))

        res._default_rule = _Rule(
            ua="*",
            allow=["/"],
            disallow=copy.deepcopy(disallow_path),
            title=cls.ua2title("*"),
            crawl_delay=0,
            request_rate=(-1, -1),
            ps=""
        )
        if not default_status:
            res._default_rule.allow = []
            if "/" not in disallow_path:
                res._default_rule.disallow.append("/")

        return res

    def replace_site_map_host(self, domains: List[str], is_https: bool) -> 'RoBots':
        res = self.__class__()
        res._default_rule = copy.deepcopy(self._default_rule)
        res._rules = [copy.deepcopy(r) for r in self._rules]
        new_sitemap = []
        sitemap_uri_list = []
        for i in self._sitemap:
            tmp_url = urlparse(i)
            uri = urlunparse(('', '', tmp_url.path, tmp_url.params, tmp_url.query, tmp_url.fragment))
            if uri not in sitemap_uri_list:
                sitemap_uri_list.append(uri)
                for domain in domains:
                    if is_https:
                        new_sitemap.append("https://" + domain + uri)
                    else:
                        new_sitemap.append("http://" + domain + uri)

        res._sitemap = new_sitemap
        return res


class RoBotsTXTCache:
    FILE_NAME = "{}/site_robots.json".format(public.get_plugin_path("monitor"))

    def __init__(self):
        self._data: Optional[Dict[str, Dict]] = None

    def __load_data(self):
        try:
            data: dict = json.loads(public.readFile(self.FILE_NAME))
            if not data or not isinstance(data, dict):
                self._data = {}
            else:
                self._data = data
            return
        except Exception as e:
            self._data = {}
            return

    def __setitem__(self, key: str, value: dict):
        if self._data is None:
            self.__load_data()
        self._data[key] = value

    def __getitem__(self, key: str, default_value: dict = None) -> Optional[dict]:
        if self._data is None:
            self.__load_data()

        return self._data.get(key, default_value)

    def save_data(self):
        if not self._data:
            return
        public.writeFile(self.FILE_NAME, json.dumps(self._data))


# 用于创建robots.txt简化类
class RoBotCreator:

    def __init__(self, site_name: str):
        self.site_name = site_name
        self._site_info: Optional[dict] = None
        self._disallow_path = []
        self._allow_spider_list = []
        self._disallow_spider_list = []
        self._site_map = []
        self._default_status = True
        self._disallow_all = False  # 是否针对所有蜘蛛都限制访问

    def to_dict(self) -> dict:
        return {
            "disallow_path": self._disallow_path,
            "allow_spider_list": self._allow_spider_list,
            "disallow_spider_list": self._disallow_spider_list,
            "site_map": self._site_map,
            "default_status": self._default_status,
            "disallow_all": self._disallow_all,
        }

    @property
    def site_info(self) -> Optional[dict]:
        if not self._site_info:
            self._site_info = public.M('sites').where('name=?', (self.site_name,)).find()
        return self._site_info

    @property
    def use_https(self) -> bool:
        if not self.site_info:
            return False
        if "https" in self.site_info:
            return bool(self.site_info['https'])
        https = sitetool.site_use_https_by_conf(self.site_info["name"], self.site_info['project_type'])
        self.site_info["https"] = https
        return bool(self.site_info['https'])

    def _site_domain_list(self) -> List[str]:
        if not self.site_info:
            return []
        if "domain_list" in self._site_info:
            return self._site_info['domain_list']

        self._site_info['domain_list'] = sitetool.site_domain_list(self.site_info["name"])
        return self._site_info['domain_list']

    def set_disallow_path(self, disallow: List[str], disallow_all: bool = False):
        disallow = [d.strip() for d in disallow if isinstance(d, str) and d.strip()]
        self._disallow_path = disallow
        self._disallow_all = disallow_all

    def set_site_map(self, site_map: List[str]):
        res = []
        for s in site_map:
            url = urlparse(unquote(s))
            if not url.netloc:
                for d in self._site_domain_list():
                    tmp_url = urlunparse(
                        (
                            "https" if self.use_https else "http", d,
                            quote(url.path, safe="/:"),
                            quote(url.params, safe=";/:"),
                            quote(url.query, safe="=&?:/"),
                            quote(url.fragment, safe="/:"),
                        )
                    )
                    res.append(tmp_url)
            else:
                res.append(urlunparse(
                    (
                        quote(url.scheme, safe=''),
                        quote(url.netloc, safe=':'),
                        quote(url.path, safe='/:'),
                        quote(url.params, safe=';/:'),
                        quote(url.query, safe='=&?:/'),
                        quote(url.fragment, safe='/:'),
                    )
                ))
        self._site_map = res

    def set_default(self, status: bool):
        self._default_status = status

    def set_allow_spider_ua(self, allow_spider_list: List[str]):
        self._allow_spider_list = [s.strip() for s in allow_spider_list if isinstance(s, str) and s.strip()]
        for s in self._allow_spider_list:
            if s in self._disallow_spider_list:
                self._disallow_spider_list.remove(s)

    def set_disallow_spider_ua(self, disallow_spider_list: List[str]):
        self._disallow_spider_list = [s.strip() for s in disallow_spider_list if isinstance(s, str) and s.strip()]
        for s in self._disallow_spider_list:
            if s in self._allow_spider_list:
                self._allow_spider_list.remove(s)

    def build(self) -> RoBots:
        return RoBots.build(
            allow_spiders=self._allow_spider_list,
            disallow_spiders=self._disallow_spider_list,
            site_map=self._site_map,
            disallow_path=self._disallow_path,
            default_status=self._default_status,
            disallow_for_all=self._disallow_all,
        )

    def get_last_data(self):
        rc = RoBotsTXTCache()
        res = rc[self.site_name]
        if res:
            return res

        return {
            "disallow_path": [],
            "allow_spider_list": [],
            "disallow_spider_list": [],
            "site_map": [],
            "default_status": True,
            "disallow_all": False,
        }

    def old_robots(self) -> RoBots:
        default_robots = RoBots.new([
            {
                "ua": "*",
                "allow": ["/"],
                "disallow": [],
                "title": "所有蜘蛛",
                "crawl_delay": 0,
                "request_rate": (-1, -1),
                "ps": ""
            }
        ], [])
        if not self.site_info:
            return default_robots
        run_path = sitetool.site_run_path(self.site_info["name"], self.site_info["project_type"])
        if not os.path.exists(run_path):
            return default_robots

        old = RoBots.load_from_file(os.path.join(run_path, "robots.txt"))
        if old is not None:
            return old
        return default_robots

    def save(self, force: bool) -> Optional[str]:
        robots = self.build()
        data = robots.dump()
        rc = RoBotsTXTCache()
        rc[self.site_name] = self.to_dict()
        rc.save_data()
        return self.save_by_data(data, force)

    def save_by_data(self, data: str, force: bool) -> Optional[str]:
        if not self.site_info:
            return "站点不存在，无法配置"
        run_path = sitetool.site_run_path(self.site_info["name"], self.site_info["project_type"])
        file = os.path.join(run_path, "robots.txt")
        if not force and os.path.exists(file):
            return "robots.txt文件已存在"
        rc = RoBotsTXTCache()
        rc[self.site_name] = self.to_dict()
        rc.save_data()
        has_attr_i = file_attr_i(file)
        if has_attr_i:
            file_attr_del_i(file)
        public.writeFile(file, data)
        public.set_mode(file, "644")
        public.set_own(file, "www")
        if has_attr_i:
            file_attr_add_i(file)
        return None

    def has_old_robots(self) -> bool:
        if not self.site_info:
            return False
        run_path = sitetool.site_run_path(self.site_info["name"], self.site_info["project_type"])
        file = os.path.join(run_path, "robots.txt")
        return os.path.exists(file)

    def save_to_other_site(self, site_name_list: List[str], force: bool) -> Optional[str]:
        sre_robots = self.build()
        target_list = []
        rc = RoBotsTXTCache()
        for site_name in site_name_list:
            site_info = sitetool.get_site_info(site_name)
            if site_info is None:
                return "站点：{} 不存在".format(site_name)
            domain_list = sitetool.site_domain_list(site_info["name"])
            use_https = sitetool.site_use_https_by_conf(site_info["name"], site_info["project_type"])

            new_robots = sre_robots.replace_site_map_host(domain_list, use_https)
            run_path = sitetool.site_run_path(site_info["name"], site_info["project_type"])
            if run_path is None or not os.path.exists(run_path):
                if not force:
                    return "站点：{} 无法获取运行目录".format(site_name)
                else:
                    continue

            file = os.path.join(run_path, "robots.txt")
            if not force and os.path.exists(file):
                return "站点：{} 中已存在robots.txt文件已存在".format(site_name)

            tmp_cache_data = self.to_dict()
            tmp_cache_data["site_map"] = new_robots.sitemap
            rc[site_name] = tmp_cache_data

            target_list.append((file, new_robots.dump()))

        for file, robots_data in target_list:
            has_attr_i = file_attr_i(file)
            if has_attr_i:
                file_attr_del_i(file)
            public.writeFile(file, robots_data)
            public.set_mode(file, "644")
            public.set_own(file, "www")
            if has_attr_i:
                file_attr_add_i(file)

        rc.save_data()
        return None

    @classmethod
    def new_by_args(cls, args: public.dict_obj) -> Union["RoBotCreator", str]:
        site_name = args.get('SiteName/s', '')
        disallow_path = args.get('disallow_path', "")
        disallow_all = args.get('disallow_all', "")
        allow_spider_list = args.get('allow_spider_list', "")
        disallow_spider_list = args.get('disallow_spider_list', '')  # 蜘蛛
        sitemap = args.get('sitemap', '')  # URL地址
        default_status = args.get('default_status', "1")  # ua

        if disallow_all in (1, "1", "true", "True"):
            disallow_all = True
        else:
            disallow_all = False

        res = cls(site_name)
        if disallow_path and isinstance(disallow_path, str):
            tmp = _list_args(disallow_path)
            for i in tmp:
                if not i.startswith('/'):
                    return "错误配置：{}, 路由相关必须以/开头，否则不生效".format(i)
            res.set_disallow_path(tmp, disallow_all=disallow_all)

        if allow_spider_list and isinstance(allow_spider_list, str):
            tmp = _list_args(allow_spider_list)
            res.set_allow_spider_ua(tmp)

        if disallow_spider_list and isinstance(disallow_spider_list, str):
            tmp = _list_args(disallow_spider_list)
            res.set_disallow_spider_ua(tmp)
        if sitemap and isinstance(sitemap, str):
            tmp = _list_args(sitemap)
            res.set_site_map(tmp)

        if default_status in (0, "0", "false", "False"):
            res.set_default(False)

        return res

    # 对比
    def contrast(self):
        new_info = self.build().info()
        old_info = self.old_robots().info()
        old_rule_map = {
            rule["ua"]: rule for rule in old_info["rules"]
        }
        res = []
        for new_rule in new_info["rules"]:
            if new_rule["ua"] in old_rule_map:
                res.append({
                    "new": new_rule,
                    "old": old_rule_map[new_rule["ua"]],
                    "compare": self._compare_rule_data(new_rule, old_rule_map[new_rule["ua"]])
                })
                del old_rule_map[new_rule["ua"]]
            else:
                res.append({
                    "new": new_rule,
                    "old": None,
                    "compare": False
                })
        for old_rule in old_rule_map.values():
            res.append({
                "new": None,
                "old": old_rule,
                "compare": False
            })

        return {
            "rules": res,
            "sitemap": {
                "new": new_info["sitemap"],
                "old": old_info["sitemap"],
                "compare": new_info["sitemap"] == old_info["sitemap"]
            }
        }

    @staticmethod
    def _compare_rule_data(new_rule: dict, old_rule: dict) -> bool:
        fields = ('ua', 'allow', 'disallow', 'crawl_delay', 'request_rate', 'title')
        return all([new_rule.get(field) == old_rule.get(field) for field in fields])


class SpiderConfig:
    _CONFIG_FILE = "/www/server/panel/plugin/monitor/spider_api.config"

    # config = {
    #     "api_map": {
    #         "BaiduSpider":[
    #             {
    #                 "id": "sdfsdjfgsdf",   # 随机字符串
    #                 "name": "百度1",   # 显示名称
    #                 "token": "ASDJFAJSFG",  # 认证信息 不同蜘蛛不一样
    #                 # sites和domains 目前不使用， 为后续扩展留下的
    #                 "sites": ["saa.com"],   # 对应的网站是那些， 若为空，则认为所有网站都适用，都会尝试
    #                 "domains": ["saa.com", "sadfgsd.com"]  # 可使用的域名列表（在百度注册过）， 若为空，则认为所有配置的域名都适用
    #                 "remain": 10 # 余量
    #             }
    #             ...
    #         ]
    #     }
    # }

    def __init__(self):
        tmp_data = self._load()
        if "api_map" in tmp_data:
            self._data = tmp_data["api_map"]
        else:
            self._data = {}

    @classmethod
    def _load(cls) -> Dict[str, Dict]:
        if not os.path.exists(cls._CONFIG_FILE):
            return {}
        try:
            data = public.readFile(cls._CONFIG_FILE)
            data = cls.decrypt_data(data)
            data = json.loads(data)
        except Exception as e:
            return {}

        if not isinstance(data, dict):
            return {}
        return data

    @staticmethod
    def encrypt_data(data: str) -> str:
        iv = b'\x00' * 16
        key = hashlib.sha256("bt-monitor".encode()).digest()[:32]
        backend = default_backend()
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=backend)
        encryptor = cipher.encryptor()

        # 对数据进行 PKCS7 填充
        padder = padding.PKCS7(algorithms.AES.block_size).padder()
        padded_data = padder.update(data.encode()) + padder.finalize()

        # 加密数据
        encrypted_data = encryptor.update(padded_data) + encryptor.finalize()
        return base64.b64encode(encrypted_data).decode("utf-8")

    @staticmethod
    def decrypt_data(data: str) -> str:
        backend = default_backend()
        key = hashlib.sha256("bt-monitor".encode()).digest()[:32]
        iv = b'\x00' * 16
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=backend)
        decryptor = cipher.decryptor()

        # 解密数据
        decrypted_padded_data = decryptor.update(base64.b64decode(data.encode("utf-8"))) + decryptor.finalize()

        # 对数据进行 PKCS7 去填充
        unpadder = padding.PKCS7(algorithms.AES.block_size).unpadder()
        decrypted_data = unpadder.update(decrypted_padded_data) + unpadder.finalize()
        return decrypted_data.decode("utf-8")

    @classmethod
    def _save(cls, data: Dict[str, Dict]):
        data = json.dumps(data)
        data = cls.encrypt_data(data)
        public.writeFile(cls._CONFIG_FILE, data)

    def __getitem__(self, item):
        return self._data[item]

    def list(self) -> List[dict]:
        res = []
        for k, v_list in self._data.items():
            for v in v_list:
                tmp = v.copy()
                tmp.update({"spider": k, "spider_title": self.get_title_by_api_name(k)})
                res.append(tmp)
        return res

    def get(self, item, default=None):
        return self._data.get(item, default)

    def save(self):
        self._save({
            "api_map": self._data
        })

    @staticmethod
    def get_title_by_api_name(api_name: str):
        for i in SpiderAPI.__subclasses__():
            if i.NAME == api_name:
                return i.TITLE
        return ""

    # api_name: 蜘蛛名称， data：具体数据， data中没有id时进行添加，否则修改已有id
    def add_api(self, api_name: str, data: dict) -> Optional[str]:
        if not data:
            return "没有具体的api数据"

        for i in SpiderAPI.__subclasses__():
            if i.NAME == api_name:
                target_cls = i
                break
        else:
            return "未找到可添加的api"

        res = target_cls.check_api_conf(data, self.get(target_cls.NAME, []))
        if res:
            return res

        if not data.get("id", ""):
            data["id"] = uuid.uuid4().hex[::3]

        if "name" not in data:
            data["name"] = "{}_{}".format(api_name, data["id"])

        if "sites" not in data:
            data["sites"] = []

        if "domains" not in data:
            data["domains"] = []

        for i in self._data.get(api_name, []):
            if i.get("id", "") == data.get("id", ""):
                i.update(data)
                break
        else:
            self._data.setdefault(api_name, []).append(data)

        self.save()
        return None

    def remove_api(self, api_name: str, api_id: str) -> Optional[str]:
        for i in self._data.get(api_name, []):
            if i.get("id", "") == api_id:
                self._data[api_name].remove(i)
                break
        else:
            return "未找到对应的api"
        self.save()
        return None


class SpiderAPI:
    NAME = "Spider"
    TITLE = "Spider"
    _AUTH_KEY = tuple()
    _AUTH_KEY_DESCRIPTION = {}
    _LIMIT = 10  # api 一日提交的限制
    QUERY_URL = ""
    QUERY_KEY = ""
    BINARY_KEY = 0  # 用于标识是否进行了推送的，二进制状态压缩

    @classmethod
    def check_api_conf(cls, data: dict, config_list: List[Dict]) -> Optional[str]:
        for i in cls._AUTH_KEY:
            if i not in data:
                return "缺少参数{}".format(i)
        for c in config_list:
            compare = all(data[j] == c[j] for j in cls._AUTH_KEY)
            if compare and c.get("id") != data.get("id", ""):
                return "已存在相同配置的api配置信息"

        return None

    def __init__(self):
        self.scf = SpiderConfig()
        self._target_domains: Optional[List[str]] = None  # 为None表示未初始化
        self._cfg_api_id_list: Optional[List[str]] = None  # 为None表示未初始化
        self._show_on_stdout = False
        self._log_file = None
        self._real_send_url: Set[str] = set()

        self.report: str = ""

    def url_result(self) -> Set[str]:
        return self._real_send_url

    def show_on_stdout(self, *args):
        if args and self._show_on_stdout:
            print(*args, file=sys.stdout, flush=True)
        if self._log_file and os.path.isfile(self._log_file):
            try:
                with open(self._log_file, "a") as f:
                    print(*args, file=f, flush=True)
            except Exception:
                pass

    def set_log_file(self, log_file: str):
        self._log_file = log_file

    def set_show_status(self, show_on_stdout: bool):
        self._show_on_stdout = show_on_stdout

    @classmethod
    def new(cls, name: str) -> Optional['SpiderAPI']:
        for i in cls.__subclasses__():
            if i.NAME == name:
                res = i()
                return res
        return None

    @classmethod
    def create_client(cls, name: str,
                      site_name: Optional[str] = None,
                      domains: Optional[List[str]] = None,
                      api_id_list: Optional[List[str]] = None,
                      ) -> Optional['SpiderAPI']:
        res = cls.new(name)
        if not res:
            return None
        res._target_domains = []
        if api_id_list:  # 设置使用的api接口列表
            res._cfg_api_id_list = api_id_list

        if domains:  # 设置使用的域名，没有设置则使用网站所有域名
            res._target_domains = domains
            return res

        if site_name and not res._target_domains:
            res._target_domains = sitetool.site_domain_list(site_name)

        if not res._target_domains:
            return None
        return res

    def get_conf_list_by_id(self, api_id_list: List[str]) -> List[dict]:
        res = []
        for i in self.scf.get(self.NAME, []):
            if i.get("id", "") in api_id_list:
                res.append(i)
        return res

    def get_default_conf_list(self, site_name: str, domains: List[str]) -> List[dict]:
        conf_list = self.scf.get(self.NAME, [])
        if not conf_list:
            return []

        domains_set = set(domains)

        def get_weight(current_conf: dict) -> int:
            # 判断是否有 site 和 domain 都符合的配置
            weight = 0
            tmp_site = current_conf.get("sites", [])
            tmp_domains = set(current_conf.get("domains", []))
            length = len(domains_set & tmp_domains)
            # weight 100
            if site_name in tmp_site and length:
                weight = 1000 + length

            # weight 10
            if site_name in tmp_site and not tmp_domains:
                weight = 999

            # weight 8
            if length > 0:
                weight = 10 + length

            # weight 1
            if not tmp_site or not tmp_domains:
                weight = 1
            return weight

        res = []
        for i in conf_list:
            tmp_weight = get_weight(i)
            if tmp_weight > 0:
                res.append((tmp_weight, i))

        res.sort(key=lambda x: x[0], reverse=True)
        return [i[1] for i in res]

    def real_send_url(self, domain: str, url_list: List[str], config: dict) -> Tuple[bool, int, str]:
        raise NotImplementedError()

    def send_url(self, site: str, url_list: List[str]) -> Union[List[Dict], str]:
        if not url_list:
            self.show_on_stdout("未指定推送的url")
            return "未指定推送的url"

        if self._target_domains is None:
            self._target_domains = sitetool.site_domain_list(site)

        _api_config_list: List[dict] = []
        if self._cfg_api_id_list:  #
            _api_config_list = self.get_conf_list_by_id(self._cfg_api_id_list)
        else:
            _api_config_list = self.get_default_conf_list(site, self._target_domains)

        if not _api_config_list:
            self.show_on_stdout("未找到可用的api配置")
            return "未找到可用的api配置"

        use_https = sitetool.site_use_https(site)
        res_list = []
        url_data = self.url_list_filter(url_list, self._target_domains, use_https)

        # 推送带域名的uri
        all_url = sum([len(i) for i in url_data.values()])
        config_idx = 0
        for d, tmp_url_list in url_data.items():
            if config_idx >= len(_api_config_list):
                break

            conf = _api_config_list[config_idx]
            last_remain = conf.get("remain", self._LIMIT)
            conf_remain = self._LIMIT  # 默认可用数量
            if 0 < last_remain < conf_remain:
                conf_remain = last_remain
            while tmp_url_list:
                send_list, tmp_url_list = tmp_url_list[:conf_remain], tmp_url_list[conf_remain:]
                flag, conf_remain, msg = self.real_send_url(d, send_list, conf)
                res_list.append({"domain": d, "status": flag, "msg": msg, "api_name": conf.get("name", "***")})
                if flag:  # 如果推送成功，则记录推送成功的uri
                    self._real_send_url.update(send_list)
                    conf["remain"] = conf_remain
                    if conf_remain <= 0:
                        config_idx += 1
                        if config_idx >= len(_api_config_list):
                            break
                else:  # 如果推送失败，则跳过该配置， 并还原url列表
                    tmp_url_list = send_list + tmp_url_list
                    config_idx += 1
                    if config_idx >= len(_api_config_list):
                        break
        if len(self._real_send_url) > 0:
            self.show_on_stdout("{}平台本次推送成功的url如下: ".format(self.TITLE))
        else:
            self.show_on_stdout("{}平台本次推送的url全部推送失败".format(self.TITLE))
        for i in self._real_send_url:
            self.show_on_stdout("\t" + i)

        self.report += "\n本次推送中{}平台有{}条url需要推送，共成功推送{}条url数据".format(self.TITLE, all_url, len(self._real_send_url))

        self.scf.save()
        return res_list

    @staticmethod
    def url_list_filter(url_list: List[str],
                        ellipsis_domains: List[str],
                        use_https: bool = False) -> Dict[str, List[str]]:

        res: Dict[str, List[str]] = {}
        ellipsis_uri = []  # 用 (...) 表示那些，没有指明域名的url
        for i in url_list:
            tmp = urlparse(unquote(i))
            if tmp.netloc:
                tmp_url = urlunparse(
                    (
                        quote(tmp.scheme, safe=''),
                        quote(tmp.netloc, safe=':'),
                        quote(tmp.path, safe='/:'),
                        quote(tmp.params, safe=';/:'),
                        quote(tmp.query, safe='=&?:/'),
                        quote(tmp.fragment, safe='/:'),
                    )
                )
                res.setdefault(tmp.netloc, []).append(tmp_url)
            else:
                tmp_url = urlunparse(
                    (
                        "", "",
                        quote(tmp.path, safe="/:"),
                        quote(tmp.params, safe=";/:"),
                        quote(tmp.query, safe="=&?:/"),
                        quote(tmp.fragment, safe="/:"),
                    )
                )
                ellipsis_uri.append(tmp_url)

        if isinstance(ellipsis_domains, list):
            for d in ellipsis_domains:
                res.setdefault(d, []).extend(
                    ["{}://{}{}".format("https" if use_https else "http", d, i) for i in ellipsis_uri]
                )

        return res

    @classmethod
    def api_template(cls) -> Dict:
        res_map = {
            "title": cls.TITLE,
            "spider": cls.NAME,
            "field_list": []
        }
        for i in cls._AUTH_KEY:
            res_map["field_list"].append({
                "name": i,
                "title": cls._AUTH_KEY_DESCRIPTION.get(i, {}).get("title", ""),
                "description": cls._AUTH_KEY_DESCRIPTION.get(i, {}).get("description", ""),
            })
        res_map["example"] = cls._AUTH_KEY_DESCRIPTION.get("example", "")
        res_map["link"] = cls._AUTH_KEY_DESCRIPTION.get("link", "")
        res_map["help"] = cls._AUTH_KEY_DESCRIPTION.get("help", "")

        return res_map

    # 通过搜索引擎页面信息判断用户的url是否已经被收录了
    @classmethod
    def has_record(cls, data: str) -> bool:
        raise NotImplementedError()

    @classmethod
    def url_record_check(cls, url: str) -> bool:  # 目前还存在问题，暂未使用
        """
        判断url是否已经被收录
        :param url:
        :return:
        """
        if not cls.QUERY_URL or not cls.QUERY_KEY:
            raise NotImplementedError("未配置查询接口")
        if not url or not url.startswith("http"):
            return False
        return cls._url_record_check(url)

    @classmethod
    def _url_record_check(cls, url: str) -> bool:
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36 Edg/129.0.0.0"
        }
        query = {
            cls.QUERY_KEY: url,
        }
        try:
            res = session().get(cls.QUERY_URL, params=query, headers=header, timeout=10)
            if res.status_code == 200:
                public.writeFile("/tmp/{}{}".format(cls.TITLE, time.time()), res.text)
                return cls.has_record(res.text)
            else:
                print(res.status_code)
                public.writeFile("/tmp/{}{}".format(cls.TITLE, time.time()), res.text)
        except:
            traceback.print_exc()
            pass
        return False


class BaiduSpiderAPI(SpiderAPI):
    NAME = "BaiduSpider"
    TITLE = "百度"
    _AUTH_KEY = ("token",)
    _LIMIT = 10  # api 一日提交的限制
    _AUTH_KEY_DESCRIPTION = {
        "token": {
            "title": "token",
            "description": "百度站长平台提供的通行信息",
        },
        "example": ["FsMnEqsOBrQRdqeM", ],
        "link": "https://ziyuan.baidu.com/",
        "help": "https://ziyuan.baidu.com/linksubmit/index",
    }
    QUERY_URL = "https://www.baidu.com/s"
    QUERY_KEY = "wd"
    BINARY_KEY = 1 << 0  # 用于标识是否进行了推送的，二进制状态压缩

    def __init__(self):
        super(BaiduSpiderAPI, self).__init__()
        self._api = "http://data.zz.baidu.com/urls"
        self._headers = {
            "Content-Type": "text/plain",
            "User-Agent": "curl/7.12.1"
        }

    def real_send_url(self, domain: str, url_list: List[str], config: dict) -> Tuple[bool, int, str]:
        if not config or not config.get("token", ""):
            self.show_on_stdout("未获取到配置的token")
            return False, 0, "未配置token"
        else:
            token = config["token"]

        self.show_on_stdout("开始推送域名：{}下的url到{}平台, 本次使用Api名称【{}】".format(domain, self.TITLE, config.get("name", "未命名")))

        # if config.get("domains", None):
        #     if domain not in config["domains"]:
        #         self.show_on_stdout("域名{}不在api配置的域名列表中，未推送".format(domain))
        #         return False, "域名{}不在配置列表中".format(domain)

        api_url = "{}?site={}&token={}".format(self._api, domain, token)
        try:
            resp = session().post(api_url, data="\n".join(url_list), headers=self._headers)
            if resp.status_code == 200:
                data: dict = resp.json()
                msg_list = []
                remain = 0
                if data.get("success", 0):
                    msg_list.append("成功推送{}条链接，剩余可推送数目为：{}".format(data['success'], data['remain']))
                    remain = int(data['remain'])
                else:
                    msg_list.append("推送失败")
                if data.get("not_same_site", []):
                    msg_list.append("非本站链接数量：{}".format(len(data['not_same_site'])))
                if data.get("not_valid", []):
                    msg_list.append("不合法的URL数量：{}".format(len(data['not_valid'])))

                if not msg_list:
                    self.show_on_stdout("未知返回数据:" + resp.text)
                    return False, 0, "未知返回数据:" + resp.text

                self.show_on_stdout("，".join(msg_list))
                return True, remain, "，".join(msg_list)
            else:
                try:
                    data: dict = resp.json()
                    msg = "提交失败:" + data.get("message", "未知错误")
                    msg = self._translate_err(msg)
                    self.show_on_stdout(msg)
                    return False, 0, msg
                except:
                    pass
                    msg = "提交失败:" + resp.text
                    msg = self._translate_err(msg)
                self.show_on_stdout(msg)
                return False, 0, msg
        except:
            self.show_on_stdout("推送失败:", traceback.format_exc())
            return False, 0, "推送失败:" + traceback.format_exc()

    @staticmethod
    def _translate_err(msg: str) -> str:
        return msg.replace(
            "over quota", "over quota (当日配额已用完)"
        ).replace("site error", "site error(站点不在api权限内)")

    @classmethod
    def has_record(cls, data: str) -> bool:
        # 有class="gap-top-small_27Rwt是未被收录的 需要定期验证
        return data.find('class="gap-top-small_27Rwt') == -1


class BingBot(SpiderAPI):
    NAME = "bingbot"
    TITLE = "必应"
    _AUTH_KEY = ("apikey",)
    _LIMIT = 100  # api 一日提交的限制
    _AUTH_KEY_DESCRIPTION = {
        "apikey": {
            "title": "apikey",
            "description": "bing站长平台申请的通行密钥",
        },
        "example": ["cbc56766995e2a56ab2b514c00a92009", ],
        "link": "https://www.bing.com/webmasters/",
        "help": "https://learn.microsoft.com/zh-cn/bingwebmaster/getting-access#using-api-key",
    }
    QUERY_URL = "https://cn.bing.com/search"
    QUERY_KEY = "q"
    BINARY_KEY = 1 << 1  # 用于标识是否进行了推送的，二进制状态压缩

    def __init__(self):
        super(BingBot, self).__init__()
        _host = "https://ssl.bing.com"
        self._submit_api = "{}/webmaster/api.svc/json/SubmitUrlbatch".format(_host)
        self._remain_api = "{}/webmaster/api.svc/json/GetUrlSubmissionQuota".format(_host)
        self._headers = {
            "Content-Type": "application/json;charset=utf-8",
            "User-Agent": "curl/7.12.1"
        }

    def real_send_url(self, domain: str, url_list: List[str], config: dict) -> Tuple[bool, int, str]:
        if not config or not config.get("apikey", ""):
            self.show_on_stdout("推送失败:", "未配置apikey")
            return False, 0, "未配置apikey"
        else:
            apikey = config["apikey"]

        self.show_on_stdout("开始推送域名：{}下的url到{}平台, 本次使用Api名称【{}】".format(domain, self.TITLE, config.get("name", "未命名")))

        # if config.get("domains", None):
        #     if domain not in config["domains"]:
        #         self.show_on_stdout("推送失败:", "域名{}不在api配置的域名列表中，未推送".format(domain))
        #         return False, "域名{}不在api配置的域名列表中".format(domain)
        site_url_up = urlparse(url_list[0])
        data = {
            "siteUrl": urlunparse((site_url_up.scheme, site_url_up.netloc, "", "", "", "")),
            "urlList": url_list
        }
        submit_url = "{}?apikey={}".format(self._submit_api, apikey)
        remain_url = "{}?apikey={}&siteUrl={}".format(self._remain_api, apikey, data["siteUrl"])
        try:
            s = session()
            resp = s.post(submit_url, json=data, headers=self._headers)
            if resp.status_code == 200:
                data: dict = resp.json()  # 正确返回时信息应当为 -> {"d": null}
                if not data.get("d", True) is None:
                    self.show_on_stdout("推送失败: 返回数据不合法->", json.dumps(data))
                    return False, 0, "推送失败，未知原因"
                try:
                    resp = s.get(remain_url, headers=self._headers)
                    if resp.status_code == 200:
                        data: dict = resp.json()
                        msg = "成功推送{}条链接，本月剩余可推送数目为：{}， 今日剩余可推送数目为：{}".format(
                            len(url_list), data["d"]['MonthlyQuota'], data["d"]['DailyQuota']
                        )
                        self.show_on_stdout(msg)
                        return True, int(data["d"]['DailyQuota']), msg
                except:
                    pass
                msg = "成功推送{}条链接, 获取剩余量失败!".format(len(url_list))
                self.show_on_stdout(msg)
                return True, 0, msg
            else:
                try:
                    data: dict = resp.json()
                    self.show_on_stdout("提交失败:", data.get("Message", "未知错误"))
                    return False, 0, data.get("Message", "未知错误")
                except:
                    pass
                self.show_on_stdout("提交失败:", resp.text)
                return False, 0, "提交失败:" + resp.text
        except:
            self.show_on_stdout("推送失败:", traceback.format_exc())
            return False, 0, "推送失败:" + traceback.format_exc()

    @classmethod
    def has_record(cls, data: str) -> bool:
        return data.find('<li class="b_no"><h1>没有与此相关的结果') == -1


class SpiderAPIMgr:
    CRON_CONFIG_FILE = "{}/crontab_spider_config.json".format(public.get_plugin_path("monitor"))

    @classmethod
    def get_url_list(cls, site_name: str, date_range: Tuple[int, int] = None, carry_id: bool = False) -> Union[
        List[str], List[Tuple[str, int]]]:
        """
        @description: 获取指定站点下的url列表
        @param site_name: 站点名称
        @param date_range: 日期范围，格式为(yyyyMMdd, yyyyMMdd)，默认值为None，代表获取前一天的url列表
        @param carry_id: 是否携带uri_id，默认值为False
        @return: Union[List[str], List[Tuple[str, int]]] - 符合条件的url列表，若携带uri_id则为元组列表，否则为字符串列表
        """
        if date_range is None:
            t = datetime.date.today() - datetime.timedelta(days=1)
            date_list = [t]
        else:
            lower = min(date_range)
            upper = max(date_range)
            lower_date = datetime.date(year=lower // 10000, month=(lower % 10000 // 100), day=lower % 100)
            upper_date = datetime.date(year=upper // 10000, month=(upper % 10000 // 100), day=upper % 100)
            date_list = []
            while lower_date <= upper_date:
                date_list.append(lower_date)
                lower_date += datetime.timedelta(days=1)

        uri_id_set = set()
        for d in date_list:
            filename = "/www/server/monitor/data/new_uri/{}_{}.txt".format(site_name, d.strftime("%Y%m%d"))
            data = public.readFile(filename)
            if isinstance(data, str):
                for i in data.split(","):
                    if i and i.isdigit():
                        uri_id_set.add(i)
        if not uri_id_set:
            return []

        return cls.get_uri_list_by_uri_id(site_name, uri_id_set, carry_id)

    @classmethod
    def get_uri_list_by_seo_uri(cls, site_name: str, date_range: Tuple[int, int] = None, ) -> List[str]:
        db_path = cls._get_db_path()

        from monitor_seo import SeoUriData

        if date_range is not None:
            lower = min(date_range)
            upper = max(date_range)
            lower_date = datetime.datetime(year=lower // 10000, month=(lower % 10000 // 100), day=lower % 100)
            upper_date = datetime.datetime(year=upper // 10000, month=(upper % 10000 // 100), day=upper % 100)
            start_time = int(lower_date.timestamp())
            end_time = int(upper_date.replace(hour=23, minute=59, second=59).timestamp())
        else:
            date = datetime.datetime.now() - datetime.timedelta(days=1)
            start_time = int(date.replace(hour=0, minute=0, second=0).timestamp())
            end_time = int(date.replace(hour=23, minute=59, second=59).timestamp())
        data = SeoUriData(site_name, db_path).get_data(
            page=1, size=10000, start_time=start_time, end_time=end_time, disable=False, no_query=None, send_time=False)
        res = [i["loc"] for i in data["data"]]
        return res

    @staticmethod
    def _get_db_path() -> str:
        global_config_file = "/www/server/monitor/config/config.json"
        db_path = None
        try:
            tmp_data = json.loads(public.ReadFile(global_config_file))
            if isinstance(tmp_data, dict):
                db_path = tmp_data["data_save_path"]
        except:
            pass
        if not isinstance(db_path, str) or not os.path.isdir(db_path):
            return ""
        return db_path

    @classmethod
    def get_uri_list_by_uri_id(cls,
                               site_name: str,
                               uri_id_list: Iterable[str],
                               carry_id: bool = False) -> Union[List[str], List[Tuple[str, int]]]:
        """
        @description: 根据uri_id获取uri列表
        @param site_name: 站点名称
        @param uri_id_list: uri_id列表
        @param carry_id: 是否携带uri_id，默认值为False
        @return: Union[List[str], List[Tuple[str, int]]] - 符合条件的uri列表，若携带uri_id则为元组列表，否则为字符串列表
        """
        db_path = cls._get_db_path()
        if not db_path:
            return []
        db_file = "{}/{}/uri_list.db".format(db_path, site_name)
        if not os.path.exists(db_file) or os.path.getsize(db_file) == 0:
            return []

        import db
        db_obj = db.Sql()
        db_obj._Sql__DB_FILE = db_file

        res = db_obj.table("uri_list").where(
            "uri_id IN ({})".format(",".join(uri_id_list)), tuple()
        ).field("uri_id,uri").select()
        db_obj.close()
        if isinstance(res, list):
            if carry_id:
                return [(i["uri"], i["uri_id"]) for i in res]
            return [i["uri"] for i in res]
        return []

    @classmethod
    def get_uri_id_by_uri(cls, site_name: str, uri_list: Iterable[str]) -> Optional[Dict[str, int]]:
        """
        @description: 根据uri获取uri_id列表
        @param site_name: 站点名称
        @param uri_list: uri列表
        @return: Optional[Dict[str, int]] - 符合条件的uri_id字典，键为uri，值为uri_id，若不存在则返回None
        """
        db_path = cls._get_db_path()
        if not db_path:
            return None
        db_file = "{}/{}/uri_list.db".format(db_path, site_name)
        if not os.path.isfile(db_file) or os.path.getsize(db_file) == 0:
            return None

        import db
        db_obj = db.Sql()
        db_obj._Sql__DB_FILE = db_file

        res = db_obj.table("uri_list").where(
            "uri IN ({})".format(",".join(uri_list)), tuple()
        ).field("uri_id,uri").select()
        db_obj.close()
        if isinstance(res, list):
            return {i["uri"]: i["uri_id"] for i in res}
        return None

    @staticmethod
    def add_api(args: public.dict_obj):
        """
        @description: 添加蜘蛛API
        @param spider: 蜘蛛类型
        @param conf_data: 配置数据，格式为json字符串
        @return: Tuple[bool, str] - 第一个元素为是否添加成功，第二个元素为提示信息
        """
        spider = args.get("spider/s", "")
        conf_data = args.get("conf_data/s", "")

        for i in SpiderAPI.__subclasses__():
            if spider == i.NAME:
                break
        else:
            return False, "暂不支持设置的蜘蛛类型"

        try:
            conf_data = json.loads(conf_data)
        except:
            return False, "配置数据格式错误"

        c = SpiderConfig()
        msg = c.add_api(spider, conf_data)
        if msg:
            return False, msg
        else:
            return True, "添加成功"

    @staticmethod
    def api_template() -> List[Dict]:
        """
        @description: 获取蜘蛛API模板
        @return: List[Dict] - 蜘蛛API模板列表
        """
        res = []
        for cls in SpiderAPI.__subclasses__():
            res.append(cls.api_template())
        return res

    @staticmethod
    def get_api_list() -> List[Dict]:
        """
        @description: 获取蜘蛛API列表
        @return: List[Dict] - 蜘蛛API列表
        """
        return SpiderConfig().list()

    @classmethod
    def modify_api(cls, args: public.dict_obj):
        """
        @description: 修改蜘蛛API
        @param spider: 蜘蛛类型
        @param api_id: API ID
        @param conf_data: 配置数据，格式为json字符串
        @return: Tuple[bool, str] - 第一个元素为是否修改成功，第二个元素为提示信息
        """
        flag, msg = cls.add_api(args)
        if flag:
            return True, "修改成功"
        else:
            return False, msg

    @staticmethod
    def remove_api(args: public.dict_obj):
        """
        @description: 删除蜘蛛API
        @param spider: 蜘蛛类型
        @param api_id: API ID
        @return: Tuple[bool, str] - 第一个元素为是否删除成功，第二个元素为提示信息
        """
        spider = args.get("spider/s", "")
        api_id = args.get("api_id/s", "")
        res = SpiderConfig().remove_api(spider, api_id)
        if not res:
            return True, "删除成功"
        else:
            return False, res

    @staticmethod
    def get_send_url_args_data(args: public.dict_obj) -> Union[str, Dict]:
        """
        @description: 获取站点指定推送任务参数
        @param api_id_list 推送API ID列表
        @param url_list 推送URL列表
        @param domains 推送域名列表
        @param spider_list 推送蜘蛛列表
        @param filters 推送过滤列表
        @return {
            "api_id_list": [],
            "url_list": [],
            "site_name": site_name,
            "domains": [],
            "spider_list": [],
            "filters": [],
            "status": False,
        }
        """
        api_id_list = args.get("api_id_list/s", "")  # 指定api进行推送  -> 未填写时将会根据配置选择最合适的api推送
        url_list_data = args.get("url_list/s", "")  # 指定要推送的url -> 未填写时将会推送昨日新增加的url
        site_name = args.get("SiteName/s", "")  # 站点名称 -> 必填
        domains_data = args.get("domains/s", "")  # 指定要推送的域名 -> 只推送指定的域名，不填则推送全部域名（不包含ip）
        spider = args.get("spider/s", "")  # 指定要推送的平台 -> 默认全部都推送，目前可选百度或bing
        filters_str = args.get("filters/s", "")  # 过滤的列表
        status = args.get("status/d", 0)  # 过滤的列表

        filters = []
        if filters_str:
            _tmp: List[Dict[str, Any]] = _list_args(filters_str)
            if _tmp:
                for i in _tmp:
                    if not isinstance(i, dict):
                        return "过滤参数格式错误"
                    if "level" in i and isinstance(i["level"], str):
                        try:
                            i["level"] = int(i["level"])
                        except:
                            return "过滤优先级格式错误，应当为数值"

                    if not isinstance(i, dict) or "exp" not in i or "level" not in i or \
                            not isinstance(i["level"], int) or not isinstance(i["exp"], str) or not i["exp"].strip():
                        return "过滤参数格式错误"
                    i["exp"] = i["exp"].strip()
                    filters.append(i)

        api_ids = []
        if api_id_list:
            _tmp = _list_args(api_id_list)
            if _tmp:
                api_ids = _tmp

        url_list = []
        if url_list_data:
            _tmp = _list_args(url_list_data)
            if _tmp:
                url_list = _tmp

        domains = []
        if domains_data:
            _tmp = _list_args(domains_data)
            if _tmp:
                domains = _tmp

        all_spider = [cls.NAME for cls in SpiderAPI.__subclasses__()]
        if spider:
            if spider not in all_spider and spider != "all":
                return "暂不支持的蜘蛛类型"
            if spider == "all":
                spider_list = all_spider
            else:
                spider_list = [spider]
        else:
            spider_list = all_spider

        if not site_name:
            return "站点名称不能为空"
        return {
            "api_id_list": api_ids,
            "url_list": url_list,
            "site_name": site_name,
            "domains": domains,
            "spider_list": spider_list,
            "filters": filters,
            "status": status,
        }

    @classmethod
    def send_url(cls, args: public.dict_obj, send_async=True):
        """
        @description: 推送URL
        @param args: 推送参数
        @param send_async: 是否异步推送，默认True
        @return: Tuple[bool, str] - 第一个元素为是否推送成功，第二个元素为提示信息
        """
        data = cls.get_send_url_args_data(args)
        if isinstance(data, str):
            return False, data

        if not data["url_list"]:
            data["url_list"] = cls.get_url_list(data["site_name"])

        if not data["url_list"]:
            return False, "没有可推送的url"

        log_file = "{}/send_url_log/{}_{}.log".format(
            public.get_plugin_path('monitor'),
            data["site_name"],
            int(time.time())
        )

        if not os.path.exists(os.path.dirname(log_file)):
            os.makedirs(os.path.dirname(log_file))

        public.writeFile(log_file, "")

        if send_async:
            data["log_file"] = log_file
            args_data = CLI.encode_args_data(data)
            sh = "nohup {}/pyenv/bin/python3.7 {}/spider_tool.py send_url {} &> /dev/null &".format(
                public.get_panel_path(), public.get_plugin_path('monitor'), args_data
            )
            public.ExecShell(sh)
            return True, log_file
        else:
            return cls.send_url_by_cli_data(data, log_file, False)

    @staticmethod
    def get_log_file(site_name: str):
        log_file = "{}/send_url_log/{}_{}.log".format(
            public.get_plugin_path('monitor'),
            site_name,
            int(time.time())
        )

        if not os.path.exists(os.path.dirname(log_file)):
            os.makedirs(os.path.dirname(log_file))

        public.writeFile(log_file, "")
        return log_file

    @classmethod
    def send_url_by_cli_data(cls, cli_data: dict, log_file: str, show_on_stdout=False) -> Dict[str, Dict]:
        res_data = {}
        send_url_data = set()

        report = ""
        for s_name in cli_data["spider_list"]:
            client = SpiderAPI.create_client(
                s_name,
                cli_data["site_name"],
                cli_data["domains"],
                cli_data["api_id_list"]
            )
            if not client:
                res_data[s_name] = {
                    "msg": "指定推送的数据错误",
                    "data": []
                }
                continue

            client.set_log_file(log_file)
            client.set_show_status(show_on_stdout)
            res = client.send_url(cli_data["site_name"], cli_data["url_list"])
            send_url_data.update(client.url_result())

            report += client.report

            if isinstance(res, str):
                res_data[s_name] = {
                    "msg": res,
                    "data": []
                }
            else:
                res_data[s_name] = {
                    "msg": "",
                    "data": res
                }

        if report:
            try:
                with open(log_file, "a") as f:
                    print("\n" + report, file=f, flush=True)
                with open(log_file + ".report", "w") as f:
                    print(report.strip(), file=f, flush=True)
            except Exception:
                pass

        if send_url_data:
            cls.update_send_time(cli_data["site_name"], send_url_data)

        return res_data

    @classmethod
    def get_log_report(cls, filename: str):
        if not os.path.isfile(filename):
            return ""
        report_file = filename + ".report"
        if not os.path.isfile(report_file):
            return ""
        res = public.readFile(report_file)
        if not res:
            return ""
        return res


    # data_set 是推送成功的url的集合
    @classmethod
    def update_send_time(cls, site_name, data_set: Set[str]):
        uri_set = set()
        res = []
        db_path = cls._get_db_path()
        from monitor_seo import SeoUriData
        sud = SeoUriData(site_name, db_path)

        for tmp_url in data_set:
            uri = "/" + tmp_url.split("/", 3)[-1]
            if uri not in uri_set:
                uri_set.add(uri)
                idx = uri.find("?")
                if idx > 0:
                    path, query = uri[:idx], uri[idx + 1:]
                    path_ids = sud.get_path_ids("^{}$".format(path))

                    if not path_ids:
                        continue
                    else:
                        path_id = path_ids[0]

                    query_ids = sud.get_query_ids(query)

                    if not query_ids:
                        continue
                    else:
                        query_id = query_ids[0]
                    res.append((path_id, query_id))
                else:
                    path_ids = sud.get_path_ids("^{}$".format(uri))
                    if not path_ids:
                        continue
                    else:
                        path_id = path_ids[0]
                    res.append((path_id, 0))

        sep = 300
        start_idx = 0
        send_time = int(time.time())
        while res[start_idx:start_idx + sep]:
            sud.set_send_time_by_path_and_query(res[start_idx:start_idx + sep], send_time)
            start_idx += sep

    @classmethod
    def read_cron_conf(cls) -> List[Dict]:
        """
        @description: 读取站点指定推送任务配置
        @return {
            "api_id_list": [],
            "url_list": [],
            "site_name": site_name,
            "domains": [],
            "spider_list": [],
            "filters": [],
            "status": False,
        }
        """
        try:
            data = json.loads(public.readFile(cls.CRON_CONFIG_FILE))
        except:
            data = []
        if not isinstance(data, list):
            data = []
        return data

    @classmethod
    def add_cron_task(cls, args: public.dict_obj):
        """
        @description: 设置站点指定推送任务
        @param SiteName 站点名称
        @param api_id_list 推送API ID列表
        @param url_list 推送URL列表
        @param domains 推送域名列表
        @param spider_list 推送蜘蛛列表
        @param filters 推送过滤列表
        @return {
            "status": False,
        }
        """
        data = cls.get_send_url_args_data(args)
        if isinstance(data, str):
            return False, data

        try:
            # 读取站点指定推送任务配置
            conf = cls.read_cron_conf()
            updated = False
            for item in conf:
                if item["site_name"] == data["site_name"]:
                    item.update(data)
                    updated = True
                    break
            
            if not updated:
                conf.append(data)
            
            # 检查并创建定时任务，如存在则更新
            result = cls.check_cron_task()
            if result and result.get("status") == False:
                return False, result.get("msg", "定时任务创建失败")

            # 保存配置文件[需检测是否可以正常创建定时任务，才给保存]
            public.writeFile(cls.CRON_CONFIG_FILE, json.dumps(conf))

            return True, "设置成功"
        except Exception as e:
            return False, f"设置失败：{str(e)}"

    @classmethod
    def remove_cron_task(cls, args: public.dict_obj):
        """
        @description: 删除站点指定推送任务
        @param SiteName 站点名称
        @return {
            "status": False,
        }
        """
        site_name = args.get("SiteName/s", "")  # 站点名称 -> 必填
        if not site_name:
            return False, "站点名称不能为空"
        conf = cls.read_cron_conf()
        target = None
        for i, item in enumerate(conf):
            if item["site_name"] == site_name:
                target = i
                break

        if target is not None:
            conf.pop(target)

        public.writeFile(cls.CRON_CONFIG_FILE, json.dumps(conf))
        cls.check_cron_task()
        return True, "删除成功"

    @classmethod
    def check_cron_task(cls):
        """
        @description: 检查站点指定推送任务定时任务是否存在，如不存在则创建
        @return {
            "status": True/False,
            "msg": "状态信息"
        }
        """
        if public.M('crontab').where('name=?', '宝塔监控报表-URL定时推送任务').find():
            return public.returnMsg(True, '定时任务已存在!')

        if cls.check_syssafe():
            return public.returnMsg(False, '推送任务创建失败！请先关闭【系统加固】')

        import crontab
        crontabs = crontab.crontab()
        sh = "{}/pyenv/bin/python3.7 -u {}/spider_tool.py cron_task".format(
            public.get_panel_path(), public.get_plugin_path('monitor')
        )

        args = {
            "name": "宝塔监控报表-URL定时推送任务",
            "type": 'day',
            "where1": '',
            "hour": '1',
            "week": "",
            "minute": '10',
            "sName": 'toShell',
            "sType": 'toShell',
            "notice": '',
            "notice_channel": '',
            "save": '',
            "save_local": '1',
            "backupTo": '',
            "sBody": sh,
            "urladdress": '',
            "status": "1"
        }
        res = crontabs.AddCrontab(args)
        if res["status"] and "id" in res.keys():
            return public.returnMsg(True, '定时任务添加成功!')
        return public.returnMsg(False, '定时任务添加失败')

    # * 代表0个或多个任意字符串
    # 除此之外的字符都要做反义处理
    @staticmethod
    def filter_uri_str2regexp(filter_uri: str) -> Optional[re.Pattern]:
        buffer = []
        start = 0
        for i, c in enumerate(filter_uri):
            if c == '*':
                if start < i:
                    buffer.append(re.escape(filter_uri[start:i]))
                buffer.append(".*")
                start = i + 1
        if start < len(filter_uri):
            buffer.append(re.escape(filter_uri[start:]))

        exp_str = ''.join(buffer)
        try:
            rexp = re.compile(exp_str)
            return rexp
        except re.error as e:
            return None

    @classmethod
    def check_syssafe(cls, args=None):
        """
        @description: 检查系统加固插件是否开启
        @return: bool - True表示系统加固已开启，False表示未开启或插件不存在
        """
        try:
            # 检查系统加固插件目录是否存在
            syssafe_plugin_path = '/www/server/panel/plugin/syssafe/'
            if not os.path.exists(syssafe_plugin_path):
                return False
            
            # 检查配置文件是否存在
            config_file_path = os.path.join(syssafe_plugin_path, 'config.json')
            if not os.path.exists(config_file_path):
                return False
            
            # 读取配置文件内容
            config_content = public.readFile(config_file_path)
            if not config_content:
                return False
            
            # 解析JSON配置
            try:
                config_data = json.loads(config_content)
            except (json.JSONDecodeError, ValueError) as e:
                # JSON解析失败，记录错误但不抛出异常
                return False
            
            # 检查配置数据是否为字典类型
            if not isinstance(config_data, dict):
                return False
            
            # 获取open字段的值，默认为False
            open_status = config_data.get('open', False)
            
            # 确保返回值为布尔类型
            if isinstance(open_status, bool):
                return open_status
            elif isinstance(open_status, (int, str)):
                # 处理可能的数值或字符串类型
                return bool(open_status) and str(open_status).lower() not in ('0', 'false', 'off', 'no')
            else:
                return False
                
        except Exception as e:
            # 捕获所有其他异常，确保方法不会崩溃
            return False

    @classmethod
    def filters_uri_list(cls, new_uri_list: List[str], filters: List[Dict[str, Any]]):
        level_map = {}
        rule_list: List[Tuple[re.Pattern, int]] = []
        for rule in filters:
            res = cls.filter_uri_str2regexp(rule["exp"])
            if res:
                rule_list.append((res, rule["level"]))

        rule_list.sort(key=lambda x: x[1])
        for rule_exp, level in rule_list:
            for idx in range(len(new_uri_list) - 1, -1, -1):
                uri = new_uri_list[idx]
                if rule_exp.findall(uri):
                    if level < 0:
                        new_uri_list.pop(idx)
                    level_map[uri] = level

        new_uri_list.sort(key=lambda x: level_map.get(x, 0), reverse=True)
        return new_uri_list

    @classmethod
    def get_cron_task_uri_list(cls, site_name: str, filters: List[Dict[str, Any]]) -> List[str]:
        """
        @description: 获取定时任务下的url列表
        @param site_name: 站点名称
        @param filters: 过滤规则
        @return: List[str] - 符合过滤规则的url列表
        """
        new_uri_list = set(cls.get_url_list(site_name))
        new_uri_list.update(cls.get_uri_list_by_seo_uri(site_name))
        new_uri_list = cls.filters_uri_list(list(new_uri_list), filters)
        return new_uri_list

    @classmethod
    def run_cron_task(cls):
        """
        @description: 运行定时任务
        @return: None
        """
        config_list = cls.read_cron_conf()
        all_site = sitetool.get_site_list()
        if not config_list:
            print("暂无定时任务")
            return
        if not all_site:
            print("暂无站点")
            return
        target_site = []
        has_all = None
        for item in config_list:
            if item.get("status", 1) not in (1, True, "true"):
                continue
            if item["site_name"] == "all":
                has_all = item
                continue

            if item["site_name"] not in all_site:
                print("站点不存在：{}".format(item["site_name"]))
                continue
            item["url_list"].extend(cls.get_cron_task_uri_list(item["site_name"], item.get("filters", [])))
            if not item["url_list"]:
                print("站点：{}下没有可推送的url".format(item["site_name"]))
                continue
            target_site.append(item)
            all_site.remove(item["site_name"])

        if has_all:
            for i in all_site:
                tmp = has_all.copy()
                tmp["site_name"] = i

                tmp["url_list"].extend(cls.get_cron_task_uri_list(i, tmp.get("filters", [])))
                if not tmp["url_list"]:
                    print("站点：{}下没有可推送的url".format(tmp["site_name"]))
                    continue
                target_site.append(tmp)

        print("-" * 50)
        for item in target_site:
            print("开始推送：{} 站点下的url".format(item["site_name"]))
            log_file = "{}/send_url_log/{}_{}.cron.log".format(
                public.get_plugin_path('monitor'), item["site_name"], int(time.time())
            )
            if not os.path.exists(os.path.dirname(log_file)):
                os.makedirs(os.path.dirname(log_file))

            public.writeFile(log_file, "")
            res = cls.send_url_by_cli_data(item, show_on_stdout=True, log_file=log_file)


class CLI:

    def __init__(self, args: List[str]):
        self._action = None if len(args) == 0 else args[0]
        self._args = None if len(args) <= 1 else args[1:]

    @staticmethod
    def encode_args_data(args: Any) -> str:
        return base64.b64encode(json.dumps(args).encode("utf-8")).decode("utf-8")

    @staticmethod
    def decode_args_data(args: str) -> Any:
        try:
            return json.loads(base64.b64decode(args.encode("utf-8")).decode("utf-8"))
        except:
            return None

    def send_url(self):
        args_data: dict = self.decode_args_data(self._args[0])
        if not args_data:
            print("参数错误")
            return

        return SpiderAPIMgr.send_url_by_cli_data(args_data, args_data["log_file"], show_on_stdout=True)

    @staticmethod
    def cron_task():
        SpiderAPIMgr.run_cron_task()

    def run(self):
        if self._action is None:
            return
        try:
            return getattr(self, self._action)()
        except:
            traceback.print_exc()


if __name__ == "__main__":
    cli = CLI(sys.argv[1:])
    cli.run()
