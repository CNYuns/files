-- 其他蜘蛛信息
CREATE TABLE IF NOT EXISTS spiders
(
    `id`      INTEGER PRIMARY KEY AUTOINCREMENT, -- ID
    `name`    TEXT UNIQUE NOT NULL,              -- 名称
    `ua_key`  TEXT DEFAULT '',                   -- UA关键字, 预留, 以','作为分隔符
    `name_cn` TEXT DEFAULT ''                    -- 中文名称
);

CREATE INDEX IF NOT EXISTS spider_name ON spiders (`name`);


-- 其他蜘蛛信息的UA信息
CREATE TABLE IF NOT EXISTS spiders_ua
(
    `id`        INTEGER PRIMARY KEY AUTOINCREMENT, -- ID
    `spider_id` INTEGER NOT NULL,                  -- 爬虫ID
    `ua`        TEXT DEFAULT ''                    -- UA完整信息
);

CREATE INDEX IF NOT EXISTS spider_ua_spider_id ON spiders_ua (`spider_id`);
