-- ERFERER列表
CREATE TABLE IF NOT EXISTS `referer_list` (
    `referer_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `referer` TEXT DEFAULT "" NOT NULL
);

-- 增加唯一索引
CREATE UNIQUE INDEX IF NOT EXISTS `idx_referer` ON `referer_list` (`referer`);