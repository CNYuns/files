import os
import sys
import re
import sqlite3
import traceback
from datetime import datetime, timedelta
import concurrent.futures
import hashlib
from typing import List, Dict, Any, Tuple, Optional, Union, Callable

DEBUG = False
if "/www/server/panel" not in sys.path:
    sys.path.insert(0, "/www/server/panel")

if "/www/server/panel/plugin/monitor" not in sys.path:
    sys.path.insert(0, "/www/server/panel/plugin/monitor")
elif not sys.path.index("/www/server/panel/plugin/monitor") == 0:
    sys.path.remove("/www/server/panel/plugin/monitor")
    sys.path.insert(0, "/www/server/panel/plugin/monitor")

from cache_tool import TTLCache

ssCache = TTLCache(maxsize=100, ttl=60 * 10)


def get_cache(key: str, default: Any = None) -> Any:
    try:
        return ssCache.get(key)
    except KeyError:
        return default


def set_cache(key: str, value: Any) -> None:
    ssCache[key] = value


def debug(msg: Any):
    if DEBUG:
        import public
        public.print_log(msg)


# 只支持使用 时间做排序，其他的无法排序
# 如果要支持其他的数据库拆分需要修改源码
class SSqlite:
    # 通过自增id，进行count计数，否则数据库超过一个G将会很慢
    # 需要提前知道主键名称和时序字段的名称
    # 如果where查询的字段只有时序相关的，count统计时可以使用前后查询（因为数据库不会在中间删除某个数据），降低Count查询导致的性能问题
    _TABLE_KEY_AND_TIME_FIELD = {
        "access_log": ("access_id", "request_time"),
        "error_logs": ("error_id", "time"),
        "session_list": ("session_id", "date"),
    }
    FIELD_PATTERN = re.compile(
        r'(?P<f>\w+)\s*(?P<r>=|<|>|<=|>=|<>|!=|(NOT\s*)?IN|(NOT\s+)?LIKE)\s*(?P<v>[^\s=><]+)',
        re.I
    )

    # db_path: str = '' 数据库目录
    # db_name: str = '' 数据库名称
    # time_range: List[Union[int, str]] = [] 数据时间范围、
    # smart_default： 当可用数据库仅有默认数据库（未分表的数据库）（不存在其他可用数据库）时，自动将默认数据库选中
    def __init__(self, db_path: str, db_name: str, time_range: List[Union[int, str]], smart_default: bool = False):
        self.db_path: str = db_path
        self.db_name: str = db_name
        self.range_time: Tuple[int, int] = (0, 21001231)
        self.db_key_list: List[int] = []
        self.table_name: str = ''
        self.opt_field: str = '*'
        self.opt_where: str = ''
        self.opt_order: Optional[Tuple[str, bool]] = None
        self.opt_limit: Optional[Tuple[int, int]] = None
        self.opt_group_by: str = ''
        self.opt_param = []
        self.smart_default = smart_default
        self._set_db_file(time_range)
        debug(self.db_key_list)
        debug(self.range_time)
        self.error = ''
        self.pre_cache_key = '{}_{}_{}_{}'.format(self.db_path, self.db_name, self.range_time[0], self.range_time[1])

    # 如果where查询的字段只有时序相关的，count统计时可以使用前后查询（因为数据库不会在中间删除某个数据），降低Count查询导致的性能问题
    def parser_time_field(self) -> Tuple[Optional[str], Optional[str]]:
        if self.table_name not in self._TABLE_KEY_AND_TIME_FIELD:
            return None, None
        time_field = self._TABLE_KEY_AND_TIME_FIELD[self.table_name][1]
        fields = set()
        param_index = 0
        left, right = "", ""
        debug(self.opt_where)
        for i in self.FIELD_PATTERN.finditer(self.opt_where):
            f = i.group('f')
            fields.add(f)
            if f == time_field:
                if i.group("r") in ("<", "<="):
                    v = i.group("v")
                    if v == "?":
                        v = self.opt_param[param_index]
                    right = "{} <= {} ".format(time_field, v)
                elif i.group("r") in (">", ">="):
                    v = i.group("v")
                    if v == "?":
                        v = self.opt_param[param_index]
                    left = "{} >= {} ".format(time_field, v)
                elif i.group("r") == "=":
                    v = i.group("v")
                    if v == "?":
                        v = self.opt_param[param_index]
                    left = "{} = {} ".format(time_field, v)
                    right = "{} = {} ".format(time_field, v)
            if i.group("v") == "?":
                param_index += 1

        if time_field in fields:
            fields.remove(time_field)
        if len(fields) == 0:
            return left, right
        else:
            return None, None

    def cache_key(self, msg: str):
        m5 = hashlib.md5()
        m5.update('{}_{}'.format(self.pre_cache_key, msg).encode())
        return m5.hexdigest()

    def _set_db_file(self, time_range: List[int]) -> None:
        if not os.path.exists(self.db_path):
            raise FileNotFoundError("错误：指定数据库文件不存在 {}".format(self.db_path))

        self.range_time = self.time_range_handle(time_range)
        self.get_db_key_list()

    @staticmethod
    def time_range_handle(time_range: List[Union[int, str]]) -> Tuple[int, int]:
        if len(time_range) == 0 or len(time_range) > 2:
            return 0, 21001231
        for i in range(len(time_range)):
            if isinstance(time_range[i], str) and re.match(r'^\d{4}-\d{2}-\d{2}$', time_range[i]):
                time_range[i] = int(time_range[i].replace('-', ''))

        # 处理单个值的情况
        if len(time_range) == 1:
            if time_range[0] <= 21001231:
                return time_range[0], 21001231
            else:
                dt = datetime.fromtimestamp(time_range[0])
                tmp_date = int(dt.year * 10000 + dt.month * 100 + dt.day)
                if tmp_date <= 21001231:
                    return tmp_date, 21001231
                else:
                    return 0, 21001231

        # 处理两个值的情况
        if time_range[0] <= 21001231 and time_range[1] <= 21001231:
            if time_range[0] < time_range[1]:
                return time_range[0], time_range[1]
            else:
                return time_range[1], time_range[0]
        else:
            dt1 = datetime.fromtimestamp(time_range[0])
            dt2 = datetime.fromtimestamp(time_range[1])
            r1 = int(dt1.year * 10000 + dt1.month * 100 + dt1.day)
            r2 = int(dt2.year * 10000 + dt2.month * 100 + dt2.day)

            if r1 > r2:
                return r2, r1
            else:
                return r1, r2

    def get_db_key_list(self) -> None:
        dirs = [
            f for f in os.listdir(self.db_path)
            if os.path.isfile(os.path.join(self.db_path, f)) and f.startswith(self.db_name)
        ]
        res_list = []
        has_default = False
        for fs in dirs:
            if fs == self.db_name + ".db":
                has_default = True
                res_list.append(0)
            if fs.startswith(self.db_name + "-") and fs.endswith(".db"):
                match = re.search(r'-(\d{8})\.db', fs)
                if match:
                    date = int(match.group(1))
                    res_list.append(date)

        if not res_list:
            self.db_key_list = []
            return
            raise ValueError("错误：数据库文件不存在")

        res_list.sort()
        res_list = [0] + res_list + [21001231]
        left, right = 0, len(res_list) - 1
        for i in range(len(res_list) - 1):
            if res_list[i] <= self.range_time[0] <= res_list[i + 1]:
                left = i
            if res_list[i] <= self.range_time[1] <= res_list[i + 1]:
                right = i
        self.db_key_list = res_list[left:right + 1]
        if not has_default and 0 in self.db_key_list:
            self.db_key_list.remove(0)
        if has_default and self.smart_default and not self.db_key_list:
            self.db_key_list = [0]

    def table(self, table_name: str) -> 'SSqlite':
        self.table_name = table_name
        return self

    def field(self, fields: Union[str, List[str]]) -> 'SSqlite':
        if isinstance(fields, list):
            fields = ','.join(fields)

        self.opt_field = str(fields)
        return self

    def limit(self, *args) -> 'SSqlite':
        if len(args) < 1:
            return self
        elif len(args) == 1:
            start, number = 0, int(args[0])
        else:
            start, number = int(args[0]), int(args[1])
        self.opt_limit = max(0, start), max(number, 1)
        return self

    def order(self, field_name: str, sort_order: str) -> 'SSqlite':
        reverse = sort_order.lower() in ('desc', 'descending', 'd')
        self.opt_order = field_name, reverse
        return self

    def where(self, where: str, params: List[Any]) -> 'SSqlite':
        self.opt_where = where
        self.opt_param = params
        return self

    def group_by(self, group_by: str) -> 'SSqlite':
        self.opt_group_by = "GROUP BY {}".format(group_by)
        return self

    def select(self) -> List[Dict[str, Any]]:
        if not self.table_name:
            raise ValueError("错误：未指定要操作的表名")

        sql = "SELECT {} FROM {}".format(self.opt_field, self.table_name)

        if self.opt_where:
            sql += ' WHERE {}'.format(self.opt_where)

        if self.opt_group_by:
            sql += ' ' + self.opt_group_by

        if self.opt_order:
            sql += ' ORDER BY {} {}'.format(self.opt_order[0], "ASC" if not self.opt_order[1] else "DESC")

        db_key_list = [(i, tuple()) for i in self.db_key_list]
        reverse = True
        if self.opt_limit and len(db_key_list) == 1:
            db_key_list = [(self.db_key_list[0], self.opt_limit)]
        if self.opt_limit and len(db_key_list) > 1:
            start, count = self.opt_limit
            db_key_list = []
            count_data = [(c, k) for k, c in self.count().items()]
            debug(count_data)
            if self.opt_order and not self.opt_order[1]:
                reverse = False
            count_data.sort(key=lambda x: x[1], reverse=reverse)
            tmp, need_assign = 0, count
            for c, k in count_data:
                tmp = tmp + c
                if tmp > start:
                    _start = max(start - (tmp - c), 0)
                    db_key_list.append(
                        (k, (_start, need_assign))
                    )
                    need_assign = need_assign - c + _start
                if tmp >= start + count:
                    break
        debug(str(self.db_key_list))
        debug(str(db_key_list))
        if not db_key_list:
            return []

        # 创建线程池
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(db_key_list)) as executor:
            future_to_conn = [
                executor.submit(self._execute_query, key, sql, self.opt_param, limit) for key, limit in db_key_list
            ]
            results = {}
            for future in concurrent.futures.as_completed(future_to_conn):
                try:
                    key, res = future.result()
                    results[key] = res
                except Exception as exc:
                    print(f"执行查询时发生异常: {exc}")
                    debug(traceback.format_exc())

        res = []
        for _, v in sorted(results.items(), key=lambda x: x[0], reverse=reverse):
            res.extend(v)

        return res

    def _execute_query(self,
                       key: int,
                       sql: str,
                       params: List[Any],
                       limit: Tuple[int, int]) -> Tuple[int, List[Dict[str, Any]]]:
        if key == 0:
            db_file = self.db_path + "/" + self.db_name + ".db"
        else:
            db_file = self.db_path + "/" + self.db_name + "-" + str(key) + ".db"
        if not os.path.exists(db_file) or os.path.getsize(db_file) == 0:
            return key, []
        if len(limit) > 0:
            sql += " LIMIT {}, {}".format(*limit)
        debug(sql)
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()
        cursor.execute(sql, params)
        columns = [col[0] for col in cursor.description]
        return key, [dict(zip(columns, row)) for row in cursor.fetchall()]

    def find(self) -> Optional[Dict[str, Any]]:
        self.limit(1)
        results = self.select()
        return results[0] if results else None

    def count_by_key(self, left_where, right_where) -> Dict[int, int]:
        key_field = self._TABLE_KEY_AND_TIME_FIELD[self.table_name][0]

        left_sql = "SELECT {} FROM {} WHERE {} ORDER BY {} ASC LIMIT 1".format(
            key_field, self.table_name, left_where, key_field
        )

        right_sql = "SELECT {} FROM {} WHERE {} ORDER BY {} DESC LIMIT 1".format(
            key_field, self.table_name, right_where, key_field
        )

        result_dict = dict()
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(self.db_key_list)) as executor:
            future_to_conn = [
                executor.submit(self._execute_count_by_key, k, left_sql, right_sql, self.opt_param) for k in self.db_key_list
            ]
            for future in concurrent.futures.as_completed(future_to_conn):
                try:
                    key, result = future.result()
                    result_dict[key] = result
                except Exception as exc:
                    print(traceback.format_exc())
                    print(f"执行查询时发生异常: {exc}")

        return result_dict

    def _execute_count_by_key(self, key: int, left_sql: str, right_sql: str, params: List[Any]) -> Tuple[int, int]:
        if key != 0:
            db_file = self.db_path + "/" + self.db_name + "-" + str(key) + ".db"
        else:
            db_file = self.db_path + "/" + self.db_name + ".db"
        if not os.path.exists(db_file) or os.path.getsize(db_file) == 0:
            return key, 0
        try:
            conn = sqlite3.connect(db_file)
            cursor = conn.cursor()

            cursor.execute(left_sql, tuple())
            left = cursor.fetchone()[0]

            cursor.execute(right_sql, tuple())
            right = cursor.fetchone()[0]

            cursor.close()
            conn.close()
            return key, right - left + 1
        except Exception as e:
            debug(traceback.format_exc())
            print(f"Error executing query: {e}")
            return key, 0

    def count(self) -> Dict[int, int]:
        if not self.table_name:
            raise ValueError("错误：未指定要操作的表名")

        sql = "SELECT COUNT(*) AS count FROM {}".format(self.table_name)

        if self.opt_where:
            sql += ' WHERE {}'.format(self.opt_where)

        if self.opt_group_by:
            sql += ' ' + self.opt_group_by

        cached_result = get_cache(self.cache_key(sql + str(self.opt_param)))
        if cached_result is not None:
            return cached_result

        if not self.db_key_list:
            return {0: 0}

        left_where, right_where = self.parser_time_field()
        if left_where is not None and right_where is not None:
            debug("only_time_field")
            return self.count_by_key(left_where, right_where)

        result_dict = dict()
        # 创建线程池
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(self.db_key_list)) as executor:
            future_to_conn = [
                executor.submit(self._execute_count, k, sql, self.opt_param) for k in self.db_key_list
            ]
            for future in concurrent.futures.as_completed(future_to_conn):
                try:
                    key, result = future.result()
                    result_dict[key] = result
                except Exception as exc:
                    print(traceback.format_exc())
                    print(f"执行查询时发生异常: {exc}")

        # 更新缓存
        set_cache(self.cache_key(sql + str(self.opt_param)), result_dict)

        return result_dict

    def _execute_count(self, key: int, sql: str, params: List[Any]) -> Tuple[int, int]:
        if key == 0:
            db_file = self.db_path + "/" + self.db_name + ".db"
        else:
            db_file = self.db_path + "/" + self.db_name + "-" + str(key) + ".db"
        if not os.path.exists(db_file) or os.path.getsize(db_file) == 0:
            return key, 0
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()
        cursor.execute(sql, params)
        result = cursor.fetchone()[0]
        conn.close()
        return key, result

    def with_iter_db(self, func: Callable[["SSqlite"], bool]):
        old_db_key_list = self.db_key_list
        try:
            for db_key in old_db_key_list:
                self.db_key_list = [db_key]
                res = func(self)
                if  not res:
                    break
        except:
            pass
        self.db_key_list = old_db_key_list



class DbID(int):
    db_id_date_mask = (1 << 20) - 1  # 20位掩码
    db_id_sep_mask = (1 << 38) - 1  # 38位掩码

    def db_key(self) -> str:
        enable = self >> 62 & 1
        if enable == 0:
            return ""
        date = (self >> 38) & self.db_id_date_mask
        return "-{:08d}".format(20000000 + date)

    def date(self) -> int:
        enable = self >> 62 & 1
        if enable == 0:
            return 0
        date = (self >> 38) & self.db_id_date_mask
        return 20000000 + date

    def date_after(self, days: int) -> int:
        date = self.date()
        if date == 0:
            return 0
        y, md = divmod(date, 10000)
        m, d = divmod(md, 100)
        this_date = (datetime(y, m, d) + timedelta(days=days)).date()
        return this_date.year * 10000 + this_date.month * 100 + this_date.day

    def date_before(self, days: int) -> int:
        return self.date_after(-days)

    def enable(self) -> bool:
        return bool(self >> 62 & 1)

    def sep(self) -> int:
        return self & self.db_id_sep_mask

    @classmethod
    def _db_start_id(cls, enable=True, reserved=0, date=None):
        if date is None or date <= 0:
            return 0

        enable_bit = 1 << 62 if enable else 0
        reserved_bits = (reserved & 0xF) << 58  # 保留位，最多4位

        date_part = (date - 20000000) << 38

        id_ = enable_bit | reserved_bits | date_part
        return cls(id_)

    @classmethod
    def db_start_id_now(cls):
        now = datetime.now()
        date_part = now.year * 10000 + now.month * 100 + now.day
        return cls._db_start_id(True, 0, date_part)
