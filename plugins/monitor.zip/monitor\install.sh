#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
PanelPath=/www/server/panel
PluginPath=$PanelPath/plugin/monitor
SetupPath=/www/server/monitor

Install_Nginx_monitor()
{
    
    # create monitor directory
    if [ ! -d $SetupPath ];then
        mkdir -p $SetupPath
    fi
    # 处理二进制文件
    Install_monitor_bin
    # 处理其他静态文件
    Copy_Static_file

    # nginx log format
    \cp -arf $PluginPath/monitor/config/nginx_log_format.conf $SetupPath/config/nginx_log_format.conf

    # sub panel nginx log format
    nginx_log_format_file=$PanelPath/vhost/nginx/0.monitor_log_format.conf
    \cp -arf $SetupPath/config/nginx_log_format.conf $nginx_log_format_file
    chmod 600 $nginx_log_format_file


    # build ipfilter
    if [ -f "${SetupPath}/ipfilter" ];then
      rm -rf $SetupPath/ipfilter
    fi
    echo "Compiling ipfilter"
    bash $PluginPath/monitor/ipfilter/build_ipfilter.sh

    Set_systemd_service

    echo "Installing monitor via python"
    /www/server/panel/pyenv/bin/python3 /www/server/panel/plugin/monitor/service.py install

    /etc/init.d/nginx reload
	  echo 'Successfully!'
}

Install_Apache_monitor()
{
    # create monitor directory
    if [ ! -d $SetupPath ];then
        mkdir -p $SetupPath
    fi
    # 处理二进制文件
    Install_monitor_bin
    # 处理其他静态文件
    Copy_Static_file

    # apache log format
    \cp -arf $PluginPath/monitor/config/apache_log_format.conf $SetupPath/config/apache_log_format.conf
    # sub panel apache log format
    apache_log_format_file=$PanelPath/vhost/apache/0.monitor_log_format.conf
    \cp -arf $SetupPath/config/apache_log_format.conf $apache_log_format_file
    chmod 600 $apache_log_format_file

    # build ipfilter
    if [ -f "${SetupPath}/ipfilter" ];then
      rm -rf $SetupPath/ipfilter
    fi
    echo "Compiling ipfilter"
    bash $PluginPath/monitor/ipfilter/build_ipfilter.sh

    Set_systemd_service

    echo "Installing monitor via python"
    /www/server/panel/pyenv/bin/python3 /www/server/panel/plugin/monitor/service.py install

    /etc/init.d/httpd reload
	  echo 'Successfully!'
}

Install_monitor_bin()
{
    # check the cpu architecture
    is64bit="x86_64"
    is_aarch64=$(uname -a | grep aarch64)
    if [ "$is_aarch64" != "" ]; then
        is64bit="aarch64"
    fi

    # copy monitor bin file
    if [[ "${is64bit}" == "aarch64" ]]; then
        Download_ARM_bin
        \cp -arf $PluginPath/monitor/monitor-arm64 $SetupPath/monitor

    else
        \cp -arf $PluginPath/monitor/monitor-amd64 $SetupPath/monitor

    fi
    chmod 700 $SetupPath/monitor
}

Download_ARM_bin()
{
  if [ -f "/www/server/panel/install/public.sh" ]; then
    source /www/server/panel/install/public.sh
  else
    NODE_URL='https://download.bt.cn'
  fi
  wget -O $PluginPath/monitor/monitor-arm64 ${NODE_URL}/src/monitor-arm64-3.7
}

Copy_Static_file()
{
    # create data directory
    if [ ! -d $SetupPath/data/sql ];then
        mkdir -p $SetupPath/data/sql
    fi
    # copy data files
    \cp -arf $PluginPath/monitor/data/sql/* $SetupPath/data/sql/

    if [ ! -d $SetupPath/data/dbs/global ];then
        mkdir -p $SetupPath/data/dbs/global
    fi

    # copy spider_ip_list.db
    if [ ! -f $SetupPath/data/dbs/global/spider_ip_list.db ];then
        \cp -arf $PluginPath/monitor/data/dbs/global/spider_ip_list.db $SetupPath/data/dbs/global/spider_ip_list.db
    fi

    # copy spider_ip_list.db zero
    f_size=$(du -b $SetupPath/data/dbs/global/spider_ip_list.db | awk '{print $1}')
    if [ $f_size -lt 100 ];then
        \cp -arf $PluginPath/monitor/data/dbs/global/spider_ip_list.db $SetupPath/data/dbs/global/spider_ip_list.db
    fi

    # copy other_spiders.db
    if [ ! -f $SetupPath/data/dbs/global/spider_ip_list.db ];then
        \cp -arf $PluginPath/monitor/data/dbs/global/other_spiders.db $SetupPath/data/dbs/global/other_spiders.db
    fi

    # copy other_spiders.db zero
    f_size=$(du -b $SetupPath/data/dbs/global/other_spiders.db | awk '{print $1}')
    if [ $f_size -lt 100 ];then
        \cp -arf $PluginPath/monitor/data/dbs/global/other_spiders.db $SetupPath/data/dbs/global/other_spiders.db
    fi

    # create config directory
    if [ ! -d $SetupPath/config ];then
        mkdir -p $SetupPath/config
    fi
    # config.json
    if [ ! -f $SetupPath/config/config.json ];then
        \cp -arf $PluginPath/monitor/config/config.json $SetupPath/config/config.json

    fi

    # malicious_ip.json
    if [ ! -f $SetupPath/config/malicious_ip.json.json ];then
        \cp -arf $PluginPath/monitor/config/malicious_ip.json $SetupPath/config/malicious_ip.json
    fi

    # sites.json
    if [ ! -f $SetupPath/config/sites.json ];then
        \cp -arf $PluginPath/monitor/config/sites.json $SetupPath/config/sites.json
    fi
    # spider.json
    \cp -arf $PluginPath/monitor/config/spider.json $SetupPath/config/spider.json

    # spider_config.json
    if [ ! -f $SetupPath/config/spider_config.json ];then
        \cp -arf $PluginPath/monitor/config/spider_config.json $SetupPath/config/spider_config.json
    fi

    # site_seo_uri.json
    if [ ! -f $SetupPath/config/site_seo_uri.json ];then
        \cp -arf $PluginPath/monitor/config/site_seo_uri.json $SetupPath/config/site_seo_uri.json
    fi

    # spider_settings.json
    \cp -arf $PluginPath/monitor/config/spider_settings.json $SetupPath/config/spider_settings.json

#    # copy icon file
#    \cp -arf $PluginPath/icon.png $PanelPath/BTPanel/static/vite/images/soft_ico/ico-monitor.png

    # create config directory
    if [ ! -d $SetupPath/web ];then
        mkdir -p $SetupPath/web
        mkdir -p $SetupPath/web/data
    fi
    # copy web static file
    \cp -arf $PluginPath/web/data/web_user.sql $SetupPath/web/data/web_user.sql
    if [ -d $SetupPath/web/static ]; then
        rm -rf $SetupPath/web/static
    fi
    \cp -r $PluginPath/web/static $SetupPath/web/static

    /www/server/panel/pyenv/bin/python3 /www/server/panel/plugin/monitor/service.py copy_default_db
}

Set_systemd_service()
{
    # install service
    echo "Adding system services"
    # 判断 /lib 是否为软链接
    if [ -L "/lib" ]; then
        # 获取软链接的目标路径
        lib_target=$(readlink -f "/lib")

        # 检查软链接的目标是否为 /usr/lib
        if [[ "$lib_target" == "/usr/lib" ]]; then
            systemd_path="/usr/lib/systemd/system"
        else
            systemd_path="/lib/systemd/system"
        fi
    else
        systemd_path="/lib/systemd/system"
    fi
    if [ -d $systemd_path ];then

        src_file=$PluginPath/service/monitor.service
        dst_file=$systemd_path/monitor.service
        if [ -f $dst_file ];then
            systemctl stop monitor.service
        fi
        \cp -f $src_file $dst_file
        systemctl daemon-reload
        systemctl enable monitor.service
        systemctl restart monitor.service
    else
        src_file=$PluginPath/service/monitor.init
        dst_file=/etc/init.d/monitor
        if [ -f $dst_file ];then
            service monitor stop
            chkconfig --del monitor
        fi
        \cp -f $src_file $dst_file
        chmod +x $dst_file
        chkconfig --add monitor
        chkconfig --level 2345 monitor on
        service monitor start
    fi
}

Check_user()
{
  username="bt-monitor"

  # 检查用户是否存在
  if getent passwd "$username" > /dev/null 2>&1; then
      echo "User $username already exists."
  else
      # 创建用户
      /www/server/panel/pyenv/bin/python3 /www/server/panel/plugin/monitor/service.py check_user
  fi
}

Install_monitor()
{
  Check_user
  if [ -x "/www/server/apache/bin/apachectl" ]; then
      echo "Install monitor for apache"
      # 调用安装 Apache 的函数
      Install_Apache_monitor
  else
      echo "Install monitor for nginx"
      # 调用安装 Nginx 的函数
      Install_Nginx_monitor
  fi
  nohup /www/server/panel/pyenv/bin/python3 /www/server/panel/plugin/monitor/monitor_seo.py init_spider_analysis &> /dev/null &
}

Uninstall_monitor()
{
    systemd_path='/usr/lib/systemd/system'
    if [ -d $systemd_path ];then
        systemctl stop monitor.service
        systemctl disable monitor.service
        rm -f $systemd_path/monitor.service
        systemctl daemon-reload
    else
        service monitor stop
        chkconfig --del monitor
        rm -f /etc/init.d/monitor
    fi
    
    /www/server/panel/pyenv/bin/python3 /www/server/panel/plugin/monitor/service.py uninstall
    rm -rf /www/server/monitor  # 删除程序目录
    # 删除日志格式
    nginx_log_format_file=/www/server/panel/vhost/nginx/0.monitor_log_format.conf
    if [ -f $nginx_log_format_file ];then
        rm -f $nginx_log_format_file
    fi
    apache_log_format_file=/www/server/panel/vhost/apache/0.monitor_log_format.conf
    if [ -f $apache_log_format_file ];then
            rm -f $apache_log_format_file
    fi
	echo 'Successfully!'
}

install_time()
{
  # 检查文件是否存在
  if [ ! -f "${PluginPath}/install_time.pl" ]; then
      # 获取当前时间的时间戳（以秒为单位）
      install_time=$(date +%s)
      # 打印时间戳
      echo "Install time (seconds): $install_time"
      # 将时间戳保存到文件中
      echo "$install_time" > "${PluginPath}/install_time.pl"
  else
      echo "Install time file already exists."
  fi
}

update_time()
{
  # 检查文件是否存在
  nowVersion="3.7"
  if [ ! -f "${PluginPath}/update_time.pl" ]; then
      # 获取当前时间的时间戳（以秒为单位）
      update_time=$(date +%s)
      # 打印时间戳
      echo "Update to $nowVersion time (seconds): $update_time"
      # 将时间戳保存到文件中
      echo "$nowVersion $update_time" > "${PluginPath}/update_time.pl"
  else
     # 读取文件中的版本号和时间戳
     # shellcheck disable=SC2034
     read -r fileVersion lastUpdateTime < "${PluginPath}/update_time.pl"

     # 检查版本号是否一致
     if [ "$fileVersion" != "$nowVersion" ]; then
         # 版本号不一致，重新写入时间戳
         update_time=$(date +%s)
         echo "Update to $nowVersion time (seconds): $update_time"
         echo "$nowVersion $update_time" > "${PluginPath}/update_time.pl"
     else
         # 版本号一致，不需要更新
         echo "Version is already up to date: $fileVersion"
     fi
  fi
}

action=$1
if [ "${1}" == 'install' ];then
#  install_time
#  update_time
#  if [ -d $PluginPath/monitor ]; then
#      rm -rf $PluginPath/monitor
#  fi
#  \cp -r $PluginPath/monitor_data $PluginPath/monitor
#	Install_monitor
  /www/server/panel/pyenv/bin/python3 /www/server/panel/plugin/monitor/install.py install
  # 安装基础统计工具
  nohup /www/server/panel/pyenv/bin/python3 /www/server/panel/plugin/monitor/free_total_update.py &> /dev/null &
  nohup /www/server/panel/pyenv/bin/python3 /www/server/panel/plugin/monitor/monitor_seo.py init_spider_analysis &> /dev/null &
else
#	Uninstall_monitor
  /www/server/panel/pyenv/bin/python3 /www/server/panel/plugin/monitor/install.py uninstall
fi

