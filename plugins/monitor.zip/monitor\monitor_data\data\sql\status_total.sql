-- 状态码统计表
CREATE TABLE IF NOT EXISTS `status_total` (
    `status_total_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `date` INTEGER DEFAULT 0,
    `status_code` INTEGER DEFAULT 0,
    `request` INTEGER DEFAULT 0
);

-- 增加索引
CREATE INDEX IF NOT EXISTS `idx_date_status_code` ON `status_total` (`date`,`status_code`);