-- URI请求统计表
CREATE TABLE IF NOT EXISTS `spider_uri_total` (
   `sut_id` INTEGER PRIMARY KEY AUTOINCREMENT,
   `date` INTEGER DEFAULT 0,               -- 日期
   `uri_id` INTEGER DEFAULT 0,             -- URI ID
   `spider` INTEGER DEFAULT 0,             -- 蜘蛛 ID
   `request` INTEGER DEFAULT 0             -- 请求次数
);

-- 增加索引
CREATE INDEX IF NOT EXISTS `idx_date_request` ON `spider_uri_total` (`date`, `request`);
CREATE INDEX IF NOT EXISTS `idx_date_uri_id` ON `spider_uri_total` (`date`,`uri_id`);