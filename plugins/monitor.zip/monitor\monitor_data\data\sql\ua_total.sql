-- UserAgent TOP
CREATE TABLE IF NOT EXISTS `user_agent_total` (
    `user_agent_total_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `user_agent_id` INTEGER DEFAULT 0,
    `date` INTEGER DEFAULT 0,
    `request` INTEGER DEFAULT 0
);

-- 增加索引
CREATE INDEX IF NOT EXISTS `idx_date_ua_id` ON `user_agent_total` (`date`,`user_agent_id`);