-- IP访问统计表 扩展信息 以日期存储 要展示的ip信息，每10分钟更新一次

CREATE TABLE IF NOT EXISTS `ip_total_ex` (
    `date` INTEGER PRIMARY KEY AUTOINCREMENT,
    `data` TEXT DEFAULT "{}"
)