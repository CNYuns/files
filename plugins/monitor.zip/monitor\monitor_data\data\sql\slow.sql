-- 慢请求记录表
CREATE TABLE IF NOT EXISTS `slow_request` (
    `slow_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `date` INTEGER DEFAULT 0,
    `uri_id` INTEGER DEFAULT 0,
    `ip_id` INTEGER DEFAULT 0,
    `ipv6` INTEGER DEFAULT 0,
    `method_id` INTEGER DEFAULT 0,
    `status_code` INTEGER DEFAULT 0,
    `request_take` INTEGER DEFAULT 0,
    `request_time` INTEGER DEFAULT 0
);

-- 创建索引
CREATE INDEX IF NOT EXISTS `idx_slow_request_date` ON `slow_request` (`date`);
CREATE INDEX IF NOT EXISTS `idx_slow_request_uri_id` ON `slow_request` (`uri_id`);
CREATE INDEX IF NOT EXISTS `idx_slow_request_status_code` ON `slow_request` (`status_code`);
CREATE INDEX IF NOT EXISTS `idx_slow_request_request_take` ON `slow_request` (`request_take`);
CREATE INDEX IF NOT EXISTS `idx_slow_request_request_time` ON `slow_request` (`request_time`);



