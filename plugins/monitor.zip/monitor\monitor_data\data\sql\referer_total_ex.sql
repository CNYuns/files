-- referer 来源访问统计表 扩展信息 以日期归档存储要展示的referer的信息， 目前信息中只包含ip相关，后续可添加其他信息

CREATE TABLE IF NOT EXISTS `referer_total_ex` (
      `date` INTEGER PRIMARY KEY AUTOINCREMENT,
      `data` TEXT DEFAULT '{}'
)