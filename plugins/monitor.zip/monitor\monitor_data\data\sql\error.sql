-- 错误日志记录表
CREATE TABLE IF NOT EXISTS `error_logs` (
    `error_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `level` TEXT DEFAULT "error" NOT NULL,
    `message` TEXT DEFAULT "" NOT NULL,
    `time` INTEGER DEFAULT 0,
    `error_source_id` INTEGER DEFAULT 0,
    `error_type` INTEGER DEFAULT 0
);

-- 添加索引
CREATE INDEX IF NOT EXISTS `error_logs_time` ON `error_logs` (`time`);
CREATE INDEX IF NOT EXISTS `idx_error_source_id` ON `error_logs` (`error_source_id`);