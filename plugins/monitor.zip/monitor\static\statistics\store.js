var to_utils = {
  overview: {
    today: {
      ip_number: 0,
      uv_number: 0,
      pv_number: 0,
      request: 0,
      spider_count: 0,
      sent_bytes: 0,
    },
    yesterday: {
      ip_number: 0,
      uv_number: 0,
      pv_number: 0,
      request: 0,
      spider_count: 0,
      sent_bytes: 0,
    },
    start7: {
      ip_number: 0,
      uv_number: 0,
      pv_number: 0,
      request: 0,
      spider_count: 0,
      sent_bytes: 0,
    },
  },
  global_real_time: {
    time_list: [],
    req_total: [],
    avg_take: [],
    sent_bytes: [],
    recv_bytes: [],
  },
  site_top5: [], // 站点：类型值
  visit_map: [], // 来访地图
  visit_area: [], // 来访区域
  visit_spider_type: [], // 来访蜘蛛类型
  visit_client_type: [], // 来访客户端类型
  visit_uri_top: [], // 来访 ip访问最多的 URI 请求 Top5
  visit_ip_top: [], // 来访IP Top5
  visit_spider_uri_top: [], // 来访蜘蛛访问最多的站点+ URI Top5
  "50x_top5": [], // 50x 状态码 Top5
  "400x_top5": [], // 400x 状态码 Top5
  "404_log": [], // 404 状态码日志
  file_perm_log: [], // 文件权限日志
  proxy_error_log: [], // 代理异常日志
  php_error_log: [], // PHP 异常日志
  lua_error_log: [], // Lua 异常日志
  other_error_log: [], // 其他异常日志
  slow_top: [], // 慢请求 Top5
  visitor_log_top: [], // 最新10条访客信息
  SITE_TYPE_MAP: {
    ip_number: "IP",
    uv_number: "UV",
    pv_number: "PV",
    request: "请求数",
    spider_count: "蜘蛛",
    flow: "流量",
  },
  /*
   * @description: 获取今日/昨日/近7日基本数据
   * @param {function} callback 回调函数
   * @return {*}
   */
  get_overview_all: function (callback) {
    var that = this;
    bt_tools.send("/monitor/get_overview_all.json", function (data) {
      that.overview.today = data.today;
      that.overview.yesterday = data.yesterday;
      that.overview.start7 = data.start7;
      callback(true);
    });
  },
  /*
   * @description: 获取实时数据
   * @param {function} callback 回调函数
   * @return {*}
   */
  get_global_real_time: function (callback) {
    var that = this;
    bt_tools.send("/monitor/get_global_real_time.json", function (data) {
      var _time = bt.format_data(new Date().getTime(), "hh:mm:ss");
      var _up = bt.format_size(data.sent_bytes, false, 2, "KB");
      var _down = bt.format_size(data.recv_bytes, false, 2, "KB");
      that.global_real_time.time_list.push(_time);
      that.global_real_time.req_total.push([_time, data.req_total]);
      that.global_real_time.avg_take.push([_time, data.avg_take]);
      that.global_real_time.sent_bytes.push([_time, _up]);
      that.global_real_time.recv_bytes.push([_time, _down]);

      // 保留最近10条数据
      if (that.global_real_time.req_total.length > 10) {
        that.global_real_time.time_list.shift();
        that.global_real_time.req_total.shift();
        that.global_real_time.avg_take.shift();
        that.global_real_time.sent_bytes.shift();
        that.global_real_time.recv_bytes.shift();
      }
      callback(true);
    });
  },
  /*
   * @description: 获取站点Top5
   * @param {string} data.metric 类型[ip_number、uv_number、pv_number、request、spider_count、flow]
   * @param {string} data.order 排序方式[desc 降序、asc 升序]
   * @param {function} callback 回调函数
   * @return {*}
   */
  get_site_top5: function (data, callback) {
    var that = this;
    if (!data.metric) {
      data = {
        metric: "pv_number",
        order: "desc",
      };
    }
    bt_tools.send(
      { url: "/monitor/get_site_top5.json", data: data },
      function (data) {
        that.site_top5 = data.site_list;
        callback(true);
      }
    );
  },
  /*
   * @description: 获取来访地图
   * @param {string} type 类型[中国 is_china为1  世界 is_china为0]
   * @param {function} callback 回调函数
   * @return {*}
   */
  get_map_data: function (type, callback) {
    var that = this;
    if (typeof type === "undefined") {
      type = 1;
    }
    bt_tools.send(
      {
        url: "/monitor/get_map_data.json",
        data: { is_china: type, part_type: "minute" },
      },
      function (data) {
        that.visit_map = data.site_map;
        that.visit_area = data.map_top10;
        // map_top10 为空时，模拟10条国家/省份数据
        if (data.map_top10.length <= 0) {
          if (type == 0) {
            that.visit_area = [
              {
                area_id: 0,
                title: "中国",
                ip_count: 0,
                request: 0,
              },
              {
                area_id: 1,
                title: "美国",
                ip_count: 0,
                request: 0,
              },
              {
                area_id: 2,
                title: "英国",
                ip_count: 0,
                request: 0,
              },
              {
                area_id: 3,
                title: "法国",
                ip_count: 0,
                request: 0,
              },
              {
                area_id: 4,
                title: "德国",
                ip_count: 0,
                request: 0,
              },
              {
                area_id: 5,
                title: "俄罗斯",
                ip_count: 0,
                request: 0,
              },
              {
                area_id: 6,
                title: "加拿大",
                ip_count: 0,
                request: 0,
              },
              {
                area_id: 7,
                title: "印度",
                ip_count: 0,
                request: 0,
              },
            ];
          } else {
            that.visit_area = [
              {
                area_id: 8,
                title: "广东",
                ip_count: 0,
                request: 0,
              },
              {
                area_id: 9,
                title: "北京",
                ip_count: 0,
                request: 0,
              },
              {
                area_id: 10,
                title: "上海",
                ip_count: 0,
                request: 0,
              },
              {
                area_id: 11,
                title: "香港",
                ip_count: 0,
                request: 0,
              },
              {
                area_id: 12,
                title: "澳门",
                ip_count: 0,
                request: 0,
              },
              {
                area_id: 13,
                title: "浙江",
                ip_count: 0,
                request: 0,
              },
              {
                area_id: 14,
                title: "江苏",
                ip_count: 0,
                request: 0,
              },
              {
                area_id: 15,
                title: "新疆",
                ip_count: 0,
                request: 0,
              },
            ];
          }
        }
        callback(true);
      }
    );
  },
  /*
   * @description: 获取来访蜘蛛类型、来访客户端、来访IP访问最多的 URI 请求 Top5
   * @param {function} callback 回调函数
   * @return {*}
   */
  get_visit_ip_top5: function (callback) {
    var that = this;
    bt_tools.send({ url: "/monitor/get_visit_IP_top5.json" }, function (data) {
      that.visit_spider_type = data.spider_type;
      that.visit_client_type = data.client_type;
      that.visit_uri_top = data.uri_top;
      that.visit_ip_top = data.ip_top5;
      callback(true);
    });
  },
  /*
   * @description: 获取来访蜘蛛访问最多的站点+ URI Top5
   * @param {function} callback 回调函数
   * @return {*}
   */
  get_spider_top: function (callback) {
    var that = this;
    bt_tools.send(
      { url: "/monitor/get_spider_top.json", data: { metric: [-2] } },
      function (data) {
        that.visit_spider_uri_top = data;
        callback(true);
      }
    );
  },
  /*
   * @description: 获取状态码 + 日志（50x、400x、404、文件权限、代理异常）
   * @param {function} callback 回调函数
   * @return {*}
   */
  get_status_log_all: function (callback) {
    var that = this;
    bt_tools.send({ url: "/monitor/get_status_log_all.json" }, function (data) {
      that["50x_top5"] = data["50x_top5"].map(function (item) {
        return {
          site: Object.keys(item)[0],
          request: item[Object.keys(item)[0]],
        };
      });
      that["400x_top5"] = data["400x_top5"].map(function (item) {
        return {
          site: Object.keys(item)[0],
          request: item[Object.keys(item)[0]],
        };
      });
      that["404_log"] = data["404_log"];
      that.file_perm_log = data.file_perm_log;
      that.proxy_error_log = data.proxy_error_log;
      that.php_error_log = data.php_error_log;
      that.lua_error_log = data.lua_error_log;
      that.other_error_log = data.other_error_log;
      that.slow_top = data.slow_top;
      callback(true);
    });
  },
  /*
   * @description: 最新10条访客信息
   * @param {function} callback 回调函数
   * @return {*}
   */
  get_visitor_log: function (callback) {
    var that = this;
    bt_tools.send({ url: "/monitor/get_visitor_log.json" }, function (data) {
      that.visitor_log_top = data;
      callback(true);
    });
  },
  get_visit_columns: function (type) {
    switch (type) {
      // 来访IP Top5表格配置
      case "visit_ip_top":
        return [
          {
            fid: "ip",
            title: "IP",
          },
          {
            fid: "area",
            title: "归属地",
          },
          {
            fid: "request",
            title: "请求次数",
            template: function (row) {
              return (
                "<span>" + bt_monitor.formatCurrency(row.request) + "</span>"
              );
            },
          },
          {
            fid: "ua_count",
            title: "UV",
            template: function (row) {
              return (
                "<span>" + bt_monitor.formatCurrency(row.ua_count) + "</span>"
              );
            },
          },
          {
            fid: "send_bytes",
            title: "流量",
            template: function (row) {
              return "<span>" + bt.format_size(row.send_bytes) + "</span>";
            },
          },
        ];
      // 来访IP访问最多的 URI 请求 Top5
      case "visit_uri_top":
        return [
          {
            fid: "uri",
            title: "URI",
            template: function (row) {
              var val = bt_monitor.xsssec(row.uri);
              return (
                "<span class='btlink overflow_hide uri-visit-top-hover'" +
                " title='" +
                val +
                "' data-index='" +
                to_utils.visit_uri_top.indexOf(row) +
                "'>" +
                val +
                "</span>"
              );
            },
          },
          {
            fid: "site",
            title: "站点",
            template: function (row) {
              var val = bt_monitor.xsssec(row.site);
              return (
                "<span class='overflow_hide' style='width: 170px;' title='" +
                val +
                "'>" +
                val +
                "</span>"
              );
            },
          },
          {
            fid: "request",
            title: "请求次数",
            template: function (row) {
              return (
                "<span>" + bt_monitor.formatCurrency(row.request) + "</span>"
              );
            },
          },
          {
            fid: "pv",
            width: 60,
            title: "PV",
            template: function (row) {
              return "<span>" + bt_monitor.formatCurrency(row.pv) + "</span>";
            },
          },
          {
            fid: "uv",
            width: 60,
            title: "UV",
            template: function (row) {
              return "<span>" + bt_monitor.formatCurrency(row.uv) + "</span>";
            },
          },
          {
            fid: "sent_bytes",
            width: 80,
            title: "流量",
            template: function (row) {
              return (
                '<span style="white-space: nowrap;">' +
                bt.format_size(row.sent_bytes) +
                "</span>"
              );
            },
          },
        ];
      //来访蜘蛛访问最多的站点+URI Top5
      case "visit_spider_uri_top":
        return [
          {
            fid: "spider",
            title: "蜘蛛",
          },
          {
            fid: "site",
            title: "站点",
            template: function (row) {
              var val = bt_monitor.xsssec(row.site);
              return (
                "<span class='overflow_hide' style='width: 360px;' title='" +
                val +
                "'>" +
                val +
                "</span>"
              );
            },
          },
          {
            fid: "uri",
            title: "URI",
            template: function (row) {
              var val = bt_monitor.xsssec(row.uri);
              return (
                "<span class='overflow_hide' style='width: 360px;' title='" +
                val +
                "'>" +
                val +
                "</span>"
              );
            },
          },
          {
            fid: "request",
            title: "访问数",
            template: function (row) {
              return (
                "<span>" + bt_monitor.formatCurrency(row.request) + "</span>"
              );
            },
          },
        ];
      case "50x_top5":
      case "400x_top5":
        return [
          {
            fid: "site",
            title: "站点",
            template: function (row) {
              var val = bt_monitor.xsssec(row.site);
              return (
                "<span class='overflow_hide' style='width: 360px;' title='" +
                val +
                "'>" +
                val +
                "</span>"
              );
            },
          },
          {
            fid: "request",
            title: "请求数",
            template: function (row) {
              return (
                "<span>" + bt_monitor.formatCurrency(row.request) + "</span>"
              );
            },
          },
        ];
      case "404_log":
      case "file_perm_log":
      case "proxy_error_log":
      case "php_error_log":
      case "lua_error_log":
      case "other_error_log":
        return [
          {
            fid: "site",
            title: "站点",
            template: function (row) {
              var val = bt_monitor.xsssec(row.site);
              return (
                "<span class='overflow_hide' style='width: 100px;' title='" +
                val +
                "'>" +
                val +
                "</span>"
              );
            },
          },
          {
            fid: "time",
            title: "时间",
            width: 138,
          },
          {
            fid: "info",
            title: "信息",
            template: function (row) {
              var _width = "170px";
              var val = bt_monitor.xsssec(row.info);
              return (
                "<span class='overflow_hide to_custom-width' data-oldwidth='" +
                _width +
                "' style='width: " +
                _width +
                "' title='" +
                val +
                "'>" +
                val +
                "</span>"
              );
            },
          },
        ];
      // 最新10条访客信息
      case "visitor_log_top":
        return [
          {
            fid: "date",
            title: "时间",
          },
          {
            fid: "ip",
            title: "IP",
            template: function (row) {
              return (
                "<span class='overflow_hide' style='max-width: 110px;' title='" +
                row.ip +
                "'>" +
                row.ip +
                "</span>"
              );
            },
          },
          {
            fid: "ip_area",
            title: "归属地",
            template: function (row) {
              var val = bt_monitor.xsssec(row.ip_area);
              return (
                "<span class='overflow_hide' style='max-width: 170px;' title='" +
                val +
                "'>" +
                val +
                "</span>"
              );
            },
          },
          {
            fid: "in_uri",
            title: "入口URL",
            template: function (row) {
              var val = bt_monitor.xsssec(row.in_uri);
              return (
                "<span class='overflow_hide' style='width: 164px;' title='" +
                val +
                "'>" +
                val +
                "</span>"
              );
            },
          },
          {
            fid: "last_uri",
            title: "最后访问",
            template: function (row) {
              var val = bt_monitor.xsssec(row.last_uri);
              return (
                "<span class='overflow_hide' style='width: 164px;' title='" +
                val +
                "'>" +
                val +
                "</span>"
              );
            },
          },
          {
            fid: "referer",
            title: "来源",
            template: function (row) {
              var val = bt_monitor.xsssec(row.referer);
              return (
                "<span class='overflow_hide' style='width: 100px;' title='" +
                val +
                "'>" +
                val +
                "</span>"
              );
            },
          },
          {
            fid: "end_msg",
            title: "状态",
          },
        ];
      //慢请求站点+URI Top5
      case "slow_top":
        return [
          {
            fid: "site",
            title: "站点",
            template: function (row) {
              var val = bt_monitor.xsssec(row.site);
              return (
                "<span class='overflow_hide' style='width: 360px;' title='" +
                val +
                "'>" +
                val +
                "</span>"
              );
            },
          },
          {
            fid: "uri",
            title: "URI",
            template: function (row) {
              var val = bt_monitor.xsssec(row.uri);
              return (
                "<span class='overflow_hide' style='width: 360px;' title='" +
                val +
                "'>" +
                val +
                "</span>"
              );
            },
          },
          {
            fid: "request_take",
            title: "平均耗时(ms)",
            template: function (row) {
              return (
                "<span>" +
                bt_monitor.formatCurrency(row.request_take) +
                "</span>"
              );
            },
          },
        ];
    }
  },
  // 一键清空数据的内置方法
  clearData: function () {
    // 处理 overview 下的嵌套对象（重置为 0）
    const resetNumberObj = (obj) => {
      Object.keys(obj).forEach((key) => {
        obj[key] = 0;
      });
    };
    resetNumberObj(this.overview.today);
    resetNumberObj(this.overview.yesterday);
    resetNumberObj(this.overview.start7);

    // 处理 global_real_time 下的数组（重置为空数组）
    const resetArrayObj = (obj) => {
      Object.keys(obj).forEach((key) => {
        obj[key] = [];
      });
    };
    resetArrayObj(this.global_real_time);

    // 处理所有顶级数组属性（重置为空数组）
    const arrayKeys = [
      "site_top5",
      "visit_map",
      "visit_area",
      "visit_spider_type",
      "visit_client_type",
      "visit_uri_top",
      "visit_ip_top",
      "visit_spider_uri_top",
      "50x_top5",
      "400x_top5",
      "404_log",
      "file_perm_log",
      "proxy_error_log",
      "php_error_log",
      "lua_error_log",
      "other_error_log",
      "slow_top",
      "visitor_log_top",
    ];
    arrayKeys.forEach((key) => {
      this[key] = [];
    });
    return this; // 可选：返回自身，支持链式调用
  },
};
