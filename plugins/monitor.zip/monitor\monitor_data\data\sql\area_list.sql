-- 地区列表
CREATE TABLE IF NOT EXISTS `area_list` (
    `area_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `title` TEXT DEFAULT '',             -- 国家/省份/城市
    `parent_id` INTEGER DEFAULT 0        -- 所属地区
);

-- 增加唯一索引
CREATE UNIQUE INDEX IF NOT EXISTS `idx_area` ON `area_list` (`title`);