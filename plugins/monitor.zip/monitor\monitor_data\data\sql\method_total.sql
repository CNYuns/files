-- 请求方法统计表
CREATE TABLE IF NOT EXISTS `method_total` (
    `method_total_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `date` INTEGER DEFAULT 0,
    `method_id` INTEGER DEFAULT 0,
    `request` INTEGER DEFAULT 0
);

-- 增加索引
CREATE INDEX IF NOT EXISTS `idx_date_method_id` ON `method_total` (`date`,`method_id`);