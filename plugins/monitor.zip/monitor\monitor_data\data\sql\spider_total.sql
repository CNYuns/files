-- spider爬虫统计表
CREATE TABLE IF NOT EXISTS `spider_total` (
    `spider_total_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `date` INTEGER DEFAULT 0,
    `hour` INTEGER DEFAULT 0,
    `spider_id` INTEGER DEFAULT 0,
    `request` INTEGER DEFAULT 0
);

-- 增加索引
CREATE INDEX IF NOT EXISTS `idx_date_hour_spider_id` ON `spider_total` (`date`,`hour`,`spider_id`);
CREATE INDEX IF NOT EXISTS `idx_date_request` ON `spider_total` (`date`, `request`);
