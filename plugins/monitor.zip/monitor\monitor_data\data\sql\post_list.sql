-- 网站post数据
CREATE TABLE IF NOT EXISTS `post_list` (
   `post_id` INTEGER PRIMARY KEY AUTOINCREMENT,
   `post_key_id` TEXT DEFAULT "" NOT NULL,        -- 请求原文索引 md5(UriId + RequestTime + IpId + RemotePort + ReceiveBytes)
   `from_data` TEXT DEFAULT "" NOT NULL   -- 请求原文
);

-- 增加索引
CREATE INDEX IF NOT EXISTS `idx_post_key_id` ON `post_list` (`post_key_id`);