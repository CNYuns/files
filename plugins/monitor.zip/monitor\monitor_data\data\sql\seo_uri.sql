-- host表
CREATE TABLE IF NOT EXISTS `path_list`
(
    `path_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `path`    TEXT DEFAULT "" NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS `idx_path` ON `path_list` (`path`);

-- host表
CREATE TABLE IF NOT EXISTS `query_list`
(
    `query_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `query`    TEXT DEFAULT "" NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS `idx_query` ON `query_list` (`query`);

-- ext表
CREATE TABLE IF NOT EXISTS `ext_list`
(
    `ext_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `ext`    TEXT DEFAULT "" NOT NULL
);

-- 批量插入ext
INSERT INTO `ext_list` (`ext_id`, `ext`)
VALUES (1, '.html'),
       (2, '.htm'),
       (3, '.php'),
       (4, '.jsp'),
       (5, '.aspx'),
       (6, '.asp'),
       (7, '.cgi'),
       (8, '.jhtml'),
       (9, '.shtml'),
       (10, '.shtm'),
       (11, '.net');

-- url列表
CREATE TABLE IF NOT EXISTS `seo_uri`
(
    `id`           INTEGER PRIMARY KEY AUTOINCREMENT,
    `path_id`      INTEGER DEFAULT 0, -- 路径信息
    `query_id`     INTEGER DEFAULT 0, -- 查询参数
    'ext_id'       INTEGER DEFAULT 0, -- 路径中包含的文件后缀 0 表示没有后缀
    `time`         INTEGER DEFAULT 0, -- 首次记录的时间
    `priority`     INTEGER DEFAULT 0, --(0 1)byte 优先级  1-100 0 未设置 生成时按规则生成
    `freq`         INTEGER DEFAULT 10, --1 byte 页面修改频率 0 always 1 hourly 2 daily 3 weekly 4 monthly 5 yearly 6 never
    `disable`      INTEGER DEFAULT 0, --0 byte 是否禁用该页面 （sitemap 和 推送）
    `lastmod`      INTEGER DEFAULT 67108864, --(4byte 默认 1<<26 先将4个字节占用 时间为1972) 最近修改时间
    `sitemap_time` INTEGER DEFAULT 67108864, --(4byte 默认 1<<26 先将4个字节占用 时间为1972) sitemap生成时间
    `send_time`    INTEGER DEFAULT 67108864, --(4byte 默认 1<<26 先将4个字节占用 时间为1972) uri推送时间
    `index_status` INTEGER DEFAULT 0  --(0 2)byte 不同平台的收录情况，0：未收录， 1 百度 2 必应 4 谷歌 8 360 ....
);

-- 不记录host id，虽然一个server可以有多个host且这些host的uri有一定区别，但这并非最佳实践
-- 也不是Seo应当处理的网站类型，且可以在一定的排除规则下生成，故不特意记录 host 信息

-- 增加索引
CREATE UNIQUE INDEX IF NOT EXISTS `idx_seo_url` ON `seo_uri` (`path_id`, `query_id`);
CREATE INDEX IF NOT EXISTS `idx_seo_url_time` ON `seo_uri` (`time`);