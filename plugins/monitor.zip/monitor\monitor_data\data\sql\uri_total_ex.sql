-- uri访问统计表 扩展信息 以日期归档存储要展示的uri的信息

CREATE TABLE IF NOT EXISTS `uri_total_ex` (
     `date` INTEGER PRIMARY KEY AUTOINCREMENT,
     `data` TEXT DEFAULT '{}'
)