-- URI列表
CREATE TABLE IF NOT EXISTS `uri_list` (
    `uri_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `uri` TEXT DEFAULT "" NOT NULL,
    `time` INTEGER NOT NULL DEFAULT 0
);

-- 增加唯一索引
CREATE UNIQUE INDEX IF NOT EXISTS `idx_uri` ON `uri_list` (`uri`);