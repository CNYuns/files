-- IP列表
CREATE TABLE IF NOT EXISTS `ip_list` (
    `ip_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `ip` VARCHAR(64) DEFAULT ''
);

-- 增加唯一索引
CREATE UNIQUE INDEX IF NOT EXISTS `idx_ip` ON `ip_list` (`ip`);


