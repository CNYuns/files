// -------------------------------------------------------------------
// 宝塔Linux面板
// -------------------------------------------------------------------
// Copyright (c) 2015-2024 宝塔软件(http://bt.cn) All rights reserved.
// -------------------------------------------------------------------
// Author: hwliang <hwl@bt.cn>
// -------------------------------------------------------------------
#define PUBLIC_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <regex.h>
#include <string>
#include <vector>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <sys/stat.h>
#include <sys/types.h>
using namespace std;


#define PID_FILE "/www/server/monitor/ipfilter.pid"
#define LOG_FILE "/www/server/monitor/ipfilter.log"
#define LOG_FILE_INFO "/www/server/monitor/ipfilter_info.log"
#define LOG_INFO "INFO"
#define LOG_ERROR "ERROR"
#define LOG_DEBUG "DEBUG"
#define LOG_WARNING "WARNING"
#define RULE_NAME "monitor_filter"
#define RULE_NAME6 "monitor_filter_v6"


/**
 * @brief 读取文件内容
 * @param filename <string> 文件名
 * @param mode <string> 读取模式
 * @return string 文件内容
 */
string read_file(string filename,string mode = "r"){
    ifstream file(filename,ios::in);
    if(!file.is_open()){
        return "";
    }
    string content;
    file.seekg(0,ios::end);
    content.resize(file.tellg());
    file.seekg(0,ios::beg);
    file.read(&content[0],content.size());
    file.close();
    return content;
}

/**
 * @brief 写入文件内容
 * @param filename <string> 文件名
 * @param content <string> 文件内容
 * @param mode <string> 写入模式
 * @return int 0.失败 1.成功
 */
int write_file(string filename,string content,string mode = "w"){
    ofstream file;
    file.open(filename.c_str(),ios::out);
    if(!file.is_open()) return 0;
    file << content;
    file.close();
    return 1;
}

/**
 * @brief 获取文件大小
 * @param filename <string> 文件名
 * @return int 文件大小
 */
int get_file_size(string filename){
    struct stat statbuf;
    stat(filename.c_str(),&statbuf);
    int size = statbuf.st_size;
    return size;
}

/**
 * @brief 获取文件修改时间
 * @param filename <string> 文件名
 * @return int 文件修改时间
 */
int get_file_mtime(string filename){
    struct stat statbuf;
    stat(filename.c_str(),&statbuf);
    return statbuf.st_mtime;
}

/**
 * @brief 获取文件访问时间
 * @param filename <string> 文件名
 * @return int 文件访问时间
 */
int get_file_atime(string filename){
    struct stat statbuf;
    stat(filename.c_str(),&statbuf);
    return statbuf.st_atime;
}

/**
 * @brief 获取文件创建时间
 * @param filename <string> 文件名
 * @return int 文件创建时间
 */
int get_file_ctime(string filename){
    struct stat statbuf;
    stat(filename.c_str(),&statbuf);
    return statbuf.st_ctime;
}


/**
 * @brief 获取当前时间
 * @param format <string> 时间格式
 * @return string 当前时间
 */
string get_time(string format = "%Y-%m-%d %H:%M:%S"){
    time_t now = time(0);
    struct tm *t = localtime(&now);
    char tmp[64];
    strftime(tmp,sizeof(tmp),format.c_str(),t);
    return tmp;
}

/**
 * @brief 获取当前时间戳
 * @return int 当前时间戳
 */
int get_timestamp(){
    return time(0);
}

/**
 * 判断文件是否存在
 * @author hwliang<2021-09-25>
 * @param filename <string&> 文件名
 * @return int
 */
int file_exists(const string& filename)
{
    if (access(filename.c_str(), F_OK) != -1)
    {
        return 1;
    }
    return 0;
}

/**
 * 删除字符串中的指定字符
 * @author hwliang<2021-09-25>
 * @param str <char *> 要被处理的字符串
 * @param del_str <char> 要被删除的字符
 * @return void
 */
void strip(char *str, char del_str)
{
    int len = strlen(str);
    int i;
    for (i = 0; str[i] != '\0'; i++)
    {
        if (str[i] == del_str)
        {
            str[i] = 0;
        }
    }
}

/*
@拆分字符串
*/
vector<string> split(const string& str, const string& delim)
{
	vector<string> res;
	if ("" == str) return res;
	//先将要切割的字符串从string类型转换为char*类型
	char * strs = new char[str.length() + 1]; //不要忘了
	strcpy(strs, str.c_str());

	char * d = new char[delim.length() + 1];
	strcpy(d, delim.c_str());

	char *p = strtok(strs, d);
	while (p) {
		string s = p; //分割得到的字符串转换为string类型
		res.push_back(s); //存入结果数组
		p = strtok(NULL, d);
	}

	return res;
}


/**
 * @brief 执行shell命令
 * @param cmd <string> 命令
 * @return string 命令执行结果
 */
string exec_shell(string cmd){
    FILE *fp;
    char buffer[1024];
    string result = "";
    fp = popen(cmd.c_str(), "r");
    if (fp == NULL) {
        return result;
    }
    while (fgets(buffer, sizeof(buffer), fp) != NULL) {
        result += buffer;
    }
    pclose(fp);
    return result;
}

/**
 * @brief 编译正则表达式
 * @author hwliang
 * @param pattern <string> 正则表达式
 * @return regex_t 正则表达式对象
 */
regex_t match_compile(const char *pattern)
{
    regex_t reg;
    int cflags = REG_EXTENDED;
    int ret = regcomp(&reg, pattern, cflags);
    if (ret != 0) printf("regcomp error\n");
    return reg;
}

/**
 * @brief 正则匹配
 * @author hwliang
 * @param reg <regex_t> 编译后的正则表达式对象
 * @param str <string> 要匹配的字符串
 * @return int 0.不匹配 1.匹配
 */
int match_exec(regex_t reg, const char *str)
{
    size_t nmatch = 1;
    regmatch_t pmatch[1];
    int ret = regexec(&reg, str, nmatch, pmatch, 0);
    if (ret == 0)
    {
        return 1;
    }
    return 0;
}

/**
 * 正则匹配
 * @author hwliang<2021-09-25>
 * @param str <const char *> 要被匹配的字符串
 * @param pattern <const char *> 正则表达式
 * @return int 1.匹配成功 0.匹配失败
 */
int match(const char *str, const char *pattern)
{
    regex_t reg = match_compile(pattern);
    int ret = match_exec(reg, str);
    regfree(&reg);
    return ret;
}


regex_t ipv4_reg = match_compile("^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)[.]){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(/([0-9]|[1-2][0-9]|3[0-2]))?$");
regex_t ipv6_reg = match_compile("^([0-9a-fA-F]{1,4}:){6}((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)[.]){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(/([1-9]?[0-9]|(1([0-1][0-9]|2[0-8]))))?$|^::([0-9a-fA-F]{1,4}:){0,4}((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)[.]){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(/([1-9]?[0-9]|(1([0-1][0-9]|2[0-8]))))?$|^([0-9a-fA-F]{1,4}:):([0-9a-fA-F]{1,4}:){0,3}((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)[.]){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(/([1-9]?[0-9]|(1([0-1][0-9]|2[0-8]))))?$|^([0-9a-fA-F]{1,4}:){2}:([0-9a-fA-F]{1,4}:){0,2}((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)[.]){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(/([1-9]?[0-9]|(1([0-1][0-9]|2[0-8]))))?$|^([0-9a-fA-F]{1,4}:){3}:([0-9a-fA-F]{1,4}:){0,1}((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)[.]){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(/([1-9]?[0-9]|(1([0-1][0-9]|2[0-8]))))?$|^([0-9a-fA-F]{1,4}:){4}:((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)[.]){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(/([1-9]?[0-9]|(1([0-1][0-9]|2[0-8]))))?$|^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}(/([1-9]?[0-9]|(1([0-1][0-9]|2[0-8]))))?$|^:((:[0-9a-fA-F]{1,4}){1,6}|:)(/([1-9]?[0-9]|(1([0-1][0-9]|2[0-8]))))?$|^[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,5}|:)(/([1-9]?[0-9]|(1([0-1][0-9]|2[0-8]))))?$|^([0-9a-fA-F]{1,4}:){2}((:[0-9a-fA-F]{1,4}){1,4}|:)(/([1-9]?[0-9]|(1([0-1][0-9]|2[0-8]))))?$|^([0-9a-fA-F]{1,4}:){3}((:[0-9a-fA-F]{1,4}){1,3}|:)(/([1-9]?[0-9]|(1([0-1][0-9]|2[0-8]))))?$|^([0-9a-fA-F]{1,4}:){4}((:[0-9a-fA-F]{1,4}){1,2}|:)(/([1-9]?[0-9]|(1([0-1][0-9]|2[0-8]))))?$|^([0-9a-fA-F]{1,4}:){5}:([0-9a-fA-F]{1,4})?(/([1-9]?[0-9]|(1([0-1][0-9]|2[0-8]))))?$|^([0-9a-fA-F]{1,4}:){6}:(/([1-9]?[0-9]|(1([0-1][0-9]|2[0-8]))))?$");

/**
 * 是否为IPv4地址
 * @author hwliang<2021-09-25>
 * @param ip <const char *> 要被匹配的字符串
 * @return int
 */
int is_ipv4(const char *ip)
{
    int ret = match_exec(ipv4_reg,ip);
    return ret;
}

/**
 * 是否为IPv6地址
 * @author hwliang<2021-09-25>
 * @param ip <const char *> 要被匹配的字符串
 * @return int
 */
int is_ipv6(const char *ip)
{
    int ret = match_exec(ipv6_reg,ip);
    return ret;
}

/**
 * @brief 判断是否为IP地址
 * @author hwliang
 * @param ip <const char *> 要被匹配的字符串
 * @return int 1.是IP地址 0.不是IP地址
 */
int is_ipaddr(const char *ip){
    if(is_ipv4(ip) || is_ipv6(ip)){
        return 1;
    }
    return 0;
}

void trim(::std::string & str)
{
    //left
    str.erase(str.begin(), std::find_if(str.begin(), str.end(), [](int ch) {
        return !std::isspace(ch);
    }));

    //right
    str.erase(std::find_if(str.rbegin(), str.rend(), [](int ch) {
        return !std::isspace(ch);
    }).base(), str.end());
}

/**
 * 写日志到文件
 * @author hwliang
 * @param msg <string> 日志内容
 * @param level <string> 日志级别  INFO/DEBUG/ERROR/WARNING
 * @return void
 */
void write_log(string msg, string level)
{
    trim(msg);
    string date_time = get_time();
    string log_body = "[" + date_time + "] [" + level + "] " + msg + "\n";
    if(level == LOG_INFO){
        write_file(LOG_FILE_INFO, log_body, "a+");
    }else{
        write_file(LOG_FILE, log_body, "a+");
    }
    
    printf("%s", log_body.c_str());
}

/**
 * @brief vector转字符串
 * @author hwliang
 * @param v <vector<string>> 要被转换的vector
 * @param dim <string> 分隔符
 * @return string
 */
string vector_to_string(vector<string> v, string dim)
{
    string ret = "";
    for (int i = 0; i < v.size(); i++)
    {
        ret += v[i];
        if (i < v.size() - 1)
        {
            ret += dim;
        }
    }
    return ret;
}