// -------------------------------------------------------------------
// 宝塔Linux面板
// -------------------------------------------------------------------
// Copyright (c) 2015-2024 宝塔软件(http://bt.cn) All rights reserved.
// -------------------------------------------------------------------
// Author: hwliang <hwl@bt.cn>
// -------------------------------------------------------------------
#ifndef UNIXSERVER_H
#include "unixserver.h"
#endif

#ifndef IPSET_ADMIN_EVENT_CPP
#include "ipset_admin_event.cpp"
#endif

using namespace std;
int epoll_server::create_socket(){
    sock = socket(AF_UNIX,SOCK_STREAM,0);
    if(sock < 0){
        printf("create socket error\n");
        return 0;
    }
    unlink(SOCK_FILE);
    memset(&addr,0,sizeof(addr));
    addr.sun_family = AF_UNIX;
    strcpy(addr.sun_path,SOCK_FILE);
    if(bind(sock,(struct sockaddr *)&addr,sizeof(addr)) < 0){
        printf("bind socket error\n");
        return 0;
    }
    if(listen(sock,5) < 0){
        printf("listen socket error\n");
        return 0;
    }
    return 1;
}

int epoll_server::create_epoll(){
    epoll_fd = epoll_create(10);
    if(epoll_fd < 0){
        printf("create epoll error\n");
        return 0;
    }
    ev.events = EPOLLIN;
    ev.data.fd = sock;
    if(epoll_ctl(epoll_fd,EPOLL_CTL_ADD,sock,&ev) < 0){
        printf("epoll_ctl error\n");
        return 0;
    }

    return 1;
}


int epoll_server::close_fd(int fd){
    close(fd);
    int ret = epoll_ctl(epoll_fd,EPOLL_CTL_DEL,fd,nullptr);
    return ret;
}

int epoll_server::run(){
    int nfds;
    int i;
    while(1){
        nfds = epoll_wait(epoll_fd,events,MAX_EVENTS,-1);
        for(i = 0; i < nfds; i++){
            if(events[i].data.fd == sock){ // 新的连接
                this->new_event();
            }else if(events[i].events & EPOLLIN){ // 读取数据
                this->hand_event(events[i].data.fd);
            }else if(events[i].events & EPOLLERR || events[i].events & EPOLLHUP){
                this->close_fd(events[i].data.fd);
            }
        }
    }
    return 0;
}

void epoll_server::new_event(){
    int client_fd;
    sockaddr_un cli_addr{};
    socklen_t len = sizeof(cli_addr);

    // 获取fd
    client_fd = accept(sock,(struct sockaddr *)&cli_addr,&len);
    if(client_fd < 1) return;
    
    // 设置连接为非阻塞模式
    int flags = fcntl(client_fd, F_GETFL, 0);
    if (flags < 0)   return;
    if (fcntl(client_fd, F_SETFL, flags | O_NONBLOCK) < 0)  return;

    // 添加到epoll
    ev.events = EPOLLIN | EPOLLET;
    ev.data.fd = client_fd;
    if(epoll_ctl(epoll_fd,EPOLL_CTL_ADD,client_fd,&ev) < 0) return;
}

int epoll_server::get_header(int fd,unsigned short *action_type,unsigned short *data_length){
    int header_size = 6;
    char buf[header_size];
    int n;
    if((n = read(fd,buf,header_size)) < 0){
        return 0;
    }

    if(n < 1){
        // 客户端关闭连接
        this->close_fd(fd);
        return 0;
    }

    // 转换为头部
    pack_header* header = (pack_header*)buf;

    // 验证头部
    if(header->h1 != 'B' || header->h2 != 'T' || header->length < 0 || header->length > 65535 || header->type < 1 || header->type > 255){
        this->close_fd(fd);
        return 0;
    }
    *action_type = header->type;
    *data_length = header->length;
    return 1;

}


void epoll_server::hand_event(int fd){
    const int buf_size = 4096;
    char buf[buf_size];
    int n = 0;
    memset(buf,0,buf_size);

    unsigned short action_type = 0;
    // 获取数据
    string data = "";
    read(fd,buf,buf_size);
    data = buf;
    
    vector<string> ptr = split(data,"!");
    if(ptr.size() < 2){
        this->close_fd(fd);
        return;
    }

    action_type = atoi(ptr[0].c_str());

    // 调用事件
    this->goto_event(fd,action_type,ptr[1]);

}


void epoll_server::ipset_admin_event(int fd,int action_type,string data){
    ipset_admin* ipset_admin_obj = new ipset_admin();
    string ret = "";
    switch(action_type){
        case 112:
            ret = ipset_admin_obj->add_waf_ip(data);
            break;
        case 113:
            ret = ipset_admin_obj->del_waf_ip(data);
            break;
        case 114:
            ret = ipset_admin_obj->update_waf_ip(data);
            break;
        default:
            write(fd,"error:101",10);
            this->close_fd(fd);
            break;
    }
    delete ipset_admin_obj;
    
    if (ret.size() > 0){
        write(fd,ret.c_str(),ret.size());
        ret.clear();
    }

    this->close_fd(fd);
}


void epoll_server::log_supervisor_event(int fd,int action_type,string data){
    this->close_fd(fd);
}

void epoll_server::other_event(int fd,int action_type,string data){
    this->close_fd(fd);
}

void epoll_server::goto_event(int fd,int action_type,string data){
    if(action_type >= 100 && action_type < 200){
        this->ipset_admin_event(fd,action_type,data);
    }else if(action_type >= 200 && action_type < 300){
        this->log_supervisor_event(fd,action_type,data);
    }else{
        this->other_event(fd,action_type,data);
    }
}


int epoll_server::start(){
    if(!create_socket()){
        printf("create socket error\n");
        return 0;
    }
    if(!create_epoll()){
        printf("create epoll error\n");
        return 0;
    }

    // 设置sock文件权限
    if (chmod(SOCK_FILE, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH) < 0) {
        printf("chmod error");
        return 0;
    }

    // 监听event
    run();
    return 1;
}
