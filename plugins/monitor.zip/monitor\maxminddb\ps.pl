# 为防止 maxminddb 安装和版本问题，这里使用了源码, 版本为2.6.2
# 原git地址: https://github.com/maxmind/MaxMind-DB-Reader-python