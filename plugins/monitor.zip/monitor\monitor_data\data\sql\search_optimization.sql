-- 🚀 搜索性能优化索引
-- 此文件包含所有用于优化前缀搜索和组合查询性能的索引
-- 系统启动时会自动执行，确保搜索性能达到最佳状态

-- ========================================
-- 前缀搜索优化索引（主要表已有UNIQUE索引，无需重复创建）
-- ========================================

-- uri_list表已有：CREATE UNIQUE INDEX idx_uri ON uri_list(uri);
-- user_agent表已有：CREATE UNIQUE INDEX idx_user_agent ON user_agent(user_agent);
-- referer_list表已有：CREATE UNIQUE INDEX idx_referer ON referer_list(referer);
-- host表已有：CREATE INDEX idx_host ON host(host);
-- method_list表已有：CREATE INDEX idx_method ON method_list(method);
-- content_type表已有：CREATE INDEX idx_content_type ON content_type(content_type);

-- ========================================
-- 访问日志表的搜索优化索引
-- ========================================

-- 确保所有外键字段都有索引（部分可能已存在于access.sql中）
CREATE INDEX IF NOT EXISTS `idx_access_status_code` ON `access_log` (`status_code`);
CREATE INDEX IF NOT EXISTS `idx_access_method_id` ON `access_log` (`method_id`);
CREATE INDEX IF NOT EXISTS `idx_access_user_agent_id` ON `access_log` (`user_agent_id`);
CREATE INDEX IF NOT EXISTS `idx_access_referer_id` ON `access_log` (`referer_id`);
CREATE INDEX IF NOT EXISTS `idx_access_host_id` ON `access_log` (`host_id`);
CREATE INDEX IF NOT EXISTS `idx_access_content_type_id` ON `access_log` (`content_type_id`);

-- ========================================
-- 高频组合查询优化索引
-- ========================================

-- 时间范围 + 搜索条件的组合索引（最常用）
CREATE INDEX IF NOT EXISTS `idx_search_time_uri` ON `access_log` (`request_time`, `uri_id`);
CREATE INDEX IF NOT EXISTS `idx_search_time_ip` ON `access_log` (`request_time`, `ip_id`);
CREATE INDEX IF NOT EXISTS `idx_search_time_ua` ON `access_log` (`request_time`, `user_agent_id`);
CREATE INDEX IF NOT EXISTS `idx_search_time_status` ON `access_log` (`request_time`, `status_code`);
CREATE INDEX IF NOT EXISTS `idx_search_time_method` ON `access_log` (`request_time`, `method_id`);

-- 搜索条件之间的组合索引
CREATE INDEX IF NOT EXISTS `idx_search_uri_status` ON `access_log` (`uri_id`, `status_code`);
CREATE INDEX IF NOT EXISTS `idx_search_ip_uri` ON `access_log` (`ip_id`, `uri_id`);
CREATE INDEX IF NOT EXISTS `idx_search_ua_uri` ON `access_log` (`user_agent_id`, `uri_id`);
CREATE INDEX IF NOT EXISTS `idx_search_ip_status` ON `access_log` (`ip_id`, `status_code`);

-- ========================================
-- 三字段组合索引（针对复杂搜索）
-- ========================================

-- 时间 + 两个搜索条件的组合
CREATE INDEX IF NOT EXISTS `idx_search_time_uri_status` ON `access_log` (`request_time`, `uri_id`, `status_code`);
CREATE INDEX IF NOT EXISTS `idx_search_time_ip_uri` ON `access_log` (`request_time`, `ip_id`, `uri_id`);
CREATE INDEX IF NOT EXISTS `idx_search_time_ua_status` ON `access_log` (`request_time`, `user_agent_id`, `status_code`);

-- ========================================
-- 特殊查询优化索引
-- ========================================

-- 爬虫分析相关索引
CREATE INDEX IF NOT EXISTS `idx_spider_time_gzip` ON `access_log` (`request_time`, `is_gzip`);
CREATE INDEX IF NOT EXISTS `idx_spider_ip_gzip` ON `access_log` (`ip_id`, `is_gzip`);

-- 会话分析相关索引
CREATE INDEX IF NOT EXISTS `idx_session_time` ON `access_log` (`session_id`, `request_time`);

-- 错误分析相关索引
CREATE INDEX IF NOT EXISTS `idx_error_status_time` ON `access_log` (`status_code`, `request_time`) WHERE `status_code` >= 400;

-- WAF拦截分析索引
CREATE INDEX IF NOT EXISTS `idx_waf_shield_time` ON `access_log` (`waf_shield`, `request_time`) WHERE `waf_shield` > 0;

-- ========================================
-- 慢查询表优化索引
-- ========================================

-- 慢查询表的搜索优化（如果存在slow表）
-- CREATE INDEX IF NOT EXISTS `idx_slow_time_uri` ON `slow_request` (`request_time`, `uri_id`);
-- CREATE INDEX IF NOT EXISTS `idx_slow_time_take` ON `slow_request` (`request_time`, `request_take`);

-- ========================================
-- 错误日志表优化索引
-- ========================================

-- 错误日志的时间索引优化
-- CREATE INDEX IF NOT EXISTS `idx_error_time_source` ON `error_logs` (`time`, `error_source_id`);

-- ========================================
-- 统计表优化索引
-- ========================================

-- URI统计表
CREATE INDEX IF NOT EXISTS `idx_uri_total_date_uri` ON `uri_total` (`date`, `uri_id`) WHERE EXISTS (SELECT 1 FROM sqlite_master WHERE type='table' AND name='uri_total');

-- IP统计表
CREATE INDEX IF NOT EXISTS `idx_ip_total_date_ip` ON `ip_total` (`date`, `ip_id`) WHERE EXISTS (SELECT 1 FROM sqlite_master WHERE type='table' AND name='ip_total');

-- UserAgent统计表
CREATE INDEX IF NOT EXISTS `idx_ua_total_date_ua` ON `ua_total` (`date`, `user_agent_id`) WHERE EXISTS (SELECT 1 FROM sqlite_master WHERE type='table' AND name='ua_total');

-- ========================================
-- 索引创建完成标记
-- ========================================

-- 创建一个标记表，记录索引优化的完成状态
CREATE TABLE IF NOT EXISTS `search_optimization_status` (
    `id` INTEGER PRIMARY KEY,
    `version` TEXT DEFAULT '1.0',
    `created_time` INTEGER DEFAULT (strftime('%s', 'now')),
    `description` TEXT DEFAULT '前缀搜索性能优化索引'
);

-- 插入标记记录
INSERT OR REPLACE INTO `search_optimization_status` (`id`, `version`, `description`)
VALUES (1, '1.0', '前缀搜索性能优化索引已创建完成');
