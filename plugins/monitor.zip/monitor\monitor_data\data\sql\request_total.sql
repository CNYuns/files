-- 请求统计表
CREATE TABLE IF NOT EXISTS `request_total` (
    `req_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `date` INTEGER DEFAULT 0,               -- 日期
    `hour` INTEGER DEFAULT 0,               -- 小时
    `minute` INTEGER DEFAULT 0,             -- 分钟
    `request` INTEGER DEFAULT 0,            -- 请求次数
    `sent_bytes` INTEGER DEFAULT 0,             -- 发送字节数
    `recv_bytes` INTEGER DEFAULT 0,          -- 接收字节数
    `sec_request` INTEGER DEFAULT 0,            -- 每秒请求次数
    `sec_sent_bytes` INTEGER DEFAULT 0,         -- 每秒发送字节数
    `sec_recv_bytes` INTEGER DEFAULT 0,      -- 每秒接收字节数
    `avg_take_time` INTEGER DEFAULT 0,      -- 平均请求时间
    `method_post` INTEGER DEFAULT 0,        -- post请求次数
    `method_get` INTEGER DEFAULT 0,         -- get请求次数
    `gzip` INTEGER DEFAULT 0,               -- gzip响应次数
    `ip_number` INTEGER DEFAULT 0,          -- ip数
    `pv_number` INTEGER DEFAULT 0,          -- pv数
    `uv_number` INTEGER DEFAULT 0,          -- uv数
    `pc_count` INTEGER DEFAULT 0,           -- pc数
    `mobile_count` INTEGER DEFAULT 0,        -- mobile数
    `spider_count` INTEGER DEFAULT 0,        -- spider数
    `slow_count` INTEGER DEFAULT 0,          -- 慢请求数
    `status_200` INTEGER DEFAULT 0,         -- 200状态码数
    `status_500` INTEGER DEFAULT 0,         -- 500状态码数
    `status_404` INTEGER DEFAULT 0,         -- 404状态码数
    `status_502` INTEGER DEFAULT 0,         -- 502状态码数
    `status_504` INTEGER DEFAULT 0,         -- 504状态码数
    `status_499` INTEGER DEFAULT 0         -- 499状态码数
);

-- 增加索引
CREATE INDEX IF NOT EXISTS `idx_date` ON `request_total` (`date`);
CREATE INDEX IF NOT EXISTS `idx_date_hour` ON `request_total` (`date`, `hour`);
CREATE INDEX IF NOT EXISTS `idx_date_minute` ON `request_total` (`date`, `hour`, `minute`);
