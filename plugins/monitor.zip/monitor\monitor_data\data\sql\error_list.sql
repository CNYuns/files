-- 错误信息列表
CREATE TABLE IF NOT EXISTS `error_list`
(
    `error_source_id` INTEGER PRIMARY KEY AUTOINCREMENT,    -- 主键id
    `error`           TEXT    DEFAULT '' NOT NULL,          -- 错误信息
    `error_type`      INTEGER DEFAULT 100,                  -- 错误类型
    `create_time`     INTEGER DEFAULT (strftime('%s', 'now')) -- 创建时间
);

-- 增加唯一索引
CREATE INDEX IF NOT EXISTS `idx_error` ON `error_list` (`error`);