import base64
import os.path
import traceback
from io import BytesIO
from typing import Tuple, Callable, List

import matplotlib
import matplotlib.pyplot as plt
from matplotlib.style import library as style_library
import numpy as np
from matplotlib import font_manager
from reportlab.lib.colors import HexColor
from reportlab.lib.fonts import addMapping
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, LongTable, \
    Flowable
from reportlab.platypus.tableofcontents import TableOfContents

# 注册字体
FONT_DIR = os.path.dirname(__file__)
FONT_FILES = {
    'NotoSansB': 'NotoSansSC-Bold.ttf',
    'NotoSansR': 'NotoSansSC-Regular.ttf',
}

for font_name, font_file in FONT_FILES.items():
    font_path = os.path.join(FONT_DIR, font_file)
    # print(f"Attempting to register font {font_path}...")

    if not os.path.exists(font_path):
        print(f"Error: Font file {font_path} does not exist.")
        continue

    if not os.access(font_path, os.R_OK):
        print(f"Error: No read permission for font file {font_path}.")
        continue

    try:
        # 注册到 reportlab
        pdfmetrics.registerFont(TTFont(font_name, font_path))
        # print(f"Font {font_name} registered successfully in reportlab.")

        # 注册到 matplotlib
        font_manager.fontManager.addfont(font_path)  # 将字体添加到全局字体管理器
        font_prop = font_manager.FontProperties(fname=font_path)
        # print(f"Font {font_name} registered successfully in matplotlib.")
    except Exception as e:
        print(f"Failed to register font {font_name}: {e}")
        traceback.print_exc()
        raise


# 模拟数据 - 实际应用中应该从数据库或日志文件中获取

def format_traffic(bytes_size: int):
    if bytes_size < 1024:
        return f"{bytes_size} B"
    elif bytes_size < 1024 * 1024:
        return f"{bytes_size / 1024:.2f} KB"
    elif bytes_size < 1024 * 1024 * 1024:
        return f"{bytes_size / (1024 * 1024):.2f} MB"
    else:
        return f"{bytes_size / (1024 * 1024 * 1024):.2f} GB"


def split_traffic(bytes_size: int) -> Tuple[Callable[[int], int], str]:
    if bytes_size < 1024:
        return lambda x: x, "Bytes"
    elif bytes_size < 1024 * 1024:
        return lambda x: x / 1024, "KB"
    elif bytes_size < 1024 * 1024 * 1024:
        return lambda x: x / (1024 * 1024), "MB"
    else:
        return lambda x: x / (1024 * 1024 * 1024), "GB"


class ChartGenerator:
    """负责生成所有图表"""

    def __init__(self):
        matplotlib.use('pdf')  # 设置后端为pdf

        # 设置统一的图表样式 - 使用更兼容的方式
        try:
            # 尝试使用 seaborn 样式，如果不存在则使用默认样式
            available_styles = list(style_library.keys())
            seaborn_style = None
            
            # 查找可用的 seaborn 样式
            for style in available_styles:
                if "seaborn" in style and "ticks" in style:
                    seaborn_style = style
                    break
            
            if seaborn_style:
                plt.style.use(seaborn_style)
            else:
                # 如果没有 seaborn 样式，使用默认样式并手动设置
                plt.style.use('default')
                # 手动设置一些样式参数
                plt.rcParams['axes.grid'] = True
                plt.rcParams['grid.alpha'] = 0.3
                plt.rcParams['axes.spines.top'] = False
                plt.rcParams['axes.spines.right'] = False
        except Exception as e:
            # 如果样式设置失败，使用默认样式
            plt.style.use('default')
            print(f"样式设置警告: {e}")

        # 设置中文字体
        plt.rcParams['font.family'] = 'sans-serif'  # 使用 sans-serif 族
        plt.rcParams['font.sans-serif'] = [
            'Noto Sans SC',  # 自定义字体别名
        ]
        # 全局设置（字体大小）
        plt.rcParams.update({
            'font.size': 12,            # 全局默认字体大小
            'axes.titlesize': 14,      # 图标题字体大小
            'axes.labelsize': 12,      # 坐标轴标签字体大小
            'xtick.labelsize': 10,      # X轴刻度标签字体大小
            'ytick.labelsize': 10,      # Y轴刻度标签字体大小
            'legend.fontsize': 10      # 图例字体大小
        })
        plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号

        # 添加字体兼容性配置
        plt.rcParams['text.antialiased'] = False  # 禁用抗锯齿
        plt.rcParams['pdf.fonttype'] = 42  # 使用 TrueType 字体
        plt.rcParams['pdf.use14corefonts'] = False

        # 验证当前使用的字体（调试用）
        # print("当前中文字体:", plt.rcParams['font.sans-serif'])
        self.colors = [
            '#2ecc71',
            '#3498db',
            '#e74c3c',
            '#f1c40f',
        ]

    def generate_trend_charts(self, data_list):
        """生成趋势图表"""
        charts = {}
        # PV和UV趋势
        plt.figure(figsize=(12, 6))
        dates = [item['date'] for item in data_list]
        plt.plot(dates, [item['pv'] for item in data_list], marker='o', color=self.colors[0], label='PV', linewidth=2)
        plt.plot(dates, [item['uv'] for item in data_list], marker='s', color=self.colors[1], label='UV', linewidth=2)
        plt.plot(dates, [item['ip'] for item in data_list], marker='*', color=self.colors[3], label='IP', linewidth=2)
        # plt.title('PV/UV/IP趋势', pad=20, fontsize=14, fontweight='bold')
        plt.xlabel('时间', labelpad=10)
        plt.ylabel('数量', labelpad=10)
        plt.xticks(rotation=45)
        plt.legend(frameon=True, facecolor='white', edgecolor='#f0f0f0')
        plt.grid(True, linestyle='--', alpha=0.7)
        try:
            plt.tight_layout()
        except RuntimeError as e:
            if "Could not load glyph" not in str(e):
                raise
        # 新增：强制 Y 轴从 0 开始
        plt.ylim(bottom=0)  # 设置 Y 轴下限为 0

        buffer = BytesIO()
        plt.savefig(buffer, format='png', dpi=200, bbox_inches='tight')
        buffer.seek(0)
        charts['pv_uv'] = base64.b64encode(buffer.getvalue()).decode()
        buffer.close()
        plt.close()

        # IP和请求数趋势
        plt.figure(figsize=(12, 6))
        plt.plot(dates, [item['request'] for item in data_list], marker='o', color=self.colors[3], label='请求数',
                 linewidth=2)
        # plt.title('请求数趋势', pad=20, fontsize=14, fontweight='bold')
        plt.xlabel('时间', labelpad=10)
        plt.ylabel('数量', labelpad=10)
        plt.xticks(rotation=45)
        plt.legend(frameon=True, facecolor='white', edgecolor='#f0f0f0')
        plt.grid(True, linestyle='--', alpha=0.7)
        try:
            plt.tight_layout()
        except RuntimeError as e:
            if "Could not load glyph" not in str(e):
                raise
        # 新增：强制 Y 轴从 0 开始
        plt.ylim(bottom=0)  # 设置 Y 轴下限为 0

        buffer = BytesIO()
        plt.savefig(buffer, format='png', dpi=200, bbox_inches='tight')
        buffer.seek(0)
        charts['ip_request'] = base64.b64encode(buffer.getvalue()).decode()
        buffer.close()
        plt.close()

        # 流量趋势
        plt.figure(figsize=(12, 6))
        max_traffic = max([item['traffic'] for item in data_list])
        to_num, unit = split_traffic(max_traffic)
        plt.plot(dates, [to_num(item['traffic']) for item in data_list], marker='o', color=self.colors[0],
                 label="流量趋势", linewidth=2)
        # plt.title('流量趋势', pad=20, fontsize=14, fontweight='bold')
        plt.xlabel('时间', labelpad=10)
        plt.ylabel('流量({})'.format(unit), labelpad=10)
        plt.xticks(rotation=45)
        plt.grid(True, linestyle='--', alpha=0.7)
        try:
            plt.tight_layout()
        except RuntimeError as e:
            if "Could not load glyph" not in str(e):
                raise
        # 新增：强制 Y 轴从 0 开始
        plt.ylim(bottom=0)  # 设置 Y 轴下限为 0

        buffer = BytesIO()
        plt.savefig(buffer, format='png', dpi=200, bbox_inches='tight')
        buffer.seek(0)
        charts['traffic'] = base64.b64encode(buffer.getvalue()).decode()
        buffer.close()
        plt.close()

        # 蜘蛛和错误数趋势
        plt.figure(figsize=(12, 6))
        plt.plot(dates, [item['spider'] for item in data_list], marker='o', color=self.colors[2], label='蜘蛛爬取',
                 linewidth=2)
        # plt.title('蜘蛛爬取趋势', pad=20, fontsize=14, fontweight='bold')
        plt.xlabel('时间', labelpad=10)
        plt.ylabel('数量', labelpad=10)
        plt.xticks(rotation=45)
        plt.legend(frameon=True, facecolor='white', edgecolor='#f0f0f0')
        plt.grid(True, linestyle='--', alpha=0.7)
        try:
            plt.tight_layout()
        except RuntimeError as e:
            if "Could not load glyph" not in str(e):
                raise
        # 新增：强制 Y 轴从 0 开始
        plt.ylim(bottom=0)  # 设置 Y 轴下限为 0

        buffer = BytesIO()
        plt.savefig(buffer, format='png', dpi=200, bbox_inches='tight')
        buffer.seek(0)
        charts['spider_error'] = base64.b64encode(buffer.getvalue()).decode()
        buffer.close()
        plt.close()

        return charts

    def generate_province_chart(self, province_data):
        """生成省份访问分布图表（柱状图+折线图双Y轴）"""
        fig, ax1 = plt.subplots(figsize=(12, 6))
        ax2 = ax1.twinx()  # 创建共享X轴的第二个Y轴

        provinces = [item['title'] for item in province_data]
        ip_counts = [item['ip_count'] for item in province_data]
        requests = [item['request'] for item in province_data]

        x = np.arange(len(provinces))
        width = 0.4

        # 绘制柱状图（请求数）在左侧Y轴
        bars = ax1.bar(x, requests, width, label='请求数', color='#2ba3db', alpha=0.8)
        ax1.set_ylabel('请求数', color='#000000')
        ax1.tick_params(axis='y', labelcolor='#000000')

        # 绘制折线图（IP数）在右侧Y轴
        line = ax2.plot(x, ip_counts, marker='o', color='#28e229', linewidth=2, label='IP数')
        ax2.set_ylabel('IP数', color='#000000')
        ax2.tick_params(axis='y', labelcolor='#000000')

        # 设置X轴标签和刻度
        plt.xticks(x, provinces, rotation=45)
        plt.xlabel('省份', labelpad=10)
        # plt.title('省份访问分布', pad=20, fontsize=14, fontweight='bold')

        # 合并图例
        lines = line + [bars]
        labels = [l.get_label() for l in lines]
        plt.legend(lines, labels, frameon=True, facecolor='white', edgecolor='#f0f0f0')

        # 网格线仅显示左侧Y轴的
        ax1.grid(True, linestyle='--', alpha=0.7)
        try:
            plt.tight_layout()
        except RuntimeError as e:
            if "Could not load glyph" not in str(e):
                raise

        # 保存图表到内存
        buffer = BytesIO()
        plt.savefig(buffer, format='png', dpi=200, bbox_inches='tight')
        buffer.seek(0)
        image_png = buffer.getvalue()
        buffer.close()
        plt.close(fig)

        return base64.b64encode(image_png).decode()

    def generate_spider_chart(self, spider_data):
        """生成蜘蛛爬取统计图表（饼图）"""
        plt.figure(figsize=(12, 6))
        spider_names = [k for k, v in spider_data['total'].items() if v > 0]
        counts = [spider_data['total'][k] for k in spider_names]

        # 创建饼图
        wedges, texts, autotexts = plt.pie(
            counts,
            labels=spider_names,
            autopct='%1.2f%%',
            startangle=90,  # 从垂直方向开始
            # autopct_textprops = {'fontsize': 12}, # 调整百分比字体大小
            textprops={'fontsize': 12},  # 调整标签字体大小
            pctdistance=0.8,
            wedgeprops={'edgecolor': 'white', 'width': 0.4},  # 分片边缘颜色
            colors=plt.cm.Pastel1.colors  # 使用柔和的配色方案
        )

        # 设置标题和样式
        plt.setp(texts, size=8)
        plt.setp(autotexts, size=8)
        # 在中心添加文本
        total = sum(counts)  # 计算总数
        if total > 0:
            max_value = max(counts)
            min_value = min(counts)
            max_name = spider_names[counts.index(max_value)]
            min_name = spider_names[counts.index(min_value)]
            plt.text(
                0, 0,
                f"总数：{total}\n\n"
                f"最大：{max_name} ({max_value})\n"
                f"最小：{min_name} ({min_value})",
                ha='center', va='center',
                fontsize=10,
                color='black',
                bbox=dict(facecolor='white', alpha=0.8, edgecolor='none')
            )

        # plt.title('蜘蛛爬取统计', pad=20, fontsize=14, fontweight='bold')
        plt.axis('equal')  # 确保饼图为正圆形
        try:
            plt.tight_layout()
        except RuntimeError as e:
            if "Could not load glyph" not in str(e):
                raise

        # 保存图表到内存
        buffer = BytesIO()
        plt.savefig(buffer, format='png', dpi=200, bbox_inches='tight')
        buffer.seek(0)
        image_png = buffer.getvalue()
        buffer.close()
        plt.close()

        return base64.b64encode(image_png).decode()

    def generate_terminal_chart(self, terminal_data):
        """生成终端分布图表"""
        plt.figure(figsize=(12, 6))
        # terminals = list(terminal_data['total'].keys())
        terminals = [k for k, v in terminal_data['total'].items() if v > 0]
        counts = [terminal_data['total'][k] for k in terminals]

        # 使用柔和的颜色
        chart_colors = plt.cm.Pastel1(np.linspace(0, 1, len(terminals)))

        # 绘制环状饼图
        patches, texts, autotexts = plt.pie(
            counts,
            labels=terminals,
            colors=chart_colors,
            autopct='%1.2f%%',
            pctdistance=0.8,
            # autopct_textprops = {'fontsize': 12}, # 调整百分比字体大小
            textprops={'fontsize': 12},  # 调整标签字体大小
            wedgeprops={'edgecolor': 'white', 'width': 0.4}  # 添加环宽度参数
        )

        # 调整标签字体大小
        plt.setp(texts, size=8)
        plt.setp(autotexts, size=8)

        # 在中心添加文本
        total = sum(counts)  # 计算总数
        if total > 0:
            max_value = max(counts)
            min_value = min(counts)
            max_name = terminals[counts.index(max_value)]
            min_name = terminals[counts.index(min_value)]
            plt.text(
                0, 0,
                f"总数：{total}\n\n"
                f"最大：{max_name} ({max_value})\n"
                f"最小：{min_name} ({min_value})",
                ha='center', va='center',
                fontsize=10,
                color='black',
                bbox=dict(facecolor='white', alpha=0.8, edgecolor='none')
            )

        # plt.title('终端分布', pad=20, fontsize=14, fontweight='bold')
        plt.axis('equal')  # 保持圆形
        try:
            plt.tight_layout()
        except RuntimeError as e:
            if "Could not load glyph" not in str(e):
                raise

        buffer = BytesIO()
        plt.savefig(buffer, format='png', dpi=200, bbox_inches='tight')
        buffer.seek(0)
        image_png = buffer.getvalue()
        buffer.close()
        plt.close()

        return base64.b64encode(image_png).decode()

    def generate_status_chart(self, status_list):
        """生成HTTP状态码分布环状图"""
        statuses = [str(item['status']) for item in status_list if item['request'] != 0]
        counts = [item['request'] for item in status_list if item['request'] != 0]

        plt.figure(figsize=(12, 6))
        chart_colors = plt.cm.Pastel1(np.linspace(0, 1, len(statuses)))

        patches, texts, autotexts = plt.pie(
            counts,
            labels=statuses,
            colors=chart_colors,
            autopct='%1.2f%%',
            pctdistance=0.8,
            # autopct_textprops = {'fontsize': 12}, # 调整百分比字体大小
            textprops={'fontsize': 12},  # 调整标签字体大小
            wedgeprops={'edgecolor': 'white', 'width': 0.4},
        )

        plt.setp(texts, size=8)
        plt.setp(autotexts, size=8)
        # 在中心添加文本
        total = sum(counts)  # 计算总数
        if total > 0:
            max_value = max(counts)
            min_value = min(counts)
            max_name = statuses[counts.index(max_value)]
            min_name = statuses[counts.index(min_value)]
            plt.text(
                0, 0,
                f"总数：{total}\n\n"
                f"最大：{max_name} ({max_value})\n"
                f"最小：{min_name} ({min_value})",
                ha='center', va='center',
                fontsize=10,
                color='black',
                bbox=dict(facecolor='white', alpha=0.8, edgecolor='none')
            )
        # plt.title('HTTP状态码分布', pad=20, fontsize=14, fontweight='bold')
        plt.axis('equal')
        try:
            plt.tight_layout()
        except RuntimeError as e:
            if "Could not load glyph" not in str(e):
                raise

        buffer = BytesIO()
        plt.savefig(buffer, format='png', dpi=200, bbox_inches='tight')
        buffer.seek(0)
        return base64.b64encode(buffer.getvalue()).decode()


# 新增PDF生成类体系
class PDFStyleManager:
    """管理PDF报告的所有样式定义"""

    def __init__(self, doc: SimpleDocTemplate):
        # 注册中文字体
        addMapping('NotoSansR', 0, 0, 'NotoSansR')  # 正常/常规样式
        addMapping('NotoSansB', 0, 0, 'NotoSansB')  # 加粗样式（如果需要）

        # 创建基础样式
        self.styles = getSampleStyleSheet()
        self.doc = doc

    def get_title_style(self):
        """
        获取主标题样式
        - 使用较大字号(24pt)
        - 居中对齐
        - 黑色文字
        - 粗体显示
        """
        return ParagraphStyle(
            'CustomTitle',
            parent=self.styles['Heading1'],
            fontName='NotoSansB',
            fontSize=24,
            spaceAfter=20,
            alignment=1,  # 居中对齐
            textColor=HexColor(0x000000),
        )

    def get_subtitle_style(self):
        """
        获取副标题样式
        - 较小字号(14pt)
        - 居中对齐
        - 深灰色文字
        - 粗体显示
        """
        return ParagraphStyle(
            'CustomSubtitle',
            parent=self.styles['Heading2'],
            fontName='NotoSansB',
            fontSize=14,
            spaceAfter=15,
            alignment=1,  # 居中对齐
            textColor=HexColor(0x333333),  # 深灰色
        )

    def get_heading_style(self):
        """
        获取章节标题样式
        - 中等字号(18pt)
        - 居中对齐
        - 白色文字
        - 蓝色背景
        - 圆角边框
        - 充足的内边距确保文字不超出背景
        - 粗体显示
        """
        return ParagraphStyle(
            'CustomHeading',
            parent=self.styles['Heading3'],
            fontName='NotoSansB',
            fontSize=20,
            spaceAfter=15,
            spaceBefore=5,
            alignment=1,  # 居中对齐
            # textColor=HexColor(0x000000),  # 白色文字
            # borderWidth=1,
            # borderColor=None,  # 蓝色边框
            # borderPadding=19,  # 增加内边距
            # borderRadius=5,  # 增加圆角
            # backColor=HexColor(0x20a53a),  #绿色背景
            fontWeight='bold'  # 添加粗体
        )

    def get_normal_style(self):
        """
        获取正文样式
        - 标准字号(12pt)
        - 居中对齐
        - 黑色文字
        """
        return ParagraphStyle(
            'CustomNormal',
            parent=self.styles['Normal'],
            fontName='NotoSansR',
            fontSize=12,
            spaceAfter=10,
            alignment=1  # 居中对齐
        )

    def get_table_style(self):
        """
        获取表格基本样式
        - 淡紫色表头背景
        - 黑色文字
        - 灰色网格线
        - 居中对齐
        - 交替行背景色(浅灰、白色)
        """
        return [
            ('BACKGROUND', (0, 0), (-1, 0), HexColor(0x52ff65)),
            ('WORDWRAP', (0, 0), (-1, -1), True),  # 自动换行
            ('TEXTCOLOR', (0, 0), (-1, 0), HexColor(0x000000)),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'NotoSansR'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 6),
            ('BACKGROUND', (0, 1), (-1, -1), HexColor(0xFFFFFF)),
            ('TEXTCOLOR', (0, 1), (-1, -1), HexColor(0x000000)),
            ('FONTNAME', (0, 1), (-1, -1), 'NotoSansR'),
            ('FONTSIZE', (0, 1), (-1, -1), 9),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('GRID', (0, 0), (-1, -1), 0.5, HexColor(0x808080)),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [
                HexColor(0xdfdfdf), HexColor(0xFFFFFF),
                HexColor(0xF5F5F5), HexColor(0xFFFFFF)]
             )
        ]

    def get_table_ps_style(self):
        """
        获取表格的每个格子的样式， ParagraphStyle
        :return:
        """
        return ParagraphStyle(
            'CustomTablePS',
            parent=self.styles['Normal'],
            fontName='NotoSansR',
            wordWrap=None,  # 自动换行
            fontSize=9,
            spaceAfter=10,
            alignment=1,  # 居中对齐
            textColor=HexColor(0x000000),
            borderWidth=0,
            borderColor=None,
            borderPadding=0,
            borderRadius=0,
            # backColor=HexColor(0xFFFFFF),
        )

    def get_image_table_style(self):
        """
        获取图片表格样式
        - 灰色边框
        - 白色背景
        - 居中对齐
        - 适当的内边距
        """
        return TableStyle([
            ('BOX', (0, 0), (-1, -1), 0.5, HexColor(0x808080)),
            ('BACKGROUND', (0, 0), (-1, -1), HexColor(0xFFFFFF)),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('PADDING', (0, 0), (-1, -1), 10),
        ])

    def get_ring_graph_style(self):
        """
        获取环形图样式
        - 无边框
        - 白色背景
        - 居中对齐
        - 无内边距
        """
        return TableStyle([
            ('BOX', (0, 0), (-1, -1), 0, HexColor(0xFFFFFF)),
            ('BACKGROUND', (0, 0), (-1, -1), HexColor(0xFFFFFF)),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('PADDING', (0, 0), (-1, -1), 0),
        ])


class PDFSection:
    """表示PDF报告中的一个部分"""

    def __init__(self, toc: List[Tuple[int, str, int]], title, style_manager):
        self.title = title
        self.style_manager = style_manager
        self.content = []
        self.toc = toc

    def add_bt(self):
        bt_png_file = os.path.join(os.path.dirname(__file__), 'bt.png')
        self.content.append(Image(bt_png_file, width=200, height=220))

    def add_title(self):
        """添加部分标题"""
        self.content.append(Spacer(1, 10))
        self.content.append(Paragraph(self.title, self.style_manager.get_heading_style()))
        self.content.append(Spacer(1, 10))
        return self

    def add_subtitle(self, subtitle: str, height=10):
        """添加部分副标题"""
        self.content.append(Paragraph(subtitle, self.style_manager.get_subtitle_style()))
        if height > 0:
            self.content.append(Spacer(1, height))
        return self

    def add_chart(self, chart_data, width=450, height=250, subtitle=None):
        """添加图表"""
        if subtitle:
            self.content.append(Paragraph(subtitle, self.style_manager.get_subtitle_style()))

        img_data = base64.b64decode(chart_data)
        img = Image(BytesIO(img_data), width=width, height=height)

        # 添加图表与边框
        img_table = Table([[img]], colWidths=[width + 30], rowHeights=[height + 20])
        img_table.setStyle(self.style_manager.get_image_table_style())
        self.content.append(img_table)
        self.content.append(Spacer(1, 15))
        return self

    def add_table(self, data, col_widths, custom_style=None, **kwargs):
        """添加表格"""
        if not custom_style:  # 如果没有自定义样式，则使用默认样式, 修改数据，支持换行
            data = [[Paragraph(cell, self.style_manager.get_table_ps_style()) for cell in row] for row in data]
        table = LongTable(data, colWidths=col_widths, **kwargs)
        table.repeatRows = 1  # 重复第一行
        if custom_style:
            table.setStyle(TableStyle(custom_style))
        else:
            table.setStyle(TableStyle(self.style_manager.get_table_style()))
        self.content.append(table)
        return self

    def add_spacer(self, width=1, height=15):
        """添加空白"""
        self.content.append(Spacer(width, height))
        return self

    def add_list(self, items, style: ParagraphStyle = None):
        for item in items:
            self.content.append(
                Paragraph("• {}".format(item), style if style else self.style_manager.get_normal_style()))
            self.content.append(Spacer(1, 5))

        return self

    def add_page_break(self):
        """添加分页符"""
        self.content.append(PageBreak())
        return self

    def get_content(self):
        """获取部分内容"""
        return self.content


class _BTDocTemplate(SimpleDocTemplate):

    def afterFlowable(self, flowable: Flowable):
        """注册目录条目和书签"""
        if flowable.__class__ is Paragraph:
            assert isinstance(flowable, Paragraph)
            text = flowable.getPlainText()
            style = flowable.style.name
            if style == 'CustomHeading':
                # 设置锚点以便目录跳转
                self.canv.bookmarkPage(text)
                self.notify('TOCEntry', (0, text, self.page))
                # 添加一级书签
                self.canv.addOutlineEntry(text, text, level=0, closed=False)


class PDFReportGenerator:
    """主类：负责生成完整的PDF报告"""

    def __init__(self, data, doc_path: str, call_log: Callable[[str], None] = None):
        self.data = data
        self.doc_path = doc_path
        self._doc = None
        self.style_manager = PDFStyleManager(self.doc)
        self.chart_generator = ChartGenerator()
        self.story = []
        self.charts = {}
        self._call_log = call_log
        self.toc_entries = []

    def log(self, msg: str):
        if self._call_log:
            self._call_log(msg)
        else:
            print(msg)

    # 创建PDF文档
    @property
    def doc(self) -> _BTDocTemplate:
        if self._doc is None:
            self._doc = _BTDocTemplate(
                self.doc_path,
                pagesize=A4,
                rightMargin=50,
                leftMargin=50,
                topMargin=50,
                bottomMargin=50
            )
            self._doc.title = self.data['title']
        return self._doc

    def prepare_data(self):
        """准备数据，生成所需的图表"""
        # 生成图表
        self.charts = {
            'trends': self.chart_generator.generate_trend_charts(self.data['global']['list']),
            'province': self.chart_generator.generate_province_chart(self.data['china_province']['list']),
            'spider': self.chart_generator.generate_spider_chart(self.data['spider']),
            'terminal': self.chart_generator.generate_terminal_chart(self.data['terminal_data']),
            'status': self.chart_generator.generate_status_chart(self.data['status_data']["list"])
        }

    def create_header_footer(self):
        """创建页眉页脚函数"""

        def add_header_footer(canvas, doc):
            canvas.saveState()
            # 页眉
            canvas.setFont('NotoSansR', 8)
            canvas.setFillColor(HexColor(0xD3D3D3))
            canvas.drawString(50, 800, self.data['title'])
            canvas.drawRightString(A4[0] - 50, 800, f"数据源时间: {self.data['time_range']}")
            # 页脚
            canvas.setFont('NotoSansR', 8)
            canvas.drawString(50, 30, f"服务器: {self.data['server_name']}")
            canvas.drawRightString(A4[0] - 50, 30, f"第 {canvas.getPageNumber()} 页")
            # 添加分隔线
            canvas.setStrokeColor(HexColor(0xD3D3D3))
            canvas.line(50, 795, A4[0] - 50, 795)
            canvas.line(50, 40, A4[0] - 50, 40)
            canvas.restoreState()

        return add_header_footer

    def add_toc_section(self):
        self.story.append(Spacer(1, 10))
        self.story.append(Paragraph(self.data['title'], self.style_manager.get_title_style()))
        self.story.append(Spacer(1, 15))
        self.story.append(Paragraph('目录', self.style_manager.get_heading_style()))
        self.story.append(Spacer(1, 10))
        toc = TableOfContents()
        toc.levelStyles = [
            ParagraphStyle(
                name='TocHeading1',
                fontName='NotoSansR',
                fontSize=16,
                leading=22,
                spaceAfter=18,
                alignment=0,
                leftIndent=10,
                rightIndent=10,
            )
        ]
        toc.dot = '·'
        toc.dotsMinLevel = 0
        toc.gap = 8
        self.story.append(toc)
        self.story.append(PageBreak())

    # def add_title_section(self):
    #     """添加标题部分"""
    #     subtitle_style = self.style_manager.get_subtitle_style()
    #     self.story.append(Paragraph(f"服务器：{self.data['server_name']}", subtitle_style))
    #     self.story.append(Paragraph(f"数据源时间：{self.data['time_range']}", subtitle_style))
    #     self.story.append(Paragraph(f"生成时间：{self.data['create_date']}", subtitle_style))
    #     self.story.append(Spacer(1, 10))
    #     self.story.append(Spacer(1, 10))
    #
    #     # 添加装饰线
    #     self.story.append(Paragraph(
    #         '<para align="center"><font color="lightgrey">—————————————————————————————————</font></para>',
    #         self.style_manager.get_normal_style())
    #     )
    #     self.story.append(Spacer(1, 15))

    def add_global_stats_section(self):
        """添加概览部分"""
        section = PDFSection(self.toc_entries, '概览', self.style_manager)
        global_data = self.data['global']['total']

        section.add_title()
        section.add_spacer()
        section.add_bt()
        section.add_spacer()
        section.add_subtitle(f"服务器：{self.data['server_name']}", height=0)
        section.add_subtitle(f"网站：{self.data['site_name']}", height=0)
        section.add_subtitle(f"数据源时间：{self.data['time_range']}", height=0)
        section.add_subtitle(f"生成时间：{self.data['create_date']}", height=0)
        section.add_spacer()

        # 统计卡片
        stats_row = [
            ['浏览数（PV）   {}'.format(str(global_data['pv'])), '访客量（UV）   {}'.format(str(global_data['uv']))],
            ['总IP数    {}'.format(str(global_data['ip'])), '总请求数  {}'.format(str(global_data['request']))],
            ['总流量    {}'.format(format_traffic(global_data['traffic'])),
             '蜘蛛爬虫    {}'.format(str(global_data['spider']))],
            ['慢请求数   {}'.format(global_data['slow_count']), "异常请求数    {}".format(str(global_data['error']))],
        ]

        custom_style = [
            ('BACKGROUND', (0, 0), (-1, -1), HexColor('#ffffff')),
            ("FONTSIZE", (0, 0), (-1, -1), 14),
            ("FONTNAME", (0, 0), (-1, -1), "NotoSansB"),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            # padding 设置
            # ('TOPPADDING', (0, 0), (-1, -1), 10),
            # ('PADDING', (0, 0), (-1, -1), 16),        # 增加单元格内边距
            # 垂直对齐
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('GRID', (0, 0), (-1, -1), 9, HexColor('#ffffff')),  # 无边框
        ]

        section.add_table(stats_row, [2.8 * inch, 2.8 * inch], custom_style, rowHeights=50)
        section.add_page_break()

        self.story.extend(section.get_content())

    def add_trends_section(self):
        """添加趋势图表部分"""
        section = PDFSection(self.toc_entries, '访问趋势', self.style_manager)
        section.add_title()

        # 添加各个趋势图表
        for chart_name, chart_data in self.charts['trends'].items():
            subtitle = None
            if chart_name == 'pv_uv':
                subtitle = 'PV/UV/IP趋势'
            elif chart_name == 'ip_request':
                subtitle = '请求数趋势'
            elif chart_name == 'traffic':
                subtitle = '流量趋势'
            elif chart_name == 'spider_error':
                subtitle = '蜘蛛爬取'

            section.add_chart(chart_data, subtitle=subtitle)

        section.add_page_break()
        self.story.extend(section.get_content())

    def add_province_section(self):
        """添加省份访问分布部分"""
        if len(self.data['china_province']['list']) == 0:
            return
        section = PDFSection(self.toc_entries, '省份访问分布', self.style_manager)
        section.add_title()

        # 添加省份图表
        section.add_chart(self.charts['province'])

        # 添加省份数据表格
        province_data = [['省份', 'IP数', '请求数']]
        for item in self.data['china_province']['list']:
            province_data.append([item['title'], str(item['ip_count']), str(item['request'])])

        section.add_table(province_data, [2 * inch, 2 * inch, 2 * inch])
        section.add_page_break()

        self.story.extend(section.get_content())

    def add_ip_section(self, top: int = 50):
        """添加IP访问统计部分"""
        section = PDFSection(self.toc_entries, 'IP访问统计', self.style_manager)
        section.add_title()

        # 添加IP数据表格
        ip_data = [['IP地址', '请求数', '流量', '信息']]
        top_idx = max(10, min(top, len(self.data['uri_data']['list'])))
        for ip in self.data['ip_data']['list'][:top_idx]:
            ip_data.append([ip['ip'], str(ip['request']), format_traffic(ip['traffic']), ip['info']])

        section.add_table(ip_data, [2 * inch, 0.8 * inch, 1 * inch, 2.8 * inch])
        section.add_page_break()

        self.story.extend(section.get_content())

    def add_uri_section(self, top: int = 50):
        """添加热门页面部分"""
        section = PDFSection(self.toc_entries, '热门页面', self.style_manager)
        section.add_title()

        # 添加uri数据表格
        uri_data = [['URI', 'PV', 'UV', '请求数', '流量']]
        top_idx = max(10, min(top, len(self.data['uri_data']['list'])))
        for page in self.data['uri_data']['list'][:top_idx]:
            uri_data.append([
                page['uri'],
                str(page['pv']),
                str(page['uv']),
                str(page['request']),
                format_traffic(page['traffic'])
            ])

        section.add_table(uri_data, [3 * inch, 0.8 * inch, 0.8 * inch, 0.8 * inch, 1 * inch])
        section.add_page_break()

        self.story.extend(section.get_content())

    def add_spider_section(self):
        """添加蜘蛛统计部分"""
        if sum(self.data['spider']['total'].values()) == 0:
            return
        section = PDFSection(self.toc_entries, '蜘蛛爬取统计', self.style_manager)
        section.add_title()

        # 添加蜘蛛图表
        img_data = base64.b64decode(self.charts['spider'])
        img = Image(BytesIO(img_data), width=588, height=300)

        # 添加图表与边框
        img_table = Table([[img]], colWidths=[450])
        img_table.setStyle(self.style_manager.get_ring_graph_style())
        section.content.append(img_table)
        section.content.append(Spacer(1, 15))

        show_spider = list(self.data['spider']['total'].keys())
        # 添加蜘蛛数据表格
        spider_data = [['时间', ] + show_spider]
        for spider_items in self.data['spider']['list']:
            spider_data.append([spider_items['date']] + [str(spider_items.get(spider, 0)) for spider in show_spider])

        spider_data.append(['总计', ] + [str(self.data['spider']['total'].get(spider, 0)) for spider in show_spider])

        section.add_table(spider_data, [0.9 * inch, ] + [420 / len(show_spider) for _ in range(len(show_spider))])
        section.add_page_break()

        self.story.extend(section.get_content())

    def add_terminal_section(self):
        """添加客户端分布部分"""
        total_visits = sum(self.data['terminal_data']['total'].values())
        if total_visits == 0:
            return
        section = PDFSection(self.toc_entries, '客户端分布', self.style_manager)
        section.add_title()

        # 添加客户端图表
        img_data = base64.b64decode(self.charts['terminal'])
        img = Image(BytesIO(img_data), width=588, height=300)

        # 添加图表与边框
        img_table = Table([[img]], colWidths=[450])
        img_table.setStyle(self.style_manager.get_ring_graph_style())
        section.content.append(img_table)
        section.content.append(Spacer(1, 15))

        # 添加客户端数据表格
        terminal_data = [['客户端', '访问量', '占比']]
        # total_visits = sum(self.data['terminal_data']['total'].values())
        for terminal, count in self.data['terminal_data']['total'].items():
            percentage = (count / total_visits * 100)
            terminal_data.append([terminal, str(count), f"{percentage:.1f}%"])

        section.add_table(terminal_data, [2 * inch, 2 * inch, 2 * inch])
        section.add_page_break()

        self.story.extend(section.get_content())

    def add_status_section(self):
        """添加HTTP状态码统计部分"""
        global_data = self.data['global']['total']
        if global_data['request'] == 0:
            return
        section = PDFSection(self.toc_entries, 'HTTP状态码统计', self.style_manager)
        section.add_title()

        # 添加客户端图表
        img_data = base64.b64decode(self.charts['status'])
        img = Image(BytesIO(img_data), width=588, height=300)

        # 添加图表与边框
        img_table = Table([[img]], colWidths=[450])
        img_table.setStyle(self.style_manager.get_ring_graph_style())
        section.content.append(img_table)
        section.content.append(Spacer(1, 15))

        # 添加状态码数据表格
        status_data = [['状态码', '请求数', '占比']]
        for status in self.data['status_data']['list']:
            percentage = (status['request'] / global_data['request'] * 100)
            status_data.append([str(status['status']), str(status['request']), f"{percentage:.1f}%"])

        section.add_table(status_data, [2 * inch, 2 * inch, 2 * inch])
        section.add_page_break()

        self.story.extend(section.get_content())

    def add_referer_section(self):
        """添加来源网站统计部分"""
        if len(self.data['referer_data']['list']) == 0:
            return

        section = PDFSection(self.toc_entries, '来源网站统计', self.style_manager)
        section.add_title()

        # 添加来源网站数据表格
        referer_data = [['来源', '请求数']]
        for item in self.data['referer_data']['list']:
            referer_data.append([item['referer'], str(item['request'])])

        section.add_table(referer_data, [5 * inch, 1 * inch])
        section.add_page_break()

        self.story.extend(section.get_content())

    def generate_pdf(self):
        """生成完整PDF报告"""
        # 准备数据
        self.log("开始生成PDF报告...")
        self.log("准备生成图表信息...")
        self.prepare_data()
        self.log("图表信息生成成功...")
        # 添加各个部分
        self.add_toc_section()
        self.add_global_stats_section()
        self.add_trends_section()
        self.add_uri_section()
        self.add_ip_section()
        self.add_spider_section()
        self.add_status_section()
        self.add_province_section()
        self.add_referer_section()
        self.add_terminal_section()

        header_footer = self.create_header_footer()
        self.doc.multiBuild(self.story, onFirstPage=header_footer, onLaterPages=header_footer)
        self.log("PDF报告生成成功...")
        self.log("PDF报告已保存到{}".format(self.doc_path))

        return None


def export_pdf(data: dict, pdf_file: str, call_log: Callable[[str], None]):
    try:
        # 获取数据
        # 创建PDF生成器
        generator = PDFReportGenerator(data, pdf_file, call_log)

        # 生成PDF
        generator.generate_pdf()
        return True

    except Exception as e:
        # 记录错误并返回错误信息
        call_log("错误信息: {}".format(traceback.format_exc()))
        call_log("PDF报告生成失败, 信息报错信息如上")
        return False

