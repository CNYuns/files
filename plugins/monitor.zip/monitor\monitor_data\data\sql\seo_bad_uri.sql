-- path_list 表
CREATE TABLE IF NOT EXISTS `path_list`
(
    `path_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `path`    TEXT DEFAULT "" NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS `idx_path` ON `path_list` (`path`);

-- query_list表
CREATE TABLE IF NOT EXISTS `query_list`
(
    `query_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `query`    TEXT DEFAULT "" NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS `idx_query` ON `query_list` (`query`);

-- seo_bad_uri 表
CREATE TABLE IF NOT EXISTS `seo_bad_uri`
(
    `id`          INTEGER PRIMARY KEY AUTOINCREMENT,
    `path_id`     INTEGER DEFAULT 0, -- 路径信息
    `query_id`    INTEGER DEFAULT 0, -- 查询参数
    `time`        INTEGER DEFAULT 0, -- 首次记录的时间
    `count`       INTEGER DEFAULT 0, -- 访问次数
    `disable`     INTEGER DEFAULT 0, -- 是否禁用
    `option_time` INTEGER DEFAULT 0, -- 最近处理的时间
    `s_time`      INTEGER DEFAULT 0, -- 添加到死链的时间
    `status`      INTEGER DEFAULT 0  -- 是否已处理
);

-- 增加索引
CREATE UNIQUE INDEX IF NOT EXISTS `idx_seo_bad_uri` ON `seo_bad_uri` (`path_id`, `query_id`);
CREATE INDEX IF NOT EXISTS `idx_bad_uri_status` ON `seo_bad_uri` (`status`, `disable`);
CREATE INDEX IF NOT EXISTS `idx_bad_uri_time` ON `seo_bad_uri` (`time`);
