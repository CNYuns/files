-- 客户端浏览器统计表
CREATE TABLE IF NOT EXISTS `browser_total` (
    `browser_total_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `date` INTEGER DEFAULT 0,                       -- 日期 20190101
    `browser_id` INTEGER DEFAULT 0,                 -- 浏览器ID
    `request` INTEGER DEFAULT 0                     -- 请求次数
);

-- 增加索引
CREATE INDEX IF NOT EXISTS `idx_date_browser_id` ON `browser_total` (`date`,`browser_id`);
CREATE INDEX IF NOT EXISTS `idx_date` ON `browser_total` (`date`);

