# conding:utf-8
import os
import shutil
import sys
import re
import json
import time
import socket
from typing import List

# 添加项目根目录到环境变量
os.chdir("/www/server/panel")
if "/www/server/panel" not in sys.path:
    sys.path.insert(0, "/www/server/panel")
if "/www/server/panel/class" not in sys.path:
    sys.path.insert(0, "/www/server/panel/class")

if "/www/server/panel/plugin/monitor" not in sys.path:
    sys.path.insert(0, "/www/server/panel/plugin/monitor")

import public
import db
from monitor_cmd import udp_cmd

class Service:
    __run_path = '{}/monitor'.format(public.get_setup_path())
    __plugin_path = public.get_plugin_path('monitor')
    __config_path = '{}/config'.format(__run_path)
    _webserver = public.GetWebServer()  # web服务
    __global_config = {}  # 全局配置
    __site_config = {}  # 网站配置
    __udp_cmd = b"PLUGIN_CMD|"  # 主进程通信信号
    def check_log_format(self,args = None):
        '''
            @name 检查日志格式配置
            @return void
        '''
        if self._webserver == "nginx":
            nginx_log_format_file = "{}/nginx_log_format.conf".format(self.__config_path)
            dst_file = "{}/vhost/nginx/0.monitor_log_format.conf".format(public.get_panel_path())
            if os.path.exists(dst_file):
                return True
            if not os.path.exists(nginx_log_format_file):
                return False
            public.writeFile(dst_file, public.readFile(nginx_log_format_file))
            public.set_mode(dst_file, '600')
            return os.path.exists(dst_file)
        else:
            apache_log_format_file = "{}/apache_log_format.conf".format(self.__config_path)
            dst_file = "{}/vhost/apache/0.monitor_log_format.conf".format(public.get_panel_path())
            if os.path.exists(dst_file):
                return True
            if not os.path.exists(apache_log_format_file):
                return False
            public.writeFile(dst_file, public.readFile(apache_log_format_file))
            public.set_mode(dst_file, '600')
            return os.path.exists(dst_file)

    def del_site_config(self,SiteName,is_reload = True,project_type="PHP"):
        '''
            @name 删除nginx网站配置
            @param SiteName 站点名称
            @return void
        '''
        # 根据项目类型确定配置文件名
        if self._webserver == "nginx":
            if project_type == "PHP" or project_type == "docker" or project_type=="WP2":
                config_file = '{}/vhost/nginx/{}.conf'.format(public.get_panel_path(),SiteName)
            elif project_type == 'proxy':
                config_file = '{}/vhost/nginx/{}.conf'.format(public.get_panel_path(),SiteName)
            else:
                config_file = '{}/vhost/nginx/{}_{}.conf'.format(public.get_panel_path(),project_type.lower(),SiteName)
        else:
            if project_type == "PHP" or project_type == "docker" or project_type=="WP2":
                config_file = '{}/vhost/apache/{}.conf'.format(public.get_panel_path(),SiteName)
            elif project_type == 'proxy':
                config_file = '{}/vhost/apache/{}.conf'.format(public.get_panel_path(),SiteName)
            else:
                config_file = '{}/vhost/apache/{}_{}.conf'.format(public.get_panel_path(),project_type.lower(),SiteName)

        if not os.path.exists(config_file): return False
        config = public.readFile(config_file)
        if not config: return False
        config = config.strip()

        # 检查是否存在配置
        if config.find('Monitor-Config') == -1: return False

        # 清理配置
        config = re.sub(r'\s*#\s*Monitor-Config-Start.*?#Monitor-Config-End','',config,flags=re.S)
        config = config.strip()

        # 写入配置
        public.writeFile(config_file,config)

        if is_reload: public.serviceReload()
        return True

    def is_nginx_config_error(self):
        '''
            @name 检查Nginx配置是否有错误
            @return string
        '''
        result = public.ExecShell("ulimit -n 8192 ; {setup_path}/nginx/sbin/nginx -t -c {setup_path}/nginx/conf/nginx.conf".format(setup_path = public.get_setup_path()))
        searchStr = 'successful'
        if result[1].find(searchStr) != -1:
            return ""
        result = "\n".join(result)
        result = "<span style='color:red;'>检测到配置文件存在错误，操作已撤回：</span><pre>" + result + "</pre>"
        return result

    def is_config_error(self):
        '''
            @name 检查配置是否有错误(兼容nginx,apache)
            @return string
        '''
        if self._webserver == "nginx":
            result = public.ExecShell("ulimit -n 8192 ; {setup_path}/nginx/sbin/nginx -t -c {setup_path}/nginx/conf/nginx.conf".format(setup_path = public.get_setup_path()))
            searchStr = 'successful'
            if result[1].find(searchStr) != -1:
                return ""
        else:
            result = public.ExecShell("ulimit -n 8192 ; {setup_path}/apache/bin/apachectl -t".format(setup_path = public.get_setup_path()))
            searchStr = 'Syntax OK'
            if result[1].find(searchStr) != -1:
                return ""
        result = "\n".join(result)
        result = "<span style='color:red;'>检测到配置文件存在错误，操作已撤回：</span><pre>" + result + "</pre>"
        return result

    # 检测server层的日志发送配置是否存在
    def repair_nginx_main_monitor_config(self, server_config: str, site_id: int):
        # 去除注释 方便后续判断是否为正确的配置
        to_check_config = re.sub(r"\s*#.*", "", server_config, flags=re.M)
        rep_server = re.compile(r"\s*server\s*\{")
        res = rep_server.search(server_config)
        if res is None:
            return None
        s_idx = res.end()
        if to_check_config.count("}", s_idx) - 1 != to_check_config.count("{", s_idx):
            return None
        level_1_data = []  # 收集所有server层的配置字符
        level = 1
        for _ in range(to_check_config.count("}", s_idx)):
            next_r = to_check_config.find("}", s_idx)
            l_count = to_check_config.count("{", s_idx, next_r)
            if l_count == 0:
                if level == 1:
                    level_1_data.append((s_idx, next_r))
                level -= 1
                if level == 0:
                    break
            else:
                if level == 1:
                    level_1_data.append((s_idx, to_check_config.find("{", s_idx)))
                level += l_count - 1
            s_idx = next_r + 1

        rep_log = re.compile(r"^\s*(access_log|error_log)\s+(?P<path>[^;\s]*)(\s+(?P<name>\w+))?;", re.M)
        access_ok, error_ok, send_num = False, False, 0
        for s_idx, e_idx in level_1_data:  # 遍历所有server层配置寻找access_log配置
            for tmp in rep_log.finditer(to_check_config[s_idx:e_idx]):
                path = tmp.group("path")
                if path.find("unix:/tmp/bt-monitor.sock") != -1:  # 如果有对应的日志发送配置就跳过
                    send_num += 1
                if path.find("tag={}__access".format(site_id)) != -1:  # 如果有对应的日志发送配置就跳过
                    access_ok = True
                if path.find("tag={}__error".format(site_id)) != -1:
                    error_ok = True

        # 配置正常，则不需要处理直接返回
        # 否则删除可能存在的错误配置，并添加新的配置 （此时使用原文操作）
        if error_ok and access_ok and send_num == 2:
            return True

        # 可能存在的错误配置
        server_config = re.sub(r"(#.*)?\s*access_log\s+syslog:server=unix:.*", "", server_config)
        server_config = re.sub(r"\s*error_log\s+syslog:server=unix:.*(\n[ \r\t]*#.*)?", "", server_config)

        access_log = "access_log syslog:server=unix:/tmp/bt-monitor.sock,nohostname,tag={}__access {};".format(
            site_id, self.get_log_format_name(site_id))
        error_log = "error_log syslog:server=unix:/tmp/bt-monitor.sock,nohostname,tag={}__error;".format(site_id)
        last_idx = server_config.rfind("}")
        if last_idx > 0:
            config = "{}\n    #Monitor-Config-Start 网站监控报表日志发送配置\n    {}\n    {}\n    #Monitor-Config-End\n{}".format(
                server_config[:last_idx], access_log, error_log, server_config[last_idx:]
            )
        else:
            return None

        return config

    def add_site_config(self,SiteName,is_reload = True,SiteId=0,project_type="PHP"):
        '''
            @name 添加网站配置(兼容nginx,apache)
            @param SiteName 站点名称
            @param SiteId 站点ID
            @param project_type 站点类型
            @return void
        '''
        # nginx的情况
        if self._webserver == "nginx":
            # 根据项目类型确定配置文件名
            if project_type == "PHP" or project_type == "docker" or project_type=="WP2":
                config_file = '{}/vhost/nginx/{}.conf'.format(public.get_panel_path(), SiteName)
            elif project_type == 'proxy':
                config_file = '{}/vhost/nginx/{}.conf'.format(public.get_panel_path(), SiteName)
            else:
                config_file = '{}/vhost/nginx/{}_{}.conf'.format(public.get_panel_path(), project_type.lower(), SiteName)

            if not os.path.exists(config_file): return False
            config = public.readFile(config_file)
            if not config:
                return False
            old_config = config[:]
            config = config.strip()

            sub_dir = list(re.finditer(r"(\n#.*\n)?\s*server\s*\{", config))
            is_monitor_config = True
            if len(sub_dir) > 1:
                server_list = []
                start_idx = 0
                for i in sub_dir[1:]:
                    server_list.append(config[start_idx: i.start()])
                    start_idx = i.start()
                server_list.append(config[start_idx:])

                for idx, s in enumerate(server_list):
                    res = self.repair_nginx_main_monitor_config(s, SiteId)
                    if isinstance(res, str):
                        is_monitor_config = False
                        server_list[idx] = res
                config = "".join(server_list)
            else:
                res = self.repair_nginx_main_monitor_config(config, SiteId)
                if isinstance(res, str):
                    is_monitor_config = False
                    config = res

            # 先检查是否存在配置
            is_monitor_log = re.findall(r"access_log\s+/dev/null;\s+}",config)
            is_monitor_log2 = re.findall(r"error_log\s+/dev/null;\s+access_log\s+/dev/null;\s+}",config)
            if is_monitor_config and not is_monitor_log and not is_monitor_log2:
                return False

            # 添加配置
            access_log = "access_log syslog:server=unix:/tmp/bt-monitor.sock,nohostname,tag={}__access {};".format(
                SiteId, self.get_log_format_name(SiteId))
            error_log = "error_log syslog:server=unix:/tmp/bt-monitor.sock,nohostname,tag={}__error;".format(SiteId)

            # 替换静态日志配置
            if is_monitor_log2:
                tips_start = "\n\t\t\t\t#Monitor-Config-Start 网站监控报表日志发送配置"
                tips_end = "\n\t\t\t\t#Monitor-Config-End\n    }"
                monitor_log_config = "access_log  /dev/null;\n\t\terror_log  /dev/null;" + tips_start + "\n\t\t\t\t" + access_log + "\n\t\t\t\t" + error_log + tips_end
                config = re.sub(r"error_log\s+/dev/null;\s+access_log\s+/dev/null;\s+}", monitor_log_config, config)
            if is_monitor_log:
                tips_start = "\n\t\t\t\t#Monitor-Config-Start 网站监控报表日志发送配置"
                tips_end = "\n\t\t\t\t#Monitor-Config-End\n    }"
                monitor_log_config = tips_start + "\n\t\t\t\t" + access_log + tips_end
                config = re.sub(r"access_log\s+/dev/null;\s+}", "access_log /dev/null;" + monitor_log_config, config)

        # apache的情况
        else:
            # 根据项目类型确定配置文件名
            if project_type == "PHP" or project_type == "docker" or project_type=="WP2":
                config_file = '{}/vhost/apache/{}.conf'.format(public.get_panel_path(),SiteName)
            elif project_type == 'proxy':
                config_file = '{}/vhost/apache/{}.conf'.format(public.get_panel_path(),SiteName)
            else:
                config_file = '{}/vhost/apache/{}_{}.conf'.format(public.get_panel_path(),project_type.lower(),SiteName)

            if not os.path.exists(config_file): return False
            config = public.readFile(config_file)
            if not config: return False
            old_config = config[:]
            config = config.strip()

            # 先检查是否存在配置
            is_monitor_config = config.find('Monitor-Config') != -1
            rep_pattern = r'CustomLog\s+"[\w\/\.\-\_]+"\s+combined'
            is_monitor_log = re.findall(rep_pattern,config)
            if is_monitor_config and not is_monitor_log: return False

            if not SiteId:
                find = public.M('sites').where('name=?',(SiteName,)).field('id').find()
                if isinstance(find,dict): SiteId = find['id']
            if not SiteId: return False

            # 添加配置
            custom_log = 'CustomLog "|/usr/bin/logger -u /tmp/bt-monitor.sock -d -S 8192 -t {}__access" monitor'.format(SiteId)
            error_log = 'ErrorLog "|/usr/bin/logger -u /tmp/bt-monitor.sock -d -S 8192 -t {}__error"'.format(SiteId)

            if not is_monitor_config:
                tips_start = "\n\t\t#Monitor-Config-Start 网站监控报表日志发送配置"
                tips_end = "\n\t\t#Monitor-Config-End"
                monitor_log_config =  tips_start + "\n\t\t" + custom_log + "\n\t\t" + error_log + tips_end
                sub_lines = re.findall(rep_pattern,config)
                tmp_lines = []
                for i in sub_lines:
                    if i in tmp_lines: continue
                    tmp_lines.append(i)

                for i in tmp_lines:
                    config = config.replace(i,i + monitor_log_config)

        # 写入配置
        public.writeFile(config_file,config)
        config_err = self.is_config_error()
        if config_err:
            public.writeFile(config_file,old_config)
            return config_err

        if is_reload: public.serviceReload()
        return True

    def get_global_config(self):
        '''
            @name 获取全局配置
            @return dict
        '''
        global_config_file = self.__config_path + "/config.json"
        if not os.path.exists(global_config_file):
            self.init_global_config()

        try:
            self.__global_config = json.loads(public.ReadFile(global_config_file))
        except:
            self.init_global_config()

        if 'install_time' not in self.__global_config:
            time_path = "/www/server/panel/plugin/monitor/install_time.pl"
            if not os.path.exists(time_path):
                self.__global_config['install_time'] = int(time.time())
            else:
                try:
                    self.__global_config['install_time'] = int(public.ReadFile(time_path))
                except:
                    self.__global_config['install_time'] = int(time.time())
            self.save_global_config()

        if "bad_seo_uri_collect" not in self.__global_config:
            self.__global_config['bad_seo_uri_collect'] = True
            self.save_global_config()

        return self.__global_config

    def init_global_config(self):
        '''
            @name 初始化全局配置
            @return void
        '''
        default_config = {
            "open": True,
            "debug": False,
            "listen": "0.0.0.0",
            "port": 9030,
            "save_err_log": True,
            "slow_time": 1000,
            "data_save_path":"/www/server/monitor/data/dbs",
            "max_access_save_day": 30,
            "max_err_save_day": 30,
            "max_slow_save_day": 30,
            "max_total_save_day": 30,
            "max_access_save_size":1073741824,
            "max_err_save_size":104857600,
            "max_slow_save_size":209715200,
            "max_memory_size":536870912,
            "bad_seo_uri_collect": True,
            "ip_total_mode": 0,
            "is_cdn": 1,
            "is_baidu_cdn": 0,
            "filter_uri": [
                "/favicon.ico"
            ],
            "filter_method": [
            ],
            "filter_status": [],
            "filter_exts": [
                ".png",
                ".jpeg",
                ".jpg",
                ".gif",
                ".bmp",
                ".swf",
                ".icon",
                ".js",
                ".css",
                ".woff",
                ".woff2",
                ".ttf",
                ".eot",
                ".svg"
            ],
            "filter_user_agent": [],
            "filter_host": [],
            "filter_ip": []
        }

        self.__global_config = default_config
        self.save_global_config()

    def save_global_config(self):
        '''
            @name 保存全局配置
            @return void
        '''
        global_config_file = self.__config_path + "/config.json"
        public.WriteFile(global_config_file, json.dumps(self.__global_config))
        # self.reload_config()

    def read_site_config(self):
        '''
            @name 读取网站配置
            @return void
        '''
        site_config_file = self.__config_path + "/sites.json"
        if not os.path.exists(site_config_file):
            return {}

        try:
            self.__site_config = json.loads(public.ReadFile(site_config_file))
        except:
            return {}

        for _, v in self.__site_config.items():
            if "site_id" not in v:
                v["site_id"] = 0

        return self.__site_config


    def get_site_config(self,SiteName):
        '''
            @name 获取网站配置
            @param SiteName 网站名称
            @return dict
        '''
        if not self.__site_config:
            self.read_site_config()

        if SiteName not in self.__site_config:
            self.init_site_config(SiteName)

        # return self.__site_config[SiteName]

    def init_site_config(self,SiteName):
        '''
            @name 初始化网站配置
            @param SiteName 网站名称
            @return void
        '''
        if not self.__global_config:
            self.get_global_config()

        default_config = {
            "open":True,
            "slow_time": self.__global_config['slow_time'],
            "save_err_log": self.__global_config['save_err_log'],
            "ip_total_mode": self.__global_config['ip_total_mode'],
            "uri_total_mode": 0,
            "is_cdn": self.__global_config['is_cdn'],
            "is_baidu_cdn": self.__global_config['is_baidu_cdn'],
            "filter_uri": [],
            "filter_method": [],
            "filter_status": [],
            "filter_exts": [],
            "filter_user_agent": [],
            "filter_host": [],
            "filter_ip": []
        }

        self.__site_config[SiteName] = default_config
        # self.save_site_config()

    def save_site_config(self):
        '''
            @name 保存网站配置
            @return void
        '''
        site_config_file = self.__config_path + "/sites.json"
        public.WriteFile(site_config_file,json.dumps(self.__site_config))
        # self.reload_config()

    def check_site_config(self, args=None):
        '''
            @name 检查网站配置文件
            @return void
        '''

        # 若为apache，先加载logio模块，否则后面的日志格式会报错
        if self._webserver == "apache":
            self.open_apache_logio_module()

        # 检查是否存在自定义日志格式配置文件
        if not self.check_log_format():
            return public.returnMsg(False, "日志格式化配置文件丢失")
        self.update_log_format()
        config_error = self.is_config_error()
        if config_error:
            return public.returnMsg(False, "配置文件存在错误，无法继续检查：" + config_error)

        is_reload = False

        # 获取网站列表
        site_list = public.M('sites').field('id,name,project_type').select()
        self.get_global_config()   # 处理全局配置文件中的补丁操作

        from monitor_seo import SeoUriCollectConfig

        seo_config = SeoUriCollectConfig()

        # 遍历网站列表
        for i in site_list:
            SiteName = i['name']
            project_type = i['project_type']
            self.get_site_config(SiteName)  # 初始化网站配置
            seo_config.site_config(SiteName)  # 初始化seo_uri_collect配置 默认是全局关闭的
            self.__site_config[SiteName]["site_id"] = i['id']
            if self.add_site_config(SiteName, False, i['id'], project_type):
                # 标记是否需要重载
                is_reload = True

        # 遍历网站列表
        docker_projects = self.docker_projects()
        for i in docker_projects:
            SiteName = i['name']
            self.get_site_config(SiteName)  # 初始化网站配置
            seo_config.site_config(SiteName)  # 初始化seo_uri_collect配置 默认是全局关闭的
            self.__site_config[SiteName]["site_id"] = i['id']
            self.__site_config[SiteName]["is_docker"] =  True

        if docker_projects:
            from mod.project.docker.sites.sitesManage import SitesManage
            SitesManage().reload_nginx_conf(public.dict_obj())

        self.save_site_config()  # 保存网站配置
        seo_config.save_config()  # 保存seo_uri_collect配置
        udp_cmd('reload_config')  # 发送信号重载配置

        if is_reload:
            public.serviceReload()

        return public.returnMsg(True, '配置检查完成!')

    def open_apache_logio_module(self):
        '''
            @name 开启apache logio模块
            @return bool 成功True，失败False
        :return:
        '''
        is_logio_on = True  # 判断logio模块默认是否开启
        apache_config_file = public.get_setup_path()+"/apache/conf/httpd.conf"
        mod_logio = "LoadModule logio_module modules/mod_logio.so"
        # 前提文件存在
        if os.path.exists(apache_config_file):
            apache_config = public.ReadFile(apache_config_file)
            # 若找到mod_logio.so模块
            if apache_config.find(mod_logio) != -1:
                apache_config_lines = apache_config.split("\n")
                for i in range(len(apache_config_lines)):
                    index = apache_config_lines[i].find(mod_logio)
                    # 目标内容不在改该行
                    if index == -1:
                        continue
                    # 判断目标内容前有注释符则替换之
                    preceding_text = apache_config_lines[i][:index].strip()
                    if preceding_text.find('#') != -1:
                        apache_config_lines[i] = mod_logio
                        is_logio_on = False
                        break  # 找到一个替换掉该行即可
                new_apache_config = '\n'.join(apache_config_lines)
            # 若找不到logio模块，则写在log_cofig模块下
            else:
                new_apache_config = apache_config.replace("LoadModule log_config_module modules/mod_log_config.so", "LoadModule log_config_module modules/mod_log_config.so\n"+mod_logio+"\n")
            # 写入新配置
            public.WriteFile(apache_config_file, new_apache_config)
            config_err = self.is_config_error()
            # 错误则恢复旧配置
            if config_err:
                public.writeFile(apache_config_file, apache_config)
                return False
            if not is_logio_on:
                # 有default_logio.pl代表logio模块原本是关闭状态
                public.WriteFile("{}/default_logio.pl".format(public.get_plugin_path('monitor')), "")
            return True
        else:
            return False

    def close_apache_logio_module(self):
        '''
            @name 关闭apache logio模块
            @return bool 成功True，失败False
        '''
        apache_config_file = public.get_setup_path()+"/apache/conf/httpd.conf"
        mod_logio = "LoadModule logio_module modules/mod_logio.so"
        # 前提文件存在
        if os.path.exists(apache_config_file):
            # 判断logio模块原本是否是关闭的状态
            if os.path.exists("{}/default_logio.pl".format(public.get_plugin_path('monitor'))):
                apache_config = public.ReadFile(apache_config_file)
                # 直接给所有mod_logio加上注释#
                new_apache_config = apache_config.replace(mod_logio, "#"+mod_logio)

                # 写入新配置
                public.WriteFile(apache_config_file, new_apache_config)
                config_err = self.is_config_error()
                # 错误则恢复旧配置
                if config_err:
                    public.writeFile(apache_config_file, apache_config)
                    return False
                return True
        else:
            return False



    def clear_site_config(self,args = None):
        '''
            @name 清理网站配置文件(apache,nginx)
            @return void
        '''
        # 清理自定义日志格式配置文件
        if self._webserver == "nginx":
            monitor_log_format = "{}/vhost/nginx/0.monitor_log_format.conf".format(public.get_panel_path())
        else:  # apache的情况
            monitor_log_format = "{}/vhost/apache/0.monitor_log_format.conf".format(public.get_panel_path())
        if os.path.exists(monitor_log_format): os.remove(monitor_log_format)

        is_reload = False

        # 获取网站列表
        site_list = public.M('sites').field('name,project_type').select()

        # 遍历网站列表
        for i in site_list:
            SiteName = i['name']
            project_type = i['project_type']
            if self.del_site_config(SiteName,False,project_type):
                is_reload = True

        # 若为apache需要关闭logio模块
        if self._webserver == "apache":
            self.close_apache_logio_module()
            is_reload = True

        if is_reload: public.serviceReload()

        if args: return public.returnMsg(True,'配置清理完成!')



    def check_nginx_config_err(self):
        '''
            @name 检查Nginx配置是否有错误，并尝试自动修改
            @return string
        '''
        searchStr = 'successful'
        errStr = 'unexpected "}" in'
        while True:
            result = public.ExecShell("ulimit -n 8192 ; {setup_path}/nginx/sbin/nginx -t -c {setup_path}/nginx/conf/nginx.conf".format(setup_path = public.get_setup_path()))
            # 配置文件正确
            if result[1].find(searchStr) != -1:
                break

            # 配置文件是目标错误
            elif result[1].find(errStr) != -1:
                err_line = ""
                err_lines = result[1].split("\n")

                # 获取错误信息所在行
                for err in err_lines:
                    if err.find(errStr) != -1:
                        err_arr = err.split(errStr)
                        if len(err_arr) < 2: continue
                        err_line = err_arr[1].strip()
                        break

                if not err_line: break

                # 获取错误文件和行号
                print(err_lines,err_line)

                filename,line = err_line.split(':')
                filename = filename.strip()
                line_number = int(line.strip())

                # 读取错误的配置文件
                if not os.path.exists(filename): break
                config = public.readFile(filename)
                if not config: break
                configlines = config.split('\n')
                line_len = len(configlines)
                if line_len < line_number: break

                # 注释错误行
                if line_number == line_len -1:
                    configlines[line_number-1] = ''
                else:
                    configlines[line_number-1] = '# 以下行存在错误，已尝试注释\n # ' + configlines[line_number-1]

                # 写入配置文件
                public.writeFile(filename,'\n'.join(configlines).strip())

            # 配置文件不是目标错误
            else:
                break

        # 重载Nginx
        init = "/etc/init.d/nginx"
        if os.path.exists(init):
            public.ExecShell("/etc/init.d/nginx start")
        else:
            public.ExecShell("systemctl start nginx")


    def udp_send(self,msg,timeout=0.01):
        '''
            @name 发送UDP请求
            @param msg string 消息
            @return string 响应内容
        '''
        message = self.__udp_cmd + msg.encode('utf-8')
        udp_host = '127.0.0.1'
        udp_port = 0
        if not self.__global_config:
            self.get_global_config()
        if not self.__global_config:
            return ''
        if 'listen' in self.__global_config:
            udp_port = self.__global_config['port']

        if not udp_port: return ''

        # 连接UDP服务
        try:
            socket.setdefaulttimeout(timeout)
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            # 发送数据
            s.sendto(message, (udp_host, int(udp_port)))
            # 接收数据
            data, _ = s.recvfrom(1024)
            if data:
                return data.decode('utf-8')

            return ''
        except:
            return ''
        finally:
            socket.setdefaulttimeout(None)
            s.close()

    @staticmethod
    def get_log_format_name(site_id: int):
        log_format_file = "{}/0.monitor{}_log_format.conf".format(public.get_panel_path(), site_id)
        if os.path.exists(log_format_file):
            return "monitor{}".format(site_id)
        else:
            return "monitor"

    def docker_projects(self) -> List[dict]:
        db_path = "/www/server/panel/data/db/docker.db"
        sql = db.Sql()
        sql._Sql__DB_FILE = db_path

        if not os.path.exists(db_path):
            return []
        try:
            data = sql.table("docker_sites").field("id,name").select()
        except:
            return []
        return data

    def default_db_copy(self):
        # spider_ip_list.db
        # other_spiders.db

        def copy_file_if_zero_or_small(src, dst, min_size=100):
            if os.path.exists(dst):
                file_size = os.path.getsize(dst)
                if file_size < min_size:
                    shutil.copy(src, dst)
            else:
                shutil.copy(src, dst)

            public.set_own(dst, "bt-monitor")
            public.set_mode(dst, "644")

        self.get_global_config()
        data_save_path = self.__global_config["data_save_path"]

        # Define the paths
        spider_ip_list_src = os.path.join(self.__plugin_path, "monitor", "data", "dbs", "global", "spider_ip_list.db")
        spider_ip_list_dst = os.path.join(data_save_path, "global", "spider_ip_list.db")

        other_spiders_src = os.path.join(self.__plugin_path, "monitor", "data", "dbs", "global", "other_spiders.db")
        other_spiders_dst = os.path.join(data_save_path, "global", "other_spiders.db")

        # Copy spider_ip_list.db if it is zero or less than 100 bytes
        copy_file_if_zero_or_small(spider_ip_list_src, spider_ip_list_dst)

        # Copy other_spiders.db if it is zero or less than 100 bytes
        copy_file_if_zero_or_small(other_spiders_src, other_spiders_dst)

    def update_log_format(self):
        file_path = os.path.join(public.get_panel_path(), 'vhost/nginx')
        if not os.path.exists(file_path):
            return

        for f_name in os.listdir(file_path):
            conf_file = '/'.join((file_path, f_name))
            if not os.path.isfile(conf_file):
                continue
            if not f_name.endswith('_log_format.conf') or not f_name.startswith('0.monitor'):
                continue
            self._update_log_format(conf_file)

    def _update_log_format(self, conf_file: str):
        conf: str = public.readFile(conf_file)
        if not conf:
            return
        # 检查字段: 添加内容
        fields = {
            "$waf2monitor_blocked": '"waf_blocked":"$waf2monitor_blocked",',
            "$waf_ip_remote_addr": '"waf_ip_remote_addr":"$waf_ip_remote_addr",',
            "$waf_status_infos": '"waf_status_infos":"$waf_status_infos",'
        }
        
        # 原始配置备份
        original_conf = conf
        modified = False
        
        # 检查并添加每个字段
        for field_var, field_text in fields.items():
            if field_var not in conf:
                # 在https字段后添加新字段
                conf = conf.replace('"https":"$https",', f'"https":"$https",\n            {field_text}')
                modified = True
        
        # 如果有修改，写入配置并检查
        if modified:
            public.writeFile(conf_file, conf)
            if self.is_config_error():
                # 配置错误，恢复原配置
                public.writeFile(conf_file, original_conf)


def check_user():
    monitor_user = "bt-monitor"

    def check_user_exists():
        try:
            import pwd
            pwd.getpwnam(monitor_user)
            return True
        except KeyError:
            return False

    if check_user_exists():
        return

    # 检查文件是否有特殊权限
    def check_special_permissions(filename):
        a, _ = public.ExecShell("lsattr " + filename)
        return 'i' in a

    # 需要检查的文件
    files_to_check = ["/etc/passwd", "/etc/shadow", "/etc/group", "/etc/gshadow"]
    files_to_restore = []
    # 检查文件是否有特殊权限
    for filename in files_to_check:
        if check_special_permissions(filename):
            print("Found special permissions on {} . Removing...".format(filename))
            public.ExecShell("chattr -i " + filename)
            files_to_restore.append(filename)

    # 创建用户
    sh = "useradd -r -s /sbin/nologin " + monitor_user
    res = public.ExecShell(sh)
    print(res)
    print("Created user: {} ..".format(monitor_user))

    # 恢复特殊权限
    for filename in files_to_restore:
        print("Restoring special permissions on {} ...".format(filename))
        public.ExecShell("chattr +i " + filename)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        exit('参数错误')
    action = sys.argv[1]

    if action == 'install':
        service = Service()
        service.check_site_config()
    elif action == 'uninstall':
        service = Service()
        service.clear_site_config()
    elif action == 'check_user':
        check_user()
    elif action == "copy_default_db":
        service = Service()
        service.default_db_copy()
