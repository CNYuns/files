import json
import os.path
import sys
import sqlite3
import time
import traceback
from typing import List, Dict, Tuple, Union, Any, Callable, Optional
from datetime import datetime, date, timedelta


if "/www/server/panel/class" not in sys.path:
    sys.path.insert(0, "/www/server/panel/class")

import public

if "/www/server/panel/plugin/monitor" not in sys.path:
    sys.path.insert(0, "/www/server/panel/plugin/monitor")
elif not sys.path.index("/www/server/panel/plugin/monitor") == 0:
    sys.path.remove("/www/server/panel/plugin/monitor")
    sys.path.insert(0, "/www/server/panel/plugin/monitor")


GENERATE_BY = "Active" #  Active 手动, Auto 自动  当计划任务脚本中执行的时候，会引入并将其设置为 Auto
_CREATE_DB_SQL = """
CREATE TABLE IF NOT EXISTS tasks (
    `id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `site_name` TEXT,
    `part_type` TEXT,
    `next_generate_time` INTEGER,
    `email` TEXT
);

CREATE TABLE IF NOT EXISTS results (
    `id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `site_name` TEXT,
    `title` TEXT,
    `part_type` TEXT,
    `time_range` TEXT,
    `time_key` INTEGER, -- 记录 generate_time  通过 site_name + part_type + time_key（generate_time） 唯一确定
    `file_name` TEXT,
    `file_size` INTEGER DEFAULT 0,
    `create_time` INTEGER DEFAULT 0,
    `generate_by` INTEGER DEFAULT 0, -- 0 Auto 1 手动
    `sent_status` INTEGER DEFAULT 0 -- 0 未设置发送， 1 发送成功， 2 发送失败
);

CREATE INDEX IF NOT EXISTS results_file_name ON results (file_name);
CREATE INDEX IF NOT EXISTS tasks_site_name ON tasks (site_name);
"""


class ReportManager:
    DB_PATH = "/www/server/panel/plugin/monitor/report_manager.db"
    REPORT_PATH = "/www/server/monitor/data/monitor_report/"

    def __init__(self):
        self.conn = sqlite3.connect(self.DB_PATH)
        self.cursor = self.conn.cursor()
        # 创建任务表
        self.cursor.executescript(_CREATE_DB_SQL)
        self.conn.commit()

    def close(self):
        self.conn.close()

    def __del__(self):
        self.close()

    @staticmethod
    def calc_next_generate_time(part_type: str) -> datetime:
        now = datetime.today()
        if part_type == "day":
            tmp_date = (now + timedelta(days=1)).date()  # 今天设置，明天生成今天的报告
        elif part_type == "week":
            tmp_date = (now - timedelta(days=now.weekday()) + timedelta(days=7)).date() # 本周设置的任务，下周生成本周报告
        elif part_type == "month":
            # 本月设置，下月生成本月的报告（处理跨年）
            if now.month == 12:
                tmp_date = now.replace(year=now.year + 1, month=1, day=1).date()
            else:
                tmp_date = now.replace(month=now.month + 1, day=1).date()
        else:
            raise ValueError("part_type must be one of 'day', 'week', 'month'")
        return datetime(tmp_date.year, tmp_date.month, tmp_date.day)

    @staticmethod
    def all_site_name() -> List[str]:
        sites_conf = "/www/server/monitor/config/sites.json"
        if not os.path.exists(sites_conf):
            return []
        try:
            sites_data = json.loads(public.readFile(sites_conf))
            return list(sites_data.keys())
        except:
            return []

    def results_exist(self, site_name: str, part_type: str, time_key: int, generate_by: int = 0) -> bool:
        """
        检查报告是否存在
        :param generate_by: 生成方式，0 Auto 1 手动
        :param site_name: 网站名称
        :param part_type: 报告类型（日报、周报、月报）
        :param time_key: 生成时间
        """
        res = self.cursor.execute('''
            SELECT * FROM results WHERE site_name = ? AND part_type = ? AND time_key = ? AND generate_by =?
        ''', (site_name, part_type, time_key, generate_by)).fetchone()
        return bool(res)

    def add_task(self, site_name: str, part_type: List[str], email: str) -> Optional[str]:
        """
        添加生成任务
        :param site_name: 网站名称
        :param part_type: 报告类型（日报、周报、月报）
        :param email: 发送邮箱
        """
        real_list = []
        if site_name == "site@all":
            sites = self.all_site_name()
        else:
            if site_name not in self.all_site_name():
                return "网站名称错误，不存在该网站配置"
            sites = [site_name]

        if not all((i in ["day", "week", "month"] for i in part_type)):
            return "报告类型错误，请选择正确的报告类型"

        for site in sites:
            for report_type in part_type:
                real_list.append({
                    "site_name": site,
                    "part_type": report_type,
                    "next_generate_time": int(self.calc_next_generate_time(report_type).timestamp()),
                    "email": email
                })

        for i in real_list: #  通过 site_name + part_type + time_key（generate_time） 做唯一性校验
            if self.cursor.execute('''
                SELECT * FROM tasks WHERE site_name = ? AND part_type = ? AND next_generate_time = ?
            ''', (i["site_name"], i["part_type"], i["next_generate_time"])).fetchone():
                continue  # 跳过已存在的记录
            self.cursor.execute('''
                INSERT OR IGNORE INTO tasks (site_name, part_type, next_generate_time, email)
                VALUES (?, ?, ?, ?)
            ''', (i["site_name"], i["part_type"], i["next_generate_time"], i["email"]))
        self.conn.commit()


    def get_tasks(self, site_name: str = None) -> List[Dict]:
        where = ""
        if site_name and site_name != "site@all":
            where = "WHERE site_name = ?"

        res = self.cursor.execute(f'''
            SELECT * FROM tasks {where}
        ''', (site_name,))
        res_data = res.fetchall()
        des = [i[0] for i in self.cursor.description]
        return [dict(zip(des, list(i))) for i in res_data]

    def delete_task(self, site_name: str, part_type: List[str]) -> Optional[str]:
        if not all((i in ["day", "week", "month"] for i in part_type)):
            return "报告类型错误，请选择正确的报告类型"

        if site_name == "site@all":
            sites = self.all_site_name()
        else:
            if site_name not in self.all_site_name():
                return "网站名称错误，不存在该网站配置"
            sites = [site_name]

        for site in sites:
            for report_type in part_type:
                self.cursor.execute('''
                    DELETE FROM tasks WHERE site_name = ? AND part_type = ?
                ''', (site, report_type))
        self.conn.commit()

    def empty_tasks(self) -> bool:
        """是否没有任何自动任务"""
        return not bool(self.cursor.execute('''SELECT * FROM tasks Limit 1''').fetchone())

    def modify_task(self, site_name: str, part_type: List[str], email: str) -> Optional[str]:
        if not all((i in ["day", "week", "month"] for i in part_type)):
            return "报告类型错误，请选择正确的报告类型"
        if site_name == "site@all":
            sites = self.all_site_name()
        else:
            if site_name not in self.all_site_name():
                return "网站名称错误，不存在该网站配置"
            sites = [site_name]

        for site in sites:
            for report_type in part_type:
                self.cursor.execute('''
                    UPDATE tasks SET email = ? WHERE site_name = ? AND part_type = ?
                ''', (email, site, report_type))

        self.conn.commit()

    def get_need_generate_tasks(self) -> List[Dict]:
        now = int(datetime.now().timestamp())
        res = self.cursor.execute('''
            SELECT * FROM tasks WHERE next_generate_time <= ?
        ''', (now,))
        data = res.fetchall()
        des = [i[0] for i in self.cursor.description]
        return [dict(zip(des, list(row))) for row in data]

    def update_next_next_generate_time(self, task_id: int, part_type: str):
        self.cursor.execute('''
            UPDATE tasks SET next_generate_time = ? WHERE id = ?
        ''', (int(self.calc_next_generate_time(part_type).timestamp()), task_id))
        self.conn.commit()

    def add_results(self, this_report:"Report", sent_status: int = 0) -> None:
        self.cursor.execute('''
            INSERT INTO results (site_name, title, part_type, time_key, time_range, file_name, file_size, create_time, generate_by, sent_status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            this_report.site_name,  # 网站名称
            this_report.title,  # 报表标题
            this_report.part_type,  # 报告类型
            this_report.time_key,  # 时间key
            this_report.time_range,  # 时间范围
            this_report.export_filename,   # 文件名
            os.path.getsize(os.path.join(this_report.REPORT_PATH, this_report.export_filename)),  # 文件大小
            int(this_report.create_time.timestamp()),  # 创建时间
            0 if GENERATE_BY == "Auto" else 1, # 生成方式
            sent_status)) # 发送状态
        self.conn.commit()

    def get_results(self,
                    site_name: str = None,
                    part_type: str = None,
                    start_time: int= None,
                    end_time: int = None) -> List[Dict]:
        where = ""
        parm = []
        if site_name:
            where = "WHERE site_name = ?"
            parm.append(site_name)
        if part_type:
            where += "WHERE part_type = ?" if not where else " AND part_type = ?"
            parm.append(part_type)

        if start_time and end_time:
            where += "WHERE create_time >= ? AND create_time <= ?" if not where else " AND create_time >= ? AND create_time <= ?"
            parm.extend([start_time, end_time])
        elif start_time:
            where += "WHERE create_time >= ?" if not where else " AND create_time >= ?"
            parm.append(start_time)
        elif end_time:
            where += "WHERE create_time <= ?" if not where else " AND create_time <= ?"

        res = self.cursor.execute(f'''SELECT * FROM results {where} ORDER BY time_key DESC''', parm)
        data = res.fetchall()
        des = res.description
        return [dict(zip([col[0] for col in des], list(row))) for row in data]

    def delete_results(self, file_name: str):
        self.cursor.execute('''DELETE FROM results WHERE file_name = ?''', (file_name,))
        self.conn.commit()


class Report:

    REPORT_PATH = "/www/server/monitor/data/monitor_report/"

    try:
        from monitor_main import monitor_main
    except:
        class monitor_main:
        
            @staticmethod
            def _run_func(func_name: str, args: Any) -> Any:
                import PluginLoader
                # args.client_ip = public.GetClientIp()
                args.fun = func_name
                args.s = func_name
                tamper_data = PluginLoader.plugin_run("monitor", func_name, args)
                if isinstance(tamper_data, list):
                    return tamper_data
                if not isinstance(tamper_data, dict):
                    return {}
                elif  "status" in tamper_data and not tamper_data["status"]:
                    return {}
                return tamper_data
        
            def __getattr__(self, func_name: str) -> Callable[[Any], Any]:
                return lambda args: self._run_func(func_name, args)


    def __init__(self, site_name: str, report_time_key: Tuple[Union[date, datetime], Union[date, datetime]], out_file_name: str =None):
        self.site_name: str = site_name
        self.report_time_key = list(report_time_key)
        if isinstance(self.report_time_key[0], datetime):
            self.report_time_key[0] = self.report_time_key[0].date()
        if isinstance(self.report_time_key[1], datetime):
            self.report_time_key[1] = self.report_time_key[1].date()

        delta = self.report_time_key[1] - self.report_time_key[0]
        if timedelta(days=32) > delta > timedelta(days=26):
            self.part_type = "month"
        elif delta == timedelta(days=6):
            self.part_type = "week"
        elif delta == timedelta(days=0):
            self.part_type = "day"
        else:
            self.part_type = "year"

        self._call_log: Optional[Callable[[str], None]] = None
        self.create_time = datetime.now()
        if out_file_name:
            self._export_filename = out_file_name
        else:
            self._export_filename = None

    @property
    def time_key(self) -> int:
        tmp_date = self.report_time_key[1] + timedelta(days=1)
        return int(datetime(tmp_date.year, tmp_date.month, tmp_date.day).timestamp())

    def set_call_log(self, call_log: Callable[[str], None]):
        if callable(call_log):
            self._call_log = call_log
        else:
            raise TypeError("call_log must be a callable object")

    def call_log(self, msg: str):
        if self._call_log:
            self._call_log(msg)
            return None

        class _DefaultCallLog:

            def __init__(self, key: str):
                self.log_file = os.path.join(Report.REPORT_PATH, "{}.log".format(key))
                self.fp = open(self.log_file, "w+")

            def __call__(self, this_msg: str) -> None:
                this_msg = this_msg.rstrip("\n")
                self.fp.write("{}: {}\n".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), this_msg))
                self.fp.flush()

            def __del__(self):
                time.sleep(40)  # 延迟40秒, 保障日志已被前端获取，然后销毁日志文件
                try:
                    self.fp.close()
                    if os.path.exists(self.log_file):
                        os.remove(self.log_file)
                except:
                    pass

        self._call_log = _DefaultCallLog(self.export_filename)
        self.call_log(msg)
        return None

    def __del__(self):
        if self._call_log:
            del self._call_log

    @property
    def title(self) -> str:
        if self.part_type == "month":
            return "网站{}-{}月报".format(self.site_name, self.report_time_key[0].strftime("%Y-%m"))
        elif self.part_type == "week":
            return "网站{}-{}周报".format(self.site_name, self.report_time_key[0].strftime("%Y-%m-%d"))
        elif self.part_type == "day":
            return "网站{}-{}日报".format(self.site_name, self.report_time_key[0].strftime("%Y-%m-%d"))
        else:
            return "网站{}-{}年报".format(self.site_name, self.report_time_key[0].strftime("%Y"))

    @property
    def server_name(self) -> str:
        title = public.GetConfigValue('title')
        if title and title != "宝塔面板":
            return title
        server_ip = public.GetClientIp()
        return server_ip

    def collect_data(self):
        self.call_log("开始收集数据..")
        return {
            "title": self.title,
            "create_date": self.create_time.strftime("%Y-%m-%d"),
            "server_name": self.server_name,
            "site_name": self.site_name,
            "time_range": self.time_range,
            "global": self._collect_global_data(),
            "ip_data": self._collect_ip_data(),
            "china_province": self._collect_china_province(),
            "spider": self._collect_spider(),
            "uri_data": self._coollect_uri_data(),
            "referer_data": self._collect_referer_data(),
            "status_data": self._collect_status_data(),
            "terminal_data": self._collect_terminal_data()
        }

    def save_data(self):
        pass

    @staticmethod
    def date_int2str(date_int: int) -> str:
        return datetime.strptime(str(date_int), "%Y%m%d").strftime("%Y-%m-%d")

    def _collect_global_data(self):
        args = public.dict_obj()
        args.SiteName = self.site_name
        args.part_type = "date" if self.part_type != "day" else "hour"
        args.start_date = self.report_time_key[0].strftime("%Y-%m-%d")
        args.end_date = self.report_time_key[1].strftime("%Y-%m-%d")
        res = self.monitor_main().get_site_total_list_custom(args)
        return_data = {
            "total": {
                "pv": res["total"]["pv_number"],
                "uv": res["total"]["uv_number"],
                "ip": res["total"]["ip_number"],
                "request": res["total"]["request"],
                "traffic": res["total"]["sent_bytes"],
                "spider": res["total"]["spider_count"],
                "slow_count": res["total"]["slow_count"],
                "error": res["total"]["status_499"] + res["total"]["status_500"] + res["total"]["status_502"] + res["total"]["status_504"],
            },
            "list": [
                {
                    "date": (self.date_int2str(i["date"]) if self.part_type != "day" else i["hour"]),
                    "pv": i["pv_number"],
                    "uv": i["uv_number"],
                    "ip": i["ip_number"],
                    "request": i["request"],
                    "traffic": i["sent_bytes"],
                    "spider": i["spider_count"],
                    "slow_count": res["total"]["slow_count"],
                    "error": i["status_499"] + i["status_500"] + i["status_502"] + i["status_504"],
                } for i in res["list"]
            ]
        }
        self.call_log("已完成概览数据收集...")
        return return_data

    def _collect_ip_data(self):
        """
            [{
            "ip": "66.249.68.4",
            "traffic": 32145,
            "request": 92,
            "info": "[Google蜘蛛]美国 山景城"
            }]
        """
        args = public.dict_obj()
        args.SiteName = self.site_name
        args.start_date = self.report_time_key[0].strftime("%Y-%m-%d")
        args.end_date = self.report_time_key[1].strftime("%Y-%m-%d")
        args.not_show_ex = True
        res = self.monitor_main().get_site_ip_total(args)
        data_list = [
            {
                "ip": i["ip"],
                "traffic": i["send_bytes"],
                "request": i["request"],
                "info":  ("[{}蜘蛛]".format(i["spider"]) if i["spider"] else (
                    "[恶意]" if i["is_malicious_ip"] or i["bt_malicious_ip"] else ""
                )) +  i["area"]
            } for i in res
        ]
        self.call_log("已完成IP数据收集...")
        return {"list": data_list}

    def _collect_china_province(self):
        """[{
              "ip_count": 64,
              "request": 171,
              "title": "河北"
            },
            {
              "ip_count": 51,
              "request": 170,
              "title": "北京"
            }
          ... #中国省份数据
        ]"""
        args = public.dict_obj()
        args.SiteName = self.site_name
        args.start_date = self.report_time_key[0].strftime("%Y-%m-%d")
        args.end_date = self.report_time_key[1].strftime("%Y-%m-%d")
        args.is_china = 1
        res = self.monitor_main().get_site_map_date(args)
        data_list = [
            {
                "ip_count": i["ip_count"],
                "request": i["request"],
                "title": i["title"]
            } for i in res if i["is_china"]
        ]
        self.call_log("已完成省份数据收集...")
        return {"list": data_list}

    def _collect_spider(self):
        """{
              "百度": 162,
              "Google":142,
              "360": 172,
              "搜狗":142,
              "雅虎": 152,
              "必应":142,
              "头条": 142,
              "Yandex":142,
              "神马": 142
            },
        """
        args = public.dict_obj()
        args.SiteName = self.site_name
        args.start_date = self.report_time_key[0].strftime("%Y-%m-%d")
        args.end_date = self.report_time_key[1].strftime("%Y-%m-%d")
        res = self.monitor_main().get_site_spider_total(args)

        date_range = []
        s = self.report_time_key[0]
        e = self.report_time_key[1]
        if self.part_type == "day":
            date_range = ["{}时".format(i) for i in range(0, 24)]
        else:
            while s <= e:
                date_range.append(s.strftime("%Y-%m-%d"))
                s += timedelta(days=1)

        show_keys = [
            "百度",
            "谷歌",
            "360",
            "搜狗",
            "雅虎",
            "必应",
            "头条",
            "Yandex",
            "神马",
        ]
        res_data = {
            "list":[{
                "date": i,
            } for i in date_range],
            "total": {k:sum(res.get(k, [])) for k in show_keys}
        }
        for k, v_list in res.items():
            if k not in show_keys:
                continue
            for idx, v in enumerate(v_list):
                res_data["list"][idx][k] = v

        self.call_log("已完成蜘蛛数据收集...")
        return res_data

    def _coollect_uri_data(self):
        """ {
            "uri": "/forum.php?mod=forumdisplay&fid=1",
            "pv": 12,
            "uv": 10,
            "request": 45,
            "traffic": 152014
        }"""
        args = public.dict_obj()
        args.SiteName = self.site_name
        args.start_date = self.report_time_key[0].strftime("%Y-%m-%d")
        args.end_date = self.report_time_key[1].strftime("%Y-%m-%d")
        args.not_show_ex = True
        res = self.monitor_main().get_site_uri_total(args)
        return_data = {"list": [
            {
                "uri": i["uri"],
                "pv": i["pv"],
                "uv": i["uv"],
                "request": i["request"],
                "traffic": i["sent_bytes"],
            } for i in res
        ]}
        self.call_log("已完成URI数据收集...")
        return return_data

    def _collect_referer_data(self):
        """
        {
            "referer": "https://www.baidu.com/",
            "request": 45
        }
        """
        args = public.dict_obj()
        args.SiteName = self.site_name
        args.start_date = self.report_time_key[0].strftime("%Y-%m-%d")
        args.end_date = self.report_time_key[1].strftime("%Y-%m-%d")
        args.not_show_ex = True
        res = self.monitor_main().get_site_referer_total(args)
        return_data = {"list": [
            {
                "referer": i["referer"],
                "request": i["request"],
            } for i in res
        ]}
        self.call_log("已完成Referer数据收集...")
        return return_data

    def _collect_status_data(self):
        """
        {
            "status": 404,
            "request": 45
        }
        """
        args = public.dict_obj()
        args.SiteName = self.site_name
        args.start_date = self.report_time_key[0].strftime("%Y-%m-%d")
        args.end_date = self.report_time_key[1].strftime("%Y-%m-%d")
        res = self.monitor_main().get_site_status_total_by_nday(args)
        data_map = {}
        for i in res["list"]:
            for k, v in i["status"].items():
                data_map.setdefault(k, 0)
                data_map[k] += v

        return_data = {"list": [
            {
                "status": k,
                "request": v,
            } for k, v in data_map.items()
        ]}
        self.call_log("已完成状态码数据收集...")
        return return_data

    def _collect_terminal_data(self):
        """
        {
            "360浏览器": 28,
            "Safari": 42,
            "Chrome": 85,
            "Firefox": 35,
            "Opera": 15,
            "IE": 10,
            "Edge": 25,
            "蜘蛛": 45,
            "机器": 18,
            "扫描器": 12,
            "QQ浏览器": 22,
            "微信": 36,
            "遨游": 8,
            "搜狗浏览器": 15,
            "猎豹": 9,
            "UC": 20
        }
        """
        args = public.dict_obj()
        args.SiteName = self.site_name
        args.start_date = self.report_time_key[0].strftime("%Y-%m-%d")
        args.end_date = self.report_time_key[1].strftime("%Y-%m-%d")
        res = self.monitor_main().get_site_browser_total(args)
        show_keys = [
            "360浏览器",
            "Safari",
            "Chrome",
            "Firefox",
            "Opera",
            "IE",
            "Edge",
            "蜘蛛",
            "机器",
            "QQ浏览器",
            "微信",
            "遨游",
            "搜狗浏览器",
            "猎豹",
            "UC",
        ]
        data_map = {}
        for i in res["list"]:
            for k, v in i["browser"].items():
                if k not in show_keys:
                    continue
                data_map.setdefault(k, 0)
                data_map[k] += v.get("total", 0)

        return_data = {"total": data_map}
        self.call_log("已完成客户端数据收集...")
        return return_data

    def check_report_data(self, collect_data: dict):
        # 检查数据是否都为空
        need_check_keys = [
            "global",
            "ip_data",
            "china_province",
            "spider",
            "uri_data",
            "referer_data",
            "status_data",
            "terminal_data",
        ]
        skip_keys = ("date", )
        def _check_not_empty(data: Any):
            """任何一个不为空都返回True"""
            if isinstance(data, dict):
                return any(map(_check_not_empty, [v for k, v in data.items() if k not in skip_keys]))
            elif isinstance(data, (list, tuple, set)):
                return any(map(_check_not_empty, data))
            else:
                return bool(data)

        res = any(map(_check_not_empty, map(lambda x: collect_data.get(x, {}), need_check_keys)))
        if not res:
            self.call_log("数据为空，跳过报告生成...")
        return res


    @property
    def export_filename(self):
        if not os.path.isdir(self.REPORT_PATH):
            os.makedirs(self.REPORT_PATH)
        if self._export_filename is not None:
            return self._export_filename
        return "{}_{}.pdf".format(self.site_name, int(self.create_time.timestamp()))

    def export_pdf(self) -> bool:
        pdf_path = os.path.join(self.REPORT_PATH, self.export_filename)
        try:
            data = self.collect_data()
        except Exception as e:
            self.call_log("数据获取失败，请检查日志...")
            self.call_log("错误信息: {}".format(traceback.format_exc()))
            return False
        if not self.check_report_data(data):
            return False

        # print(json.dumps(data, indent=4, ensure_ascii=False))

        if "/www/server/panel/plugin/monitor" not in sys.path:
            sys.path.insert(0, "/www/server/panel/plugin/monitor")
        elif not sys.path.index("/www/server/panel/plugin/monitor") == 0:
            sys.path.remove("/www/server/panel/plugin/monitor")
            sys.path.insert(0, "/www/server/panel/plugin/monitor")

        from report import export_pdf

        res = export_pdf(data, pdf_path, self._call_log)
        if not res:
            self.call_log("PDF报告生成失败，请检查日志...")
        return res

    @property
    def time_range(self) -> str:
        if self.part_type == "day":
            return self.report_time_key[0].strftime("%Y/%m/%d")
        return "{} - {}".format(
            self.report_time_key[0].strftime("%Y/%m/%d"),
            self.report_time_key[1].strftime("%Y/%m/%d")
        )

def normalize_time(date_key: Union[date, datetime, str, int]) -> Optional[date]:
    if isinstance(date_key, date):
        return date_key
    elif isinstance(date_key, datetime):
        return date_key.date()
    elif isinstance(date_key, str):
        format_list = [
            "%Y-%m-%d",
            "%Y%m%d",
            "%Y/%m/%d",
            "%Y-%m-%d %H:%M:%S",
            "%Y/%m/%d %H:%M:%S",
        ]
        for fmt in format_list:
            try:
                return datetime.strptime(date_key, fmt).date()
            except:
                pass
        if date_key.isdigit(): # 处理疑似时间戳的
            return normalize_time(int(date_key))
    elif isinstance(date_key, int):
        if date_key < 30000000:
            return normalize_time(str(date_key)) # 兼容 20250102 的格式
        if date_key > 1742745600000: # 兼容毫秒级时间戳
            return date.fromtimestamp(date_key / 1000)
        return date.fromtimestamp(date_key)
    return None

def day_report(site_name: str, date_key: Union[date, datetime, str, int], out_file_name=None) -> Report:
    if not isinstance(date_key, date):
        date_key = normalize_time(date_key)
        if not date_key:
            raise ValueError("date_key is not valid")
    return Report(site_name, (date_key, date_key), out_file_name=out_file_name)

def month_report(site_name: str, date_key: Union[date, datetime, str, int], out_file_name=None) -> Report:
    if not isinstance(date_key, date):
        date_key = normalize_time(date_key)
        if not date_key:
            raise ValueError("date_key is not valid")
    date_key_start = date_key.replace(day=1)

    # 处理跨年情况（12月 -> 下一年1月）
    if date_key.month == 12:
        next_month = date_key.replace(year=date_key.year + 1, month=1, day=1)
    else:
        next_month = date_key.replace(month=date_key.month + 1, day=1)

    date_key_end = next_month - timedelta(days=1)
    return Report(site_name, (date_key_start, date_key_end), out_file_name=out_file_name)

# 暂时不支持年报，时间太长， 后续可能通过合成周报或月报的形式实现
def year_report(site_name: str, date_key: Union[date, datetime, str, int], out_file_name) -> Report:
    raise NotImplementedError

def week_report(site_name: str, date_key: Union[date, datetime, str, int], out_file_name=None) -> Report:
    # 自然周时间范围
    if not isinstance(date_key, date):
        date_key = normalize_time(date_key)
        if not date_key:
            raise ValueError("date_key is not valid")
    date_key_start = date_key - timedelta(days=date_key.weekday())
    date_key_end = date_key_start + timedelta(days=6)
    return Report(site_name, (date_key_start, date_key_end), out_file_name=out_file_name)


if __name__ == "__main__":
    # 手动生成 并 记录数据
    import argparse
    from datetime import date

    parser = argparse.ArgumentParser(description='网站监控报告生成工具')
    parser.add_argument('--site', required=True, help='站点名称（如：www.example.com）')
    parser.add_argument('--date', required=True, help='日期（支持格式：YYYY-MM-DD/YYMMDD/时间戳等）')
    parser.add_argument('--type', required=True, choices=['day', 'week', 'month'], help='报告类型')
    parser.add_argument("--out", required=True, help='导出文件名')
    parser.add_argument('--default-log',action="store_true", required=False, default=False, help='是否使用默认日志') # 不打印
    args = parser.parse_args()

    parsed_date = normalize_time(args.date)
    if not parsed_date:
        raise ValueError("日期格式不支持，请使用 YYYY-MM-DD 或时间戳格式")
    out_file = os.path.basename(args.out)
    if args.type == 'day':
        report = day_report(args.site, parsed_date, out_file)
    elif args.type == 'week':
        report = week_report(args.site, parsed_date, out_file)
    elif args.type == 'month':
        report = month_report(args.site, parsed_date, out_file)
    else:
        raise ValueError("未知的报告类型，支持：day/week/month")


    if not args.default_log:
        report.set_call_log(print)
    report_status = report.export_pdf()
    if report_status:
        rm = ReportManager()
        rm.add_results(report, 0)
    # print(f"报告已生成：{report.REPORT_PATH}/{report.title}.pdf")