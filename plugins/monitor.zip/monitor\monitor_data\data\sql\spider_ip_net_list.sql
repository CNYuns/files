-- 蜘蛛IP段列表
CREATE TABLE IF NOT EXISTS `spider_ip_net_list` (
    `id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `ip_net` TEXT NOT NULL DEFAULT '', -- ip段, 格式为： CIDR格式 如： 192.168.11.0/24
    `spider_title_id` INTEGER DEFAULT 0  -- 爬虫标题ID 1=百度,2=Google,3=360,4=搜狗,5=雅虎,6=必应,7=头条,8=Yandex,9=神马
);

-- 增加唯一索引
CREATE UNIQUE INDEX IF NOT EXISTS `idx_ip_net` ON `spider_ip_net_list` (`ip_net`);
CREATE INDEX IF NOT EXISTS `idx_spider_title_id` ON `spider_ip_net_list` (`spider_title_id`);
