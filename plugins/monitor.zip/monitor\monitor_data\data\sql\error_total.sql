-- 错误信息统计表
CREATE TABLE IF NOT EXISTS `error_total`
(
    `ert_id`          INTEGER PRIMARY KEY AUTOINCREMENT, -- 自增ID
    `date`            INTEGER DEFAULT 0,                 -- 日期
    `error_source_id` INTEGER DEFAULT 0,                 -- 错误来源id
    `number`          INTEGER DEFAULT 0,                 -- 错误数量
    `error_type`      INTEGER DEFAULT 0                  -- 错误类型
);

CREATE INDEX IF NOT EXISTS `idx_date_error_id` ON `error_total` (`date`, `error_source_id`);
CREATE INDEX IF NOT EXISTS `idx_date_number` ON `error_total` (`date`, `number`);