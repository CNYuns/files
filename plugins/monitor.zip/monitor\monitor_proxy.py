import base64
import hashlib
import json
import sys
from collections import OrderedDict
from warnings import filterwarnings
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Any, Optional, Union
from urllib.parse import unquote

filterwarnings(
    action="ignore",
    message=".*Python [\\d.]+ is no longer supported.*",
)

import requests
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

if "/www/server/panel/plugin/monitor" not in sys.path:
    sys.path.insert(0, "/www/server/panel/plugin/monitor")
elif not sys.path.index("/www/server/panel/plugin/monitor") == 0:
    sys.path.remove("/www/server/panel/plugin/monitor")
    sys.path.insert(0, "/www/server/panel/plugin/monitor")

from cache_tool import TTLCache


def _encrypt_data(data: str) -> str:
    iv = b'\x00' * 16
    key = hashlib.sha256("bt-monitor-baidu".encode()).digest()[:32]
    backend = default_backend()
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=backend)
    encryptor = cipher.encryptor()

    # 对数据进行 PKCS7 填充
    padder = padding.PKCS7(algorithms.AES.block_size).padder()
    padded_data = padder.update(data.encode()) + padder.finalize()

    # 加密数据
    encrypted_data = encryptor.update(padded_data) + encryptor.finalize()
    return base64.b64encode(encrypted_data).decode("utf-8")


def _decrypt_data(data: str) -> str:
    backend = default_backend()
    key = hashlib.sha256("bt-monitor-baidu".encode()).digest()[:32]
    iv = b'\x00' * 16
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=backend)
    decryptor = cipher.decryptor()

    # 解密数据
    decrypted_padded_data = decryptor.update(base64.b64decode(data.encode("utf-8"))) + decryptor.finalize()

    # 对数据进行 PKCS7 去填充
    unpadder = padding.PKCS7(algorithms.AES.block_size).unpadder()
    decrypted_data = unpadder.update(decrypted_padded_data) + unpadder.finalize()
    return decrypted_data.decode("utf-8")


def _label_30_days():
    now = datetime.now()
    return [(now - timedelta(days=i)).strftime("%Y-%m-%d") for i in range(30, 0, -1)]

class BaiduZZApi:
    BASE_URL: str = "https://ziyuan.baidu.com"
    HEADER: Dict[str, str] = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:133.0) Gecko/20100101 Firefox/133.0"
    }
    COOKIE_FILE = "/www/server/panel/plugin/monitor/baidu_user.config"
    # baidu_user = {
    #     "username": "xxxxx",
    #     "site_list": ["http://xxxx.xffffxx.xxx/"],
    #     "cookie": {
    #         "BDUSS": "XXXXX"
    #     }
    # }
    ttl_cache = TTLCache(maxsize=10, ttl=60 * 10)

    @classmethod
    def bt_site2baidu_site(cls, bt_site_name) -> List[str]:
        try:
            from utils import sitetool
        except:
            import sys
            monitor_path = "/www/server/panel/plugin/monitor"
            if monitor_path in sys.path:
                sys.path.remove(monitor_path)

            sys.path.insert(0, monitor_path)
            from utils import sitetool

        domains = sitetool.site_domain_list(bt_site_name)
        schema = "https://" if sitetool.site_use_https(bt_site_name) else "http://"
        sites = [schema + i + "/" for i in domains]

        baidu_user = cls._load_baidu_users()
        res = []
        for u in baidu_user:
            for site in u["site_list"]:
                if site in sites:
                    res.append(site)
                    break
        return res

    @classmethod
    def _load_baidu_users(cls) -> List[Dict[str, Any]]:
        try:
            with open(cls.COOKIE_FILE, "r") as f:
                cookie_str = _decrypt_data(f.read())
            user_data = json.loads(cookie_str)
            if isinstance(user_data, list):
                return user_data
            else:
                return []
        except:
            return []

    @classmethod
    def _save_baidu_users(cls, user_data: List[Dict[str, Any]]):
        with open(cls.COOKIE_FILE, "w") as f:
            f.write(_encrypt_data(json.dumps(user_data)))

    @classmethod
    def add_baidu_user(cls, username: str, cookie: Dict[str, str]) -> Optional[str]:
        if "BDUSS" not in cookie:
            return "没有必要的登录信息"

        zz = cls("")
        zz._cookie = cookie
        site_list = zz.site_list()
        if zz.error is not None:
            return "验证账户信息失败，请重新尝试"
        if zz.need_refresh_cookie:
            return "登录信息异常，无法获取网站信息"

        tmp = {
            "username": username,
            "site_list": site_list,
            "cookie": cookie
        }

        baidu_users = cls._load_baidu_users()
        for ud in baidu_users:
            if ud["username"] == username:
                ud["site_list"] = site_list
                ud["cookie"] = cookie
                break
        else:
            baidu_users.append(tmp)

        cls._save_baidu_users(baidu_users)
        return None

    @classmethod
    def get_baidu_users(cls) -> List[Dict[str, Any]]:
        data = cls._load_baidu_users()
        for ud in data:
            ud.pop("cookie", None)

        return data

    @classmethod
    def saved_site_list(cls) -> List[Dict[str, Any]]:
        baidu_users = cls._load_baidu_users()
        data = []
        for ud in baidu_users:
            for site in ud["site_list"]:
                data.append({
                    "username": ud["username"],
                    "site": site
                })
        return data

    @classmethod
    def get_info(cls):
        sites = []
        data = cls._load_baidu_users()
        for ud in data:
            ud.pop("cookie", None)
            for site in ud["site_list"]:
                sites.append({
                    "username": ud["username"],
                    "site": site
                })

        return {
            "baidu_users": data,
            "baidu_sites": sites,
        }

    @classmethod
    def remove_baidu_user(cls, username: str) -> Optional[str]:
        baidu_users = cls._load_baidu_users()
        for i, ud in enumerate(baidu_users):
            if ud["username"] == username:
                del baidu_users[i]
                break
        else:
            return "没有找到该用户"
        cls._save_baidu_users(baidu_users)
        return None

    def __init__(self, username: str = None, default_site: str = None):
        self.username = username
        self.baidu_site = default_site
        self._session: Optional[requests.Session] = None
        self._cookie: Optional[Dict[str, str]] = None
        self.error = None
        self.need_refresh_cookie = False

    @property
    def session(self) -> requests.Session:
        if self._session is None:
            self._session = requests.Session()
            if self._cookie is None:
                self.get_cookie()
            self._session.cookies.update(self._cookie)
        return self._session

    def has_cookie(self) -> bool:
        self.get_cookie()
        return bool(self._cookie)

    def get_cookie(self) -> Dict[str, str]:
        if self._cookie is None:
            user_data = self._load_baidu_users()
            if not self.username and not self.baidu_site:
                for ud in user_data:
                    if "BDUSS" in ud["cookie"]:
                        self.username = ud["username"]
                        self._cookie = ud["cookie"]
                        break
                else:
                    self._cookie = {}
            elif self.baidu_site:
                for ud in user_data:
                    if "BDUSS" in ud["cookie"] and self.baidu_site in ud["site_list"]:
                        self.username = ud["username"]
                        self._cookie = ud["cookie"]
                        break
                else:
                    self._cookie = {}
            elif self.username:
                for ud in user_data:
                    if "BDUSS" not in ud["cookie"]:
                        continue
                    if ud["username"] == self.username:
                        self._cookie = ud["cookie"]
                        break
            else:
                self._cookie = {}

        return self._cookie

    def site_list(self) -> List[str]:
        try:
            uri = "/site/validateSites"
            resp = self.session.get(self.BASE_URL + uri, headers=self.HEADER)
            # print(resp.text)
            # print(resp.status_code)
            if resp.status_code == 200:
                if "list" not in resp.json():
                    return []
                return resp.json()["list"]
            else:
                self.need_refresh_cookie = True
                return []
        except Exception as e:
            self.error = e
            self.need_refresh_cookie = True
            # public.print_error()
            return []

    def update_site_list(self):
        site_list = self.site_list()
        if site_list:
            baidu_user = self._load_baidu_users()
            for ud in baidu_user:
                if ud["username"] == self.username:
                    ud["site_list"] = site_list
                    break
            else:
                return
            self._save_baidu_users(baidu_user)

    @classmethod
    def update_site_list_all(cls):
        data = cls._load_baidu_users()
        for ud in data:
            if "BDUSS" in ud["cookie"]:
                zz = cls(ud["username"])
                site_list = zz.site_list()
                if site_list:
                    ud["site_list"] = site_list

        cls._save_baidu_users(data)
        return True

    def index_num_list(self, site: str,
                       time_range: str = "month",
                       page: int = 1,
                       pagesize: int = 30) -> List[Dict[str, any]]:

        def ctime_to_label(ctime: int) -> str:
            return datetime.fromtimestamp(ctime).strftime("%m-%d")

        try:
            uri = "/indexs/list"
            params = {
                "site": site,
                "id": 0,
                "range": time_range,
                "page": page,
                "pagesize": pagesize,
                "isNew": 1
            }
            resp = self.session.get(self.BASE_URL + uri, params=params, headers=self.HEADER)
            # print(resp.text)
            # print(resp.status_code)
            if resp.status_code == 200:
                list_data = resp.json()["list"]
                for i in list_data:
                    i["label"] = ctime_to_label(i["ctime"])
                return list_data
            else:
                self.need_refresh_cookie = True
                return []
        except Exception as e:
            self.error = e
            return []

    def robots_do_analysis(self, site: str) -> Tuple[bool, str, str]:
        try:
            uri = "/robots/doanalysis"
            params = {
                "site": site
            }
            resp = self.session.get(self.BASE_URL + uri, params=params, headers=self.HEADER)
            # print(resp.text)
            # print(resp.status_code)
            if resp.status_code == 200:
                status = resp.json().get("status", 5)
                if status == 1:
                    return True, "获取成功", unquote(resp.json().get("robots", ""))
                elif status == 5:
                    return False, "获取失败", ""
                elif status == 2:
                    return True, "更新成功", ""
                else:
                    return True, "更新请求已提交", ""
            else:
                self.need_refresh_cookie = True
                return False, "登录信息失效,获取失败", ""
        except Exception as e:
            self.error = e
            return False, "获取失败", str(e)

    # 未验证, 目前无法使用
    def _link_submit_save(self, site: str, uri_list: List[str]) -> Tuple[bool, str]:
        try:
            uri = "/linksubmit/save"
            params = {
                "site": site
            }
            # resp = self.session.get(self.BASE_URL + uri, params=params, headers=self.HEADER)
            # print(resp.text)
            # print(resp.status_code)
            return False, "登录信息失效,获取失败"
        except Exception as e:
            self.error = e
            return False, "获取失败" + str(e)

    def link_submit_update_all(self, site: str) -> Tuple[bool, str]:
        all_site_map = self.link_submit_list(site)
        if all_site_map:
            return self.link_submit_update(site, all_site_map)
        else:
            return False, "获取百度站长平台sitemap信息失败"

    def link_submit_update(self, site: str, sitemap_list: List[Union[str, Dict[str, Any]]]) -> Tuple[bool, str]:
        try:
            uri = "/linksubmit/update"
            params = {
                "site": site
            }
            if len(sitemap_list) == 0:
                return False, "提交的sitemap列表为空"
            if isinstance(sitemap_list, list) and isinstance(sitemap_list[0], str):
                data = {
                    "ids[]": sitemap_list
                }
            elif isinstance(sitemap_list, list) and isinstance(sitemap_list[0], dict):
                data = {
                    "ids[]": [item["uid"] for item in sitemap_list if 'uid' in item]
                }
            else:
                return False, "提交的参数格式不正确"
            resp = self.session.post(self.BASE_URL + uri, params=params, data=data, headers=self.HEADER)
            if resp.status_code == 200:
                return True, "更新成功，提交了{}个url的更新".format(len(resp.json()["success"]))
            else:
                return False, "更新成功失败"
        except Exception as e:
            self.need_refresh_cookie = True
            self.error = e
            return False, "获取失败" + str(e)

    # stat: 0 全部， 1 等待， 2 正常， 3 错误
    def link_submit_list(self, site: str) -> List[Dict[str, Any]]:
        try:
            uri = "/linksubmit/sitemaplist"
            params = {
                "site": site,
                "page": 1,
                "pagesize": 100,
            }
            resp = self.session.get(self.BASE_URL + uri, params=params, headers=self.HEADER)
            if resp.status_code == 200 and "list" in resp.json() and resp.json().get("status", 1) == 0:
                return resp.json()["list"]
            else:
                return []
        except Exception as e:
            self.need_refresh_cookie = True
            self.error = e
            return []

    def link_submit_stat(self, site: str) -> List[Dict[str, Any]]:
        # {
        #     "sitemap": 0,
        #     "js": 0,
        #     "push_auto": 0,
        #     "push_manual": 0,
        #     "original": 0,
        #     "news": 0,
        #     "label": "11-20"
        # }
        try:
            uri = "/linksubmit/submitstat"
            params = {
                "site": site,
            }
            resp = self.session.get(self.BASE_URL + uri, params=params, headers=self.HEADER)
            # push_auto: api  sitemap: sitemap push_manual: 手动
            if resp.status_code == 200 and "list" in resp.json():
                return resp.json()["list"]
            else:
                return []
        except Exception as e:
            self.need_refresh_cookie = True
            self.error = e
            return []

    # 抓取量
    def pressure_flow_stat(self, site: str) -> List[Dict[str, Any]]:
        try:
            uri = "/pressure/flowstat"
            params = {
                "site": site,
            }
            resp = self.session.get(self.BASE_URL + uri, params=params, headers=self.HEADER)
            # push_auto: api  sitemap: sitemap push_manual: 手动
            # date 格式： MM-DD
            if resp.status_code == 200 and "date" in resp.json() and "flow" in resp.json():
                res = []
                for idx, itme in enumerate(resp.json()["date"]):
                    res.append({"date": itme, "flow": resp.json()["flow"][idx]})
                return res
            else:
                return []
        except Exception as e:
            self.need_refresh_cookie = True
            self.error = e
            return []

    # 抓时间信息
    def pressure_time_stat(self, site: str) -> List[Dict[str, Any]]:
        try:
            uri = "/pressure/timestat"
            params = {
                "site": site,
            }
            # date 格式： MM-DD
            resp = self.session.get(self.BASE_URL + uri, params=params, headers=self.HEADER)
            if resp.status_code == 200 and "date" in resp.json():
                date_list = resp.json()["date"]
                avg_list = resp.json()["avg"]
                max_list = resp.json()["max"]
                min_list = resp.json()["min"]
                res = []
                for idx, itme in enumerate(date_list):
                    res.append({
                        "date": itme,
                        "avg": avg_list[idx],
                        "max": max_list[idx],
                        "min": min_list[idx]
                    })
                return res
            else:
                return []
        except Exception as e:
            self.need_refresh_cookie = True
            self.error = e
            return []

    def data_list(self, site: str = None):
        if site is None:
            site = self.baidu_site
        if not site:
            return "没有指定站点信息"
        cache_data = self.ttl_cache.get("data_list_{}".format(site), None)
        if cache_data is not None:
            return cache_data
        flow = self.pressure_flow_stat(site)
        if not flow:
            return []

        submit_stat = self.link_submit_stat(site)
        label_30_days = _label_30_days()
        time_range = label_30_days[0].replace("-", ".") + "-" + label_30_days[-1].replace("-", ".")
        index_num_list = self.index_num_list(site, time_range, page=1, pagesize=100)

        data_map = OrderedDict()
        for i in label_30_days:
            data_map[i[5:]] = {"date": i}

        for item in flow:
            if item["date"] in data_map:
                data_map[item["date"]]["flow"] = item["flow"]

        for item in submit_stat:
            if item["label"] in data_map:
                data_map[item["label"]]["submit_stat"] = item

        for item in index_num_list:
            if item["label"] in data_map:
                data_map[item["label"]]["index_num"] = item

        data = list(data_map.values())[::-1]
        self.ttl_cache["data_list_{}".format(site)] = data
        return data


class ZZ360Login:
    base_url = "https://login.360.cn/"
    qr_query = "?o=sso&m=getLoginQrcode&s=3&src=pcw_i360&qrcodeType=miniprogram&userCenter=1&t="
    login_query = "?src=pcw_i360&from=pcw_i360&charset=UTF-8&requestScema=https&quc_sdk_version=7.2.9&quc_sdk_name=jssdk&mid=&o=sso&m=qrLogin&_="

    @classmethod
    def random_str(cls):
        import random
        # 生成一个在 [0.9, 1.0) 范围内的随机浮点数
        random_float = random.uniform(0.9, 1.0)
        return "%.16f" % random_float

    @classmethod
    def get_qrcode(cls):
        """
        获取二维码
        :return:
        """
        s = requests.Session()
        s.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:133.0) Gecko/20100101 Firefox/133.0",
            "Accept": "*/*",
        })

        url = cls.base_url + cls.qr_query + cls.random_str()
        try:
            resp = s.get(url)
            if resp.status_code == 200 and "i360QRKEY" in s.cookies:
                return {
                    "qrkey": s.cookies.get("i360QRKEY"),
                    "qrb64": base64.b64encode(resp.content).decode("utf-8"),
                    "status": True
                }
            else:
                return {"status": False, "qrkey": "", "qrb64": ""}
        except:
            return {"status": False, "qrkey": "", "qrb64": ""}
        finally:
            s.close()

    @classmethod
    def qr_login(cls, qrkey: str):
        s = requests.Session()
        s.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:133.0) Gecko/20100101 Firefox/133.0",
            "Accept": "*/*",
        })
        s.cookies.update({"i360QRKEY": qrkey})

        url = cls.base_url + cls.login_query + str(int(datetime.now().timestamp() * 1000))
        try:
            resp = s.get(url)
            data = resp.json()
            if data["errno"] == 0 and data["errmsg"] == "" and "T" in s.cookies and "Q" in s.cookies:
                res = {"status": True, "T": s.cookies.get("T"), "Q": s.cookies.get("Q")}
                # res.update(cls.login_info(s.cookies.get("T"), s.cookies.get("Q")))
                return res
            else:
                return {"status": False, "T": "", "Q": "", "msg": data["errmsg"], "errno": data["errno"]}
        except:
            return {"status": False, "T": "", "Q": "", "msg": "登录失败"}
        finally:
            s.close()


class ZZ360Api:
    BASE_URL: str = "https://zhanzhang.so.com"
    HEADER: Dict[str, str] = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:133.0) Gecko/20100101 Firefox/133.0"
    }

    COOKIE_FILE = "/www/server/panel/plugin/monitor/360_user.config"
    # baidu_user = {
    #     "username": "xxxxx",
    #     "site_list": ["http://xxxx.xffffxx.xxx/"],
    #     "cookie": {
    #         "BDUSS": "XXXXX"
    #     }
    # }
    ttl_cache = TTLCache(maxsize=10, ttl=60 * 10)

    @classmethod
    def bt_site2zz360_site(cls, bt_site_name) -> List[str]:
        try:
            from utils import sitetool
        except:
            import sys
            monitor_path = "/www/server/panel/plugin/monitor"
            if monitor_path in sys.path:
                sys.path.remove(monitor_path)

            sys.path.insert(0, monitor_path)
            from utils import sitetool

        domains = sitetool.site_domain_list(bt_site_name)
        baidu_user = cls._load_360_users()
        res = []
        for u in baidu_user:
            for site in u["site_list"]:
                if site in domains:
                    res.append(site)
                    break
        return res

    @classmethod
    def _load_360_users(cls) -> List[Dict[str, Any]]:
        try:
            with open(cls.COOKIE_FILE, "r") as f:
                cookie_str = _decrypt_data(f.read())
            user_data = json.loads(cookie_str)
            if isinstance(user_data, list):
                return user_data
            else:
                return []
        except:
            return []

    @classmethod
    def _save_360_users(cls, user_data: List[Dict[str, Any]]):
        with open(cls.COOKIE_FILE, "w") as f:
            f.write(_encrypt_data(json.dumps(user_data)))

    @classmethod
    def add_360_user(cls, username: str, cookie: Dict[str, str]) -> Optional[str]:
        if "Q" not in cookie or "T" not in cookie:
            return "没有必要的登录信息"

        zz = cls("")
        zz._cookie = cookie
        site_list = zz.site_list()
        if zz.error is not None:
            return "验证账户信息失败，请重新尝试"
        if zz.need_refresh_cookie:
            return "登录信息异常，无法获取网站信息"

        tmp = {
            "username": username,
            "site_list": site_list,
            "cookie": cookie
        }

        zz360_users = cls._load_360_users()
        for ud in zz360_users:
            if ud["username"] == username:
                ud["site_list"] = site_list
                ud["cookie"] = cookie
                break
        else:
            zz360_users.append(tmp)

        cls._save_360_users(zz360_users)
        return None

    @classmethod
    def get_360_users(cls) -> List[Dict[str, Any]]:
        data = cls._load_360_users()
        for ud in data:
            ud.pop("cookie", None)

        return data

    @classmethod
    def saved_site_list(cls) -> List[Dict[str, Any]]:
        baidu_users = cls._load_360_users()
        data = []
        for ud in baidu_users:
            for site in ud["site_list"]:
                data.append({
                    "username": ud["username"],
                    "site": site
                })
        return data

    @classmethod
    def get_info(cls):
        sites = []
        data = cls._load_360_users()
        for ud in data:
            ud.pop("cookie", None)
            for site in ud["site_list"]:
                sites.append({
                    "username": ud["username"],
                    "site": site
                })

        return {
            "zz360_users": data,
            "zz360_sites": sites,
        }

    @classmethod
    def remove_360_user(cls, username: str) -> Optional[str]:
        zz360_users = cls._load_360_users()
        for i, ud in enumerate(zz360_users):
            if ud["username"] == username:
                del zz360_users[i]
                break
        else:
            return "没有找到该用户"
        cls._save_360_users(zz360_users)
        return None

    def get_cookie(self) -> Dict[str, str]:
        if self._cookie is None:
            user_data = self._load_360_users()
            if not self.username and not self.zz360_site:
                for ud in user_data:
                    if "Q" in ud["cookie"] and "T" in ud["cookie"]:
                        self.username = ud["username"]
                        self._cookie = ud["cookie"]
                        break
                else:
                    self._cookie = {}
            elif self.zz360_site:
                for ud in user_data:
                    if "Q" in ud["cookie"] and "T" in ud["cookie"] and self.zz360_site in ud["site_list"]:
                        self.username = ud["username"]
                        self._cookie = ud["cookie"]
                        break
                else:
                    self._cookie = {}
            elif self.username:
                for ud in user_data:
                    if "Q" in ud["cookie"] and "T" in ud["cookie"]:
                        if ud["username"] == self.username:
                            self._cookie = ud["cookie"]
                            break
            else:
                self._cookie = {}

        return self._cookie

    def __init__(self, username: str = None, default_site: str = None):
        self.username = username
        self.zz360_site = default_site
        self._session: Optional[requests.Session] = None
        self._cookie: Optional[Dict[str, str]] = None
        self.error = None
        self.need_refresh_cookie = False

    @property
    def session(self) -> requests.Session:
        if self._session is None:
            self._session = requests.Session()
            if self._cookie is None:
                self.get_cookie()
            self._session.cookies.update(self._cookie)
        return self._session

    def has_cookie(self) -> bool:
        self.get_cookie()
        return bool(self._cookie)

    def site_list(self) -> List[str]:
        try:
            uri = "/?m=Userinfo&a=sites"
            resp = self.session.get(self.BASE_URL + uri, headers=self.HEADER)
            if resp.status_code == 200:
                if "data" not in resp.json():
                    return []
                res = []
                for site in resp.json()["data"]:
                    if site["authed"] != "1":
                        continue
                    res.append(site["site"])
                return res
            else:
                self.need_refresh_cookie = True
                return []
        except Exception as e:
            self.error = e
            self.need_refresh_cookie = True

            return []

    # 流量分析数据
    def flow_data(self, site: str):
        try:
            uri = "?m=Flow&a=index_info&site={}".format(site)
            resp = self.session.get(self.BASE_URL + uri, headers=self.HEADER)
            print(self.session.cookies)
            print(resp.content)
            print(resp.json())
            if resp.status_code == 200:
                if "flowData" not in resp.json()["data"]:
                    return []
                data = resp.json()["data"]["flowData"]
                res = []
                for i in data:
                    res.append(
                        {
                            "date": datetime.fromtimestamp(i[0] / 1000).strftime("%Y-%m-%d"),
                            "flow": i[1],
                        }
                    )
                return res
            else:
                return []
        except Exception as e:
            self.error = e
            self.need_refresh_cookie = True
            return []

    # 蜘蛛压力
    def spider_reporter(self, site: str):
        try:
            uri = "?m=Spiderreporter&a=get&site={}".format(site)
            resp = self.session.get(self.BASE_URL + uri, headers=self.HEADER)
            print(self.session.cookies)
            print(resp.content)
            print(resp.json())
            if resp.status_code == 200:
                if "data" not in resp.json():
                    return []
                data = resp.json()["data"]["data"]
                res = []
                for i in data:
                    res.append(
                        {
                            "date": datetime.fromtimestamp(i[0] / 1000).strftime("%Y-%m-%d"),
                            "spider_reporter": i[1],
                        }
                    )
                return res
            else:
                return []
        except Exception as e:
            self.error = e
            self.need_refresh_cookie = True
            return []

    # 索引数量
    def include_num(self, site: str):
        try:
            uri = "?m=Includenum&a=index_info&site={}".format(site)
            resp = self.session.get(self.BASE_URL + uri, headers=self.HEADER)
            print(self.session.cookies)
            print(resp.content)
            print(resp.json())
            if resp.status_code == 200:
                if "data" not in resp.json():
                    return []
                data = resp.json()["data"]["data"]
                res = []
                for i in data:
                    res.append(
                        {
                            "date": datetime.fromtimestamp(i[0] / 1000).strftime("%Y-%m-%d"),
                            "include_num": i[1],
                        }
                    )
                return res
            else:
                return []
        except Exception as e:
            self.error = e
            self.need_refresh_cookie = True
            return []

    def sitemap_list(self, site: str):
        try:
            uri = "?m=Sitemap&a=get_list&host={}&p=1".format(site)
            resp = self.session.get(self.BASE_URL + uri, headers=self.HEADER)
            if resp.status_code == 200:
                if "data" not in resp.json():
                    return []
                data_list = resp.json()["data"]["list"]
                page_count = resp.json()["data"]["page"]["totalPages"]
                if page_count > 1:
                    data_list += self._other_sitemap_list(site, page_count)
                res = []
                for item in data_list:
                    res.append(
                        {
                            "url": item["url"],
                            "url_num": item["OPTS"],
                            "update_time": item["MOD_TIME"],
                            "update_cycle": item["CRAW_INTV"],
                            "id": item["id"],
                            "host": item["host"],
                        }
                    )
                return res
            else:
                return []
        except Exception as e:
            self.error = e
            self.need_refresh_cookie = True
            return []

    def _other_sitemap_list(self, site: str, page_count: int) -> List[dict]:
        res = []
        for i in range(2, page_count + 1):
            try:
                uri = "?m=Sitemap&a=get_list&host={}&p={}".format(site, i)
                resp = self.session.get(self.BASE_URL + uri, headers=self.HEADER)
                print(resp.json())
                if resp.status_code == 200:
                    if "data" not in resp.json():
                        return []
                    data_list = resp.json()["data"]["list"]
                    res.extend(data_list)
            except Exception as e:
                self.error = e
                self.need_refresh_cookie = True
        return res

    def update_sitemap(self, site: str, url: str, all_sitemap: Optional[List[Dict]] = None) -> Tuple[bool,str]:
        url_list = []
        if all_sitemap:
            for i in all_sitemap:
                if i.get("url", None):
                    url_list.append(i["url"])
        if url:
            url_list.append(url)

        try:
            uri = "/?m=Sitemap&a=ping&host={}".format(site)
            res_msg = ""
            for url in url_list:
                data = {
                    "seed": url,
                }
                resp = self.session.post(self.BASE_URL + uri, data=data, headers=self.HEADER)
                if resp.status_code == 200:
                    res_msg = resp.json()["info"]
                else:
                    return False, "更新失败"
            return True, res_msg
        except Exception as e:
            self.error = e
            self.need_refresh_cookie = True
            return False, "更新失败"

    def update_site_list(self):
        site_list = self.site_list()
        if site_list:
            baidu_user = self._load_360_users()
            for ud in baidu_user:
                if ud["username"] == self.username:
                    ud["site_list"] = site_list
                    break
            else:
                return
            self._save_360_users(baidu_user)

    @classmethod
    def update_site_list_all(cls):
        data = cls._load_360_users()
        for ud in data:
            if "Q" in ud["cookie"] and "T" in ud["cookie"]:
                zz = cls(ud["username"])
                site_list = zz.site_list()
                if site_list:
                    ud["site_list"] = site_list

        cls._save_360_users(data)
        return True

    def data_list(self, site: str = None):
        if site is None:
            site = self.zz360_site
        if not site:
            return "没有指定站点信息"
        cache_data = self.ttl_cache.get("data_list_{}".format(site), None)
        if cache_data is not None:
            return cache_data
        flow = self.flow_data(site)
        if not flow:
            return []

        label_30_days = _label_30_days()
        spider_reporters = self.spider_reporter(site)
        index_num_list = self.include_num(site)

        data_map = OrderedDict()
        for i in label_30_days:
            data_map[i] = {"date": i, "spider_reporter": 0, "index_num": 0, "flow": 0}

        for i in flow:
            data_map[i["date"]]["flow"] = i["flow"]

        for i in spider_reporters:
            data_map[i["date"]]["spider_reporter"] = i["spider_reporter"]

        for i in index_num_list:
            data_map[i["date"]]["index_num"] = i["include_num"]

        data = list(data_map.values())[::-1]
        self.ttl_cache["data_list_{}".format(site)] = data
        return data

    def update_sitemap_all(self, site: str) -> Tuple[bool, str]:
        all_site_map = self.sitemap_list(site)
        if all_site_map:
            return self.update_sitemap(site, "", all_site_map)
        else:
            return False, "获取百度站长平台sitemap信息失败"

