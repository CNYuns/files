
-- 储存每日用于画地图的数据
CREATE TABLE IF NOT EXISTS `map_date` (
  `map_date_id` INTEGER PRIMARY KEY AUTOINCREMENT,
  `date` INTEGER DEFAULT 0,
  `data` TEXT DEFAULT "{}" NOT NULL
);
