-- URI请求统计表
CREATE TABLE IF NOT EXISTS `custom_uri_total` (
   `ut_id` INTEGER PRIMARY KEY AUTOINCREMENT,
   `date` INTEGER DEFAULT 0,               -- 日期
   `uri_id` INTEGER DEFAULT 0,             -- URI ID
   `browser_id` INTEGER DEFAULT 0,         -- 浏览器 ID
   `sent_bytes` INTEGER DEFAULT 0,         -- 总计发送字节数
   `recv_bytes` INTEGER DEFAULT 0,         -- 总计接收字节数
   `pv` INTEGER DEFAULT 0,                 -- PV
   `uv` INTEGER DEFAULT 0,                 -- UV
   `spider` INTEGER DEFAULT 0,             -- 蜘蛛数量
   `spider_recv_bytes` INTEGER DEFAULT 0,  -- 蜘蛛接收字节数
   `request` INTEGER DEFAULT 0,            -- 请求次数
   `ip_count` INTEGER DEFAULT 0            -- ip数
);

-- 增加索引
CREATE INDEX IF NOT EXISTS `idx_custom_uri_total_date` ON `custom_uri_total` (`date`);
CREATE INDEX IF NOT EXISTS `idx_date_uri_id` ON `custom_uri_total` (`date`,`uri_id`,`browser_id`);