<?php

error_reporting(0);

require 'login.class.php';
require 'qqlogin.class.php';


//宝塔Linux面板插件demo for PHP
//@author 阿良<287962566@qq.com>

//必需面向对象编程，类名必需为bt_main
//允许面板访问的方法必需是public方法
//通过_get函数获取get参数,通过_post函数获取post参数
//可在public方法中直接return来返回数据到前端，也可以任意地方使用echo输出数据后exit();
//可在./php_version.json中指定兼容的PHP版本，如：("56","71","72","73")，没有./php_version.json文件时则默认兼容所有PHP版本，面板将选择 已安装的最新版本执行插件
//允许使用模板，请在./templates目录中放入对应方法名的模板，如：test.html，请参考插件开发文档中的【使用模板】章节
//支持直接响应静态文件，请在./static目录中放入静态文件，请参考插件开发文档中的【插件静态文件】章节
class bt_main{
	//不允许被面板访问的方法请不要设置为公有方法

	public function test(){
		//_post()会返回所有POST参数，要获取POST参数中的username参数，请使用 _post('username')
		//可通过_version()函数获取面板版本
		//可通过_post('client_ip') 来获取访客IP

		//常量说明：
		//PLU_PATH 插件所在目录
		//PLU_NAME 插件名称
		//PLU_FUN  当前被访问的方法名称
		return array(
			_get(),
			_post(),
			_version(),
			PLU_FUN,
			PLU_NAME,
			PLU_PATH
		);
	}

    public function getqrcode(){
        $login=new baiduLogin();
        $array=$login->getqrcode();
        return $array;
    }
    
    public function time(){
        $login=new baiduLogin();
        $array=$login->servertime();
        return $array;
    }
    
    public function checkvc(){
        $login=new baiduLogin();
        $array=$login->checkvc(_post('user'));
        return $array;
    }
    
    public function sendcode(){
        $login=new baiduLogin();
       $array=$login->sendcode(_post('type'),_post('token'),_post('lurl'),_post('BAIDUID'));
        return $array;
    }
    
    public function login(){
        $login=new baiduLogin();
        $array=$login->login(_post('time'),_post('user'),_post('pwd'),_post('p'),_post('vcode'),_post('vcodestr'),_post('BAIDUID'));
        return $array;
    }
    
    
    public function login2(){
        $login=new baiduLogin();
        $array=$login->login2(_post('type'),_post('token'),_post('lurl'),_post('BAIDUID'),_post('vcode'));
        return $array;
    }

    public function getvcpic()
    {
        header('content-type:image/jpeg');
        echo $login->getvcpic(_get('vcodestr'));
        exit;
    }
       
    public function getphone()
    {
        $login=new baiduLogin();
        	$array=$login->getphone(_post('phone'));
        return $array;
    }
    
    public function sendsms()
    {
        $login=new baiduLogin();
        $array=$login->sendsms(_post('phone'),_post('BAIDUID'),_post('vcode'),_post('vcodestr'),_post('vcodesign'));
        return $array;
    }

    public function login3()
    {
        $login=new baiduLogin();
        $array=$login->login3(_post('phone'),_post('BAIDUID'),_post('smsvc'));
        return $array;
    }
  
    public function qrlogin()
    {
        $login=new baiduLogin();
        $array=$login->qrlogin(_post('sign'));
        return $array;
    }

    public function getqrpic()
    {
        $login=new qq_login();
        $array=$login->getqrpic();
        return $array;
    }

    public function qqrlogin(){
        $login=new qq_login();
        $array=$login->qrlogin(_get('qrsig'));
        return $array;
    }

    public function qqconnect()
    {
        $login=new qq_login();
        $array=$login->qqconnect(_post('redirect_uri'), _post('mkey'));
        return $array;
    }

    public function getwxpic()
    {
        $login=new qq_login();
        $array=$login->getwxpic();
        return $array;
    }

    public function wxlogin()
    {
        $login=new qq_login();
        $array=$login->wxlogin(_get('uuid'), _get('last'));
        return $array;
    }
}

?>