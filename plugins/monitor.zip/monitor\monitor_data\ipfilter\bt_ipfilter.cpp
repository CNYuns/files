// -------------------------------------------------------------------
// 宝塔Linux面板
// -------------------------------------------------------------------
// Copyright (c) 2015-2024 宝塔软件(http://bt.cn) All rights reserved.
// -------------------------------------------------------------------
// Author: hwliang <hwl@bt.cn>
// -------------------------------------------------------------------
#include "include/public.h"
#include "include/ipset_manager.cpp"
#include "include/unixserver.cpp"
#include <iostream>
#include <fstream>
#include <unistd.h> // 用于 getpid()
#include <pthread.h>
using namespace std;

#define CONGIE_PATH "/www/server/panel/data/ip_filter_config"
ipset_manager ipset_obj = ipset_manager();

void create_default_ipset(){
    
    string hash = "ip";
    int hashsize = 1024 * 16;
    int maxelem = 204800;
    int timeout = 86400 * 24;
    string ports = "80,443";
    string protocol = "tcp";
    string cmd = "netstat -tunlp|grep -E '(nginx|httpd)'|awk '{print $4}'|awk -F ':' '{print $2}'|grep -v '^80$'|grep -v '^443$'";
    string result = exec_shell(cmd);
    vector<string> port_list = split(result,"\n");
    for(int i=0;i<port_list.size();i++){
        if(port_list[i] != ""){
            ports += "," + port_list[i];
        }
    }

    ipset_obj.create_ipset(RULE_NAME,hash,hashsize,maxelem,timeout,ports,protocol);
}

void writePidToFile() {
    ofstream pidFileStream(PID_FILE, ios::out | ios::trunc);
    if (pidFileStream.is_open()) {
        pidFileStream << getpid() << endl;
        pidFileStream.close();
    } else {
        cerr << "Unable to open file: " << PID_FILE << endl;
        exit(EXIT_FAILURE);
    }
}



int main(){
    create_default_ipset();
    writePidToFile();
    epoll_server server = epoll_server();
    write_log("服务已启动", LOG_INFO);
    
    server.start();
    return 0;
}