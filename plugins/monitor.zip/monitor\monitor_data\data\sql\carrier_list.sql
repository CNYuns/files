-- 运营商列表
CREATE TABLE IF NOT EXISTS `carrier_list` (
    `carrier_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `title` TEXT DEFAULT ''            -- IP运营商
);

-- 增加唯一索引
CREATE UNIQUE INDEX IF NOT EXISTS `idx_carrier` ON `carrier_list` (`title`);