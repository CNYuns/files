// -------------------------------------------------------------------
// 宝塔Linux面板
// -------------------------------------------------------------------
// Copyright (c) 2015-2024 宝塔软件(http://bt.cn) All rights reserved.
// -------------------------------------------------------------------
// Author: hwliang <hwl@bt.cn>
// -------------------------------------------------------------------
#define IPSET_MANAGER_H
#ifndef PUBLIC_H
#include "public.h"
#endif
using namespace std;

/**
 * @brief ipset管理类
 * @author hwliang
 */
class ipset_manager
{
    public:
        /**
         * @brief 构造函数
         */
        ipset_manager();

        /**
         * @brief 获取ipset集合信息
         * @author hwliang
         * @param name <string> ipset集合名称
         * @return vector<string> ipset集合信息  格式：[name,hash,hashsize,maxelem,timeout,ports,protocol]
         */
        vector<string> get_ipset_info(string name);

        /**
         * @brief 创建ipset
         * @author hwliang
         * @param name <string> ipset集合名称
         * @param hash <string> hash类型 支持：ip 或 ip,port 或 net
         * @param hashsize <int> 初始化大小
         * @param maxelem <int> 最大元素数量
         * @param timeout <int> 元素最大超时时间
         * @param ports <string> 目标端口号（在protocol=tcp或udp时有效）,多个端口号用逗号分隔
         * @param protocol <string> 协议类型 支持：tcp/udp/icmp/all
         * @return int 0.失败 1.成功
         */
        int create_ipset(string name,string hash,int hashsize,int maxelem,int timeout,string ports,string protocol);


        /**
         * @brief 删除ipset
         * @author hwliang
         * @param name <string> ipset集合名称
         * @param ports <string> 目标端口号（在protocol=tcp或udp时有效）,多个端口号用逗号分隔
         * @param protocol <string> 协议类型 支持：tcp/udp/icmp/all 
         * @return int 0.失败 1.成功
         */
        int delete_ipset(string name,string ports,string protocol);


        /**
         * @brief 创建ipset集合
         * @author hwliang
         * @param name <string> 集合名称
         * @param hash <string> hash类型,支持：ip 或 ip,port 或 net
         * @param hashsize <int> 初始化大小
         * @param maxelem <int> 最大元素数量
         * @param timeout <int> 元素最大超时时间
         * @return int 0.失败 1.成功
         */
        int create_collection(string name,string hash,int hashsize,int maxelem,int timeout);

        /**
         * @brief 删除ipset集合
         * @author hwliang
         * @param name <string> 集合名称
         * @return int 0.失败 1.成功
         */
        int delete_collection(string name);


        /**
         * @brief 添加ipset集合元素
         * @param name <string> 集合名称
         * @param ip <string> ip地址
         * @param port <int> 端口
         * @param timeout <int> 超时时间
         * @return int 0.失败 1.成功
         */
        int add_to_collection(string name,string ip,int port,int timeout);


        /**
         * @brief 修改ipset集合元素
         * @param name <string> 集合名称
         * @param ip <string> ip地址
         * @param port <int> 端口
         * @param timeout <int> 超时时间
         * @return int 0.失败 1.成功
         */
        int update_to_collection(string name,string ip,int port,int timeout);

        /**
         * @brief 删除ipset集合元素
         * @param name <string> 集合名称
         * @param ip <string> ip地址
         * @param port <int> 端口
         * @return int 0.失败 1.成功
         */
        int del_from_collection(string name,string ip,int port);

        /**
         * @brief 获取ipset集合元素数量
         * @param name <string> 集合名称
         * @return int 元素数量
         */
        int get_collection_count(string name);

        /**
         * @brief 获取ipset集合列表
         * @return vector<string> 集合列表
         */
        vector<string> get_collection_list();

        /**
         * @brief 获取ipset集合元素列表
         * @param name <string> 集合名称
         * @return vector<string> 元素列表
         */
        vector<string> get_collection_element_list(string name);

        /**
         * @brief 获取ipset集合元素超时时间
         * @param name <string> 集合名称
         * @param ip <string> ip地址
         * @param port <int> 端口
         * @return int 超时时间
         */
        int get_collection_element_timeout(string name,string ip,int port);

        /**
         * @brief 清空集合
         * @author hwliang
         * @param name <string> 集合名称
         * @return int 0.失败 1.成功
         */
        int flush_collection(string name);
    
    // private:
        regex_t ipset_name_regex; //ipset集合名称正则表达式

        /**
         * @brief 检查ipset集合名称是否合法
         * @author hwliang
         * @param name <string> 集合名称
         * @return int 0.不合法 1.合法
         */
        int check_ipset_name(string name);

        /**
         * @brief 设置ipset集合到iptables规则中
         * @author hwliang
         * @param name <string> 集合名称
         * @param port <int> 目标端口
         * @param protocol <string> 协议 tcp/udp/all/icmp 默认tcp
         * @return int 0.失败 1.成功
         */
        int set_collection_to_iptables(string name,int port,string protocol="tcp");

        /**
         * @brief 从iptables规则中删除ipset集合
         * @param name <string> 集合名称
         * @param port <int> 目标端口
         * @param protocol <string> 协议 tcp/udp/all/icmp 默认tcp
         * @return int 0.失败 1.成功
         */
        int del_collection_from_iptables(string name,int port,string protocol="tcp");

        /**
         * @brief 获取iptables规则中的ipset集合列表
         * @return vector<string> 集合列表
         */
        vector<string> get_iptables_collection_list();


        /**
         * @brief 是否设置了ipset集合到iptables规则中
         * @author hwliang
         * @param name <string> 集合名称
         * @param port <int> 目标端口
         * @return int 0.未设置 1.已设置
         */
        int iptables_is_exists(string name,int port = 0);

        /**
         * @brief 是否设置了ipset集合到ip6tables规则中
         * @author hwliang
         * @param name <string> 集合名称
         * @param port <int> 目标端口 
         * @return int 0.未设置 1.已设置
         */
        int ip6tables_is_exists(string name,int port = 0);

        /**
         * @brief 尝试安装ipset
         * @return int
         */
        int install_ipset();

        /**
         * @brief 判断是否安装ipset
         * @author hwliang
         * @return int 0.未安装 1.已安装
         */
        int is_ipset_installed();

        /**
         * @brief 判断是否安装iptables
         * @return int 0.未安装 1.已安装
         */
        int is_iptables_installed();

        /**
         * @brief 判断hash类型是否支持
         * @param hash <string> hash类型
         * @return int 0.不支持 1.支持
         */
        int is_hash_supported(string hash);

        /**
         * @brief 判断集合是否存在
         * @param name <string> 集合名称
         * @return int 0.不存在 1.存在
         */
        int is_collection_exists(string name);

        /**
         * @brief 检查协议是否合法
         * @author hwliang
         * @param protocol <string> 协议 
         * @return int 0.不合法 1.合法
         */
        int check_protocol(string protocol);

        /**
         * @brief WAF添加ip到ipset集合中
         * @author hwliang
         * @param ip <string> ip地址
         * @return int 0.失败 1.成功 2.已存在
         */
        int add_waf_ip(string ip,int timeout);

        /**
         * @brief WAF删除ip从ipset集合中
         * @param ip <string> ip地址
         * @return int 0.失败 1.成功
         */
        int del_waf_ip(string ip);

        /**
         * @brief WAF更新ip到期时间到ipset集合中
         * @author
         * @param ip <string> ip地址
         * @return int 0.失败 1.成功
         */
        int update_waf_ip(string ip,int timeout);
};