-- 蜘蛛访问统计
-- uri特征统计
CREATE TABLE IF NOT EXISTS `uri_total`
(
    `total_id`  INTEGER PRIMARY KEY AUTOINCREMENT,
    `rule_id`   TEXT    DEFAULT "",
    `spider_id` INTEGER DEFAULT 0,
    `date`      INTEGER DEFAULT 0,
    `request`   INTEGER DEFAULT 0
);

-- 增加索引
CREATE UNIQUE INDEX IF NOT EXISTS `idx_date_rule_id` ON `uri_total` (`date`, `rule_id`, `spider_id`);
