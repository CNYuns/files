# conding:utf-8
import os
import sys
import time

import psutil
import stat
import pwd
from typing import Dict, List, Tuple, Optional, Union

# 添加项目根目录到环境变量
os.chdir("/www/server/panel")
if "/www/server/panel/class" not in sys.path:
    sys.path.insert(0, "/www/server/panel/class")

if "/www/server/panel/plugin/monitor" not in sys.path:
    sys.path.insert(0, "/www/server/panel/plugin/monitor")

import public
from service import Service
# 排除docker同步出现的日志干扰
def WriteLog(type, logMsg, args=(), not_web=False):
    return None
public.WriteLog =  WriteLog

_SHOW_LOG = True


def print_log(msg: Union[str, dict], not_starts:bool=False):
    if not _SHOW_LOG:
        return
    if isinstance(msg, str):
        if not not_starts:
            print("*" * 30)
        print(msg)
    else:
        msg_str = "检查结果:{}".format(msg.get("msg"))
        if msg.get("repair_msg", None):
            msg_str += "\n修复结果:{}".format(msg.get("repair_msg"))
        if msg.get("help", None):
            msg_str += "\n帮助:{}".format(msg.get("help"))
        print(msg_str)


class _Monitor:
    monitor_path = "/www/server/monitor"
    monitor_exe = "/www/server/monitor/monitor"

    @staticmethod
    def has_systemd() -> bool:
        # return False
        res = public.readFile("/proc/1/comm")
        if isinstance(res, str) and res.strip() == "systemd":
            return True
        return False

    def running(self) -> bool:
        if self.has_systemd():
            return public.ExecShell("systemctl is-active monitor")[0].strip() == "active"
        return self._check_monitor_running_by_exe() != 0

    def _check_monitor_running_by_exe(self) -> int:
        """通过可执行文件路径精确获取监控服务主进程ID"""
        try:
            target_exe = os.path.realpath(self.monitor_exe)
            if not os.path.isfile(target_exe):
                return 0

            candidate_pids = []
            for proc in psutil.process_iter(['pid', 'exe', 'ppid']):
                try:
                    if os.path.samefile(proc.exe(), target_exe):
                        candidate_pids.append(proc)
                except (psutil.NoSuchProcess, FileNotFoundError, PermissionError):
                    continue

            # 根据进程树确定主进程
            for proc in candidate_pids:
                # 如果父进程不在候选列表中，则为根进程
                if not any(p.pid == proc.ppid() for p in candidate_pids):
                    return proc.pid

            return candidate_pids[0].pid if candidate_pids else 0
        except Exception as e:
            print_log(f"进程停止异常: {str(e)}")
            return 0

    def start_monitor(self) -> Tuple[str, str]:
        if not self.stop_exception_process():
            if self.check_yun_suo():
                return "监控服务启动失败", "检测到您可能安装了云锁，请尝试关闭云锁后修复插件"
            return "监控服务启动失败", "监控服务可执行文件丢失，请尝试修复整个插件。\n如果您在修复后仍然遇到这条信息，请检查是否有开启其他安全服务，导致了可执行文件被删除，例如云锁等。"

        if not self.running():
            self._start_monitor()
        if not self.running():
            return "监控服务启动失败", "请尝试执行：systemctl status monitor 查看服务信息"
        return "监控服务启动成功", ""

    def _start_monitor(self):
        if self.has_systemd():
            public.ExecShell("systemctl restart monitor")
        else:
            public.ExecShell("cd {path} && nohup {path}/monitor &> /dev/null &".format(path=self.monitor_path))
        time.sleep(0.5)

    def _stop_monitor_process_by_exe(self):
        try:
            target_exe = os.path.realpath(self.monitor_exe)
            if not os.path.isfile(target_exe):
                return
            candidate_pids = []
            for proc in psutil.process_iter(['pid', 'exe', 'ppid']):
                try:
                    if os.path.samefile(proc.exe(), target_exe):
                        candidate_pids.append(proc)
                except (psutil.NoSuchProcess, FileNotFoundError, PermissionError):
                    continue

            for proc in candidate_pids:
                try:
                    proc.kill()
                except psutil.NoSuchProcess:
                    continue
        except Exception as e:
            print(f"进程停止异常: {str(e)}")


    def stop_exception_process(self):
        if self.has_systemd():
            public.ExecShell("systemctl stop monitor")
        else:
            self._stop_monitor_process_by_exe()

        time.sleep(0.5)

        res = os.path.isfile(self.monitor_exe)
        os.chmod(self.monitor_exe, 0o700)
        return res

    @staticmethod
    def check_yun_suo():
        path_list = [
            "/etc/init.d/yunsuo",
            "/usr/local/yunsuo_agent"
        ]
        for path in path_list:
            if os.path.exists(path):
                return True
        return False



# 检查监控服务状态，并自动修复部分问题
# 1. 服务运行用户
# 2. 相关文件权限
# 3. 服务状态
# 4. 配置文件错误
class MonitorCheck:
    _default_error = {
        "title": "",
        "is_error": False,
        "msg": "",
        "repair_msg": "",
        "help": "",
    }

    print_log = staticmethod(print_log)

    def __init__(self):
        self._error_list: List[Dict[str, str]] = []
        self.need_reload = False
        self.monitor_user = "bt-monitor"
        self.monitor_path = "/www/server/monitor"
        self.monitor = _Monitor()

    def check(self):
        self._error_list = []
        self.print_log("开始检查环境...")
        flag, err_data = self.check_env()
        if not flag:
            repair_msg, help_msg = self.repair_env()
            err = {
                "title": "环境检查", "is_error": True if help_msg else "",
                "msg": err_data,
                "repair_msg": repair_msg,
                "help": help_msg,
            }
            self._error_list.append(err)
            self.print_log(err)
            if help_msg:  # 运行用户添加失败，则跳过
                return
            self.need_reload = True
        else:
            self.print_log("运行环境无异常", not_starts=True)

        res = self.check_timezone()
        if res:
            self.print_log(res, not_starts=True)

        self.print_log("开始检测并修复配置文件...\n这可能需要耗费一段时间，请稍等待...")
        err_msg, help_msg = self.check_config()
        if not help_msg:
            self.print_log(err_msg, not_starts=True)
        else:
            err = {
                "title": "配置文件检查", "is_error": True,
                "msg": err_msg,
                "repair_msg": "",
                "help": help_msg,
            }
            self._error_list.append(err)
            self.print_log(err)

        self.print_log("开始检测监控服务状态...")
        if self.monitor.running():
            self.print_log("监控服务运行正常", not_starts=True)
        else:
            repair_msg, help_msg = self.monitor.start_monitor()
            err = {
                "title": "监控服务检查", "is_error": True if help_msg else False,
                "msg": "监控服务未运行",
                "repair_msg": repair_msg,
                "help": help_msg,
            }
            self._error_list.append(err)
            self.print_log(err)
            if self.need_reload:
                return

        if self.need_reload:
            self.monitor.start_monitor()

        return

    @staticmethod
    def check_permissions(path, user: pwd.struct_passwd, file_mode: int, dir_mode: int):
        stat_info = os.stat(path)
        # 检查文件所属用户是否正确
        if stat_info.st_uid != user.pw_uid:
            return False
        if os.path.isdir(path):
            # 这里简单检查是否可读可执行
            if stat.S_IMODE(stat_info.st_mode) < dir_mode:
                return False
        elif os.path.isfile(path):
            # 这里简单检查是否可读可写
            if stat.S_IMODE(stat_info.st_mode) < file_mode:
                return False
        return True

    def check_user_exists(self):

        try:
            pwd.getpwnam(self.monitor_user)
            return True
        except KeyError:
            return False

    @staticmethod
    def check_timezone() -> Optional[str]:
        import time
        tz1, tz2 = int(-time.timezone/3600), int(-time.altzone/3600)
        if tz1 == 8 or tz2 == 8:
            return None
        else:
            tz_str = "{}{}区".format("东" if tz1 > 0 else "西", tz1)
            return "当前系统时区为{}, 不是东8区（Asia/Shanghai）会对您查看数据造成影响，请注意。".format(tz_str)

    def check_env(self) -> Tuple[bool, str]:
        # 检查bt-monitor运行用户是否存在，并检查/www/server/monitor 及其下所有文件权限 和 用户是否正确
        try:
            user = pwd.getpwnam(self.monitor_user)
        except:
            return False, "运行用户"

        file_mode = 0o600
        dir_mode = 0o700
        if not self.check_permissions(self.monitor_path, user, file_mode, dir_mode):
            return False, "文件权限异常: " + self.monitor_path

        for root, dirs, files in os.walk(self.monitor_path):
            for name in dirs + files:
                full_path = os.path.join(root, name)
                if name in ["monitor", "ipfilter"]:
                    if not self.check_permissions(full_path, user, 0o700, dir_mode):
                        os.chown(full_path, user.pw_uid, user.pw_gid)
                        os.chmod(full_path, 0o700)
                else:
                    if not self.check_permissions(full_path, user, file_mode, dir_mode):
                        return False, "文件权限异常: " + full_path
        return True, ""

    @staticmethod
    def check_config() -> Tuple[str, str]:
        service = Service()
        res = service.check_site_config()
        if res["status"] is False:
            return res["msg"], "无法修复"
        else:
            return "配置文件已检查完成", ""

    def add_user(self) -> bool:
        sh = "useradd -r -s /sbin/nologin " + self.monitor_user
        public.ExecShell(sh)
        if self.check_user_exists():
            return True
        else:
            return False

    def repair_env(self) -> Tuple[str, str]:
        # 如果没有bt-monitor（系统用户，不可登录）用户，则添加，并检测是否添加成功， 如果添加失败，则提示用户关闭系统加固，并手动添加
        if not self.check_user_exists():
            if not self.add_user():
                return "监控用户添加失败", "请尝试关闭系统加固，并手动添加用户：{}".format(self.monitor_user)
            return "监控用户添加成功", ""
        # 文件权限问题，可以在重启时自动处理
        return "文件权限处理完成", ""

    def repair_config(self):
        pass


if __name__ == "__main__":
    monitor_ck = MonitorCheck()
    monitor_ck.show_log = True
    monitor_ck.check()
