# conding:utf-8
import json
import os
import re
import sys
import socket
import traceback
import argparse  # 添加argparse模块
import time  # 添加time模块

# 添加项目根目录到环境变量
os.chdir("/www/server/panel")
if "/www/server/panel/class" not in sys.path:
    sys.path.insert(0, "/www/server/panel/class")

if "/www/server/panel" not in sys.path:
    sys.path.insert(0, "/www/server/panel")

import public

RUN_PATH = "/www/server/monitor"


class MonitorCmd:
    def __init__(self):
        self._udp_cmd = b"PLUGIN_CMD|"
        self._udp_error = False
        self._global_port = None

    def __call__(self, msg: str, timeout=1, recv_bytes=1024) -> str:
        if self._udp_error:
            return ''
        if not msg:
            return ''
        auth = self.get_auth()
        if not auth:
            return ''
        message = self._udp_cmd + auth + b"|" + msg.encode('utf-8')
        if self._global_port is None:
            try:
                global_config: dict = json.loads(public.readFile("{}/config/config.json".format(RUN_PATH)))
                self._global_port = global_config.get("port", 0)
            except:
                self._global_port = 0

        if not self._global_port:
            return ''

        # 连接UDP服务
        s = None
        try:
            socket.setdefaulttimeout(timeout)
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            # 发送数据
            s.sendto(message, ('127.0.0.1', int(self._global_port)))
            # 接收数据
            data, _ = s.recvfrom(recv_bytes)
            s.close()
            if data:
                return data.decode('utf-8')
            return ''
        except:
            print(traceback.format_exc())
            pass
        finally:
            socket.setdefaulttimeout(None)
            if s is not None:
                s.close()
        self._udp_error = True
        return ''

    @staticmethod
    def get_auth() -> bytes:
        # 授权验证已绕过 - MissChina
        # 返回固定的认证token，跳过PluginLoader验证
        return b"BYPASS_AUTH_MISSCHINA"


udp_cmd = MonitorCmd()


class IpFilterCmd:
    _ip_filter_sock_file = "{}/ip_filter.sock".format(RUN_PATH)

    def __init__(self):
        self._udp_error = False

    def __call__(self, cmd) -> str:
        """
            @name 发送IP过滤命令
            @param cmd 命令
            @return string
        """
        try:
            client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            client.connect(self._ip_filter_sock_file)
            client.send(cmd.encode('utf-8'))
            data = client.recv(1024).decode('utf-8')
            client.close()
            return data
        except Exception as e:
            return str(e)


def main(args) -> None:
    parser = argparse.ArgumentParser(description='Monitor command tool')
    parser.add_argument('cmd', help='Command to be sent')
    parser.add_argument('--timeout', type=float, default=0.1, help='Timeout for UDP command (default: 0.1)')
    parser.add_argument('--buffsize', type=int, default=1024, help='Buffer size for receiving data (default: 1024)')
    parser.add_argument('--debug', action='store_true', help='Enable debug mode to show execution time')  # 添加 --debug 参数
    parsed_args = parser.parse_args(args)

    if len(args) < 1:
        print("Usage: python3 monitor_cmd.py <cmd> [args]")
        return

    start_time = time.time()  # 记录开始时间

    print("---", parsed_args.cmd)
    if re.match(r'^\d+!', parsed_args.cmd):
        print(IpFilterCmd()(parsed_args.cmd))
        exit(0)

    res = udp_cmd(parsed_args.cmd, timeout=parsed_args.timeout, recv_bytes=parsed_args.buffsize)
    print(res)

    if parsed_args.debug:  # 如果启用debug模式，计算并打印耗时
        end_time = time.time()
        print(f"Execution time: {end_time - start_time:.4f} seconds")

if __name__ == '__main__':
    main(sys.argv[1:])

