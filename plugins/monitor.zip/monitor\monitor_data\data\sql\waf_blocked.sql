-- waf拦截原因列表
CREATE TABLE IF NOT EXISTS `waf_blocked`
(
    `id`     INTEGER PRIMARY KEY AUTOINCREMENT, -- 自增ID
    `filter` TEXT DEFAULT '',                   -- 过滤器名称
    `reason` TEXT DEFAULT ''                    -- 拦截原因
);

-- 增加唯一索引
CREATE INDEX IF NOT EXISTS `idx_filter_reason` ON `waf_blocked` (`filter`, `reason`);

-- 插入默认数据id为1 表示默认的未知拦截
INSERT INTO `waf_blocked`(`id`, `filter`, `reason`) VALUES (1, '', '未知拦截');