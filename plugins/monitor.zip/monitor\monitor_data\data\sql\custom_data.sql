-- 自定义的统计数据列表
CREATE TABLE IF NOT EXISTS `data_list` (
   `id` INTEGER PRIMARY KEY AUTOINCREMENT,
   `data` TEXT DEFAULT "" NOT NULL,
   `count` INTEGER DEFAULT 0 NOT NULL
);

-- 增加唯一索引
CREATE UNIQUE INDEX IF NOT EXISTS `idx_data` ON `data_list` (`data`);
CREATE INDEX IF NOT EXISTS `idx_count` ON `data_list` (`count`);


-- 自定义的统计数据与日志之间的关联表
CREATE TABLE IF NOT EXISTS `key_list` (
  `access_id` INTEGER PRIMARY KEY,
  `key` INTEGER NOT NULL
);

-- 增加唯一索引
CREATE INDEX IF NOT EXISTS `idx_key` ON `key_list` (`key`);