-- 地区统计表
CREATE TABLE IF NOT EXISTS `uri_ip_total`
(
    `id`          INTEGER PRIMARY KEY AUTOINCREMENT,
    `uri_id`      INTEGER DEFAULT 0, -- URI ID
    `ip_id`       INTEGER DEFAULT 0, -- 访问IP int64用去33位, 后32位表示ipv4， 33位表示ipv6
    `request`     INTEGER DEFAULT 0  -- 请求次数
);


-- 增加索引
CREATE UNIQUE INDEX IF NOT EXISTS `idx_uri_id` ON `uri_ip_total` (`uri_id`, `ip_id`);
CREATE INDEX IF NOT EXISTS `idx_uri_id_request` ON `uri_ip_total` (`uri_id`, `request`);
