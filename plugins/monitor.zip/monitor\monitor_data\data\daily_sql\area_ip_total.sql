-- 地区统计表
CREATE TABLE IF NOT EXISTS `area_ip_total`
(
    `id`          INTEGER PRIMARY KEY AUTOINCREMENT,
    `country_id`  INTEGER DEFAULT 0, -- 国家ID
    `province_id` INTEGER DEFAULT 0, -- 省份ID
    `city_id`     INTEGER DEFAULT 0, -- 城市ID
    `ip_id`       INTEGER DEFAULT 0, -- 访问IP int64用去33位, 后32位表示ipv4， 33位表示ipv6
    `request`     INTEGER DEFAULT 0  -- 请求次数
);


-- 增加索引
CREATE UNIQUE INDEX IF NOT EXISTS `idx_area_id` ON `area_ip_total` (`country_id`, `province_id`, `city_id`, `ip_id`);
CREATE INDEX IF NOT EXISTS `idx_country_id_request` ON `area_ip_total` (`country_id`, `ip_id`, `request`);
CREATE INDEX IF NOT EXISTS `idx_province_id_request` ON `area_ip_total` (`province_id`, `province_id`, `request`);
