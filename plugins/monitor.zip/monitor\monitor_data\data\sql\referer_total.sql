-- REFERER来路统计表
CREATE TABLE IF NOT EXISTS `referer_total` (
    `referer_total_id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `date` INTEGER DEFAULT 0,
    `referer_id` INTEGER DEFAULT 0,
    `request` INTEGER DEFAULT 0
);

-- 增加索引
CREATE INDEX IF NOT EXISTS `idx_date_referer_id` ON `referer_total` (`date`,`referer_id`);
CREATE INDEX IF NOT EXISTS `idx_date_request` ON `referer_total` (`date`, `request`);