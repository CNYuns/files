#!/bin/bash
src_path=/www/server/panel/plugin/monitor/monitor/ipfilter
bin_file=/www/server/monitor/ipfilter
cpp_file=$src_path/bt_ipfilter.cpp

if [ ! -d $src_path ];then
    echo "Error: The directory $src_path does not exist."
    exit 1
fi

cd $src_path
g++ $cpp_file -o $bin_file -std=c++11

if [ $? -ne 0 ];then
    echo "Error: Failed to compile $cpp_file."
    exit 1
fi

if [ ! -f $bin_file ];then
    echo "Error: The file $bin_file does not exist."
    exit 1
fi

chmod 700 $bin_file
chown bt-monitor:bt-monitor $bin_file

echo "Success: The file $bin_file has been compiled successfully."
