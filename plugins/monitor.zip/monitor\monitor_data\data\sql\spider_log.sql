
-- 蜘蛛访问日志表
CREATE TABLE IF NOT EXISTS `spider_log` (
    `id` INTEGER PRIMARY KEY AUTOINCREMENT,
    `host_id` INTEGER DEFAULT 0,        -- 访问域名
    `ip_id` INTEGER DEFAULT 0,          -- 访问IP int64用去33位, 后32位表示ipv4， 33位表示ipv6
    `uri_id` INTEGER DEFAULT 0,         -- 访问URI
    `method_id` INTEGER DEFAULT 0,      -- 请求类型
    `referer_id` INTEGER DEFAULT 0,     -- 来路
    `status_code` INTEGER DEFAULT 0,        -- 状态码
    `request_take` INTEGER DEFAULT 0,       -- 请求耗时
    `request_time` INTEGER DEFAULT 0,       -- 请求时间
    `send_bytes` INTEGER DEFAULT 0,         -- 发送字节数
    `receive_bytes` INTEGER DEFAULT 0,      -- 接收字节数
    `user_agent_id` INTEGER DEFAULT 0,      -- user_agent
    `is_https` INTEGER DEFAULT 0,           -- 是否https
    `spider` INTEGER DEFAULT 0,            -- 蜘蛛类型
    `content_type_id` INTEGER DEFAULT 0,    -- 响应类型
    `access_log_id` INTEGER DEFAULT 0     -- 关联的access_log
);

-- 增加索引
CREATE INDEX IF NOT EXISTS `access_log_uri_id` ON `spider_log` (`uri_id`);
CREATE INDEX IF NOT EXISTS `access_log_spider` ON `spider_log` (`spider`);
CREATE INDEX IF NOT EXISTS `access_log_request_time` ON `spider_log` (`request_time`);
CREATE INDEX IF NOT EXISTS `access_log_ip_id` ON `spider_log` (`ip_id`);
