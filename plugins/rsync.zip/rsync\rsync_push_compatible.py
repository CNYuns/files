import json
import os
import time
from typing import Dict, Union, Optional, Iterable
from datetime import datetime, timedelta
import importlib
import sys

if "/www/server/panel/class" not in sys.path:
    sys.path.insert(0, "/www/server/panel/class")

if "/www/server/panel" not in sys.path:
    sys.path.insert(0, "/www/server/panel")

import public


class _OldPushManager:
    _conf_file = "/www/server/panel/class/push/push.json"

    def __init__(self):
        self._push_counter = None
        self._tamper_core_config = None

    def get_task_data(self):
        if not os.path.isfile(self._conf_file):
            return []

        try:
            conf = json.loads(public.readFile(self._conf_file))
        except:
            return []

        res = None
        for k, v in conf.get("rsync_push", {}).items():
            res = {
                "title": "文件同步异常告警",
                "day_num": int(v["push_count"]),
                "status": v["status"],
                "sender": v["module"].split(",")
            }
            break
        return res

    def del_today_push_counter(self, task_id):
        if task_id in self.push_counter:
            del self.push_counter[task_id]
            today_push_counter = '{}/data/push/tips/rsync_today.json'.format(public.get_panel_path())
            if self._push_counter is not None:
                public.writeFile(today_push_counter, json.dumps(self.push_counter))

    @property
    def push_counter(self) -> dict:
        if self._push_counter is not None:
            return self._push_counter
        else:
            today_push_counter = '{}/data/push/tips/rsync_today.json'.format(public.get_panel_path())
            t_day = datetime.now().strftime('%Y-%m-%d')
            if os.path.exists(today_push_counter):
                tip = json.loads(public.readFile(today_push_counter))
                if tip["t_day"] != t_day:
                    tip = {"t_day": t_day}
            else:
                tip = {"t_day": t_day}
        self._push_counter = tip
        return self._push_counter

    @staticmethod
    def get_sender_list():
        config_mod = importlib.import_module("config", "class")
        sender_map = config_mod.config().get_msg_configs(None)
        return [{
            "title": v["title"],
            "value": v["name"]
        } for _, v in sender_map.items() if v["name"] != "sms"]

    def set_task_conf_data(self, config_data: dict) -> Optional[str]:
        """
        {
            "template_id": "40",
            "task_data": {
                "status": bool(v_data.get("status", True)),
                "sender": sender_list,
                "task_data": {
                },
                "number_rule": {
                    "day_num": v_data.get("push_count", 3)
                }
            }
        }
        """
        sender = config_data["task_data"].get("sender", [])
        day_num = config_data["task_data"].get("number_rule", {}).get("day_num", 3)
        if not sender:
            return "请选择告警通道"

        sl = [i["value"] for i in self.get_sender_list()]
        for i in sender:
            if i not in sl:
                return "请选择正确的告警通道"

        if not day_num or day_num < 0:
            return "请设置推送次数"
        if not os.path.isfile(self._conf_file):
            conf = {}
        else:
            try:
                conf = json.loads(public.readFile(self._conf_file))
            except:
                conf = {}

        rsync_push = conf.get("rsync_push", {})
        for k, _ in rsync_push.items():
            self.del_today_push_counter(str(k))

        task_data = {
            "project": "rsync_all",
            "module": ",".join(sender),
            "status": config_data["task_data"].get("status", True),
            "key": "",
            "type": "rsync_pash",
            "push_count": day_num
        }

        conf["rsync_push"] = {str(time.time()): task_data}
        public.writeFile(self._conf_file, json.dumps(conf))

        return None

    def change_task_status(self, status: bool):
        if not os.path.isfile(self._conf_file):
            conf = {}
        else:
            try:
                conf = json.loads(public.readFile(self._conf_file))
            except:
                conf = {}

        rsync_push = conf.get("rsync_push", {})
        for _, v in rsync_push.items():
            v["status"] = status
        public.writeFile(self._conf_file, json.dumps(conf))

    def remove_task_conf(self):
        if not os.path.isfile(self._conf_file):
            conf = {}
        else:
            try:
                conf = json.loads(public.readFile(self._conf_file))
            except:
                conf = {}

        conf.pop("rsync_push", None)
        public.writeFile(self._conf_file, json.dumps(conf))


class _ModPushManager:
    TYPE2TITLE = {
        "wx_account": "微信公众号",
        "mail": "邮箱",
        "webhook": "自定义",
        "feishu": "飞书",
        "dingding": "钉钉",
        "weixin": "企业微信",
    }
    TYPE_SORT = ("wx_account", "mail",  "feishu", "dingding", "weixin", "webhook")


    def __init__(self):
        from mod.base.push_mod import PushManager, TaskConfig, SenderConfig

        self.push_manager = PushManager
        self.tc = TaskConfig
        self.sc = SenderConfig

    def get_task_data(self):
        tc = self.tc()
        data_list = [{
            "title": v["title"],
            "day_num": int(v["number_rule"]["day_num"]),
            "status": v["status"],
            "sender": v["sender"]
        } for v in tc.config if v["template_id"] == "40"]

        return None if not data_list else data_list[0]

    def set_task_conf_data(self, config_data: dict):
        return self.push_manager().set_task_conf_data(config_data)

    def change_task_status(self, status: bool):
        task = self.tc().get_by_keyword("rsync_push", "rsync_push")
        if not task:
            return "该目录的告警任务不存在"

        self.push_manager().change_task_conf(public.to_dict_obj(
            {
                "task_id": task["id"],
                "status": status
            }
        ))

    def remove_task_conf(self):
        task = self.tc().get_by_keyword("rsync_push", "rsync_push")
        if not task:
            return "该目录的告警任务不存在"

        self.push_manager().remove_task_conf(public.to_dict_obj(
            {
                "task_id": task["id"]
            }
        ))

    def get_sender_list(self):
        sc = self.sc()
        res = [
            {
                "title": v["data"]["title"] + "({})".format(self.TYPE2TITLE[v["sender_type"]]),
                "value": v["id"],
                "sender_type": v["sender_type"]
            }
            for v in sc.config if v["sender_type"] != "sms" and v["used"]
        ]
        res.sort(key=lambda i: self.TYPE_SORT.index(i["sender_type"]))
        return res


def _can_use_mod_push():
    """
    是否可用新版本的告警设置
    """
    return os.path.exists("/www/server/panel/mod/base/push_mod/rsync_push.py")


# 兼容新旧版本告警，实现设置告警、移除告警、关闭告警、获取告警、获取告警通道等功能

def get_push_task_data(get=None):
    default_task = {
        "day_num": 3,
        "sender": [],
        "title": "文件同步异常告警",
        "status": False
    }
    if _can_use_mod_push():
        the_pm = _ModPushManager()
        task_data = the_pm.get_task_data() or default_task
        sender_list = the_pm.get_sender_list()
    else:
        old_pm = _OldPushManager()
        task_data = old_pm.get_task_data() or default_task
        sender_list = old_pm.get_sender_list()

    sender_values = [i["value"] for i in sender_list]
    task_data["sender"] = [i for i in task_data["sender"] if i in sender_values]

    return {
        "task_data": task_data,
        "sender_list": sender_list
    }

def set_push_task_conf(get):
    day_num = get.get("day_num/d", 3)
    status = bool(get.get("status/d", 1))
    sender = get.get("sender/s", '')
    if not status:
        remove_push_task_conf(None)
        return public.returnMsg(True, "告警关闭成功")

    sender_list = [i.strip() for i in sender.split(",") if i.strip()]
    pdata = {
        "template_id": "40",
        "task_data": {
            "status": bool(status),
            "sender": sender_list,
            "task_data": {},
            "number_rule": {
                "day_num": day_num
            }
        }
    }

    if _can_use_mod_push():
        the_pm = _ModPushManager()
        res = the_pm.set_task_conf_data(pdata)
    else:
        the_pm = _OldPushManager()
        res = the_pm.set_task_conf_data(pdata)

    if res is None:
        return public.returnMsg(True, "告警设置成功")
    else:
        return public.returnMsg(False, res)

def change_task_status(get):
    status = bool(get.get("status/d", 1))
    if _can_use_mod_push():
        the_pm = _ModPushManager()
        the_pm.change_task_status(status)
    else:
        the_pm = _OldPushManager()
        the_pm.change_task_status(status)


    return public.returnMsg(True, "修改告警状态成功")


def remove_push_task_conf(get=None):
    if _can_use_mod_push():
        the_pm = _ModPushManager()
        the_pm.remove_task_conf()
    else:
        the_pm = _OldPushManager()
        the_pm.remove_task_conf()

    return public.returnMsg(True, "移除告警任务成功")