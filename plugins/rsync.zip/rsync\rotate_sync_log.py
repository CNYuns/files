import os,sys
import shutil
import time
import glob
import json
sys.path.append("/www/server/panel/class/")
sys.path.append("/www/server/panel/")
import public

class LogSplit:
    def __init__(self, split_type="day", log_size=1024*1024*10, limit=180, compress=False):
        self.stype = split_type  # 切割方式：按天或按大小
        self.log_size = log_size  # 切割大小阈值
        self.limit = limit  # 保留的最大日志数量
        self.compress = compress  # 是否压缩日志
        self._time = time.strftime("%Y-%m-%d_%H%M%S")  # 当前时间，用于生成文件名

    def split_logs(self, log_directories):
        """处理多个日志目录"""
        self._start()
        self._show()
        for log_type, directory in log_directories.items():
            counter = 0
            for logfile in glob.glob(os.path.join(directory, '*.log')):
                # 按大小切割时，若文件大小未达到阈值则跳过
                if self.stype == 'size' and os.path.getsize(logfile) < self.log_size:
                    print()
                    print(f"|---跳过文件 {logfile}，文件大小未达到设定的切割阈值 {self.log_size / (1024 * 1024):.2f} MB")
                    continue
                # 执行切割处理
                if self.process_log_file(logfile, log_type):
                    counter += 1
            if counter == 0:
                print(f"|---目录 {directory} 中暂无日志文件可以处理")
        self._stop()
        self.restart_bt_sync()

    def process_log_file(self, logfile, log_type):
        """处理单个日志文件"""
        print()
        print(f"|---开始处理日志文件：{logfile}")

        # 如果文件为空，直接跳过处理
        if os.path.getsize(logfile) == 0:
            print(f"|---文件 {logfile} 为空，跳过处理")
            return False

        log_dir = "/www/server/bt_sync/logs"  # 主日志存储目录

        base_name = os.path.basename(logfile)

        # 针对run_logs.log做特殊处理
        # 如果日志文件是run_logs.log，则切割后的文件存放于 /www/server/bt_sync/logs/run_logs 目录下
        if base_name == "run_logs.log":
            identifier_dir = os.path.join(log_dir, "run_logs")
            if not os.path.exists(identifier_dir):
                os.makedirs(identifier_dir)
            new_log_file = os.path.join(identifier_dir, f"{self._time}.log")

        else:
            # 原有逻辑：从文件名中提取标识符，用于存放在对应子目录下
            # 例如：33333333333_exec.log => 标识符为 "33333333333"
            # log_type 将作为子目录名称（如 exec_logs、sync_logs、service_logs）
            log_sub_dir = os.path.join(log_dir, log_type)
            log_identifier = base_name.split('_')[0]  # 提取文件名前的标识符
            identifier_dir = os.path.join(log_sub_dir, log_identifier)
            if not os.path.exists(identifier_dir):
                os.makedirs(identifier_dir)
            new_log_file = os.path.join(identifier_dir, f"{self._time}.log")

        shutil.move(logfile, new_log_file)
        print(f"|---日志文件 {logfile} 已被切割并移动到 {new_log_file}")

        # 压缩切割后的日志
        if self.compress:
            os.system(f'gzip "{new_log_file}"')
            print(f"|---日志文件已被压缩：{new_log_file}.gz")

        # 管理旧日志
        self.manage_old_logs(identifier_dir)

        # 置空原日志
        public.writeFile(logfile, "")

        print(f"|---原日志文件 {logfile} 已被清空")
        print()
        return True

    def manage_old_logs(self, directory):
        """管理超过限制数量的日志文件"""
        files = sorted(glob.glob(os.path.join(directory, '*')), key=os.path.getmtime, reverse=True)
        if len(files) > self.limit:
            print("|---检测到旧文件数量超过限制，开始删除旧的文件...")
            for old_file in files[self.limit:]:
                os.remove(old_file)
                print(f"|---已删除旧日志文件：{old_file}")

    def _start(self):
        print('==================================================================')
        print('★[' + time.strftime("%Y/%m/%d %H:%M:%S") + ']开始日志切割任务')
        print('==================================================================')

    def _show(self):
        if self.stype == "day":
            print('|---切割方式: 每天切割1次')
        else:
            print(f'|---切割方式: 按大小切割，文件超过 {self.log_size / (1024 * 1024):.2f} MB 开始切割')
        print(f'|---当前保留最新的 {self.limit} 份')

    def _stop(self):
        print()
        print('=================日志切割任务完成==================')

    def restart_bt_sync(self):
        bt_sync_path = "/www/server/bt_sync"
        bt_sync_bin = "{}/bin/btsync".format(bt_sync_path)
        bt_sync_file = bt_sync_path + "/bt_sync_config.conf"
        public.ExecShell("pkill btsync")
        exec_log = bt_sync_path + "/exec_logs.log"
        cmd_str = "nohup {} -c {} 2>&1 >> {} &".format(bt_sync_bin, bt_sync_file, exec_log)
        out, err = public.ExecShell(cmd_str)
        # public.print_log("启动btsync")
        # public.print_log(out)
        # public.print_log(err)
def load_sync_config(config_path):
    default_config = {
        "log_size": 0,
        "num": 10,
        "compress": False,
        "stype": "day"
    }
    if not os.path.exists(config_path):
        with open(config_path, 'w') as config_file:
            json.dump(default_config, config_file, indent=4)
        return default_config

    with open(config_path, 'r') as config_file:
        config = json.load(config_file)
    return config or default_config

def main():
    config_path = '/www/server/panel/data/sync_log_split.conf'  # 配置文件路径
    config = load_sync_config(config_path)

    log_splitter = LogSplit(
        split_type='day' if config['log_size'] == 0 else 'size',
        log_size=float(config['log_size']),
        limit=int(config['num']),
        compress=config['compress']
    )

    # 定义日志目录（按类型分类）
    # 新增 service_logs 用于处理 /www/server/bt_sync/run_logs.log
    log_directories = {
        "exec_logs": "/www/server/panel/plugin/rsync/sclient",  # 执行日志目录
        "sync_logs": "/www/server/bt_sync/logs",                # 同步日志目录
        "service_logs": "/www/server/bt_sync"                   # service日志目录
    }

    log_splitter.split_logs(log_directories)  # 执行日志切割

if __name__ == '__main__':
    main()
