#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

public_file=/www/server/panel/install/public.sh
publicFileMd5=$(md5sum ${public_file} 2>/dev/null | awk '{print $1}')
md5check="8e49712d1fd332801443f8b6fd7f9208"
if [ "${publicFileMd5}" != "${md5check}" ]; then
    wget -O Tpublic.sh http://download.bt.cn/install/public.sh -T 20
    publicFileMd5=$(md5sum Tpublic.sh 2>/dev/null | awk '{print $1}')
    if [ "${publicFileMd5}" == "${md5check}" ]; then
        \cp -rpa Tpublic.sh $public_file
    fi
    rm -f Tpublic.sh
fi
. $public_file
download_Url=$NODE_URL
pluginPath=/www/server/panel/plugin/rsync
centos=1
if [ ! -f /usr/bin/yum ]; then
    centos=0
fi
# 系统检测
is_ubuntu24=0
if [ -f /etc/os-release ]; then
    os_id=$(grep '^ID=' /etc/os-release | cut -d'=' -f2 | tr -d '"')
    os_version=$(grep '^VERSION_ID=' /etc/os-release | cut -d'=' -f2 | tr -d '"')
    
    # 输出调试信息
    echo "Detected OS ID: $os_id"
    echo "Detected OS Version: $os_version"

    if [[ "$os_id" == "ubuntu" && "$os_version" == "24.04" ]]; then
        is_ubuntu24=1
        echo "This is Ubuntu 24.04"
    else
        echo "Not Ubuntu 24.04"
    fi
fi
install_main() {
    check_fs
    get_rsync_version
    if [[ "${1}" == "install" ]]; then
        if [ -f "${pluginPath}/repair.pl" ] || [ -f "${pluginPath}/upgrade.pl" ]; then
            check_package "reinstall"
        else
            if [[ -z "$rsync_version" ]] || [[ "$rsync_version" != "3.2.6" ]]; then
                check_package
            elif [ $is_ubuntu24 -eq 1 ] || [[ -z "$rsync_version" ]] || [[ "$rsync_version" != "3.2.7" ]]; then
                check_package
            fi
        fi
    else
        check_package "$@"
    fi

    \cp -f $pluginPath/rsynd.init /etc/init.d/rsynd
    chmod +x /etc/init.d/rsynd
    if [ $centos == 1 ]; then
        chkconfig --add rsynd
        chkconfig --level 2345 rsynd on
    else
        update-rc.d rsynd defaults
    fi

    mkdir -p /www/server/bt_sync/bin
    if [ -f /www/server/bt_sync/bin/btsync ]; then
        /www/server/bt_sync/bin/btsync -s stop
    fi
    
    is_aarch64=$(uname -a|grep aarch64)
    if [ "$is_aarch64" != "" ];then
      \cp -f $pluginPath/btsync-arm64 /www/server/bt_sync/bin/btsync
    else
      \cp -f $pluginPath/btsync-amd64 /www/server/bt_sync/bin/btsync
    fi
    
    chmod +x /www/server/bt_sync/bin/btsync
    # ln -s /www/server/bt_sync/bin/btsync /usr/bin/btsync
    mkdir -p /www/server/bt_sync/logs
    if [ -f /www/server/bt_sync/bt_sync_config.conf ]; then
      nohup /www/server/bt_sync/bin/btsync -c /www/server/bt_sync/bt_sync_config.conf > /www/server/bt_sync/logs/exec_logs.log 2>&1 &
    fi

    mkdir -p $pluginPath
    cd $pluginPath && rm -f rsync_*.so
    # /www/server/panel/pyenv/bin/python3.7 $pluginPath/rsync_cron.py
    if command -v rlcone &>/dev/null; then
        echo "rlcone 已经安装，跳过安装过程"
    else
        echo "rlcone 未安装，开始安装"
        # install_rclone  # 新增 rclone 安装逻辑
    fi
    rm -rf "${pluginPath}/repair.pl"
    rm -rf "${pluginPath}/upgrade.pl"
    echo >/www/server/panel/data/reload.pl
    echo 'Successify'
}

rsync_install() {
    # 检测是否为 Ubuntu 24
    if [ $is_ubuntu24 -eq 1 ]; then
        echo "Detected Ubuntu 24, using system package manager for rsync installation"
        apt-get remove --purge rsync -y
        apt-get install rsync -y
    else
        # 如果不是 Ubuntu 24，继续执行下载和编译 rsync 的逻辑
        if [[ -z "$rsync_version" ]] || [[ "$rsync_version" != "3.2.6" ]]; then
            wget -O rsync-3.2.6.tar.gz $download_Url/install/src/rsync-3.2.6.tar.gz -T 20
            tar xvf rsync-3.2.6.tar.gz
            cd rsync-3.2.6
            ./configure --prefix=/usr $parm
            make -j $cpuCore
            make install
            cd ..
            rm -rf rsync-3.2.6*
            rsync_version=$(/usr/bin/rsync --version | grep version | awk '{print $3}')
            if [ "$rsync_version" != "3.2.6" ]; then
                rm -f /usr/bin/rsync
                ln -sf /usr/local/bin/rsync /usr/bin/rsync
            fi
        fi
    fi
}

install_rclone() {
    
    echo "Installing rclone..."
    local rclone_version="v1.68.2"
    # 定义下载地址为最新版本的稳定链接
    # local rclone_url="https://downloads.rclone.org/rclone-current-linux-amd64.zip"
    local install_dir="/usr/bin" # 指定安装路径

    # 下载 rclone 并解压
    wget -O rclone.zip $download_Url/install/src/rclone-current-linux-amd64.zip
    if [ $? -ne 0 ]; then
        echo "Failed to download rclone. Please check your network or the rclone version URL."
        exit 1
    fi


    unzip -o rclone.zip
    rm -f rclone.zip
    cd rclone-$rclone_version-linux-amd64 || exit 1

    # 将 rclone 安装到指定路径
    cp rclone "$install_dir/"
    chmod +x "$install_dir/rclone"


    # echo "Rclone installed successfully in $install_dir."
    # echo "You can create or edit your configuration in $config_dir/rclone.conf using the 'rclone config' command."

    cd ..
    rm -rf rclone-$rclone_version-linux-$(uname -m)
}

get_rsync_version() {
    rsync_version=$(/usr/bin/rsync --version | grep version | awk '{print $3}')
}

check_package() {
    if [ $centos == 1 ]; then
        install_packages="expect tcl gcc g++ gawk autoconf automake python3-pip acl libacl-devel attr libattr-devel xxhash-devel libzstd-devel lz4-devel openssl-devel"
        for i_name in $install_packages; do
            yum -y install $i_name
        done
    else
        install_packages="expect tcl gcc g++ gawk autoconf automake python3-cmarkgfm acl libacl1-dev attr libattr1-dev libxxhash-dev libzstd-dev liblz4-dev libssl-dev"
        for i_name in $install_packages; do
            apt-get install $i_name -y
        done
    fi


    rconf=$(cat /etc/rsyncd.conf | grep 'rsyncd.pid')
    if [ "$rconf" == "" ]; then
        cat >/etc/rsyncd.conf <<EOF
uid = root
use chroot = no
dont compress = *.gz *.tgz *.zip *.z *.Z *.rpm *.deb *.bz2 *.mp4 *.avi *.swf *.rar
hosts allow =
max connections = 200
gid = root
timeout = 600
lock file = /var/run/rsync.lock
pid file = /var/run/rsyncd.pid
log file = /var/log/rsyncd.log
port = 873
EOF
    fi

    if [[ "${1}" = "reinstall" ]] || [[ -z "$rsync_version" ]] || [[ "$rsync_version" != "3.2.6" ]]; then
        if [ $centos == 1 ]; then
            xxhash_result=$(rpm -qa | grep xxHash-devel)
            zstd_result=$(rpm -qa | grep libzstd-devel)
            lz4_result=$(rpm -qa | grep liblz4-devel)
        else
            xxhash_result=$(dpkg -l | grep libxxhash-dev)
            zstd_result=$(dpkg -l | grep libzstd-dev)
            lz4_result=$(dpkg -l | grep liblz4-dev)
        fi

        if [[ -z $xxhash_result ]]; then
            wget -O xxHash-0.8.0.tar.gz $download_Url/install/src/xxHash-0.8.0.tar.gz
            tar xvf xxHash-0.8.0.tar.gz
            cd xxHash-0.8.0
            make -j $cpuCore
            make install
        fi

        if [[ -z $zstd_result ]]; then
            wget -O zstd-1.5.0.tar.gz $download_Url/install/src/zstd-1.5.0.tar.gz
            tar xvf zstd-1.5.0.tar.gz
            cd zstd-1.5.0
            make -j $cpuCore
            make install
        fi

        if [[ -z $lz4_result ]]; then
            wget -O lz4-v1.9.3.tar.gz $download_Url/install/src/lz4-v1.9.3.tar.gz
            tar xvf lz4-v1.9.3.tar.gz
            cd lz4-v1.9.3
            make -j $cpuCore
            make install
        fi
    fi

    rsync_install
    get_rsync_version
    parm="--disable-xxhash --disable-zstd --disable-lz4"
    rsync_install

}

check_fs() {
    is_max_user_instances=$(cat /etc/sysctl.conf | grep max_user_instances)
    if [ "$is_max_user_instances" == "" ]; then
        echo "fs.inotify.max_user_instances = 1024" >>/etc/sysctl.conf
        echo "1024" >/proc/sys/fs/inotify/max_user_instances
    fi

    is_max_user_watches=$(cat /etc/sysctl.conf | grep max_user_watches)
    if [ "$is_max_user_watches" == "" ]; then
        echo "fs.inotify.max_user_watches = 819200" >>/etc/sysctl.conf
        echo "819200" >/proc/sys/fs/inotify/max_user_watches
    fi
}
uninstall_rclone() {
    echo "Uninstalling rclone..."

    # 删除 rclone 可执行文件
    local rclone_path="/usr/bin/rclone"
    if [ -f "$rclone_path" ]; then
        rm -f "$rclone_path"
        echo "Removed rclone binary from $rclone_path."
    else
        echo "Rclone binary not found at $rclone_path."
    fi

    # 删除配置文件目录
    local config_dir="/etc/rclone.conf"
    if [ -d "$config_dir" ]; then
        rm -rf "$config_dir"
        echo "Removed rclone configuration directory at $config_dir."
    else
        echo "Rclone configuration directory not found at $config_dir."
    fi

    # 检查是否有运行的 rclone 进程并终止
    local rclone_pid=$(pgrep -f "rclone")
    if [ -n "$rclone_pid" ]; then
        echo "Killing rclone processes..."
        pkill -f "rclone"
        echo "Rclone processes terminated."
    else
        echo "No running rclone processes found."
    fi

    echo "Rclone uninstallation completed."
}

uninstall_main() {
    /etc/init.d/rsynd stop
    ps aux |grep "btsync" |grep -v grep| awk '{print $2}'| xargs kill -9
    ps -ef|grep "rsync"|grep -v grep |awk '{print $2}'|xargs kill -9
    if [ $centos == 1 ]; then
        chkconfig --del rsynd
    else
        update-rc.d -f rsynd remove
    fi
    rm -f /etc/init.d/rsynd

    if [ -f /etc/init.d/rsync_inotify ]; then
        /etc/init.d/rsync_inotify stopall
        chkconfig --del rsync_inotify
        rm -f /etc/init.d/rsync_inotify
    fi
    # 卸载 rclone
    uninstall_rclone
    rm -f /etc/rsyncd.conf
    rm -rf $pluginPath
}

remove_lsyncd() {
    if [ -f /etc/init.d/lsyncd ]; then
        /etc/init.d/lsyncd stop
        if [ $centos == 1 ]; then
            chkconfig --level 2345 lsyncd off
            chkconfig --del lrsynd
        else
            update-rc.d -f lrsynd remove
        fi
    else
        systemctl disable lsyncd
        systemctl stop lsyncd
    fi

    rm -f /etc/lsyncd.conf
}


if [ "${1}" == 'install' ]; then
    remove_lsyncd
    install_main "$@"
elif [ "${1}" == 'repair' ] || [ "${1}" == "upgrade" ]; then
    /etc/init.d/rsynd stop
    ps aux |grep "btsync" |grep -v grep| awk '{print $2}'| xargs kill -9
    ps -ef|grep "rsync"|grep -v grep |awk '{print $2}'|xargs kill -9

    install_main "$@"
elif [ "${1}" == 'uninstall' ]; then
    uninstall_main
fi
