#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# 独立定时任务执行脚本

import os
import json
import time
import hashlib
import re
import sys

panelPath = os.getenv('BT_PANEL')
if not panelPath: panelPath = '/www/server/panel'
os.chdir(panelPath)
sys.path.insert(0, panelPath + "/class/")
import public
from projectModel import totle_db

class WPCronScanner:
    def __init__(self):
        """初始化扫描器"""
        self.plugin_dir = '{}/plugin/wp_toolkit/'.format(panelPath)
        self.config_file = self.plugin_dir + 'config.json'
        self.whitelist_file = self.plugin_dir + 'whitelist.json'
        self.wordpress_vuln = self.plugin_dir + 'wordpress_vuln.db'
        self.scan_result = self.plugin_dir + 'data/log/'
        self.task_status_dir = self.plugin_dir + 'data/tasks/'
        
        # 确保目录存在
        if not os.path.exists(self.scan_result):
            os.makedirs(self.scan_result, exist_ok=True)
        if not os.path.exists(self.task_status_dir):
            os.makedirs(self.task_status_dir, exist_ok=True)
    
    def M(self, table):
        """获取数据库对象"""
        with totle_db.Sql().dbfile("../wordpress") as sql:
            return sql.table(table)
    
    def find_wp_sites(self):
        """自动识别WordPress站点"""
        results = []
        try:
            rows = public.M('sites').field('name,path').select()
        except:
            rows = []
        seen = set()
        for r in rows or []:
            name = r.get('name', '')
            path = r.get('path', '')
            if not path:
                continue
            try:
                wp_flag = os.path.exists(os.path.join(path, 'wp-includes', 'version.php'))
                wp_plugins = os.path.exists(os.path.join(path, 'wp-content', 'plugins'))
                if wp_flag and wp_plugins:
                    sid = hashlib.md5(path.encode()).hexdigest()
                    if path in seen:
                        continue
                    seen.add(path)
                    results.append({
                        "site_id": sid,
                        "name": name or os.path.basename(path),
                        "path": path,
                        "desc": ""
                    })
            except:
                continue
        return results
    
    def _verify_wordpress_site(self, site_path):
        """验证是否为有效的WordPress站点"""
        try:
            # 检查WordPress标志性文件
            wp_includes = os.path.join(site_path, 'wp-includes', 'version.php')
            wp_content = os.path.join(site_path, 'wp-content', 'plugins')
            
            if not (os.path.exists(wp_includes) and os.path.exists(wp_content)):
                return False

            # 验证wp-includes/version.php内容
            try:
                with open(wp_includes, 'r', encoding='utf-8') as f:
                    version_content = f.read()
                    # 检查是否包含WordPress版本变量
                    if '$wp_version' not in version_content:
                        return False
            except:
                return False
            
            return True
        except:
            return False
    
    def _get_plugin_data(self, plugin_file, default_headers, context=''):
        """获取插件信息"""
        # 读取文件内容
        if not os.path.exists(plugin_file): 
            return {}
        
        # 定义8KB大小
        max_length = 8 * 1024  # 8 KB
        try:
            # 读取文件的前8KB
            with open(plugin_file, 'r', encoding='utf-8') as file:
                file_data = file.read(max_length)
        except Exception as e:
            return {}
        
        # 替换CR为LF
        file_data = file_data.replace('\r', '\n')
        
        # 处理额外的headers
        extra_headers = {}
        if context:
            extra_context_headers = []
            extra_headers = dict.fromkeys(extra_context_headers, '')
        
        all_headers = {**extra_headers, **default_headers}

        # 检索所有headers
        for field, regex in all_headers.items():
            if field.startswith('_'):  # 跳过以_开头的内部字段
                continue
            match = re.search(f'{regex}:(.*)$', file_data, re.IGNORECASE | re.MULTILINE)
            if match:
                all_headers[field] = match.group(1).strip()
            else:
                all_headers[field] = ''
        
        if all_headers.get("Network") and not all_headers['Network'] and all_headers['_sitewide']:
            all_headers['Network'] = all_headers['_sitewide']
        
        if all_headers.get("Network"):
            all_headers['Network'] = 'true' == all_headers['Network'].lower()
        
        if all_headers.get("_sitewide"):
            del all_headers['_sitewide']

        if all_headers.get("TextDomain") and not all_headers['TextDomain']:
            plugin_slug = os.path.dirname(os.path.basename(plugin_file))
            if '.' != plugin_slug and '/' not in plugin_slug:
                all_headers['TextDomain'] = plugin_slug

        all_headers['Title'] = all_headers['Name']
        all_headers['AuthorName'] = all_headers['Author']

        # 返回插件的信息
        return all_headers
    
    def _get_plugins(self, path):
        """获取WordPress站点所有插件信息"""
        plugins = {}
        plugin_dir = os.path.join(path, 'wp-content', 'plugins')
        
        if not os.path.exists(plugin_dir):
            return plugins
        
        # 默认插件的头部信息
        plugin_default_headers = {
            "Name": "Plugin Name",
            "PluginURI": "Plugin URI",
            "Version": "Version",
            "Description": "Description",
            "Author": "Author",
            "AuthorURI": "Author URI",
            "TextDomain": "Text Domain",
            "DomainPath": "Domain Path",
            "Network": "Network",
            "RequiresWP": "Requires at least",
            "RequiresPHP": "Requires PHP",
            "UpdateURI": "Update URI",
            "RequiresPlugins": "Requires Plugins",
            "_sitewide": "Site Wide Only"
        }
        
        try:
            for item in os.listdir(plugin_dir):
                item_path = os.path.join(plugin_dir, item)
                if os.path.isdir(item_path):
                    # 查找插件主文件
                    main_file = None
                    for file in os.listdir(item_path):
                        if file.endswith('.php'):
                            file_path = os.path.join(item_path, file)
                            try:
                                with open(file_path, 'r', encoding='utf-8') as f:
                                    content = f.read(8192)  # 读取前8KB
                                    if 'Plugin Name:' in content:
                                        main_file = file_path
                                        break
                            except:
                                continue
                    
                    if main_file:
                        plugin_data = self._get_plugin_data(main_file, plugin_default_headers)
                        if plugin_data.get('Name'):
                            plugins[f"{item}/{os.path.basename(main_file)}"] = plugin_data
        except:
            pass
        
        return plugins
    
    def _compare_versions(self, version1, version2):
        """对比版本号"""
        try:
            # 分割版本号为整数列表
            v1 = [int(num) for num in version1.split('.')]
            v2 = [int(num) for num in version2.split('.')]
            
            # 逐个比较版本号的每个部分
            for num1, num2 in zip(v1, v2):
                if num1 > num2:
                    return 1  # version1 > version2
                elif num1 < num2:
                    return -1  # version1 < version2
            
            # 如果所有部分都相同，比较长度（处理像'1.0'和'1.0.0'这样的情况）
            if len(v1) > len(v2):
                return 1 if any(num > 0 for num in v1[len(v2):]) else 0
            elif len(v1) < len(v2):
                return -1 if any(num > 0 for num in v2[len(v1):]) else 0
            
            # 如果完全相同
            return 0
        except:
            return 0
    
    def _let_identify(self, version, vlun_infos):
        """对比版本号判断是否存在漏洞"""
        for i in vlun_infos:
            vlun_status = False
            if i["let"] == "<=":
                if self._compare_versions(version, i["vlun_version"]) <= 0:
                    vlun_status = True
            elif i["let"] == "<":
                if self._compare_versions(version, i["vlun_version"]) < 0:
                    vlun_status = True
            elif i["let"] == "-":
                v_list = i["vlun_version"].split("-")
                if self._compare_versions(version, v_list[0]) >= 0 and self._compare_versions(version, v_list[1]) <= 0:
                    vlun_status = True
            i["vlun_status"] = vlun_status
        return vlun_infos
    
    def _scan_site_vulnerabilities(self, site_id, site_path):
        """扫描WordPress站点漏洞"""
        vuln_list = []
        
        try:
            # 判断文件是否存在
            if not os.path.exists(site_path):
                return vuln_list
            
            result = {}
            result["plugins"] = self._get_plugins(site_path)
            
            # 扫描插件是否存在漏洞
            for i in result["plugins"]:
                plugin = i.split("/")[0]
                name = result["plugins"][i]["Name"]
                
                if result["plugins"][i]["Version"] == "":
                    continue
                
                # 检查插件是否存在漏洞
                try:
                    vlun_infos = self.M("vulnerabilities").where("plugin=?", (plugin,)).select()
                    if vlun_infos:
                        vlun_infos = self._let_identify(result["plugins"][i]["Version"], vlun_infos)
                        
                        for j2 in vlun_infos:
                            if j2["vlun_status"]:
                                vlun = {
                                    "site_id": site_id,
                                    "id": hashlib.md5(f"{site_id}_{plugin}_{j2['cve']}_{j2['time']}".encode()).hexdigest(),
                                    "type": "plugin",
                                    "name": name,
                                    "vlun_info": j2["msg"],
                                    "css": j2["css"],
                                    "cve": j2["cve"],
                                    "slug": plugin,
                                    "load_version": result["plugins"][i]["Version"],
                                    "time": int(time.time())
                                }
                                vuln_list.append(vlun)
                except Exception as e:
                    continue
            
        except Exception as e:
            pass
        
        return vuln_list
    
    def _apply_whitelist_filter(self, site_id, vulnerabilities):
        """应用白名单过滤"""
        try:
            # 读取白名单配置
            wl_str = public.readFile(self.whitelist_file)
            if wl_str:
                try:
                    wl = json.loads(wl_str)
                except:
                    wl = {"version": 1, "updated_at": int(time.time()), "rules": []}
            else:
                wl = {"version": 1, "updated_at": int(time.time()), "rules": []}
            
            rules = wl.get('rules') if isinstance(wl.get('rules'), list) else []
            
            # 如果没有白名单规则，直接返回所有漏洞
            if not rules:
                return vulnerabilities
            
            # 创建白名单规则集合，便于快速查找
            whitelist_set = set()
            for rule in rules:
                if not rule.get('enabled', True):
                    continue
                if str(rule.get('site_id')) == str(site_id):
                    whitelist_set.add((rule.get('slug'), rule.get('cve_id')))
            
            # 过滤漏洞
            filtered_vulns = []
            for vuln in vulnerabilities:
                slug = vuln.get('slug')
                cve_id = vuln.get('cve')
                if (slug, cve_id) not in whitelist_set:
                    filtered_vulns.append(vuln)
            
            return vulnerabilities
            
        except Exception as e:
            return vulnerabilities
    
    def create_scan_task(self, site_ids):
        """创建扫描任务"""
        try:
            # 生成任务ID
            task_id = hashlib.md5(f"scan_{time.time()}".encode()).hexdigest()
            
            # 创建任务状态文件
            task_status = {
                "task_id": task_id,
                "status": "pending",
                "start_time": int(time.time()),
                "end_time": None,
                "total_sites": len(site_ids),
                "scanned_sites": 0,
                "vulnerabilities_found": 0,
                "sites": site_ids,
                "message": "检测任务已创建，准备开始扫描"
            }
            
            # 保存任务状态文件
            task_file = os.path.join(self.task_status_dir, f"{task_id}.json")
            public.writeFile(task_file, json.dumps(task_status))
            
            return task_id
        except Exception as e:
            print(f"创建扫描任务失败: {str(e)}")
            return None
    
    def update_task_status(self, task_id, status, message=None, scanned_sites=None, vulnerabilities_found=None):
        """更新任务状态"""
        try:
            task_file = os.path.join(self.task_status_dir, f"{task_id}.json")
            if not os.path.exists(task_file):
                return False
                
            task_status = json.loads(public.readFile(task_file))
            task_status['status'] = status
            
            if message:
                task_status['message'] = message
            if scanned_sites is not None:
                task_status['scanned_sites'] = scanned_sites
            if vulnerabilities_found is not None:
                task_status['vulnerabilities_found'] = vulnerabilities_found
            if status in ['completed', 'failed']:
                task_status['end_time'] = int(time.time())
            
            public.writeFile(task_file, json.dumps(task_status))
            return True
        except Exception as e:
            print(f"更新任务状态失败: {str(e)}")
            return False
    
    def cleanup_old_tasks(self):
        """清理旧的任务文件，保留最新的10个"""
        try:
            if not os.path.exists(self.task_status_dir):
                return
                
            task_files = sorted(
                [f for f in os.listdir(self.task_status_dir) if f.endswith('.json')],
                key=lambda x: os.path.getmtime(os.path.join(self.task_status_dir, x)),
                reverse=True
            )
            if len(task_files) > 30:
                for f in task_files[10:]:
                    os.remove(os.path.join(self.task_status_dir, f))
        except Exception as e:
            print(f"清理旧任务文件失败: {str(e)}")
    
    def run_scan(self):
        """运行扫描任务"""
        task_id = None
        try:
            print("开始WordPress站点漏洞扫描任务")
            start_time = time.time()
            
            # 获取所有WordPress站点
            sites = self.find_wp_sites()
            if not sites:
                print("没有找到WordPress站点")
                return
            
            # 获取站点ID列表
            site_ids = [site['site_id'] for site in sites]
            
            # 清理旧任务文件
            self.cleanup_old_tasks()
            
            # 创建扫描任务
            task_id = self.create_scan_task(site_ids)
            if not task_id:
                print("创建扫描任务失败")
                return
            
            # 更新任务状态为运行中
            self.update_task_status(task_id, 'running', '正在扫描站点...')
            
            total_vulnerabilities = 0
            scanned_sites = 0
            
            # 扫描每个站点
            for site in sites:
                site_id = site['site_id']
                site_path = site['path']
                site_name = site['name']
                
                # 更新任务状态
                self.update_task_status(
                    task_id, 
                    'running', 
                    f"正在扫描站点: {site_name} ({scanned_sites + 1}/{len(sites)})", 
                    scanned_sites
                )
                
                # 验证WordPress站点
                if not self._verify_wordpress_site(site_path):
                    continue
                
                # 扫描漏洞
                vulnerabilities = self._scan_site_vulnerabilities(site_id, site_path)
                
                # 应用白名单过滤
                vulnerabilities = self._apply_whitelist_filter(site_id, vulnerabilities)
                
                # 写入扫描结果
                result_file = os.path.join(self.scan_result, f"{site_id}.jsonl")
                if vulnerabilities:
                    # 每次扫描都覆盖文件内容
                    with open(result_file, 'w', encoding='utf-8') as f:
                        for vuln in vulnerabilities:
                            # 转换数据格式，从数据库格式转换为文件存储格式
                            formatted_vuln = {
                                "id": vuln.get('id', ''),
                                "site_id": vuln.get('site_id'),
                                "type": vuln.get('type', 'plugin'),
                                "name": vuln.get('name', ''),
                                "info": vuln.get('vlun_info', ''),
                                "severity": vuln.get('css', 0),
                                "cvss": vuln.get('css', 0),
                                "cve_id": vuln.get('cve', ''),
                                "slug": vuln.get('slug', ''),
                                "load_version": vuln.get('load_version', ''),
                                "found_at": int(time.time()),
                                "status": "active"
                            }
                            f.write(json.dumps(formatted_vuln, ensure_ascii=False) + '\n')
                    
                    total_vulnerabilities += len(vulnerabilities)
                else:
                    # 直接覆盖文件内容为空
                    public.writeFile(result_file, "")
                
                scanned_sites += 1
            
            end_time = time.time()
            duration = end_time - start_time
            
            # 更新任务状态为完成
            self.update_task_status(
                task_id, 
                'completed', 
                f"扫描完成，共发现 {total_vulnerabilities} 个漏洞", 
                scanned_sites, 
                total_vulnerabilities
            )
            
            print(f"扫描任务完成，共扫描 {scanned_sites} 个站点，发现 {total_vulnerabilities} 个漏洞，耗时 {duration:.2f} 秒")
        
        except Exception as e:
            print(f"扫描任务失败: {str(e)}")
            # 更新任务状态为失败
            if task_id:
                self.update_task_status(task_id, 'failed', f"扫描失败: {str(e)}")


# 脚本入口点
if __name__ == "__main__":
    scanner = WPCronScanner()
    scanner.run_scan()