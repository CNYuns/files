#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH


pluginPath=/www/server/panel/plugin/wp_toolkit
Install_wp_toolkit()
{
	mkdir -p $pluginPath
    # logo
    \cp -a -r $pluginPath/ico-wp_toolkit.png /www/server/panel/BTPanel/static/img/soft_ico/ico-wp_toolkit.png
	echo '安装完成'
}

Uninstall_wp_toolkit()
{
	rm -rf $pluginPath
    # 删除logo
    rm -rf /www/server/panel/BTPanel/static/img/soft_ico/ico-wp_toolkit.png
}


action=$1
if [ "${1}" == 'install' ];then
	Install_wp_toolkit
else
	Uninstall_wp_toolkit
fi
