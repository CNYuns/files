import sys
panelPath = '/www/server/panel/class'
if panelPath not in sys.path:
    sys.path.append(panelPath)

import PluginLoader
data_type = sys.argv[1]
if data_type == 'auto_sync_data':
    args = sys.argv[2]
    PluginLoader.plugin_run('mysql_replicate', 'auto_sync_data', args)

elif data_type == 'manual_sync_data':
    args = sys.argv[2]
    PluginLoader.plugin_run('mysql_replicate', 'manual_sync_data', args)

