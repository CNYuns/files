#!/bin/bash

seconds=$1

echo "Stoping bt_syssafe..."

/etc/init.d/bt_syssafe stop

echo "Waiting for $seconds seconds before executing the bt_syssafe..."
sleep $seconds

echo "Starting bt_syssafe..."
/etc/init.d/bt_syssafe start

echo "Completed!"

