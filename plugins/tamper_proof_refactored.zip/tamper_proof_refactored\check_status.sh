#!/bin/bash
# chkconfig: 2345 55 25
# description: BT-Safe Agent
target_dir=/www/server/panel/plugin/tamper_proof_refactored
if [ -f $target_dir/check_status.pl ];then
  cd $target_dir
fi
server_start()
{
	isStart=$(systemctl status tamper_proof.service|grep "Active"|awk '{print $2}')
	if [ "$isStart" != 'active' ];then
	  if [ -f $target_dir/check_status.pl ];then
	        echo "检测到防篡改服务已断开，恢复防护中……"
		      systemctl restart tamper_proof.service
		      echo "防篡改服务已开启"
		fi
	fi
}
server_start