#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
PluginPath=/www/server/panel/plugin/tamper_proof_refactored
SetupPath=/www/server/tamper_proof_refactored

Install_tamper_proof()
{
	mkdir -p $PluginPath
	mkdir -p $PluginPath/tamper/data
	mkdir -p $PluginPath/tamper/data/sites
	mkdir -p $PluginPath/tamper/data/backup
	mkdir -p $PluginPath/Recycle_bin
#	 引入下网站配置信息，避免报错
	/www/server/panel/pyenv/bin/python3 /www/server/panel/plugin/tamper_proof_refactored/service.py install
	# create tamper_proof_refactored-amd64 directory
  if [ ! -d $SetupPath ];then
      mkdir -p $SetupPath
  fi

  Install_tamper_proof_bin
  systemd_path='/etc/systemd/system'
  if [ -d $systemd_path ];then
      src_file=$PluginPath/service/tamper_proof.service
      dst_file=$systemd_path/tamper_proof.service
      check_fs
      if [ -f $dst_file ];then
          systemctl stop tamper_proof.service
      fi
      \cp -f $src_file $dst_file
      systemctl daemon-reload
      systemctl enable tamper_proof.service

      if [ $? -ne 0 ]; then
          echo "服务启动失败，请检查！"
          systemctl start tamper_proof.service
#          exit 1
      else
          echo "服务开启成功"
      fi
      echo '服务开启成功'
  else
      src_file=$PluginPath/service/tamper_proof.init
      dst_file=/etc/init.d/tamper_proof_refactored
      if [ -f $dst_file ];then
          service tamper_proof_refactored stop
          chkconfig --del tamper_proof_refactored
      fi
      \cp -f $src_file $dst_file
      chmod +x $dst_file
      chkconfig --add tamper_proof_refactored
      chkconfig --level 2345 tamper_proof_refactored on
      check_fs
  fi
	echo > /www/server/panel/data/reload.pl
	echo 'Successify'
}
# 安装服务进程
Install_tamper_proof_bin()
{
    # check the cpu architecture
    is64bit="x86_64"
    is_aarch64=$(uname -a | grep aarch64)
    if [ "$is_aarch64" != "" ]; then
        is64bit="aarch64"
    fi

    # copy tamper_proof_refactored-amd64 bin file
    if [[ "${is64bit}" == "aarch64" ]]; then
        Download_ARM_bin
        \cp -arf $PluginPath/tamper/tamper_proof_refactored-arm64 $SetupPath/tamper_proof_refactored

    else
        \cp -arf $PluginPath/tamper/tamper_proof_refactored-amd64 $SetupPath/tamper_proof_refactored

    fi
    chmod 700 $SetupPath/tamper_proof_refactored
}

Download_ARM_bin()
{
  if [ -f "/www/server/panel/install/public.sh" ]; then
    source /www/server/panel/install/public.sh
  else
    NODE_URL='https://download.bt.cn'
  fi
#  /www/server/panel/plugin/tamper_proof_refactored/tamper_proof_refactored
  wget -O $PluginPath/tamper/tamper_proof_refactored-arm64 ${NODE_URL}/src/tamper_proof_refactored-arm64
}

check_fs()
{
	is_max_user_instances=`cat /etc/sysctl.conf|grep max_user_instances`
	if [ "$is_max_user_instances" == "" ];then
		echo "fs.inotify.max_user_instances = 1024" >> /etc/sysctl.conf
		echo "1024" > /proc/sys/fs/inotify/max_user_instances
	fi
	
	is_max_user_watches=`cat /etc/sysctl.conf|grep max_user_watches`
	if [ "$is_max_user_watches" == "" ];then
		echo "fs.inotify.max_user_watches = 81920000" >> /etc/sysctl.conf
		echo "81920000" > /proc/sys/fs/inotify/max_user_watches
	fi
}

Uninstall_tamper_proof()
{
    systemd_path='/etc/systemd/system/'
    if [ -d $systemd_path ];then
        systemctl stop tamper_proof.service
        systemctl disable tamper_proof.service
        rm -f $systemd_path/tamper_proof.service
        systemctl daemon-reload
    else
        service tamper_proof_refactored stop
        chkconfig --del tamper_proof_refactored
        rm -f /etc/init.d/tamper_proof_refactored
    fi
    rm -rf $PluginPath
}

action=$1
if [ "${1}" == 'install' ];then
	Install_tamper_proof
else
	Uninstall_tamper_proof
fi
