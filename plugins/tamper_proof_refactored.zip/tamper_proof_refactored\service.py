# -*- coding: UTF-8 -*-
"""
@FileName：service.py.py\n
@Description：\n
@Author：Bacon-Wu\n
@Time：2024/3/15 15:40\n
"""
import json
# coniing:utf-8
import os
import sys
import time
import re
# 添加项目根目录到环境变量
os.chdir("/www/server/panel")
sys.path.append("class/")
import public


class Service:
    __run_path = '{}/tamper_proof_refactored'.format(public.get_plugin_path())
    __config_path = '{}/config'.format(__run_path)
    __SITE_PATH = os.path.join(__run_path, "tamper/config/sites.json")
    __SITE_DIR = os.path.join(__run_path, "tamper/data/sites")  # 站点配置日志数据存储位置
    #  配置文件信息
    __CONFIG_PATH = os.path.join(__run_path, "tamper/config/config.json")
    def check_site_config(self, args=None):
        '''
            @name 检查关键配置文件，并添加
            @return void
        '''
        if not os.path.exists(self.__SITE_DIR):
            os.makedirs(self.__SITE_DIR)
        if not os.path.exists(self.__CONFIG_PATH):
            config = {
                "open": True,
                "excludePath": ["cache", "threadcache", "log", "logs", "config", "runtime", "temp", "tmp", "caches",
                                "tmps", "data/temp"],
                "protectExt": ["php", "html", "htm", "js", "css"],
                'totalLog': 10 * 1024 * 1024,
                'runLog': 100 * 1024,
                'siteLog': 100 * 1024,
                'zipSize': 10 * 1024 * 1024
            }
            public.writeFile(self.__CONFIG_PATH, json.dumps(config))
        if not os.path.exists(self.__SITE_PATH):
            public.writeFile(self.__SITE_PATH, "[]")
            try:
                site_list = json.loads(public.readFile(self.__SITE_PATH))
            except:
                site_list = []
            config = json.loads(public.readFile(self.__CONFIG_PATH))
            # with open(self.__CONFIG_PATH, 'r') as file:
            #     content = file.read()
            # config = json.loads(content)
            new_site_list = public.M("sites").field("name,path").where("project_type=?", ("PHP")).select()

            site_name_set = set()
            is_restart = False

            # 添加 | 更新 网站
            for new_info in new_site_list:
                real_path = os.path.realpath(new_info["path"])
                if real_path != "":
                    new_info["path"] = real_path

                site_name_set.add(new_info["name"])

                for info in site_list:
                    if new_info["name"] == info["siteName"]:
                        if info["path"] != new_info["path"]:
                            info["path"] = new_info["path"]
                            is_restart = True
                        break
                else:

                    combinedExcludePath = [os.path.join(new_info["path"], excludePath) for excludePath in
                                           config["excludePath"]]
                    data = {
                        "siteName": new_info["name"],
                        "path": new_info["path"],
                        "open": 0,  # 默认为0 视为关闭，1为开启
                        "excludePath": combinedExcludePath,
                        "protectExt": config["protectExt"],
                        "closeTime": int(time.time()) - 120,  # 获取当前时间120s，避免初始化报错
                    }

                    site_list.append(data)
                    is_restart = True

            # 删除网站
            num = len(site_list)
            idx = 0
            while idx < num:
                info = site_list[idx]
                if info["siteName"] not in site_name_set:
                    path = os.path.join(self.__SITE_DIR, info["siteName"])
                    public.ExecShell("rm -rf {}".format(path))
                    del site_list[idx]
                    num -= 1
                    is_restart = True
                else:
                    idx += 1

            if is_restart is True:
                public.writeFile(self.__SITE_PATH, json.dumps(site_list))
            # public.writeFile(self.__SITE_PATH, "[]")

    def clear_site_config(self, args=None):
        '''
            @name 清理配置文件
            @return void
        '''


if __name__ == "__main__":
    if len(sys.argv) < 2: exit('参数错误')
    action = sys.argv[1]
    service = Service()

    if action == 'install':
        service.check_site_config()
    elif action == 'uninstall':
        service.clear_site_config()


