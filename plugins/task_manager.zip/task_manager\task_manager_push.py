# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Windows面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2020 宝塔软件(https://www.bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: baozi <1191604998@qq.com>
# | version: 1.0.0
# +-------------------------------------------------------------------
import json
import os
import sys
import time
from datetime import datetime, date
import psutil
from typing import Optional

class_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# /www/server/panel/class
bt_panel_path = os.path.dirname(class_path)
if class_path not in sys.path:
    sys.path.insert(0, class_path)
if bt_panel_path not in sys.path:
    sys.path.insert(0, bt_panel_path)

import public
import panelPush

try:
    from push.base_push import base_push
    from push.base_push import WxAccountMsg
    from panel_msg import Message, collect_message
except:
    WxAccountMsg = None
    base_push = object
    Message = object

    def collect_message(*args, **kwargs):
        return ()


class task_manager_push(base_push):
    __push_conf = "{}/class/push/push.json".format(public.get_panel_path())

    def __init__(self):
        self.__push = panelPush.panelPush()
        self._process_info = None
        self._push_tip : Optional[TaskManagerPushTip]  = None

    def get_version_info(self, get=None):
        data = {
            'ps': '宝塔系统告警',
            'version': '1.0',
            'date': '2023-12-5',
            'author': '宝塔',
            'help': 'https://www.bt.cn/bbs'
        }
        return data

    # 格式化返回执行周期， 目前无作用
    def get_push_cycle(self, data: dict):
        return data

    # 获取模块推送参数
    def get_module_config(self, get: public.dict_obj):
        data = []
        item = self.__push.format_push_data(
            push=["mail", 'dingding', 'weixin', "feishu", "wx_account"],
            project='system', type='')
        item['cycle'] = 30
        item['title'] = '防篡改'
        data.append(item)
        return data

    # 获取模块配置项
    def get_push_config(self, get: public.dict_obj):
        task_id = get.id
        push_list = self.__push._get_conf()

        if task_id not in push_list["task_manager_push"]:
            res_data = public.returnMsg(False, '未找到指定配置.')
            res_data['code'] = 100
            return res_data
        result = push_list["task_manager_push"][task_id]
        return result

    @staticmethod
    def clear_push_count(task_id):
        """清除推送次数"""
        TaskManagerPushTip().clear_tip_data(task_id)

    # 写入推送配置文件
    def set_push_config(self, get: public.dict_obj):
        pdata = json.loads(get.data)
        task_id = get.id
        conf_data = self.__push._get_conf()
        if "task_manager_push" not in conf_data:
            conf_data["task_manager_push"] = dict()

        # 检查输入参数是否合理:
        if "count" not in pdata:
            return public.returnMsg(False, "未设置检查的阈值参数")
        else:
            if pdata["type"] == "task_manager_cpu":
                if not 0 < pdata["count"] <= 100:
                    return public.returnMsg(False, "设置的检查范围不正确")
            else:
                if not pdata["count"] > 0:
                    return public.returnMsg(False, "设置的检查范围不正确")

        # 处理检查特殊情况 -> 可以直接查出平均值:
        if int(pdata["interval"]) <= 60:
            pdata["interval"] = 60
        else:
            pdata["interval"] = int(pdata["interval"])

        for conf_id, task in conf_data["task_manager_push"].items():
            # 对于已存在的任务，做修改
            if task["type"] == pdata["type"] and task["project"] == pdata["project"]:
                task["interval"] = pdata["interval"]
                task["module"] = pdata["module"]
                task["push_count"] = pdata["push_count"]
                task["count"] = pdata["count"]
                task["status"] = True  # 设置后自动开启

                self.clear_push_count(conf_id)
                break
        else:
            # 不存在的做添加
            # 磁盘告警需要通过挂载目录指定
            if pdata["type"] == "task_manager_cpu":
                title = "进程【{}】的CPU占用量告警".format(pdata["project"])
            elif pdata["type"] == "task_manager_mem":
                title = "进程【{}】的内存占用量告警".format(pdata["project"])
            else:
                title = "进程【{}】的子进程数告警".format(pdata["project"])

            pdata["status"] = True
            pdata["title"] = title

            conf_data["task_manager_push"][str(task_id)] = pdata

        public.set_module_logs("task_manager_push", "set_push_config", 1)

        return conf_data

    # 删除推送配置
    def del_push_config(self, get: public.dict_obj):
        # 从配置中删除信息，并做一些您想做的事，如记日志
        task_id = get.id
        data = self.__push._get_conf()
        if str(task_id).strip() in data["task_manager_push"]:
            del data["task_manager_push"][task_id]
        public.writeFile(self.__push_conf, json.dumps(data))
        return public.returnMsg(True, '删除成功.')

    def get_total(self):
        return True

    # 检查并获取推送消息，返回空时，不做推送, 传入的data是配置项
    def get_push_data(self, data, total):
        # data 内容
        # index :  时间戳 time.time()
        # 消息 以类型为key， 以内容为value， 内容中包含title 和msg
        # push_keys： 列表，发送了信息的推送任务的id，用来验证推送任务次数（） 意义不大
        # todo:

        if self._push_tip is None:
            self._push_tip = TaskManagerPushTip()

        if len(self._push_tip.today_list(data["id"])) >= data["push_count"]:
            return None

        if data["type"] == "task_manager_cpu":
            return self._get_cpu_push_data(data)

        elif data["type"] == "task_manager_mem":
            return self._get_mem_push_data(data)
        else:
            return self._get_process_num_push_data(data)

    def _get_cpu_push_data(self, task_data):
        stime = time.time()
        result = {'index': stime}
        process_info = self._get_process_info()

        used = 0
        count = 0
        for p in process_info:
            if p["name"] == task_data['project']:
                used += p["cpu_percent"]
                count += 1 if "children" not in p else len(p["children"]) + 1

        if used <= task_data['count']:
            return None

        s_list = [
            ">通知类型：任务管理器CPU占用量告警",
            ">告警内容: 进程名称为【{}】的进程共有{}个，消耗的CPU资源占比为{}%，大于告警阈值{}%。".format(
                task_data['project'], count, used, task_data['count']
            )
        ]

        wx_msg = ToWechatAccountMsg().task_manager_cpu(task_data["project"], int(task_data["count"]))

        msg = PushMsgCollect.cpu(s_list, task_data["title"])

        sdata = public.get_push_info('任务管理器CPU占用量告警', s_list)
        sdata["push_type"] = "任务管理器CPU占用量告警"
        for m_module in task_data['module'].split(','):
            if m_module == 'sms':
                continue

            if m_module == 'wx_account' and wx_msg is not None:
                result[m_module] = wx_msg
                continue

            result[m_module] = sdata

        self._push_tip.add_tip_data(task_data["id"])
        self._push_tip.save()

        return result

    def _get_mem_push_data(self, task_data):
        stime = time.time()
        result = {'index': stime}
        process_info = self._get_process_info()

        used = 0
        count = 0
        for p in process_info:
            if p["name"] == task_data['project']:
                used += p["memory_used"]
                count += 1 if "children" not in p else len(p["children"]) + 1

        if used <= task_data['count'] * 1024 * 1024:
            return None

        s_list = [
            ">通知类型：任务管理器内存占用量告警",
            ">告警内容: 进程名称为【{}】的进程共有{}个，消耗的内存资源为{}MB，大于告警阈值{}MB。".format(
                task_data['project'], count, int(used / 1024 / 1024), task_data['count']
            )
        ]
        wx_msg = ToWechatAccountMsg().task_manager_mem(task_data["project"])

        msg = PushMsgCollect.mem(s_list, task_data["title"])

        sdata = public.get_push_info('任务管理器内存占用量告警', s_list)
        sdata["push_type"] = "任务管理器内存占用量告警"
        for m_module in task_data['module'].split(','):
            if m_module == 'sms':
                continue

            if m_module == 'wx_account' and wx_msg is not None:
                result[m_module] = wx_msg
                continue

            result[m_module] = sdata

        self._push_tip.add_tip_data(task_data["id"])
        self._push_tip.save()

        return result

    def _get_process_num_push_data(self, task_data):
        stime = time.time()
        result = {'index': stime}
        process_info = self._get_process_info()
        count = 0

        for p in process_info:
            if p["name"] == task_data['project']:

                count += 1 if "children" not in p else len(p["children"]) + 1

        if count <= task_data['count']:
            return None

        s_list = [
            ">通知类型：任务管理器进程开销告警",
            ">告警内容: 进程名称为【{}】的进程共有{}个，大于告警阈值{}个。".format(
                task_data['project'], count, task_data['count']
            )
        ]

        wx_msg = ToWechatAccountMsg().task_manager_process(task_data["project"], task_data['count'])

        msg = PushMsgCollect.process(s_list, task_data["title"])

        sdata = public.get_push_info('任务管理器进程开销告警', s_list)
        sdata["push_type"] = "任务管理器进程开销告警"
        for m_module in task_data['module'].split(','):
            if m_module == 'sms':
                continue

            if m_module == 'wx_account' and wx_msg is not None:
                result[m_module] = wx_msg
                continue

            result[m_module] = sdata

        self._push_tip.add_tip_data(task_data["id"])
        self._push_tip.save()

        return result

    # 返回到前端信息的钩子, 默认为返回传入信息（即：当前设置的任务的信息）
    @staticmethod
    def get_view_msg(task_id, task_data):
        task_data["tid"] = view_msg.get_tid(task_data)
        task_data["view_msg"] = view_msg.get_msg_by_type(task_data)
        return task_data

    @staticmethod
    def check_self_plugin():
        if os.path.exists("{}/plugin/task_manager/task_manager_main.py".format(public.get_panel_path())):
            return True
        return False

    @staticmethod
    def _get_bak_task_template():
        return [
            {
                "field": [
                    {
                        "attr": "project",
                        "name": "进程名称",
                        "type": "select",
                        "items": [
                        ]
                    },
                    {
                        "attr": "count",
                        "name": "占用率超过",
                        "type": "number",
                        "unit": "%",
                        "suffix": "后触发告警",
                        "default": 80,
                        "err_msg_prefix": "CUP占用率"
                    },
                    {
                        "attr": "interval",
                        "name": "间隔时间",
                        "type": "number",
                        "unit": "秒",
                        "suffix": "后再次监控检测条件",
                        "default": 600
                    },
                    {
                        "attr": "push_count",
                        "name": "每天发送",
                        "type": "number",
                        "unit": "次",
                        "suffix": (
                            "后，当日不再发送，次日恢复&nbsp;&nbsp;&nbsp;&nbsp;"
                            "<i style='color: #999;font-style: initial;font-size: 12px;margin-right: 5px'>*</i>"
                            "<span style='color:#999'>设置为0时，每天触发告警次数没有上限</span>"
                        ),
                        "default": 3
                    }
                ],
                "sorted": [
                    [
                        "project"
                    ],
                    [
                        "count"
                    ],
                    [
                        "interval"
                    ],
                    [
                        "push_count"
                    ]
                ],
                "module": [
                    "wx_account",
                    "dingding",
                    "feishu",
                    "mail",
                    "weixin"
                ],
                "tid": "task_manager_push@0",
                "type": "task_manager_cpu",
                "title": "任务管理器CPU占用量告警",
                "name": "task_manager_push"
            },
            {
                "field": [
                    {
                        "attr": "project",
                        "name": "进程名称",
                        "type": "select",
                        "items": [
                        ]
                    },
                    {
                        "attr": "count",
                        "name": "占用量超过",
                        "type": "number",
                        "unit": "MB",
                        "suffix": "后触发告警",
                        "default": None,
                        "err_msg_prefix": "占用量"
                    },
                    {
                        "attr": "interval",
                        "name": "间隔时间",
                        "type": "number",
                        "unit": "秒",
                        "suffix": "后再次监控检测条件",
                        "default": 600
                    },
                    {
                        "attr": "push_count",
                        "name": "每天发送",
                        "type": "number",
                        "unit": "次",
                        "suffix": (
                            "后，当日不再发送，次日恢复&nbsp;&nbsp;&nbsp;&nbsp;"
                            "<i style='color: #999;font-style: initial;font-size: 12px;margin-right: 5px'>*</i>"
                            "<span style='color:#999'>设置为0时，每天触发告警次数没有上限</span>"
                        ),
                        "default": 3
                    }
                ],
                "sorted": [
                    [
                        "project"
                    ],
                    [
                        "count"
                    ],
                    [
                        "interval"
                    ],
                    [
                        "push_count"
                    ]
                ],
                "module": [
                    "wx_account",
                    "dingding",
                    "feishu",
                    "mail",
                    "weixin"
                ],
                "tid": "task_manager_push@1",
                "type": "task_manager_mem",
                "title": "任务管理器内存占用量告警",
                "name": "task_manager_push"
            },
            {
                "field": [
                    {
                        "attr": "project",
                        "name": "进程名称",
                        "type": "select",
                        "items": [
                        ]
                    },
                    {
                        "attr": "count",
                        "name": "进程数超过",
                        "type": "number",
                        "unit": "个",
                        "suffix": "后触发告警",
                        "default": 20,
                        "err_msg_prefix": "进程数"
                    },
                    {
                        "attr": "interval",
                        "name": "间隔时间",
                        "type": "number",
                        "unit": "秒",
                        "suffix": "后再次监控检测条件",
                        "default": 600
                    },
                    {
                        "attr": "push_count",
                        "name": "每天发送",
                        "type": "number",
                        "unit": "次",
                        "suffix": (
                            "后，当日不再发送，次日恢复&nbsp;&nbsp;&nbsp;&nbsp;"
                            "<i style='color: #999;font-style: initial;font-size: 12px;margin-right: 5px'>*</i>"
                            "<span style='color:#999'>设置为0时，每天触发告警次数没有上限</span>"
                        ),
                        "default": 3
                    }
                ],
                "sorted": [
                    [
                        "project"
                    ],
                    [
                        "count"
                    ],
                    [
                        "interval"
                    ],
                    [
                        "push_count"
                    ]
                ],
                "module": [
                    "wx_account",
                    "dingding",
                    "feishu",
                    "mail",
                    "weixin"
                ],
                "tid": "task_manager_push@2",
                "type": "task_manager_process",
                "title": "任务管理器进程开销告警",
                "name": "task_manager_push"
            }
        ]

    def _get_process_info(self) -> list:
        """从插件获取信息"""
        if self._process_info is not None:
            return self._process_info

        try:
            import PluginLoader
            get_obj = public.dict_obj()
            get_obj.sortx = "status"
            process_info = PluginLoader.plugin_run("task_manager", "get_process_list", get_obj)
        except:
            return []

        if isinstance(process_info, dict) and "process_list" in process_info and isinstance(
                process_info["process_list"], list):
            self._process_info = process_info["process_list"]
            return self._process_info
        else:
            return []

    def get_task_template(self):
        res_data = self._get_bak_task_template()

        # process_map = {p.get("name"): {
        #     "title": p.get("ps"),
        #     "value": p.get("name"),
        # } for p in self._get_process_info() if "name" in p and "ps" in p}
        #
        # if "nginx" in process_map:
        #     process_map["nginx"] = {
        #         "title": "Nginx服务",
        #         "value": "nginx"
        #     }
        #
        # if len(process_map) == 0:
        #     return None, None
        #
        # process_list = [i for i in process_map.values()]
        total = int(psutil.virtual_memory().total / (1024 * 1024))

        for i in range(0, len(res_data)):
            res_data[i]["field"][0]["items"] = {
                "url": "plugin?action=a&name=task_manager&s=get_process_list_to_push"
            }
        res_data[1]["field"][1]["default"] = int(total * 0.7)
        return "任务管理器告警", res_data


class ViewMsgFormat(object):
    _FORMAT = {
        "task_manager_cpu": (
            lambda x: "<span>进程：{}的CUP占用超过{}%触发</span>".format(
                x.get("project"), x.get("count")
            )
        ),
        "task_manager_mem": (
            lambda x: "<span>进程：{}的内存使用率超过{}MB后触发</span>".format(
                x.get("project"), x.get("count")
            )
        ),
        "task_manager_process": (
            lambda x: "<span>进程：{}的子进程数量超过{}后触发</span>".format(
                x.get("project"), x.get("count")
            )
        ),
    }

    _TID = {
        "task_manager_cpu": "task_manager_push@0",
        "task_manager_mem": "task_manager_push@1",
        "task_manager_process": "task_manager_push@2",
    }

    def get_msg_by_type(self, data):
        return self._FORMAT[data["type"]](data)

    def get_tid(self, data):
        return self._TID[data["type"]]


view_msg = ViewMsgFormat()


class TaskManagerPushTip(object):
    _FILE = '{}/data/push/tips/task_manager_push.tip'.format(public.get_panel_path())

    def __init__(self):
        self._tip_data = None
        self._read_tip()

    def _read_tip(self):
        t_day = datetime.now().strftime('%Y-%m-%d')
        if os.path.exists(self._FILE):
            try:
                tip = json.loads(public.readFile(self._FILE))
            except json.JSONDecodeError:
                tip = {"t_day": t_day}
            else:
                if tip["t_day"] != t_day:
                    tip = {"t_day": t_day}
        else:
            tip = {"t_day": t_day}

        today = date.today()
        try:
            for k, v in tip.items():
                if k == "t_day":
                    continue
                if not isinstance(v, list):
                    continue
                for t_idx in range(len(v) - 1, -1, -1):
                    tip_time = datetime.fromtimestamp(float(v[t_idx]))
                    if tip_time.date() < today:
                        del v[t_idx]
        except:
            tip = {"t_day": t_day}

        self._tip_data = tip

    def today_list(self, task_id) -> list:
        if str(task_id) in self._tip_data:
            return self._tip_data[str(task_id)]
        return []

    def add_tip_data(self, task_id):
        if str(task_id) in self._tip_data:
            self._tip_data[str(task_id)].append(int(datetime.now().timestamp()))
        else:
            self._tip_data[str(task_id)] = [int(datetime.now().timestamp())]

    def clear_tip_data(self, task_id):
        if str(task_id) in self._tip_data:
            self._tip_data[str(task_id)] = []

    def save(self):
        if self._tip_data is not None:
            public.writeFile(self._FILE, json.dumps(self._tip_data))


class ToWechatAccountMsg:
    @staticmethod
    def task_manager_cpu(project: str, count: int):
        if WxAccountMsg is None:
            return None
        msg = WxAccountMsg.new_msg()
        msg.thing_type = "任务管理器CPU占用量告警"
        if len(project) > 11:
            project = project[:9] + ".."

        msg.msg = "{}的CUP超过{}%".format(project, count)
        return msg

    @staticmethod
    def task_manager_mem(project: str):
        if WxAccountMsg is None:
            return None
        msg = WxAccountMsg.new_msg()
        if len(project) > 11:
            project = project[:9] + ".."
        msg.thing_type = "任务管理器内存占用量告警"
        msg.msg = "{}的内存超过告警数值".format(project)
        return msg

    @staticmethod
    def task_manager_process(project: str, count: int):
        if WxAccountMsg is None:
            return None
        msg = WxAccountMsg.new_msg()
        msg.thing_type = "任务管理器进程开销告警"
        if len(project) > 11:
            project = project[:9] + ".."

        if count > 100:  # 节省字数
            count = "限制"

        msg.msg = "{}的子进程数超过{}".format(project, count)
        return msg


class PushMsgCollect:
    _self_type = "push_msg"

    @classmethod
    def cpu(cls, s_list, title: str) -> Message:
        if Message is object:
            return None
        data = "\n".join(s_list)
        msg = collect_message(
            title=title,
            msg_types=["插件", "宝塔任务管理器"],
            source=["软件商店", "宝塔任务管理器", title],
            sub_msg={
                "push_type": "任务管理器CPU占用量告警",
                "push_title": title,
                "data": data,
                "self_type": cls._self_type
            },
            level="warning",
        )
        if isinstance(msg, Message):
            return msg

        return msg

    @classmethod
    def mem(cls, s_list, title: str) -> Message:
        if Message is object:
            return None
        data = "\n".join(s_list)
        msg = collect_message(
            title=title,
            msg_types=["插件", "宝塔任务管理器"],
            source=["软件商店", "宝塔任务管理器", title],
            sub_msg={
                "push_type": "任务管理器内存占用量告警",
                "push_title": title,
                "data": data,
                "self_type": cls._self_type
            },
            level="warning",
        )
        if isinstance(msg, Message):
            return msg

        return msg

    @classmethod
    def process(cls, s_list, title: str) -> Message:
        if Message is object:
            return None
        data = "\n".join(s_list)
        msg = collect_message(
            title=title,
            msg_types=["插件", "宝塔任务管理器"],
            source=["软件商店", "宝塔任务管理器", title],
            sub_msg={
                "push_type": "任务管理器进程开销告警",
                "push_title": title,
                "data": data,
                "self_type": cls._self_type
            },
            level="warning",
        )
        if isinstance(msg, Message):
            return msg

        return msg
